@echo off
setlocal
cd /d "%~dp0"
echo GPNB_v1 - install / repair isolated PyTorch environment
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\setup.ps1" %*
set "GPNB_EXIT=%ERRORLEVEL%"
if "%~1"=="" pause
exit /b %GPNB_EXIT%
