@echo off
setlocal
cd /d "%~dp0"
echo GPNB_v1 - local genomic prediction workbench
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\start.ps1" %*
set "GPNB_EXIT=%ERRORLEVEL%"
if "%~1"=="" pause
exit /b %GPNB_EXIT%
