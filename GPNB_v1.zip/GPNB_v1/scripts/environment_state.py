"""Offline readiness marker. Check complete installed package versions + inputs."""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import importlib.util
import json
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path

_root = Path(__file__).resolve().parents[1]
_policy_spec = importlib.util.spec_from_file_location("gpnb_install_policy", _root / "src/gpnb/environment_profiles.py")
_policy = importlib.util.module_from_spec(_policy_spec)
_policy_spec.loader.exec_module(_policy)
get_profile, profile_ids = _policy.get_profile, _policy.profile_ids


def inputs(root, profile):
    selected = get_profile(profile, root)
    names = [f"requirements/{selected['lock']}", "requirements/profiles.json", ".python-version", "pyproject.toml", "scripts/bootstrap.ps1",
             "scripts/setup.ps1", "scripts/native.ps1", "scripts/environment_state.py",
             "scripts/installer_common.ps1", "scripts/start.ps1"]
    return {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in names}


def packages():
    return {d.metadata["Name"].lower().replace("_", "-"): d.version
            for d in importlib.metadata.distributions() if d.metadata["Name"]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=["check", "write"])
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--profile", choices=profile_ids(_root), required=True)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    marker = Path(sys.prefix) / "gpnb-ready.json"
    expected_python = (args.root / ".python-version").read_text().strip()
    if platform.python_version() != expected_python or sys.prefix == sys.base_prefix:
        print("Python version or isolation mismatch.")
        return 1
    spec = importlib.util.find_spec("gpnb")
    if not spec or Path(spec.origin).resolve() != (args.root / "src/gpnb/__init__.py").resolve():
        print("GPNB_v1 editable install belongs to another directory. Run setup in this copy.")
        return 1
    current = {"inputs": inputs(args.root, args.profile), "packages": packages(),
               "environment_profile": get_profile(args.profile, args.root),
               "profile": args.profile, "dev": False, "python": platform.python_version(),
               "root": str(args.root.resolve())}
    if args.mode == "check":
        try:
            saved = json.loads(marker.read_text(encoding="utf-8"))
            if any(saved.get(k) != v for k, v in current.items()):
                raise ValueError("Lock/config/package versions changed")
        except (OSError, ValueError) as error:
            print(f"Environment requires setup/repair: {error}")
            return 1
        print("Environment marker, locks and package versions match (offline).")
        return 0
    if not args.report:
        parser.error("write requires --report")
    report = json.loads(args.report.read_text(encoding="utf-8"))
    if not report.get("ok") or report.get("mode") != "full" or report.get("profile") != args.profile:
        raise ValueError("A matching full doctor pass is required")
    if Path(report["python_executable"]).resolve() != Path(sys.executable).resolve():
        raise ValueError("Doctor report belongs to a different interpreter")
    current.update(created_utc=datetime.now(timezone.utc).isoformat(), report=str(args.report),
                   qt_mode=report["qt_mode"])
    temp = marker.with_suffix(".partial")
    temp.write_text(json.dumps(current, indent=2) + "\n", encoding="utf-8")
    temp.replace(marker)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
