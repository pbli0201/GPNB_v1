﻿[CmdletBinding()]
param(
    [string]$Profile = '',
    [ValidateSet('window','offscreen','skip')] [string]$QtMode = 'window',
    [switch]$Doctor,
    [string]$Project = '',
    [ValidateSet('zh_CN','en_US')] [string]$Language = 'zh_CN',
    [int]$SmokeMilliseconds = 0
)
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
. (Join-Path $PSScriptRoot 'installer_common.ps1')
. (Join-Path $PSScriptRoot 'native.ps1')
$Guard = $null
$Transcript = $false
$ExitCode = 1
try {
    Initialize-LocalProcess $Root
    $Policy = Get-EnvironmentPolicy $Root
    $Log = Join-Path $Root ("logs\launch-" + (Get-Date -Format 'yyyyMMdd-HHmmss-fff') + '.log')
    Start-Transcript -Path $Log | Out-Null
    $Transcript = $true
    try {
        # Multiple launches may share a read/write handle; setup requires exclusivity.
        $Guard = [IO.File]::Open((Join-Path $Root 'runtime\setup.guard'), 'OpenOrCreate', 'ReadWrite', 'ReadWrite')
    } catch { throw 'Setup is running. Wait for it to finish. / 环境正在配置，请稍后启动。' }
    $ActivePath = Join-Path $Root 'runtime\active-profile.json'
    if (-not $Profile) {
        if (-not (Test-Path -LiteralPath $ActivePath)) { throw 'Run Setup_GPNB_v1.cmd first.' }
        $Profile = (Get-Content -Raw -LiteralPath $ActivePath | ConvertFrom-Json).profile
    }
    $ProfileInfo = Get-EnvironmentProfile $Policy $Profile
    $EnvPython = Join-Path $Root "runtime\envs\$Profile\Scripts\python.exe"
    $Marker = Join-Path $Root "runtime\envs\$Profile\gpnb-ready.json"
    if (-not (Test-Path -LiteralPath $EnvPython) -or -not (Test-Path -LiteralPath $Marker)) {
        throw "Environment is incomplete. Run Setup_GPNB_v1.cmd -Profile $Profile."
    }
    $State = Get-Content -Raw -LiteralPath $Marker | ConvertFrom-Json
    $ArgsForState = @('--root',$Root,'--profile',$Profile)
    Invoke-LoggedNative $EnvPython (@((Join-Path $PSScriptRoot 'environment_state.py'), 'check') + $ArgsForState)
    if ($LASTEXITCODE -ne 0) { throw "Environment changed. Run Setup_GPNB_v1.cmd -Profile $Profile to repair." }
    $Report = Join-Path $Root ("logs\start-$Profile-" + (Get-Date -Format 'yyyyMMdd-HHmmss-fff') + '.json')
    if ($Doctor -or $QtMode -ne 'window') {
        Invoke-LoggedNative $EnvPython @('-m', 'gpnb', 'doctor', '--profile', $Profile, '--qt', $QtMode, '--json', $Report)
    } else {
        $GuiArguments = @('-m','gpnb.gui.app','--lang',$Language)
        if ($Project) { $GuiArguments += @('--project',$Project) }
        if ($SmokeMilliseconds -gt 0) {
            $GuiArguments += @('--smoke-ms',"$SmokeMilliseconds",'--report',$Report)
        }
        Invoke-LoggedNative $EnvPython $GuiArguments
    }
    $ExitCode = $LASTEXITCODE
    if ($ExitCode -ne 0) { throw "Application/diagnostic failed ($ExitCode). Run Setup_GPNB_v1.cmd -Profile $Profile -Repair. Log: $Log" }
} catch {
    Write-Host ("START FAILED / 启动失败: " + $_.Exception.Message) -ForegroundColor Red
    if ($Log) { Write-Host "Log / 日志: $Log" }
    $ExitCode = 1
} finally {
    if ($Guard) { $Guard.Dispose() }
    if ($Transcript) { Stop-Transcript | Out-Null }
}
exit $ExitCode
