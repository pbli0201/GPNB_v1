﻿# Windows PowerShell transcripts do not reliably capture unpiped native output.
function Invoke-LoggedNative {
    param([string]$Executable, [string[]]$Arguments)
    if (-not (Get-Command $Executable -ErrorAction SilentlyContinue)) { throw "Executable not found: $Executable" }
    $PreviousPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        $global:LASTEXITCODE = 1
        & $Executable @Arguments 2>&1 | ForEach-Object { Write-Host $_.ToString() }
        $NativeExit = $LASTEXITCODE
    } finally { $ErrorActionPreference = $PreviousPreference }
    $global:LASTEXITCODE = $NativeExit
}
