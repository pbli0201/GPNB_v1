﻿[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'native.ps1')
. (Join-Path $PSScriptRoot 'installer_common.ps1')
function Get-Sha256([string]$Path) {
    $Stream = [IO.File]::OpenRead($Path)
    $Hasher = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($Hasher.ComputeHash($Stream))).Replace('-', '').ToLowerInvariant() }
    finally { $Stream.Dispose(); $Hasher.Dispose() }
}
$Root = Split-Path -Parent $PSScriptRoot
$Runtime = Join-Path $Root 'runtime'
$Cache = Join-Path $Root 'cache'
foreach ($relative in @('runtime\tools', 'runtime\python', 'cache\bootstrap', 'cache\uv', 'tmp', 'logs')) {
    New-Item -ItemType Directory -Force -Path (Join-Path $Root $relative) | Out-Null
}
$env:UV_CACHE_DIR = Join-Path $Cache 'uv'
$env:UV_PYTHON_INSTALL_DIR = Join-Path $Runtime 'python'
$env:UV_PYTHON_BIN_DIR = Join-Path $Runtime 'bin'
$env:UV_PYTHON_PREFERENCE = 'only-managed'
$env:UV_LINK_MODE = 'copy'
$env:UV_HTTP_TIMEOUT = '300'
$env:UV_NO_PROGRESS = '0'
$env:PYTHONNOUSERSITE = '1'
$env:PYTHONUTF8 = '1'
$env:TEMP = Join-Path $Root 'tmp'
$env:TMP = $env:TEMP
$env:MPLCONFIGDIR = Join-Path $Cache 'matplotlib'
# Process-local settings only. No changes to registry, PATH, drivers or system Python.
$UvVersion = '0.8.22'
$PythonVersion = '3.12.11'
$ExpectedZip = '5049375aa2a5162f132b2c1cb992e25d42d47d934cab8c174dbe6f60973dcc12'
$ExpectedExe = 'd8d1494355d68435959cd297cecb0fa02a44c7ad60acad02eb82135dbbd4fa64'
$Zip = Join-Path $Cache "bootstrap\uv-$UvVersion.zip"
$ToolDir = Join-Path $Runtime "tools\uv-$UvVersion"
$Uv = Join-Path $ToolDir 'uv.exe'
if (-not (Test-WindowsX64)) {
    throw 'GPNB_v1 supports Windows x64 only.'
}
if (-not (Test-Path -LiteralPath $Zip) -or (Get-Sha256 $Zip) -ne $ExpectedZip) {
    if ($env:UV_OFFLINE -eq '1') { throw 'Verified uv archive is unavailable in offline mode. Run setup online once.' }
    Write-Host "[bootstrap] Downloading uv $UvVersion from official GitHub..."
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $Part = "$Zip.partial"
    for ($Attempt = 1; $Attempt -le 3; $Attempt++) {
        try {
            Invoke-WebRequest -UseBasicParsing -Uri "https://github.com/astral-sh/uv/releases/download/$UvVersion/uv-x86_64-pc-windows-msvc.zip" -OutFile $Part -TimeoutSec 300
            if ((Get-Sha256 $Part) -ne $ExpectedZip) { throw 'uv checksum mismatch' }
            break
        } catch {
            if ($Attempt -eq 3) { throw "uv download failed after 3 attempts: $($_.Exception.Message). Partial retained at $Part" }
            Write-Host "[bootstrap] Download retry $Attempt/3..."
            Start-Sleep -Seconds $Attempt
        }
    }
    Move-Item -LiteralPath $Part -Destination $Zip -Force
}
# Verify and reuse the executable, avoiding a rewrite while another uv task runs.
if (-not (Test-Path -LiteralPath $Uv) -or (Get-Sha256 $Uv) -ne $ExpectedExe) {
    # .NET APIs also work on Windows PowerShell installations without Archive/Utility modules.
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    New-Item -ItemType Directory -Force -Path $ToolDir | Out-Null
    $Archive = [IO.Compression.ZipFile]::OpenRead($Zip)
    try {
        $Entry = $Archive.GetEntry('uv.exe')
        if (-not $Entry) { throw 'Verified archive does not contain uv.exe.' }
        [IO.Compression.ZipFileExtensions]::ExtractToFile($Entry, $Uv, $true)
    } finally { $Archive.Dispose() }
}
if ((Get-Sha256 $Uv) -ne $ExpectedExe) { throw 'Extracted uv executable checksum mismatch.' }
Invoke-LoggedNative $Uv @('--version')
if ($LASTEXITCODE -ne 0) { throw 'uv could not start.' }
Write-Host "[bootstrap] Ensuring managed CPython $PythonVersion under $Runtime..."
$ManagedDir = Join-Path $env:UV_PYTHON_INSTALL_DIR 'cpython-3.12.11-windows-x86_64-none'
$ManagedExe = Join-Path $ManagedDir 'python.exe'
$ManagedBuild = Join-Path $ManagedDir 'BUILD'
if (Test-Path -LiteralPath $ManagedDir) {
    $BaseHealthy = (Test-Path -LiteralPath $ManagedExe) -and (Test-Path -LiteralPath $ManagedBuild)
    if ($BaseHealthy) {
        $BaseHealthy = (Get-Sha256 $ManagedExe) -eq '3754872ea8a1bb902aa1faddfdd48c0f60dc3977f579c4e3476ac4294e527fb3' -and
                       (Get-Content -Raw -LiteralPath $ManagedBuild).Trim() -eq '20250918'
    }
    if ($BaseHealthy) {
        Invoke-LoggedNative $ManagedExe @('-I', '-c', 'import ssl,encodings,sys; assert sys.version_info[:3] == (3,12,11)')
        $BaseHealthy = ($LASTEXITCODE -eq 0)
    }
    if (-not $BaseHealthy) {
        if (-not $Repair) { throw 'Managed Python is incomplete/damaged. Retry Setup_GPNB_v1.cmd with -Repair (online may be needed).' }
        $Resolved = Assert-ManagedPath $ManagedDir $env:UV_PYTHON_INSTALL_DIR
        $Archive = Join-Path $Runtime ('python-repair-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
        $null = Assert-ManagedPath $Archive $Runtime
        Move-Item -LiteralPath $Resolved -Destination $Archive
        Write-Host "[bootstrap] Preserved damaged Python at $Archive; reinstalling the pinned runtime."
    }
}
Invoke-LoggedNative $Uv @('python', 'install', $PythonVersion, '--no-bin', '--no-registry', '--no-config')
if ($LASTEXITCODE -ne 0) { throw 'Managed Python installation failed. Retry the same setup command.' }
$PythonResult = & $Uv python find $PythonVersion --no-config
if ($LASTEXITCODE -ne 0 -or -not $PythonResult) { throw 'Managed Python not found.' }
$Python = $PythonResult.Trim()
if (-not (Test-Path -LiteralPath $Python)) { throw 'Managed Python executable is missing.' }
$null = Assert-ManagedPath $Python $env:UV_PYTHON_INSTALL_DIR
$BuildFile = Join-Path (Split-Path -Parent $Python) 'BUILD'
if (-not (Test-Path -LiteralPath $BuildFile) -or (Get-Content -Raw -LiteralPath $BuildFile).Trim() -ne '20250918') {
    throw 'Unexpected managed Python build. This release requires python-build-standalone 20250918.'
}
if ((Get-Sha256 $Python) -ne '3754872ea8a1bb902aa1faddfdd48c0f60dc3977f579c4e3476ac4294e527fb3') {
    throw 'Managed Python executable checksum mismatch. Reinstall the project-managed Python before continuing.'
}
Write-Host "[bootstrap] Python: $Python"
