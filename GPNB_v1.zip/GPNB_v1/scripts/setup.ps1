﻿[CmdletBinding()]
param(
    [string]$Profile = '',
    [switch]$Repair,
    [switch]$Offline,
    [ValidateSet('window', 'offscreen')] [string]$QtMode = 'window',
    [ValidateSet('zh_CN', 'en_US')] [string]$Language = 'zh_CN'
)
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
. (Join-Path $PSScriptRoot 'native.ps1')
. (Join-Path $PSScriptRoot 'installer_common.ps1')
function Say([string]$Chinese, [string]$English) {
    if ($Language -eq 'zh_CN') { Write-Host $Chinese } else { Write-Host $English }
}
$ExitCode = 1
$Guard = $null
$Transcript = $false
$Log = ''
$StatusPath = ''
$Stage = 'preflight'
$Report = ''
$Reuse = $false
function Status([string]$Phase, [string]$State = 'running', [string]$ErrorText = '') {
    $script:Stage = $Phase
    if ($script:StatusPath) {
        Write-LocalJson $script:StatusPath @{
            schema_version=1; profile=$Profile; stage=$Phase; status=$State; error=$ErrorText
            updated_utc=[DateTime]::UtcNow.ToString('o'); log=$Log; report=$Report
            reused=$Reuse; offline=[bool]$Offline; dev=$false
        }
    }
}
try {
    Initialize-LocalProcess $Root
    $Policy = Get-EnvironmentPolicy $Root
    $Log = Join-Path $Root ("logs\setup-" + (Get-Date -Format 'yyyyMMdd-HHmmss-fff') + '.log')
    Start-Transcript -Path $Log | Out-Null
    $Transcript = $true
    if (-not (Test-WindowsX64)) { throw 'This release requires Windows x64 (AMD64).' }
    try {
        $Guard = [IO.File]::Open((Join-Path $Root 'runtime\setup.guard'), 'OpenOrCreate', 'ReadWrite', 'None')
    } catch { throw 'GPNB_v1 or another setup is running. Close it first. / 请先关闭 GPNB_v1 和其他安装窗口。' }
    if (-not $Profile) {
        $Recommended = Get-RecommendedProfile $Policy
        Say "检测建议环境档: $Recommended。驱动检测不保证显卡可用，安装后会实际计算检查。" "Suggested profile: $Recommended. Driver detection is advisory; actual compute will be checked."
        $Names = @($Policy.profiles.PSObject.Properties.Name)
        foreach ($Name in $Names) {
            $Item = Get-EnvironmentProfile $Policy $Name
            Write-Host ("  {0}: {1}; PyTorch {2}" -f $Name, $Item.label, $Item.torch)
        }
        $Answer = Read-Host "Profile [$Recommended]"
        $Profile = if ($Answer) { $Answer.Trim() } else { $Recommended }
    }
    $ProfileInfo = Get-EnvironmentProfile $Policy $Profile
    $StatusPath = "$Log.status.json"
    $Lock = Join-Path $Root ("requirements\" + $ProfileInfo.lock)
    if (-not (Test-Path -LiteralPath $Lock)) { throw "Missing verified dependency lock: $Lock" }
    $EnvDir = Join-Path $Root "runtime\envs\$Profile"
    $EnvPython = Join-Path $EnvDir 'Scripts\python.exe'
    $Marker = Join-Path $EnvDir 'gpnb-ready.json'
    $null = Assert-ManagedPath $EnvDir (Join-Path $Root 'runtime\envs')
    $StateArgs = @('--root', $Root, '--profile', $Profile)
    Status 'reuse_check'
    $Drive = New-Object System.IO.DriveInfo ([IO.Path]::GetPathRoot($Root))
    Write-Host ("[1/5] OS: {0}; CPUs: {1}; free disk: {2:N1} GiB" -f [Environment]::OSVersion, [Environment]::ProcessorCount, ($Drive.AvailableFreeSpace / 1GB))
    # Healthy reuse needs neither bootstrap files nor network/cache metadata.
    if ((Test-Path -LiteralPath $EnvPython) -and -not $Repair) {
        Invoke-LoggedNative $EnvPython (@((Join-Path $PSScriptRoot 'environment_state.py'), 'check') + $StateArgs)
        if ($LASTEXITCODE -eq 0) {
            Invoke-LoggedNative $EnvPython @('-m', 'gpnb', 'doctor', '--profile', $Profile, '--quick', '--qt', 'skip')
            $Reuse = ($LASTEXITCODE -eq 0)
        }
    }
    # Invalidate before mutation or re-verification, including interrupted repair.
    if (Test-Path -LiteralPath $Marker) {
        Move-Item -LiteralPath $Marker -Destination "$Log.previous-ready.json"
    }
    if (-not $Reuse) {
        Status 'bootstrap'
        $Minimum = [long]$ProfileInfo.minimum_free_gib * 1GB
        if ($Drive.AvailableFreeSpace -lt $Minimum) { throw "Insufficient free space: this install requires at least $Minimum bytes." }
        if ($ProfileInfo.device -eq 'cuda') {
            if (-not (Get-Command nvidia-smi -ErrorAction SilentlyContinue)) {
                throw 'NVIDIA diagnostic unavailable. Choose CPU; GPNB_v1 does not change drivers. / 未发现 NVIDIA 驱动诊断，请选择 CPU；软件不会更改驱动。'
            }
            Invoke-LoggedNative 'nvidia-smi' @('--query-gpu=name,memory.total,driver_version', '--format=csv,noheader')
            if ($LASTEXITCODE -ne 0) { throw 'NVIDIA driver check failed; CPU installation remains available.' }
        }
        $env:UV_OFFLINE = if ($Offline) { '1' } else { '0' }
        . (Join-Path $PSScriptRoot 'bootstrap.ps1')
        $InterpreterHealthy = $false
        if (Test-Path -LiteralPath $EnvPython) {
            Invoke-LoggedNative $EnvPython @('-I', '-c', 'import sys,ssl,encodings; assert sys.version_info[:3] == (3,12,11) and sys.prefix != sys.base_prefix')
            $InterpreterHealthy = ($LASTEXITCODE -eq 0)
        }
        if (-not $InterpreterHealthy -and (Test-Path -LiteralPath $EnvDir)) {
            $Resolved = Assert-ManagedPath $EnvDir (Join-Path $Root 'runtime\envs')
            $Archive = "$EnvDir.repair-" + (Get-Date -Format 'yyyyMMdd-HHmmss-fff')
            $null = Assert-ManagedPath $Archive (Join-Path $Root 'runtime\envs')
            Move-Item -LiteralPath $Resolved -Destination $Archive
        }
        Status 'environment'
        if (-not $InterpreterHealthy) {
            Say '[2/5] 创建项目专用隔离环境……' '[2/5] Creating project-isolated environment...'
            Invoke-LoggedNative $Uv @('venv', $EnvDir, '--python', $Python, '--no-config')
            if ($LASTEXITCODE -ne 0) { throw 'Environment creation failed.' }
        }
        Status 'dependencies'
        Say '[3/5] 安装固定版本依赖；下方显示下载和安装进度……' '[3/5] Installing hash-locked dependencies; progress follows...'
        $SyncArgs = @('pip', 'sync', $Lock)
        $SyncArgs += @('--python', $EnvPython, '--require-hashes', '--only-binary', ':all:', '--no-config')
        if ($Repair) { $SyncArgs += '--reinstall' }
        Invoke-LoggedNative $Uv $SyncArgs
        if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed. Retry online; use -Repair for damaged packages. / 依赖安装失败，请联网重试；已安装包损坏时加 -Repair。' }
        Status 'application'
        Invoke-LoggedNative $Uv @('pip', 'install', '--python', $EnvPython, '--no-deps', '--no-build-isolation', '--offline', '--no-config', '--editable', $Root)
        if ($LASTEXITCODE -ne 0) { throw 'Local GPNB_v1 installation failed.' }
        Invoke-LoggedNative $Uv @('pip', 'check', '--python', $EnvPython, '--no-config')
        if ($LASTEXITCODE -ne 0) { throw 'Dependency consistency check failed.' }
    } else {
        Say '[2/5] 复用已有环境，不下载、不重装依赖。' '[2/5] Existing environment reused; no dependency download or installation.'
    }
    $Report = Join-Path $Root ("logs\doctor-$Profile-" + (Get-Date -Format 'yyyyMMdd-HHmmss-fff') + '.json')
    Status 'health_check'
    Say '[4/5] 检查依赖、BED、CPU/GPU 小模型和窗口……' '[4/5] Checking imports, BED, CPU/GPU model and Qt window...'
    Invoke-LoggedNative $EnvPython @('-m', 'gpnb', 'doctor', '--profile', $Profile, '--qt', $QtMode, '--json', $Report)
    if ($LASTEXITCODE -ne 0) { throw "Health check failed; no ready marker. Review $Report and retry with -Repair." }
    Status 'commit'
    Invoke-LoggedNative $EnvPython (@((Join-Path $PSScriptRoot 'environment_state.py'), 'write') + $StateArgs + @('--report', $Report))
    if ($LASTEXITCODE -ne 0) { throw 'Could not record verified environment state.' }
    Write-LocalJson (Join-Path $Root 'runtime\active-profile.json') @{profile=$Profile; dev=$false; python=$EnvPython; language=$Language}
    Status 'ready' 'completed'
    Say '[5/5] 配置完成。双击 Start_GPNB_v1.cmd 启动；日志和诊断已保存。' '[5/5] Ready. Open Start_GPNB_v1.cmd; logs and diagnostics are saved.'
    $ExitCode = 0
} catch {
    $Reason = $_.Exception.Message
    try { Status $Stage 'failed' $Reason } catch { }
    Write-Host ("SETUP FAILED / 配置失败: " + $Reason) -ForegroundColor Red
    if ($Log) { Write-Host "Log / 日志: $Log" }
    $RetryProfile = if ($Profile) { $Profile } else { 'cpu' }
    Write-Host "Retry / 重试: Setup_GPNB_v1.cmd -Profile $RetryProfile -Repair -Language $Language"
    Write-Host 'CPU alternative / CPU 备用入口: Setup_GPNB_v1_CPU.cmd (does not change your project training device)'
    Write-Host 'Offline needs complete caches. / 缓存完整时才可加 -Offline。'
} finally {
    if ($Guard) { $Guard.Dispose() }
    if ($Transcript) { Stop-Transcript | Out-Null }
}
exit $ExitCode
