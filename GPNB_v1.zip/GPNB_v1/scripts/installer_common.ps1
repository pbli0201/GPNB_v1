﻿# Shared by setup and start. Compatible with Windows PowerShell 5.1.
function Initialize-LocalProcess([string]$Root) {
    foreach ($name in @('runtime', 'logs', 'tmp', 'cache\matplotlib')) {
        New-Item -ItemType Directory -Force -Path (Join-Path $Root $name) | Out-Null
    }
    $env:GPNB_ROOT = $Root
    $env:PYTHONHOME = ''
    $env:PYTHONPATH = ''
    $env:PYTHONNOUSERSITE = '1'
    $env:PYTHONUTF8 = '1'
    $env:TEMP = Join-Path $Root 'tmp'
    $env:TMP = $env:TEMP
    $env:MPLCONFIGDIR = Join-Path $Root 'cache\matplotlib'
}

function Get-EnvironmentPolicy([string]$Root) {
    $Policy = Get-Content -Raw -LiteralPath (Join-Path $Root 'requirements\profiles.json') | ConvertFrom-Json
    if ($Policy.schema_version -ne 1) { throw 'Unsupported environment profile manifest.' }
    return $Policy
}

function Get-EnvironmentProfile($Policy, [string]$Name) {
    $Property = $Policy.profiles.PSObject.Properties[$Name]
    if (-not $Property -or $Name -notmatch '^[a-z0-9]+$') { throw "Unknown environment profile: $Name" }
    return $Property.Value
}

function Get-RecommendedProfile($Policy) {
    $Drivers = @()
    if (Get-Command nvidia-smi -ErrorAction SilentlyContinue) {
        try {
            $Text = & nvidia-smi --query-gpu=driver_version --format=csv,noheader 2>$null
            if ($LASTEXITCODE -eq 0) {
                foreach ($Line in $Text) { $Drivers += [version]$Line.Trim() }
            }
        } catch { $Drivers = @() }
    }
    foreach ($Name in $Policy.recommendation_order) {
        $Entry = Get-EnvironmentProfile $Policy $Name
        if (-not $Entry.driver_recommendation_min) { return $Name }
        if ($Drivers.Count -gt 0 -and @($Drivers | Where-Object { $_ -lt [version]$Entry.driver_recommendation_min }).Count -eq 0) {
            return $Name
        }
    }
    return $Policy.default_profile
}

function Write-LocalJson([string]$Path, $Value) {
    $Utf8 = New-Object System.Text.UTF8Encoding($false)
    [IO.File]::WriteAllText("$Path.partial", ($Value | ConvertTo-Json -Depth 8), $Utf8)
    Move-Item -LiteralPath "$Path.partial" -Destination $Path -Force
}

function Assert-ManagedPath([string]$Path, [string]$Parent) {
    $Resolved = [IO.Path]::GetFullPath($Path)
    $Allowed = [IO.Path]::GetFullPath($Parent).TrimEnd('\') + '\'
    if (-not $Resolved.StartsWith($Allowed, [StringComparison]::OrdinalIgnoreCase)) {
        throw "Refusing a path outside the managed directory: $Resolved"
    }
    $Current = $Resolved
    while ($Current.Length -ge $Allowed.TrimEnd('\').Length) {
        if (Test-Path -LiteralPath $Current) {
            $Item = Get-Item -LiteralPath $Current -Force
            if ($Item.Attributes -band [IO.FileAttributes]::ReparsePoint) {
                throw "Refusing a managed path containing a junction/symlink: $Current"
            }
        }
        $Current = Split-Path -Parent $Current
        if (-not $Current) { break }
    }
    return $Resolved
}

function Test-WindowsX64 {
    $Arch = if ($env:PROCESSOR_ARCHITEW6432) { $env:PROCESSOR_ARCHITEW6432 } else { $env:PROCESSOR_ARCHITECTURE }
    return ([Environment]::OSVersion.Platform -eq 'Win32NT' -and
            [Environment]::Is64BitOperatingSystem -and $Arch -eq 'AMD64')
}
