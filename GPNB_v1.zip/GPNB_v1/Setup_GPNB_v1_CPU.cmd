@echo off
call "%~dp0Setup_GPNB_v1.cmd" -Profile cpu %*
set "GPNB_EXIT=%ERRORLEVEL%"
if "%~1"=="" pause
exit /b %GPNB_EXIT%
