@echo off
call "%~dp0Start_GPNB_v1.cmd" -Profile cpu %*
set "GPNB_EXIT=%ERRORLEVEL%"
if "%~1"=="" pause
exit /b %GPNB_EXIT%
