"""Read-only batch index and serial, bounded-memory export of every trait.

IDs and safe output directories are independent of display names. A retry can
refer to a preserved result; its original archived settings remain authoritative.
"""
from __future__ import annotations
import hashlib
import html
from pathlib import Path

from .bundle import safe_member
from .config import fail
from .data.files import read_json, write_json, write_csv, sha256, snapshot, verify_snapshots
from .results import result_root, result_targets, load_result_data, selected_caption


def batch_result_index(source):
    root=Path(source).resolve();path=root/'summary.json';summary=read_json(path)
    if summary.get('kind')!='trait_batch':fail('E_FORMAT',str(root),'expected a trait batch result')
    if (root/'complete.json').is_file():
        manifest=read_json(root/'complete.json')
        if manifest.get('files',{}).get('summary.json')!=sha256(path):fail('E_BUNDLE',str(path),'batch summary hash mismatch')
    records=[]
    for number,task in enumerate(summary['tasks'],1):
        identity=str(task.get('id',f'trait_{number:03}'))
        base=dict(task_id=identity,trait=task['trait'],status=task['status'],error=task.get('error',''),
                  preserved_from=task.get('preserved_from'),source=None,unit='',metrics={},partition=None,
                  evaluation='',seconds=None,kind=None,seed=None,folds=[],configuration={})
        if task['status']=='completed':
            try:
                child=safe_member(Path(task.get('preserved_from',root)),task['output'])
                child_summary=read_json(child/'summary.json')
                if child_summary.get('kind')=='final_refit':child=safe_member(child,child_summary.get('model_directory','model'))
                child,actual=result_root(child)
                for target in result_targets(actual):
                    partition='train' if actual.get('evaluation_status')=='no_independent_test_set' else 'test'
                    # Initial index reads sealed summaries only; full prediction arrays are loaded lazily.
                    metrics=actual.get('oof_metrics_by_target',{}).get(target['id'],actual.get('oof_metrics',{})) if actual['kind']=='cross_validation' else actual.get('test_metrics_by_target',{}).get(target['id'],actual.get('test_metrics',{}))
                    if partition=='train':metrics={}  # No fabricated independent score for final refits.
                    key=hashlib.sha256((identity+'\0'+target['id']).encode()).hexdigest()[:16]
                    records.append(dict(base,id=key,target_id=target['id'],trait=target['trait'],unit=target.get('unit',''),
                        source=str(child),partition=partition,kind=actual['kind'],metrics=metrics,
                        evaluation='no_independent_test' if partition=='train' else 'pooled_oof' if actual['kind']=='cross_validation' else 'independent_test',
                        seconds=actual.get('timing',{}).get('total_seconds',actual.get('resources',{}).get('elapsed_seconds')),
                        seed=actual.get('seed'),folds=[r['fold'] for r in actual.get('fold_runs',[])],
                        configuration_path='project.json',reused=bool(task.get('preserved_from'))))
            except (ValueError,OSError,KeyError) as error:
                records.append(dict(base,id=hashlib.sha256(identity.encode()).hexdigest()[:16],target_id=None,status='unreadable',error=str(error)))
        else:records.append(dict(base,id=hashlib.sha256(identity.encode()).hexdigest()[:16],target_id=None))
    return dict(schema_version=1,kind='batch_result_index',source=str(root),records=records,
                source_snapshot=snapshot(path),counts={s:sum(r['status']==s for r in records) for s in sorted({r['status'] for r in records})})


def export_batch_results(source,output,*,language='en',target_id=None,formats=('png','svg','pdf'),progress=None,cancelled=None):
    from .results import export_result_plots
    from .training.core import check_cancel
    from .data.files import protect_inputs
    index=batch_result_index(source);output=Path(output).resolve();root=Path(source).resolve()
    if output.exists():fail('E_EXISTS',str(output),'choose a new output directory')
    protect_inputs(output,[root,*[Path(r['source']) for r in index['records'] if r['source']]])
    if language not in ('zh','en') or not formats or len(set(formats))!=len(formats) or any(f not in ('png','svg','pdf') for f in formats):fail('E_VALUE','export','invalid language or formats')
    records=index['records']
    if target_id is not None:
        records=[r for r in records if r['id']==target_id]
        if not records:fail('E_VALUE','target','unknown batch target ID')
    output.mkdir(parents=True);(output/'INCOMPLETE').write_text('Batch export in progress',encoding='utf8')
    exported=[]
    try:
        for number,record in enumerate(records,1):
            check_cancel(cancelled);row=dict(record,export_status='not_exported',export_directory=None)
            if record['status']=='completed':
                destination=output/('trait_'+record['id'])
                try:
                    export_result_plots(record['source'],destination,language=language,target_id=record['target_id'],
                                        partition=record['partition'],formats=formats,cancelled=cancelled)
                    details=archived_fit_details(record['source'])
                    write_json(destination/'fit_details.json',details)
                    row.update(export_status='completed',export_directory=destination.name)
                except Exception as error:
                    if getattr(error,'code','')=='E_CANCELLED':raise
                    row.update(export_status='failed',export_error=str(error))
            exported.append(row)
            if progress:progress(dict(event='stage',stage='batch_export',trait=record['trait'],done=number,total=len(records)))
        verify_snapshots({'batch':index['source_snapshot']})
        summary=dict(ok=all(r['export_status']=='completed' for r in exported),kind='batch_result_export',schema_version=1,language=language,
                     source=str(root),records=exported,counts=index['counts'],note='No pooled accuracy across traits; scores retain original units.')
        write_json(output/'summary.json',summary);write_json(output/'result_index.json',index)
        fields=['id','task_id','trait','target_id','unit','status','evaluation','seed','seconds','preserved_from','export_status','export_directory','error']
        write_csv(output/'traits.csv',fields,([r.get(k) for k in fields] for r in exported))
        metric_fields=['id','trait','unit','evaluation','n','pearson','rmse','mae']
        write_csv(output/'metrics.csv',metric_fields,([dict(r,**r['metrics']).get(k) for k in metric_fields] for r in exported))
        write_batch_report(output,summary,language)
        summary['files']=[p.relative_to(output).as_posix() for p in sorted(output.rglob('*')) if p.is_file() and p.name!='INCOMPLETE']
        write_json(output/'summary.json',summary);(output/'INCOMPLETE').unlink()
        return summary
    except BaseException as error:
        write_json(output/'failure.json',dict(ok=False,error=str(error)));raise


def archived_fit_details(source):
    """Actual outer-fold/config/search records. Never re-score candidates on tests."""
    from .results import _verify_artifacts, _rows
    root,summary=result_root(source);rows=[]
    members=summary.get('fold_runs',[dict(fold=summary.get('fold'),directory='.')])
    for member in members:
        child=root if member['directory']=='.' else safe_member(root,member['directory']);actual=read_json(child/'summary.json')
        paths=[child/'summary.json']
        row=dict(fold=member['fold'],best_epoch=actual.get('best_epoch'),epochs_ran=actual.get('epochs_ran'),
                 stop_reason=actual.get('stop_reason'),search=actual.get('search'),configuration={})
        project=child/'project.json'
        if project.is_file():paths.append(project);row['configuration']=read_json(project)
        history=child/'history.csv'
        if history.is_file():paths.append(history);row['history']=_rows(history)
        for name in ('search/summary.json','search/trials.json','search/trials.csv'):
            file=child/name
            if file.is_file():paths.append(file);row[name]=read_json(file) if file.suffix=='.json' else _rows(file)
        _verify_artifacts(root,paths);rows.append(row)
    return rows


def write_batch_report(output,summary,language):
    zh=language=='zh';escape=lambda x:html.escape(str(x));blocks=[]
    for record in summary['records']:
        blocks.append('<section><h2>'+escape(record['trait'])+' '+escape(record['unit'])+'</h2><p>'+escape(record['status']+' / '+record['evaluation'])+'</p>')
        if record['preserved_from']:blocks.append('<p>'+('沿用先前成功任务' if zh else 'Reused earlier successful task')+'</p>')
        if record['export_status']=='completed':
            directory=record['export_directory']
            blocks.append(f'<p><a href="{directory}/report.html">'+('详细结果、实际配置与逐样本预测' if zh else 'Details, actual settings and per-sample predictions')+'</a> · '+f'<a href="{directory}/fit_details.json">'+('折与搜索记录' if zh else 'Fold and search records')+'</a></p>')
            image=next((f'{directory}/target_001/combination.{fmt}' for fmt in ('svg','png') if (output/directory/'target_001'/f'combination.{fmt}').is_file()),None)
            if image:blocks.append('<img loading="lazy" src="'+image+'" alt="'+escape(record['trait'])+'">')
        else:blocks.append('<p>'+escape(record.get('export_error',record['error']))+'</p>')
        blocks.append('</section>')
    title='GPNB '+('全部性状结果' if zh else 'All trait results')
    note='每性状分别评价，不计算跨性状平均准确率。失败项保留；最终重训无独立测试。' if zh else 'Traits are evaluated separately; no cross-trait mean accuracy. Failed tasks remain listed. Final refits have no independent test.'
    (output/'report.html').write_text('<!doctype html><html lang="'+('zh-CN' if zh else 'en')+'"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+title+'</title><style>body{max-width:1200px;margin:auto;padding:24px;font:16px/1.7 sans-serif}img{width:100%}section{border-top:1px solid #ccc}a{color:#175ba0}</style><h1>'+title+'</h1><p>'+note+'</p><a href="traits.csv">CSV</a>'+''.join(blocks)+'</html>',encoding='utf8')
