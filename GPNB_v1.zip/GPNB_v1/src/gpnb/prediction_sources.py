"""Single-model and all-member prediction with frozen, member-local state."""
from __future__ import annotations

from pathlib import Path

import numpy as np

from .config import fail
from .data.files import read_json


def _targets(project):
    from .model_package import _targets as package_targets
    return package_targets(project.to_dict())


def describe_prediction_source(path, *, fold=None):
    """Read verified saved contracts without touching the training input files."""
    from .model_package import resolve_model_source
    from .config import load_spec
    resolved = resolve_model_source(path, fold=fold)
    members = resolved["members"]
    if not members:
        fail("E_BUNDLE", str(path), "prediction source contains no model members")
    project = load_spec(members[0]["directory"] / "project.json")
    value = project.to_dict()
    spec = value["model"]
    inputs = {c["id"]: c for c in value.get("extensions", {}).get("input_tables", [])}
    graph = spec.get("individual_graph_spec", {})
    model_bytes = sum((m["directory"] / "weights.pt").stat().st_size for m in members)
    result = dict(resolved.get("metadata", {}))
    result.update(name=spec.get("name", "Regression model"), source_kind=resolved["kind"],
                  member_count=len(members), targets=_targets(project), required_input_tables=inputs,
                  members=[dict(id=m["id"], fold=m.get("fold"), directory=str(m["directory"])) for m in members],
                  graph_scope=("transductive_fixed_cohort" if not resolved["metadata"]["input_requirements"]["permits_unknown_individuals"]
                               else graph.get("protocol", "new_individuals")), model_bytes=model_bytes,
                  prediction_strategy="equal_weight_original_units" if len(members) > 1 else "single_model",
                  model_disagreement="Population SD across member predictions in original target units; not a confidence interval or reliability.",
                  work_estimate=dict(model_evaluations_per_batch=len(members),
                                     basis="One full prediction by every member; no silent member sampling."))
    result.setdefault("origin_method", "fixed_split")
    return result


def load_predictor(path, *, device="cpu", max_parameter_bytes=None, fold=None):
    from .model_package import resolve_model_source
    from .models.core import DEFAULT_PARAMETER_BYTES
    from .prediction import Predictor
    maximum = DEFAULT_PARAMETER_BYTES if max_parameter_bytes is None else max_parameter_bytes
    resolved = resolve_model_source(path, fold=fold)
    if len(resolved["members"]) == 1:
        predictor = Predictor(resolved["members"][0]["directory"], device=device, max_parameter_bytes=maximum)
        predictor.resolved_source = resolved
        predictor.member_directories = [m["directory"] for m in resolved["members"]]
        predictor.targets = _targets(predictor.project)
        return predictor
    return EnsemblePredictor(resolved, device=device, max_parameter_bytes=maximum)


class EnsemblePredictor:
    """Bounded-memory ensemble. Each member performs its own inverse transform.

    Members are loaded sequentially, avoiding simultaneous GPU copies of every
    LOO model. This favors bounded memory over loading speed for large ensembles.
    No member is discarded on a load, alignment, graph, or prediction failure.
    """

    def __init__(self, resolved, *, device, max_parameter_bytes):
        from .prediction import Predictor
        self.resolved_source = resolved
        self.member_directories = [m["directory"] for m in resolved["members"]]
        self.device, self.max_parameter_bytes = device, max_parameter_bytes
        self.targets = None
        for index, directory in enumerate(self.member_directories):
            member = Predictor(directory, device=device, max_parameter_bytes=max_parameter_bytes)
            targets = _targets(member.project)
            columns = {name: state.value["config"]["columns"] for name, state in member.input_states.items()}
            if index == 0:
                for attr in ("directory", "project", "summary", "state", "spec", "config", "target_state",
                             "input_states", "input_features", "reference_state", "kernel_mode"):
                    setattr(self, attr, getattr(member, attr))
                self.targets, self.additional_columns = targets, columns
            elif targets != self.targets or columns != self.additional_columns:
                fail("E_BUNDLE", str(directory), "ensemble members have incompatible targets/units or numeric input columns")
            else:
                # Original marker inventory/encoding is common; selected masks,
                # means, target scaling and kernel widths are deliberately not.
                member.align(self.state.metadata["input_markers"])
                if len(member.state.metadata["input_markers"]) != len(self.state.metadata["input_markers"]):
                    fail("E_BUNDLE", str(directory), "ensemble original marker inventories differ")
                if member.state.metadata["encoding"] != self.state.metadata["encoding"]:
                    fail("E_BUNDLE", str(directory), "ensemble genotype encoding contracts differ")
            del member

    def align(self, markers):
        from .prediction import Predictor
        return Predictor.align(self, markers)

    def verify_encoding_declaration(self, declaration):
        from .prediction import Predictor
        # All members are checked again at prediction; this check fails early.
        return Predictor.verify_encoding_declaration(self, declaration)

    def predict_distribution(self, raw, markers, additional=None, sample_ids=None, *, allele_declaration=None,
                             progress=None, cancelled=None):
        from .prediction import Predictor
        from .training.core import check_cancel
        mean, squared = None, None
        for count, directory in enumerate(self.member_directories, 1):
            check_cancel(cancelled)
            if progress:
                progress({"event": "stage", "stage": "ensemble_member", "done": count - 1,
                          "total": len(self.member_directories)})
            member = Predictor(directory, device=self.device, max_parameter_bytes=self.max_parameter_bytes)
            estimate = np.asarray(member.predict_raw(raw, markers, additional, sample_ids,
                                                     allele_declaration=allele_declaration), dtype=np.float64)
            del member
            if mean is None:
                mean, squared = estimate.copy(), np.zeros_like(estimate)
            else:
                if estimate.shape != mean.shape:
                    fail("E_BUNDLE", str(directory), "ensemble output shapes differ")
                delta = estimate - mean
                mean += delta / count
                squared += delta * (estimate - mean)
        # Population spread describes this finite set of members, not uncertainty.
        spread = np.sqrt(np.maximum(squared / len(self.member_directories), 0))
        if not np.isfinite(mean).all() or not np.isfinite(spread).all():
            fail("E_BUNDLE", "ensemble", "nonfinite ensemble aggregate")
        return mean, spread

    def predict_raw(self, raw, markers, additional=None, sample_ids=None, *, allele_declaration=None):
        return self.predict_distribution(raw, markers, additional, sample_ids,
                                         allele_declaration=allele_declaration)[0]


def identity_statuses(predictor, samples, relation, note, query_files=None):
    """Use explicit source assertions; same-looking IDs never establish identity."""
    if relation not in ("unknown", "same_source", "confirmed_new"):
        fail("E_VALUE", "identity_relation", "choose unknown, same_source, or confirmed_new")
    if not isinstance(note, str) or (relation == "confirmed_new" and not note.strip()):
        fail("E_VALUE", "identity_note", "confirmed_new requires a recorded basis for confirming no training/selection overlap")
    requested_relation = relation
    exact_sources = []
    for member in predictor.resolved_source["members"]:
        saved = member.get("metadata", {}).get("source_genotype_files", {})
        # BED without its matching FAM is only a genotype fingerprint. Both ID
        # and genotype source snapshots must match to identify an archived cohort.
        keys = set(saved)
        valid_source = {"bed", "bim", "fam"}.issubset(keys) or "matrix" in keys
        if valid_source and query_files and all(
                key in query_files and saved[key]["sha256"] == query_files[key]["sha256"]
                for key in keys):
            exact_sources.append(member["id"])
    if exact_sources:
        if relation == "confirmed_new":
            fail("E_VALUE", "identity_relation", "query genotype and ID source hashes match the archived training cohort; confirmed_new contradicts this source evidence")
        relation = "same_source"
    training, selection, graph_context, modes = set(), set(), set(), set()
    def key(pair, mode):
        return (mode, pair[1]) if mode == "iid" else (mode, *pair[:2])
    for directory in predictor.member_directories:
        project = read_json(directory / "project.json")
        mode = project["data"]["phenotype_options"]["id_mode"]
        modes.add(mode)
        split = read_json(directory / "prepared/split.json")["manifest"]
        ids = split["context"]["sample_ids"]
        state = read_json(directory / "prepared/preprocessor/state.json")
        selection_rows = split["partitions"].get("validation", [])
        if (not isinstance(selection_rows, list) or
                any(type(i) is not int or i < 0 or i >= len(ids) for i in selection_rows)):
            fail("E_BUNDLE", str(directory / "prepared/split.json"), "invalid validation identity rows")
        training.update(key(ids[i], mode) for i in state["train_rows"])
        selection.update(key(ids[i], mode) for i in selection_rows)
        if project.get("model", {}).get("individual_graph_spec", {}).get("protocol") == "transductive_fixed_cohort":
            if relation == "confirmed_new":
                fail("E_REFERENCE", "identity_relation", "a fixed-cohort transductive model cannot provide new-individual predictions; its graph already includes the allowed cohort")
            reference = read_json(directory / "reference_state.json")
            graph_context.update(key(pair, mode) for pair in reference["reference_ids"])
    if relation == "unknown":
        statuses = ["identity_uncertain"] * len(samples)
    elif relation == "confirmed_new":
        statuses = ["confirmed_unseen"] * len(samples)
    else:
        statuses = [("seen_training" if any(key(row, mode) in training for mode in modes) else
                     "seen_selection" if any(key(row, mode) in selection for mode in modes) else
                     "seen_graph_context" if any(key(row, mode) in graph_context for mode in modes) else "confirmed_unseen") for row in samples]
    return statuses, dict(relation=relation, requested_relation=requested_relation, note=note,
                          basis="exact_genotype_and_id_source_snapshots" if exact_sources else "explicit_user_source_declaration",
                          exact_source_members=exact_sources,
                          training_id_count=len(training), selection_id_count=len(selection),
                          graph_context_id_count=len(graph_context),
                          id_modes=sorted(modes),
                          counts={s: statuses.count(s) for s in sorted(set(statuses))},
                          genotype_identity_inference=False,
                          scoring_policy="Only confirmed_unseen records enter new-individual scores; training, selection, fixed graph context and uncertain identities are reported separately. Ensemble on the original cohort is not OOF.")


def score_optional_phenotypes(path, options, predictor, samples, estimates, statuses):
    """Called after frozen predictions exist. Missing observations never drop predictions."""
    from .data.tables import read_phenotypes, match_samples
    from .training.metrics import regression_metrics
    opts = dict(predictor.project.to_dict()["data"]["phenotype_options"])
    if options is not None:
        if not isinstance(options, dict) or set(options) - set(opts):
            fail("E_VALUE", "phenotype_options", "use delimiter, encoding, id_mode, id_columns, trait, missing_tokens")
        opts.update(options)
    # Reuse the project validator so optional scoring has the same explicit ID rules.
    from .config import ProjectSpec
    project = predictor.project.to_dict()
    project["data"]["phenotype_options"] = opts
    ProjectSpec(project)
    table = read_phenotypes(Path(path), opts)
    mapping, extras = match_samples(samples, table, opts, Path(path))
    matched_lines = {table.lines[row] for row in mapping if row is not None}
    observed = np.full(estimates.shape, np.nan, dtype=np.float64)
    matches = np.full(estimates.shape, "unmatched_id", dtype=object)
    result = {}
    for j, target in enumerate(predictor.targets):
        column = target["column"] if predictor.target_state else opts["trait"]
        if column not in table.values:
            fail("E_FIELD", str(path), f"missing scoring trait column {column!r}")
        invalid = next((issue for issue in table.invalid if issue["column"] == column and issue["line"] in matched_lines), None)
        if invalid is not None:
            issue = invalid
            fail("E_TRAIT", f"{path}:{issue['line']}:{column}", f"invalid observation {issue['value']!r}")
        for i, row in enumerate(mapping):
            if row is not None:
                value = table.values[column][row]
                matches[i, j] = "missing_trait" if value is None else "matched"
                if value is not None:
                    observed[i, j] = value
        groups = {}
        for status in ("confirmed_unseen", "seen_training", "seen_selection", "seen_graph_context", "identity_uncertain"):
            mask = (np.asarray(statuses) == status) & np.isfinite(observed[:, j])
            groups[status] = regression_metrics(observed[mask, j], estimates[mask, j])
        result[target["id"]] = dict(new_individual_metrics=groups["confirmed_unseen"],
                                    other_identity_groups={s: m for s, m in groups.items() if s != "confirmed_unseen"},
                                    matched_observations=int(np.isfinite(observed[:, j]).sum()),
                                    unmatched_ids=int(np.sum(matches[:, j] == "unmatched_id")),
                                    missing_traits=int(np.sum(matches[:, j] == "missing_trait")))
    return observed, matches, dict(targets=result, extra_phenotype_rows=len(extras), options=opts,
                                  phenotype_used_for="post_prediction_scoring_only", oof=False)
