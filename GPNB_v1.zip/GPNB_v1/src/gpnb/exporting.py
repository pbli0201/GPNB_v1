"""Portable local experiment exports. Source files are copied, never modified."""
from __future__ import annotations

import shutil
from pathlib import Path

from .bundle import safe_member, seal, verify_bundle
from .config import ProjectSpec, fail
from .data.files import protect_inputs, read_json, sha256, verify_snapshots, write_json
from .prediction import Predictor


def _archived_source_namespace(directory, manifest):
    """Select a complete, checksummed source package, excluding old alias shims."""
    for namespace in ("gpnb", "gsapp"):
        required = (f"source/{namespace}/__init__.py", f"source/{namespace}/paths.py")
        if all(name in manifest["files"] for name in required):
            return namespace
    fail("E_BUNDLE", str(directory), "training-time source snapshot unavailable")


# Stdlib-only bootstrap checks every bundled artifact before loading snapshot code.
REPRODUCE = '''"""Run from any working directory with a compatible Python environment."""
import argparse
import hashlib
import importlib.metadata
import json
import os
import platform
from pathlib import Path, PureWindowsPath
import sys

for stream in (sys.stdout, sys.stderr):
    if hasattr(stream, "reconfigure"):
        stream.reconfigure(encoding="utf-8", errors="replace")
root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description="Verify, predict or repeat this archived GPNB experiment")
parser.add_argument("mode", choices=["verify", "train", "predict"])
parser.add_argument("--output", type=Path)
source_args = parser.add_mutually_exclusive_group()
source_args.add_argument("--bed", type=Path)
source_args.add_argument("--matrix-config", type=Path)
parser.add_argument("--bim", type=Path)
parser.add_argument("--fam", type=Path)
parser.add_argument("--dataset-id", default="new_cohort")
parser.add_argument("--device", choices=["cpu", "cuda"])
parser.add_argument("--batch-size", type=int)
parser.add_argument("--input-table", action="append", default=[], help="Additional numeric table: name=path; repeat per branch")
parser.add_argument("--fold", type=int, help="Advanced single fold; current archives default to all-member averaging")
args = parser.parse_args()
try:
    if (root / "INCOMPLETE").exists():
        raise ValueError("export is incomplete")
    manifest = json.loads((root / "complete.json").read_text(encoding="utf-8"))
    if manifest["schema_version"] != 1 or manifest["kind"] not in ("exported_run", "exported_cv"):
        raise ValueError("unsupported export manifest")
    files = manifest["files"]
    for required in ("export.json", "reproduce.py", "run/complete.json"):
        if required not in files:
            raise ValueError("required artifact missing: " + required)
    namespace = next((name for name in ("gpnb", "gsapp")
                      if all("run/source/" + name + "/" + file in files
                             for file in ("__init__.py", "paths.py"))), None)
    if namespace is None:
        raise ValueError("required complete source package missing")
    for name, expected in files.items():
        if (not isinstance(name, str) or "\\\\" in name or PureWindowsPath(name).drive
                or Path(name).is_absolute() or any(p in ("", ".", "..") for p in name.split("/"))):
            raise ValueError("unsafe archive path: " + str(name))
        path = root / name
        if not path.resolve().is_relative_to(root) or not path.is_file():
            raise ValueError("missing/outside artifact: " + name)
        digest = hashlib.sha256()
        with path.open("rb") as stream:
            for block in iter(lambda: stream.read(4194304), b""):
                digest.update(block)
        if digest.hexdigest() != expected:
            raise ValueError("SHA256 mismatch: " + name)
    if args.mode == "verify":
        print(json.dumps({"ok": True, "verified_files": len(files)}))
        sys.exit(0)
    if args.output is None:
        raise ValueError("--output is required")
    if args.output.resolve().is_relative_to(root):
        raise ValueError("choose an output outside the immutable export directory")
    metadata = json.loads((root / "export.json").read_text(encoding="utf-8"))
    if args.mode == "train":
        if not metadata["includes_training_data"]:
            raise ValueError("prediction-only export; export again with --include-data to retrain")
        expected = json.loads((root / "run/environment.json").read_text(encoding="utf-8"))
        if platform.python_version() != expected["python"]:
            raise ValueError("Python version differs from training: " + expected["python"])
        for name, version in expected["packages"].items():
            if name not in {"gpnb", "gsapp"} and importlib.metadata.version(name) != version:
                raise ValueError("dependency version differs: " + name + "==" + version)
        if args.device is not None and args.device != expected["device"]:
            raise ValueError("retraining preserves original device; edit a separate project for a new experiment")
    # Never import an editable GPNB installation outside this bundle.
    source = root / "run/source"
    sys.path.insert(0, str(source))
    os.environ["GPNB_ROOT"] = str(root)
    import importlib
    configure_local_paths = importlib.import_module(namespace + ".paths").configure_local_paths
    if namespace == "gsapp":
        os.environ["GSAPP_ROOT"] = str(root)
    # Use output sibling workspace so the export itself remains immutable.
    workspace = args.output.resolve().parent / (args.output.name + "_workspace")
    if workspace.exists():
        raise ValueError("workspace already exists; choose a new --output")
    workspace.mkdir(parents=True)
    import shutil
    shutil.copytree(root / "run/requirements", workspace / "requirements")
    os.environ["GPNB_ROOT"] = str(workspace)
    if namespace == "gsapp":
        os.environ["GSAPP_ROOT"] = str(workspace)
    configure_local_paths()
    if args.mode == "train":
        if metadata.get("final_refit"):
            final_refit_project = importlib.import_module(namespace + ".training.final_refit").final_refit_project
            result = final_refit_project(root / "project.json", args.output, cache_root=workspace / "cache/genotypes")
        else:
            train_project = importlib.import_module(namespace + ".training.run").train_project
            result = train_project(root / "project.json", args.output, cache_root=workspace / "cache/genotypes")
    else:
        if args.bed is None and args.matrix_config is None:
            raise ValueError("--bed or --matrix-config is required")
        predict_bed = importlib.import_module(namespace + ".prediction").predict_bed
        load_matrix_config = importlib.import_module(namespace + ".data.genotypes").load_matrix_config
        additional_options = {"matrix": load_matrix_config(args.matrix_config) if args.matrix_config else None}
        if args.input_table:
            parse_table_arguments = importlib.import_module(namespace + ".data.additional").parse_table_arguments
            additional_options["input_tables"] = parse_table_arguments(args.input_table)
        prediction_run = root / "run"
        if manifest["kind"] == "exported_cv":
            import inspect
            if "fold" in inspect.signature(predict_bed).parameters:
                additional_options["fold"] = args.fold
            else:
                if args.fold is None:
                    raise ValueError("This historical archive's saved code requires --fold; its behavior is preserved")
                if not 1 <= args.fold <= metadata["folds"]:
                    raise ValueError("fold outside archived range")
                prediction_run = prediction_run / "folds" / ("fold_" + str(args.fold))
        result = predict_bed(prediction_run, args.bed, args.output, bim=args.bim, fam=args.fam,
                             dataset_id=args.dataset_id, device=args.device or "cpu", batch_size=args.batch_size,
                             **additional_options)
    snapshot_package = importlib.import_module(namespace)
    result["runtime_source"] = str(Path(snapshot_package.__file__).resolve())
    print(json.dumps(result, ensure_ascii=False, indent=2))
except Exception as error:
    print(json.dumps({"ok": False, "error": str(error)}, ensure_ascii=False), file=sys.stderr)
    sys.exit(2)
'''


def export_run(bundle, output, *, include_data=False, max_parameter_bytes=256 * 1024**2,
               progress=None, cancelled=None):
    from .training.core import check_cancel
    def stage(name):
        check_cancel(cancelled)
        if progress:
            progress({"event": "stage", "stage": name})
    stage("export_verification")
    bundle, output = Path(bundle).resolve(), Path(output).resolve()
    if output.exists():
        fail("E_EXISTS", str(output), "choose a new export directory")
    protect_inputs(output, [])
    if output.is_relative_to(bundle) or bundle.is_relative_to(output):
        fail("E_IO", str(output), "export and source archive must not overlap")
    if (bundle / 'summary.json').is_file() and read_json(bundle / 'summary.json').get('kind') == 'final_refit':
        from .final_export import export_final_refit
        return export_final_refit(bundle, output, include_data=include_data,
            max_parameter_bytes=max_parameter_bytes, progress=progress, cancelled=cancelled)
    if (bundle / "summary.json").is_file() and read_json(bundle / "summary.json").get("kind") == "cross_validation":
        from .cv_export import export_cv
        return export_cv(bundle, output, include_data=include_data, progress=progress, cancelled=cancelled)
    predictor = Predictor(bundle, max_parameter_bytes=max_parameter_bytes)
    run = predictor.directory
    environment = read_json(run / "environment.json")
    # Legacy A06 archives remain usable for prediction, but a current checkout
    # must not be relabelled as the exact code used for an older training run.
    source_manifest = verify_bundle(run, "training_run")
    source_namespace = _archived_source_namespace(run, source_manifest)
    for name, digest in environment["source_sha256"].items():
        path = safe_member(run / "source" / source_namespace, name)
        if not path.is_file() or sha256(path) != digest:
            fail("E_BUNDLE", str(path), "training-time source snapshot unavailable; create a new A07 run for export")
    required_locks = {"cpu.lock", "cuda.lock"}
    if (run / "requirements/profiles.json").is_file():
        from .environment_profiles import load_profiles
        required_locks.update(profile["lock"] for profile in load_profiles(run)["profiles"].values())
    for name in sorted(required_locks):
        if not (run / "requirements" / name).is_file():
            fail("E_BUNDLE", name, "training-time dependency lock missing")
    descriptor = read_json(run / "prepared/input_descriptor.json")
    files = descriptor["source_files"]
    if include_data:
        verify_snapshots(files)
    output.mkdir(parents=True)
    (output / "INCOMPLETE").write_text("Export in progress\n", encoding="utf-8")
    try:
        # Copy only checksummed members, excluding stray runtime/generated files.
        manifest = verify_bundle(run, "training_run")
        for name in [*manifest["files"], "complete.json"]:
            stage("export_copy")
            target = safe_member(output / "run", name)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(safe_member(run, name), target)
        project = predictor.project.to_dict()
        copies = {}
        if include_data:
            from .data.additional import copy_table_sources
            if predictor.input_states:
                copies["additional"] = copy_table_sources({name: s.value for name, s in predictor.input_states.items()}, project, output)
            for key, record in files.items():
                stage("export_inputs")
                if key not in ("bed", "bim", "fam", "matrix", "phenotype", "manifest", "split_groups"):
                    continue
                origin = Path(record["path"])
                # Preserve each basename (manifest hash keys) without collisions.
                relative = Path("inputs") / key / origin.name
                target = output / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(origin, target)
                if sha256(target) != record["sha256"]:
                    fail("E_CHANGED", str(origin), "input changed during export")
                from .data.genotypes import set_source_path
                set_source_path(project["data"], key, relative.as_posix())
                copies[key] = {"original": record, "portable_path": relative.as_posix(),
                               "byte_identical": True}
            if project["data"]["manifest"] is not None:
                portable = output / project["data"]["manifest"]
                value = read_json(portable)
                if value.get("technical_qc", {}).get("split_groups_file") is not None:
                    # Keep raw original in run/import or in an explicit evidence file.
                    shutil.copyfile(portable, portable.with_name(portable.name + ".original"))
                    import os
                    group = output / project["data"]["split_groups"]
                    value["technical_qc"]["split_groups_file"] = Path(os.path.relpath(group, portable.parent)).as_posix()
                    write_json(portable, value)
                    copies["manifest"].update(byte_identical=False,
                                              change="only technical_qc.split_groups_file rebased; original retained")
            project["run"]["split"]["reuse_manifest"] = "run/prepared/split.json"
            project["output_dir"] = "results"
            ProjectSpec(project).save(output / "project.json")
            verify_snapshots(files)
        (output / "reproduce.py").write_text(REPRODUCE, encoding="utf-8")
        report = {"ok": True, "schema_version": 1, "kind": "exported_run",
                  "includes_training_data": include_data, "source_archive": str(run),
                  "training_source_sha256": environment["source_sha256"], "input_copies": copies,
                  "provenance": predictor.state.metadata["provenance"],
                  "target_interpretation": predictor.summary.get("prediction_interpretation", "input phenotype scale"),
                  "limits": ["Checksums detect accidental corruption, not authenticity.",
                             "No guarantee of bitwise equality across hardware or dependency versions.",
                             "Archive includes sample IDs, phenotypes and paths; review before sharing."]}
        write_json(output / "export.json", report)
        (output / "README.txt").write_text(
            "GPNB portable local export / GPNB 可迁移实验包\n"
            "Use a compatible Python environment; run/requirements contains fixed dependency locks.\n"
            "No GPNB installation or GUI is needed. Python/PyTorch are not embedded.\n"
            "需要兼容 Python 环境；固定依赖锁和环境档位于 run/requirements，无需安装 GPNB 界面。\n"
            "依次可执行校验、预测或重训（重训要求导出时包含训练数据）：\n"
            "python -I reproduce.py verify\n"
            "python -I reproduce.py predict --bed PATH --output NEW_DIRECTORY\n"
            "python -I reproduce.py train --output NEW_DIRECTORY  (requires --include-data export)\n"
            "Outputs must be outside this export; a NEW_DIRECTORY_workspace sibling stores cache/logs.\n"
            "Retraining enforces recorded Python and numerical package versions and the original device.\n"
            "Predictions are on the training phenotype scale, not automatically breeding values.\n"
            "Source inputs and raw cache are unnecessary for prediction; extra markers are reported/ignored.\n"
            "Preserve this directory intact. Hashes are integrity checks, not signatures.\n"
            "输出选择包外的新目录；同级 NEW_DIRECTORY_workspace 存缓存和日志。\n"
            "重训核对记录的 Python、数值库版本及原设备；跨硬件不保证逐位相同。\n"
            "预测为训练表型尺度，不自动等同育种值。预测无需原输入或原缓存，多余标记会报告并忽略。\n"
            "保留包内文件完整；哈希用于完整性检查，并非数字签名。包可能含个体 ID、表型和路径，分享前请审阅。\n",
            encoding="utf-8")
        verify_bundle(output / "run", "training_run")
        stage("export_seal")
        seal(output, "exported_run")
        (output / "INCOMPLETE").unlink()
        return report
    except BaseException as error:
        write_json(output / "failure.json", {"ok": False, "error": str(error)})
        raise
