"""One data-driven environment policy shared by setup, doctor and run archives."""
from __future__ import annotations

import json
from pathlib import Path


def load_profiles(root=None):
    if root is None:
        from .paths import project_root
        root = project_root()
    path = Path(root) / "requirements/profiles.json"
    if not path.is_file():
        # Data/work directories can be relocated independently of installed code.
        path = Path(__file__).resolve().parents[2] / "requirements/profiles.json"
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    if value.get("schema_version") != 1 or not value.get("profiles"):
        raise ValueError(f"Unsupported environment profiles: {path}")
    return value


def profile_ids(root=None):
    return tuple(load_profiles(root)["profiles"])


def get_profile(profile, root=None):
    policy = load_profiles(root)
    if profile not in policy["profiles"]:
        raise ValueError(f"Unknown environment profile {profile!r}")
    return {"id": profile, "python": policy["python"], **policy["profiles"][profile]}


def recommended_profile(drivers, root=None):
    """Advisory only; never changes the configured training device."""
    policy = load_profiles(root)
    versions = []
    for driver in drivers:
        try:
            versions.append(tuple(int(part) for part in driver.strip().split(".")))
        except ValueError:
            continue
    for name in policy["recommendation_order"]:
        profile = policy["profiles"][name]
        threshold = profile["driver_recommendation_min"]
        if threshold is None or (versions and min(versions) >= tuple(map(int, threshold.split(".")))):
            return name
    return policy["default_profile"]
