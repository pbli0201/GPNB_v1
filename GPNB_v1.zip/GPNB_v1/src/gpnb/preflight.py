"""Disposable, train-boundary-aware checks shared by desktop and CLI.

A receipt is evidence of a bounded probe, never a guarantee about full training.
No probe weights or fitted state are passed to the subsequent experiment.
"""
from __future__ import annotations

import copy
import hashlib
import json
import platform
from pathlib import Path

from .config import ModelSpec, ProjectSpec, fail, load_spec, resolve_project_path
from .data.files import protect_inputs, read_json, sha256, snapshot, verify_snapshots, write_json
from .training.events import tracked_operation, enrich


def resolved_project(path):
    from .data.additional import resolve_table_paths
    value = load_spec(path).to_dict()
    resolve_table_paths(value, path)
    for key in ('bed', 'bim', 'fam', 'phenotype', 'manifest', 'split_groups'):
        if value['data'][key] is not None:
            value['data'][key] = str(resolve_project_path(path, value['data'][key]))
    value['output_dir'] = str(resolve_project_path(path, value['output_dir']))
    for config in (value['run']['split'], value['run'].get('extensions', {}).get('cross_validation', {})):
        if config.get('reuse_manifest'):
            config['reuse_manifest'] = str(resolve_project_path(path, config['reuse_manifest']))
    return value


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False).encode()).hexdigest()


def computation_digest(value):
    """Only fields proven irrelevant to numerical checks may be ignored."""
    current = copy.deepcopy(value)
    current.pop('output_dir', None)
    current.pop('name', None)
    return digest(current)


def source_files(value, path):
    from .data.genotypes import source_paths
    paths = source_paths(value['data'], path)
    for item in value.get('extensions', {}).get('input_tables', []):
        paths['input:' + item['id']] = resolve_project_path(path, item['path'])
    for key, config in (('split', value['run']['split']), ('cv', value['run'].get('extensions', {}).get('cross_validation', {}))):
        if config.get('reuse_manifest'):
            paths[key] = resolve_project_path(path, config['reuse_manifest'])
    return paths


def code_digest():
    package = Path(__file__).parent
    return digest({p.relative_to(package).as_posix(): sha256(p) for p in sorted(package.rglob('*.py'))})


def environment():
    import importlib.metadata
    return dict(python=platform.python_version(), packages={name: importlib.metadata.version(name)
                for name in ('torch', 'numpy', 'psutil')})


def verify_preflight(project_path, report_path, *, quick=False, value=None, max_parameter_bytes=256 * 2**20):
    """GUI uses cheap stat checks; the worker always checks full source hashes."""
    report = read_json(Path(report_path))
    value = value if value is not None else resolved_project(project_path)
    if (report.get('kind') != 'preflight' or not report.get('ok') or report.get('schema_version') != 1
            or (computation_digest(value) != report['computation_digest'] if 'computation_digest' in report
                else digest(value) != report.get('project_digest'))
            or max_parameter_bytes != report.get('max_parameter_bytes')):
        fail('E_PREFLIGHT', 'configuration', 'configuration changed or no successful preflight; run checks again')
    if quick:
        for item in report['sources'].values():
            stat = Path(item['path']).stat()
            if (stat.st_size, stat.st_mtime_ns) != (item['bytes'], item['mtime_ns']):
                fail('E_PREFLIGHT', item['path'], 'input changed; run checks again')
    else:
        verify_snapshots(report['sources'])
        if code_digest() != report['code_digest'] or environment() != report['environment']:
            fail('E_PREFLIGHT', 'environment', 'code or dependency versions changed; run checks again')
    return report


def _probe(data, project, project_path, stage, cancelled, max_parameter_bytes, checking):
    import torch
    from .data.additional import fit_tables
    from .graphs.state import fit_graph
    from .graphs.individual import fit_reference
    from .models.core import build_model, inspect_model, check_execution, check_budget
    from .training.core import effective_training, execution_context, _inputs, _targets, loss_for_data, check_cancel
    from .training.stages import configure_frozen, objective_components
    from .data.kernel_features import bind_kernel
    checking('branches', 'running')
    spec = bind_kernel(project, data, progress=stage, cancelled=cancelled)
    config = effective_training(project['run']['training'], spec)
    _, data.additional_inputs, _ = fit_tables(project, project_path, data)
    if getattr(data, 'kernel_state', None) is not None:
        # Check queries without touching their labels or changing reference state.
        from .data.kernel_features import transform_inputs
        for part in ('train', 'validation', 'test'):
            partition_rows = data.split.rows(part)
            actual_rows = min(config['batch_size'], len(partition_rows))
            required_bytes = actual_rows * data.kernel_state.reference_count * 4
            if required_bytes > data.kernel_state.recipe['max_matrix_bytes']:
                fail('E_MODEL_LIMIT', 'kernel.' + part,
                     f'Actual batch kernel output needs {required_bytes} bytes; reduce batch_size or raise max_matrix_bytes')
            probe_batch = min(64, config['batch_size'])
            for offset in range(0, len(partition_rows), probe_batch):
                check_cancel(cancelled)
                transform_inputs(data, data.cache.batch(partition_rows[offset:offset+probe_batch]),
                                 spec.to_dict().get('input_representation', 'standardized_dosage'))
    data.graph_state = fit_graph(spec, data, stage, cancelled)
    data.reference_state, data.reference_features = fit_reference(spec, data, cancelled)
    data.reference_spec = spec.to_dict().get('individual_graph_spec')
    checking('branches', 'passed')
    checking('model', 'running')
    plan = inspect_model(spec, data.input_features, graph_state=data.graph_state, reference_state=data.reference_state)
    check_budget(plan, max_parameter_bytes)
    train = data.split.rows('train')
    check_execution(plan, config['device'], config['deterministic'], config['batch_size'], len(train))
    checking('model', 'passed')
    checking('numerical', 'running')
    # Probe at most four real training individuals, preserving a legal singleton batch.
    rows = train[:min(4, config['batch_size'], len(train))]
    losses = []
    with execution_context(config) as device:
        model = build_model(spec, data.input_features, seed=config['seed'], max_parameter_bytes=max_parameter_bytes,
            graph_state=data.graph_state, reference_state=data.reference_state, reference_data=data.reference_features).to(device)
        for training_stage in config.get('stages', [None]):
            check_cancel(cancelled)
            model.train()
            if training_stage:
                configure_frozen(model, training_stage['freeze'])
            parameters = [p for p in model.parameters() if p.requires_grad]
            if not parameters:
                fail('E_PREFLIGHT', 'parameters', 'no trainable parameters')
            from .training.objectives import make_optimizer
            optimizer = make_optimizer(parameters, config)
            optimizer.zero_grad(set_to_none=True)
            loss = (objective_components(model, data, rows, device, training_stage)[0] if training_stage else
                    loss_for_data(model(_inputs(data, rows, device, model)), _targets(data, rows, device), data, config))
            if not torch.isfinite(loss) or not loss.requires_grad:
                fail('E_PREFLIGHT', 'loss', 'nonfinite loss or no trainable path')
            loss.backward()
            if any(p.grad is not None and not torch.isfinite(p.grad).all() for p in parameters):
                fail('E_PREFLIGHT', 'gradient', 'nonfinite gradients')
            optimizer.step()
            if any(not torch.isfinite(p).all() for p in parameters):
                fail('E_PREFLIGHT', 'parameters', 'optimizer produced nonfinite parameters')
            losses.append(float(loss.detach()))
    checking('numerical', 'passed')
    return dict(input_features=data.input_features, probe_rows=list(map(int, rows)),
                kernel_reference_rows=list(map(int, train)) if getattr(data, 'kernel_state', None) else None,
                probe_steps=len(losses), finite_loss=True, effective_training=config,
                parameters=plan['parameters'], parameter_bytes=plan['parameter_bytes'],
                configured_batch_size=config['batch_size'])


@tracked_operation('preflight')
def preflight_project(project_path, output, *, cache_root=None, max_parameter_bytes=256 * 2**20,
                      progress=None, cancelled=None, _preview=None):
    from .data.preview import preview_split
    from .data.prepare import prepare_project, PreparedDataset
    from .data.split import SplitManifest
    from .data.folds import fold_value
    from .training.core import check_cancel, validate_training
    from .training.search import candidates, apply_candidate, selection_partitions
    from .data.preprocessing import PreprocessorState
    from .data.multitask import fit_target_state
    import psutil
    project_path, output = Path(project_path).resolve(), Path(output).resolve()
    value = resolved_project(project_path)
    if value.get('extensions', {}).get('trait_batch'):
        from .training.trait_batch import run_batch
        return run_batch(project_path, output, operation='preflight', cache_root=cache_root,
                         max_parameter_bytes=max_parameter_bytes, progress=progress, cancelled=cancelled)
    if output.exists():
        fail('E_EXISTS', str(output), 'choose a new check directory')
    paths = source_files(value, project_path)
    protect_inputs(output, [project_path, *paths.values()])
    process = psutil.Process()
    threads = len(process.cpu_affinity()) if hasattr(process, 'cpu_affinity') else psutil.cpu_count()
    output.mkdir(parents=True)
    (output / 'INCOMPLETE').write_text('Preflight in progress', encoding='utf-8')
    def stage(name, done=0, total=0):
        check_cancel(cancelled)
        if progress:
            progress(dict(event='stage', stage=name, done=done, total=total))
    items = {key: dict(key=key, status='pending', detail='') for key in
             ('inputs', 'device', 'partitions', 'preprocessing', 'branches', 'model', 'numerical', 'binding')}
    active = 'inputs'
    def checking(key, status, detail=''):
        nonlocal active
        active = key
        items[key].update(status=status, detail=detail)
        if progress:
            progress(dict(event='preflight_check', **items[key]))
    try:
        checking('inputs', 'running')
        originals = {k: snapshot(Path(p)) for k, p in paths.items()}
        original_project = snapshot(project_path)
        source_hash = code_digest()
        checking('inputs', 'passed')
        checking('device', 'running')
        validate_training(value['run']['training'])
        if value['run']['training']['threads'] > threads:
            fail('E_PREFLIGHT', 'threads', f'requested threads exceed available logical CPUs ({threads})')
        import torch
        device_info = dict(requested=value['run']['training']['device'], cuda_available=torch.cuda.is_available())
        if device_info['requested'] == 'cuda':
            device_info.update(name=torch.cuda.get_device_name(0), capability=list(torch.cuda.get_device_capability(0)),
                               total_memory_bytes=torch.cuda.get_device_properties(0).total_memory)
        checking('device', 'passed')
        ProjectSpec(value).save(output / 'project.json')
        checking('partitions', 'running')
        if _preview is None:
            preview = preview_split(output / 'project.json', output / 'partitions', cache_root=cache_root,
                                    progress=progress, cancelled=cancelled)
        else:
            # This private fast path is only available inside a shared batch job.
            from .data.shared import current as shared_current
            if shared_current() is None:
                fail('E_PREFLIGHT', 'shared_preview', 'shared preview requires its active batch context')
            saved = copy.deepcopy(_preview['project'])
            requested = copy.deepcopy(value)
            for item in (saved, requested):
                item['run'].get('extensions', {}).get('cross_validation', {}).pop('approved_folds', None)
            if saved != requested:
                fail('E_PREFLIGHT', 'shared_preview', 'preview configuration changed')
            preview = _preview
        plan = read_json(Path(preview['plan']))['manifest']
        cv = value['run'].get('extensions', {}).get('cross_validation')
        if cv and cv.get('method', 'five_fold').startswith('leave_one') and cv.get('approved_folds') != preview['models']:
            fail('E_PREFLIGHT', 'approved_folds', f"preview and acknowledge {preview['models']} leave-out fits first")
        checking('partitions', 'passed')
        records = []
        for fold in range(1, preview['models'] + 1):
            stage('preflight_fold', fold, preview['models'])
            current = copy.deepcopy(value)
            current['run'].setdefault('extensions', {}).pop('cross_validation', None)
            split = SplitManifest(fold_value(plan, fold)) if cv else SplitManifest(plan)
            split_path = output / f'fold_{fold}' / 'split.json'
            split_path.parent.mkdir()
            split.save(split_path)
            current['run']['split'].update(seed=cv['seed'] if cv else current['run']['split']['seed'],
                ratios=split.value['requested_ratios'], reuse_manifest=str(split_path))
            if not len(split.rows('validation')):
                current['run']['training']['selection_mode'] = 'fixed_epochs'
            path = split_path.parent / 'project.json'
            ProjectSpec(current).save(path)
            checking('preprocessing', 'running')
            prepare_project(path, Path(preview['plan']).parent / 'import', split_path.parent / 'prepared', progress=stage)
            data = PreparedDataset.load(split_path.parent / 'prepared')
            search = current['run'].get('extensions', {}).get('search')
            choices = list(candidates(search)) if search else [None]
            # Search preprocessing is fitted again on its exact inner training rows.
            selection = copy.copy(data)
            if search:
                selection.split = SplitManifest({**data.split.value, 'partitions': selection_partitions(data, search)})
                train, validation = selection.split.rows('train'), selection.split.rows('validation')
                multi = hasattr(data, 'target_state')
                selection.state = PreprocessorState.fit(data.cache, train,
                    None if multi else [float(data.samples[i]['value']) for i in train], data.state.metadata['input_markers'],
                    current['run']['preprocessing'], provenance=data.state.metadata['provenance'], progress=stage)
                if multi:
                    context = data.split.value['context']
                    selection.target_state = fit_target_state(data.target_values, train, validation, current,
                        context['sample_ids'], context['phenotype_sha256'])
                write_json(split_path.parent / 'search_partitions.json', selection.split.value['partitions'])
            checking('preprocessing', 'passed')
            passed = 0
            for trial, params in enumerate(choices, 1):
                stage('preflight_candidate', trial, len(choices))
                record = dict(fold=fold, candidate=trial, parameters=params, ok=False)
                try:
                    checking('model', 'running')
                    candidate = apply_candidate(current, params) if params is not None else current
                    record['probe'] = _probe(selection, candidate, path, stage, cancelled, max_parameter_bytes, checking)
                    # Also validate final N-1 refit shape and batch remainder when inner search differs.
                    if search and not len(data.split.rows('validation')):
                        record['refit_probe'] = _probe(data, candidate, path, stage, cancelled, max_parameter_bytes, checking)
                    record['ok'] = True
                    passed += 1
                except (ValueError, RuntimeError) as error:
                    if getattr(error, 'code', '') == 'E_CANCELLED' or not search:
                        raise
                    record['error'] = str(error)
                records.append(record)
                write_json(output / 'checks.json', records)
            if not passed:
                fail('E_PREFLIGHT', f'fold {fold}', 'no search candidate passed; see checks.json')
            # Some invalid search candidates may be skipped, exactly as in formal search.
            checking('model', 'passed' if passed == len(choices) else 'warning',
                     '' if passed == len(choices) else f'{passed}/{len(choices)} candidates passed; see checks.json')
        checking('binding', 'running')
        verify_snapshots({'project': original_project, **originals})
        if source_hash != code_digest():
            fail('E_CHANGED', 'source', 'code changed during checks; retry after edits finish')
        checking('binding', 'passed')
        report = dict(kind='preflight', schema_version=1, ok=True, project_digest=digest(value), computation_digest=computation_digest(value),
            sources=originals, code_digest=source_hash, environment=environment(),
            max_parameter_bytes=max_parameter_bytes, folds=preview['models'], checks=records,
            available_threads=threads, available_memory_bytes=psutil.virtual_memory().available,
            device=device_info, items=list(items.values()),
            disk_free_bytes=psutil.disk_usage(str(output)).free,
            scope='Actual data, every fold and candidate; train-only preprocessing; at most 4 training rows per numerical probe. No test loss, model ranking, time estimate or full-training guarantee.',
            failed_candidates=sum(not r['ok'] for r in records), formal_training_refits_from_scratch=True)
        write_json(output / 'summary.json', report)
        (output / 'INCOMPLETE').unlink()
        return report
    except BaseException as error:
        checking(active, 'failed', str(error))
        write_json(output / 'failure.json', dict(ok=False, error=str(error), items=list(items.values())))
        raise
