"""One CV archive with five frozen predictors and optional shared training inputs."""
import os
import shutil
from pathlib import Path

from .bundle import safe_member, seal, verify_bundle
from .config import ProjectSpec, fail
from .data.files import read_json, sha256, verify_snapshots, write_json


def export_cv(bundle, output, *, include_data, progress=None, cancelled=None):
    from .exporting import REPRODUCE, _archived_source_namespace
    from .training.core import check_cancel
    bundle, output = Path(bundle).resolve(), Path(output).resolve()
    manifest = verify_bundle(bundle, "cross_validation", required=(
        "summary.json", "environment.json", "project.json", "cv_plan.json"))
    source_namespace = _archived_source_namespace(bundle, manifest)
    descriptor = read_json(bundle / "import/descriptor.json")
    if include_data:
        verify_snapshots(descriptor["source_files"])
    output.mkdir(parents=True)
    (output / "INCOMPLETE").write_text("CV export incomplete", encoding="utf-8")
    try:
        for name in [*manifest["files"], "complete.json"]:
            check_cancel(cancelled)
            target = safe_member(output / "run", name)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(safe_member(bundle, name), target)
        project = read_json(bundle / "project.json")
        copies = {}
        if include_data:
            if project.get("extensions", {}).get("input_tables"):
                from .data.additional import copy_table_sources
                states = read_json(bundle/"folds/fold_1/input_states.json")
                copies["additional"] = copy_table_sources(states, project, output)
            for key, record in descriptor["source_files"].items():
                if key not in ("bed", "bim", "fam", "matrix", "phenotype", "manifest", "split_groups"):
                    continue
                check_cancel(cancelled)
                origin = Path(record["path"])
                relative = Path("inputs") / key / origin.name
                target = output / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(origin, target)
                if sha256(target) != record["sha256"]:
                    fail("E_CHANGED", str(origin), "input changed during CV export")
                from .data.genotypes import set_source_path
                set_source_path(project["data"], key, relative.as_posix())
                copies[key] = dict(original=record, portable_path=relative.as_posix())
            if project["data"]["manifest"]:
                path = output / project["data"]["manifest"]
                value = read_json(path)
                if value.get("technical_qc", {}).get("split_groups_file") is not None:
                    shutil.copyfile(path, path.with_name(path.name + ".original"))
                    group = output / project["data"]["split_groups"]
                    value["technical_qc"]["split_groups_file"] = Path(os.path.relpath(group, path.parent)).as_posix()
                    write_json(path, value)
            project["run"]["extensions"]["cross_validation"]["reuse_manifest"] = "run/cv_plan.json"
            project["run"]["split"]["reuse_manifest"] = None
            project["output_dir"] = "runs"
            ProjectSpec(project).save(output / "project.json")
            verify_snapshots(descriptor["source_files"])
        (output / "reproduce.py").write_text(REPRODUCE, encoding="utf-8")
        ensemble_capable = f"source/{source_namespace}/prediction_sources.py" in manifest["files"]
        report = dict(ok=True, schema_version=1, kind="exported_cv", includes_training_data=include_data,
                      folds=read_json(bundle / "summary.json")["folds"], source_archive=str(bundle), input_copies=copies,
                      prediction=("All members equally averaged after inverse target transforms; --fold selects one member explicitly."
                                  if ensemble_capable else "Historical saved code requires --fold; its original behavior is preserved."),
                      limits=["Requires a compatible Python/PyTorch environment.",
                              "Contains sample IDs, phenotype records and paths. No public upload performed."])
        write_json(output / "export.json", report)
        (output / "README.txt").write_text(
            "GPNB cross-validation export / GPNB 交叉验证实验包\npython -I reproduce.py verify\n"
            + ("python -I reproduce.py predict --bed INPUT.bed --output NEW_DIRECTORY\n" if ensemble_capable else
               "python -I reproduce.py predict --fold 1 --bed INPUT.bed --output NEW_DIRECTORY\n") +
            "python -I reproduce.py train --output NEW_DIRECTORY (requires included training data)\n"
            "Inputs are copied once and shared by all folds. OOF is evaluation, not a single fitted model.\n"
            "需要兼容 Python 环境；依赖锁与环境档在 run/requirements。输入仅复制一份供各折共用。\n"
            "以上命令依次为校验、预测、重训；重训要求导出包含训练数据。输出请选择新的目录。\n"
            "OOF 用于评估，不能视为单个已拟合模型。预测默认对各成员反变换后的预测等权平均；--fold 可指定单折。\n"
            "旧版本归档若仅支持单折，以本文件显示的命令为准。此包可能含个体 ID、表型和路径，分享前请审阅。\n",
            encoding="utf-8")
        check_cancel(cancelled)
        seal(output, "exported_cv")
        (output / "INCOMPLETE").unlink()
        return report
    except BaseException as error:
        write_json(output / "failure.json", dict(ok=False, error=str(error)))
        raise
