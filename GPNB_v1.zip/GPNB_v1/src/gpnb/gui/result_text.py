"""Selected-language result captions; stored metrics and scientific IDs stay intact."""
import json
from pathlib import Path


def model_info(window, project, output):
    t = window.tr_pair
    value = (f"{project['name']} · {project['data']['phenotype_options']['trait']}\n" +
             t("模型包：", "Model package: ") + str(output) + "\n" +
             t("必需的额外输入：", "Required additional inputs: ") +
             ", ".join(project["model"].get("external_inputs", {})))
    targets = project.get("extensions", {}).get("multitask", {}).get("targets", [])
    if targets:
        value += "\n" + t("目标：", "Targets: ") + "; ".join(
            f"{r['id']} · {r['trait']} · {r['environment']} · {r['unit']}" for r in targets)
    return value


def deployment_info(window, description):
    """Deployment metadata never borrows or invents an independent test score."""
    t = window.tr_pair
    methods = {'fixed_split': ('固定划分', 'Fixed split'), 'fixed': ('固定划分', 'Fixed split'),
        'five_fold': ('五折', 'Five-fold'), 'ten_fold': ('十折', 'Ten-fold'),
        'leave_one_individual_out': ('留一法', 'Leave-one-individual-out'),
        'leave_one_genotype_group_out': ('旧版留组', 'Legacy leave-group-out'),
        'full_data_final': ('全数据最终重训', 'Final full-data refit'), 'final_refit': ('全数据最终重训', 'Final full-data refit')}
    origin = description.get('origin_method', description.get('source_kind', ''))
    origin = t(*methods.get(origin, (origin, origin)))
    count = description.get('member_count', 1)
    text = str(description.get('name', 'GPNB_v1')) + '\n' + t('训练来源：', 'Training origin: ') + origin
    text += '\n' + t(f'模型成员：{count}；每批新个体需要运行 {count} 个模型。',
        f'Model members: {count}; each query batch runs {count} models.')
    size = description.get('model_bytes')
    if isinstance(size, (int, float)):
        text += t(f' 成员权重占用 {size / 2**20:.2f} MiB（包内另有预处理等文件）。', f' Member weights occupy {size / 2**20:.2f} MiB (the package also stores preprocessing and other files).')
    if count > 1:
        text += '\n' + t('各成员独立预处理，并先恢复目标原单位再等权平均；不省略成员。',
            'Each member applies its own preprocessing and inverse target transform before an equal average; no member is omitted.')
    targets = description.get('targets', [])
    if targets:
        def target_text(target):
            values = []
            for key in ('id', 'trait', 'environment', 'unit'):
                value = target.get(key)
                if value:
                    values.append(t('未注明', 'Unspecified') if key in ('environment', 'unit') and value == 'unspecified' else str(value))
            return ' · '.join(values)
        text += '\n' + t('目标：', 'Targets: ') + '; '.join(target_text(target) for target in targets)
    names = list(description.get('required_input_tables', {}))
    text += '\n' + t('必需输入：基因型', 'Required input: genotypes')
    if names: text += t('；额外数值表：', '; additional numeric tables: ') + ', '.join(names)
    scope = description.get('graph_scope')
    if scope:
        scopes = {'transductive_fixed_cohort': ('仅限既定图内个体；不接受未知新个体', 'Fixed graph cohort only; unknown new individuals are not supported'),
            'new_individuals': ('支持新个体；仍须核对输入协议', 'New individuals supported, subject to input checks'),
            'inductive': ('使用冻结训练参考图预测新个体', 'New individuals use the frozen training reference graph')}
        text += '\n' + t('适用范围：', 'Prediction scope: ') + t(*scopes.get(scope, (str(scope), str(scope))))
    return text


def metric_line(window, metrics):
    def number(key):
        value = metrics.get(key)
        return "—" if value is None else f"{value:.6g}"
    text = f"n={metrics['n']} · Pearson={number('pearson')} · RMSE={number('rmse')} · MAE={number('mae')}"
    reason = metrics.get("pearson_reason")
    explanations = {"no_samples": ("没有有效观测", "No finite observations"),
                    "fewer_than_two_samples": ("少于两个样本", "Fewer than two samples"),
                    "constant_observed": ("观测值恒定", "Observed values are constant"),
                    "constant_prediction": ("预测值恒定", "Predictions are constant")}
    if reason:
        text += "\nPearson: " + window.tr_pair(*explanations.get(reason, (reason, reason)))
    return text


def fold_summary_line(window, stats):
    if not stats:
        return window.tr_pair("本版本未记录折间汇总；可从逐折结果查看。", "This version did not record a fold summary; inspect individual folds.")
    t = window.tr_pair
    if stats.get("reason") == "leave_out_use_pooled_oof":
        return t("留一法报告合并 OOF 指标；单个体测试没有 Pearson 或折间 Pearson SD。",
                 "Leave-one-out reports pooled OOF metrics; a single test individual has no Pearson or fold Pearson SD.")
    if stats.get("reason") == "leave_group_use_pooled_oof":
        return t("旧版留组协议报告合并 OOF 指标，不汇总逐组 Pearson SD；一个留出组可能含多个个体。",
                 "Legacy leave-group-out reports pooled OOF metrics without a group Pearson SD summary; a held-out group may contain several individuals.")
    def number(key):
        value = stats.get(key)
        return "—" if value is None else f"{value:.6g}"
    return t("外层测试逐折 Pearson：均值 ", "Outer-test fold Pearson: mean ") + number("mean") + t(" · 样本 SD ", " · sample SD ") + number("sample_sd") + \
        t(f" · 有效折 {stats['valid_folds']}/{stats['total_folds']}（ddof=1）\n仅描述折间波动；不是独立重复实验或置信区间。",
          f" · valid folds {stats['valid_folds']}/{stats['total_folds']} (ddof=1)\nDescriptive fold variation; not independent repetitions or a confidence interval.")


def format_result(window, result, split_counts=None):
    t = window.tr_pair
    output, summary = Path(result["output"]), result["summary"]
    if summary.get('kind')=='trait_batch':
        from .result_pages import format_batch
        return str(output)+'\n'+format_batch(window,summary)
    if summary.get('kind') in ('training_run','cross_validation'):
        text=str(summary.get('dataset_id',''))+' · '+str(summary.get('trait',''))+' · '+t('已完成','Completed')
        if summary.get('evaluation_status')=='no_independent_test_set':text+='\n'+t('没有独立测试集；用于最终预测或内部选择。','No independent test set; final prediction or internal selection only.')
        elif summary['kind']=='cross_validation':text+='\n'+t('默认展示合并 OOF；每个体一次外测，配置请逐折查看。','Pooled OOF by default: one outer test per individual; inspect actual settings per fold.')
        return text+'\n'+str(output)
    if summary.get('kind') in ('model_package', 'prediction_model_package', 'final_refit', 'final_model', 'final_training'):
        text = t('可用于预测的模型。', 'Model available for prediction.')
        if summary.get('kind') not in ('model_package', 'prediction_model_package'):
            text += '\n' + t('内部验证选择参数和轮数，再在全部合格训练个体上重拟合；没有新的独立测试分数。',
                'Internal validation selects settings and epochs, followed by refitting on all eligible training individuals; no new independent test score is reported.')
        if result.get('model_description'):
            text += '\n' + deployment_info(window, result['model_description'])
    elif result["kind"] in ("train", "view") and summary.get("kind") == "cross_validation":
        text = (f"{summary['dataset_id']} · {summary['trait']} · " +
                t(f"{summary['folds']} 折", f"{summary['folds']} folds") + "\nOOF " +
                metric_line(window, summary["oof_metrics"]) + "\n" +
                t("外层测试预测汇总；每折预处理与训练独立。OOF 结果不是单个模型。", "Outer-test predictions; preprocessing and training are independent per fold. OOF is not one model."))
        text += "\n" + fold_summary_line(window, summary.get("fold_pearson"))
        text += "\n" + t("在下方选择性状和折，查看逐折结果；训练记录不跨折合并。",
                          "Choose a target and fold below for individual results; training records are never pooled across folds.")
    elif summary.get('kind') == 'training_run' and summary.get('evaluation_status') == 'no_independent_test_set':
        text = f"{summary['dataset_id']} · {summary['trait']}\n"
        text += t('没有独立测试集；不报告测试准确性。', 'No independent test set; no test accuracy is reported.')
        if summary.get('best_validation_mse') is None:
            text += '\n' + t('这是用于预测的全数据最终模型。下方仅展示训练拟合，不代表对新个体的泛化能力。',
                'This is the final full-data model for deployment. The view below shows training fit only, not generalization to new individuals.')
        else:
            text += '\n' + t('这是最终重训前的内部选择模型；验证结果参与参数或轮数选择，不能作为独立测试。',
                'This model performs internal selection before final refitting. Validation helped select settings or epochs and is not an independent test.')
        text += '\n' + t('输入维度 / 选定轮次 / 实际轮数：', 'Input features / selected epoch / epochs run: ')
        text += f"{summary['input_features']} / {summary['best_epoch']} / {summary['epochs_ran']}"
    elif result["kind"] in ("train", "view") and summary.get('kind') == 'training_run':
        text = (f"{summary['dataset_id']} · {summary['trait']} · " +
                t(f"种子 {summary['seed']} · 折 {summary['fold']}", f"seed {summary['seed']} · fold {summary['fold']}") + "\n" +
                t("输入维度 / 最佳轮次 / 实际轮数：", "Input features / best epoch / epochs run: ") +
                f"{summary['input_features']} / {summary['best_epoch']} / {summary['epochs_ran']}\n" +
                t("测试集：", "Test: ") + metric_line(window, summary["test_metrics"]) + "\n" +
                t("输入表型量纲；不自动等于育种值。", "Input phenotype scale; not automatically breeding values."))
        if split_counts is not None:
            text += "\n" + t("实际划分人数：", "Actual split counts: ") + json.dumps(split_counts, ensure_ascii=False)
        resource = summary["resources"]
        text += "\n" + t(f"耗时：{resource['elapsed_seconds']:.2f} 秒 · 抽样峰值 RSS：{resource['rss_sampled_peak_bytes']/2**20:.1f} MiB",
                         f"Elapsed: {resource['elapsed_seconds']:.2f} s · sampled peak RSS: {resource['rss_sampled_peak_bytes']/2**20:.1f} MiB")
        if summary.get("individual_graph"):
            text += "\n" + t("个体参考图：", "Individual reference graph: ") + json.dumps(summary["individual_graph"], ensure_ascii=False)
        if summary.get("search"):
            search = summary["search"]
            text += "\n" + t(f"搜索：{search['method']} · 选中候选 {search['selected_trial']} · 完成 {search['completed']} · 失败 {search['failed']}",
                             f"Search: {search['method']} · selected trial {search['selected_trial']} · completed {search['completed']} · failed {search['failed']}") + "\n" + str(output / "search")
        if summary.get("warnings"):
            # These are archived diagnostics, not UI translations or altered evidence.
            text += "\n" + t("运行记录提示：", "Archived run diagnostics: ") + "\n" + "\n".join(summary["warnings"])
    else:
        text = json.dumps(summary, ensure_ascii=False, indent=2)
    if summary.get("multitask"):
        text += "\n" + t("各目标指标（原始单位，不跨性状混合）：", "Per-target metrics (original units; no pooling across traits):")
        for target, metrics in summary.get("test_metrics_by_target", summary.get("oof_metrics_by_target", {})).items():
            text += "\n" + target + ": " + metric_line(window, metrics)
            if target in summary.get("fold_pearson_by_target", {}):
                text += "\n" + fold_summary_line(window, summary['fold_pearson_by_target'][target])
    timing = summary.get("timing")
    if timing:
        from ..results import TIMING_FIELDS
        text += "\n" + t("实测耗时（秒）：", "Measured time (seconds): ") + "; ".join(
            t(zh, en) + f" {timing[key]:.3f}" for key, zh, en in TIMING_FIELDS if key in timing)
        if timing.get("scope") == "joint_multi_target":
            text += "\n" + t("这是多性状共享训练的联合耗时，未分摊为每性状耗时。", "This is joint multi-target time, not an allocated per-trait time.")
    return str(output) + "\n" + text


def prediction_info(window, output, summary):
    text = str(output) + "\n" + window.tr_pair(
        f"个体数：{summary['samples']} · 未重新拟合 · 输入表型量纲",
        f"Samples: {summary['samples']} · no refitting · input phenotype scale")
    count = summary.get('member_count', summary.get('model_members'))
    if isinstance(count, int) and count > 1:
        text += '\n' + window.tr_pair(f'集成成员：{count}；分歧列仅描述模型间变化。', f'Ensemble members: {count}; disagreement columns describe between-model variation only.')
    text += '\n' + window.tr_pair('新个体评分仅使用身份已核实且未参与任何成员训练、选择或固定图构建的记录；已见与身份待核对者单独列出。',
        'New-individual scoring uses only confirmed individuals unseen by every member training, selection or fixed graph; seen and uncertain records are listed separately.')
    names = {'confirmed_unseen': ('确认未见个体', 'Confirmed unseen'), 'seen_training': ('参与训练', 'Seen in training'),
        'seen_selection': ('参与内部验证/选择', 'Seen in validation/selection'),
        'seen_graph_context': ('已用于固定图构建', 'Seen in fixed graph context'), 'identity_uncertain': ('身份待核对', 'Identity uncertain')}
    counts = summary.get('identity', {}).get('counts', {})
    if counts:
        text += '\n' + '; '.join(window.tr_pair(*names.get(key, (key, key))) + f': {value}' for key, value in counts.items())
    scoring = summary.get('scoring')
    if scoring:
        for target, data in scoring.get('targets', {}).items():
            text += '\n' + str(target) + ' · ' + window.tr_pair('确认新个体评分：', 'Confirmed new-individual scores: ') + metric_line(window, data['new_individual_metrics'])
            for status, metrics in data.get('other_identity_groups', {}).items():
                if metrics['n']:
                    text += '\n' + window.tr_pair(*names.get(status, (status, status))) + window.tr_pair('（单列，不是新个体评价）：', ' (separate, not new-individual evaluation): ') + metric_line(window, metrics)
        text += '\n' + window.tr_pair('完整匹配和评分明细见输出报告。', 'Full matching and scoring details are in the output report.')
    return text


def draw_history(flow):
    """Rebuild only the visible curve, retaining epoch records unchanged."""
    w = flow.window
    flow.axes.clear()
    if not flow.history:
        flow.canvas.draw_idle()
        return
    t = w.tr_pair
    epochs = [r["epoch"] for r in flow.history]
    flow.axes.plot(epochs, [r.get("train_loss",r.get("train_online_mse")) for r in flow.history], marker=".", label=t("训练（在线）", "Training (online)"))
    if any(r.get("validation_loss",r.get("validation_mse")) is not None for r in flow.history):
        flow.axes.plot(epochs, [r.get("validation_loss",r.get("validation_mse")) for r in flow.history], marker=".", label=t("验证", "Validation"))
    objective=flow.history[-1].get('loss_name',w.document.value['run']['training'].get('loss','mse')).upper()
    ylabel=t('加权阶段目标','Weighted stage objective') if 'stage' in flow.history[-1] else t('加权掩码目标 ','Weighted masked objective ') + objective if w.document.value['model'].get('task')=='multi_target_regression' else objective+t('（训练目标量纲）',' (training target scale)')
    flow.axes.set(xlabel=t("轮次", "Epoch"), ylabel=ylabel)
    event=flow.history[-1]
    identity=[str(event.get('trait',getattr(flow,'current_context',{}).get('trait','')))]
    if event.get('joint_target_ids'):identity=[t('联合目标共享损失：','Joint-target shared loss: ')+', '.join(event['joint_target_ids'])]
    for key,zh,en in (('fold','外层折','Outer fold'),('trial','搜索试验','Search trial'),('stage','阶段','Stage')):
        if event.get(key) is not None:identity.append(t(zh,en)+' '+str(event[key]))
    flow.axes.set_title(' · '.join(x for x in identity if x),fontsize=10)
    from matplotlib.font_manager import FontProperties
    font_path = Path("C:/Windows/Fonts/msyh.ttc")
    font = FontProperties(fname=str(font_path)) if font_path.is_file() else FontProperties()
    flow.axes.xaxis.label.set_fontproperties(font)
    flow.axes.yaxis.label.set_fontproperties(font)
    flow.axes.title.set_fontproperties(font)
    flow.axes.legend(prop=font)
    flow.canvas.draw_idle()
