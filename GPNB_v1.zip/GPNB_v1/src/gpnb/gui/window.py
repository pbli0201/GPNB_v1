from __future__ import annotations

import json
import sys
import uuid
from pathlib import Path

from PySide6.QtCore import QByteArray, QProcess, Qt
from PySide6.QtGui import QCloseEvent
from PySide6.QtSvgWidgets import QSvgWidget
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QDialog, QFileDialog, QFormLayout, QFrame,
    QHBoxLayout, QLabel, QLineEdit, QMainWindow, QMessageBox, QPushButton,
    QScrollArea, QSpinBox, QSplitter, QTabWidget, QVBoxLayout, QWidget, QPlainTextEdit, QTextBrowser,
)

from ..config import ModelSpec
from ..branding import APP_NAME
from ..data.files import protect_inputs, read_json, write_json
from ..data.tables import text_table
from ..errors import GPNBError
from ..models.registry import COMPONENTS
from ..models.expansion import EXPANDABLE
from ..models.export import structure_svg
from ..paths import configure_local_paths
from .document import Document
from .appearance import configure_appearance
from .workflow import Workflow


class MainWindow(QMainWindow):
    def __init__(self, project=None):
        super().__init__()
        configure_appearance(QApplication.instance())
        self.root = configure_local_paths()
        self.document = Document(self.root)
        self.language = "zh_CN"
        self.features = 0
        self.feature_source = "manual"
        self.graph_state = None
        self.reference_state = None
        self.document_generation = 0
        self.audit = None
        self.baseline_files = {}
        self.process = None
        self.plan = None
        self.translations = []
        self.text_catalog = {}
        self.text_bindings = []
        self.combo_bindings = []
        self.translation_callbacks = []
        self.cards = []
        self.fields = {}
        self.setMinimumSize(950, 640)
        self.resize(1260, 850)
        self.setStyleSheet("""
            QMainWindow {background:#f3f6fa;}
            QLabel {color:#23364b;}
            QLineEdit,QSpinBox,QComboBox {color:#23364b; padding:5px; background:white; border:1px solid #bdcbd9; border-radius:4px;}
            QPushButton {padding:7px 13px; background:#e4edf7; border:1px solid #bdcbd9; border-radius:5px; color:#173b61;}
            QPushButton:hover {background:#d0e3f7;}
            QPushButton:disabled {color:#8894a0; background:#e9edf1;}
            QFrame#layerCard {background:white; border:1px solid #d4dfe9; border-radius:7px;}
            QTabWidget::pane {border:1px solid #d4dfe9; background:#f8fafc;}
            QTabBar::tab {padding:10px 24px;}
        """)
        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        heading = QLabel(APP_NAME)
        heading.setStyleSheet("font-size:26px; font-weight:700; color:#164a76;")
        toolbar = QHBoxLayout()
        toolbar.addWidget(heading)
        toolbar.addStretch()
        for zh, en, callback, name in (
            ("新建", "New", self.new_project, "new"), ("打开", "Open", self.open_dialog, "open"),
            ("保存", "Save", self.save_dialog, "save"), ("另存为", "Save as", lambda: self.save_dialog(True), "save_as"),
        ):
            button = self.button(zh, en, callback, name)
            toolbar.addWidget(button)
        self.language_box = QComboBox()
        self.language_box.addItems(["中文", "English"])
        self.language_box.setObjectName("language")
        self.language_box.currentIndexChanged.connect(lambda i: self.set_language("zh_CN" if i == 0 else "en_US"))
        toolbar.addWidget(self.language_box)
        layout.addLayout(toolbar)
        self.tabs = QTabWidget()
        layout.addWidget(self.tabs, 1)
        self.data_page = self.make_data_page()
        self.network_page = self.make_network_page()
        self.tabs.addTab(self.data_page, "")
        self.tabs.addTab(self.network_page, "")
        self.message = QLabel()
        self.message.setWordWrap(True)
        self.message.setTextFormat(Qt.PlainText)
        self.message.setTextInteractionFlags(Qt.TextSelectableByMouse)
        layout.addWidget(self.message)
        footer = QHBoxLayout()
        note = self.label("每次运行独立保存；训练、验证和测试遵守固定划分。",
                          "Each run is saved separately; training, validation and test use fixed partitions.")
        note.setWordWrap(True)
        footer.addWidget(note, 1)
        self.train_button = self.button("开始训练", "Start training", lambda: self.workflow.start_training(), "train")
        self.train_button.setEnabled(False)
        layout.addLayout(footer)
        self.workflow = Workflow(self)
        self.populate()
        if project is not None:
            try:
                self.open_project(project)
            except (GPNBError, OSError, ValueError) as error:
                self.show_error(error)

    def tr_pair(self, zh, en):
        self.text_catalog[zh] = self.text_catalog[en] = (zh, en)
        return zh if self.language == "zh_CN" else en

    def bind_text(self, widget, zh, en, setter="setText"):
        self.text_bindings.append((widget, setter, zh, en))
        getattr(widget, setter)(self.tr_pair(zh, en))
        return widget

    def bind_tooltip(self, widget, zh, en):
        return self.bind_text(widget, zh, en, "setToolTip")

    def bind_combo(self, widget, choices):
        self.combo_bindings.append((widget, choices))
        for index, (zh, en) in enumerate(choices):
            if index >= widget.count():
                widget.addItem(self.tr_pair(zh, en))
            else:
                widget.setItemText(index, self.tr_pair(zh, en))
        return widget

    def label(self, zh, en):
        item = QLabel()
        item.setTextFormat(Qt.PlainText)
        self.translations.append((item, zh, en))
        item.setText(self.tr_pair(zh, en))
        return item

    def button(self, zh, en, callback, name=None):
        item = QPushButton()
        if zh in ("[?]", "?"):
            from .form_helpers import HelpButton
            item = HelpButton()
            zh = en = "?"
            self.bind_tooltip(item, "帮助：查看说明和示例", "Help: explanation and example")
            self.bind_text(item, "帮助", "Help", "setAccessibleName")
        if name:
            item.setObjectName(name)
        item.clicked.connect(callback)
        self.translations.append((item, zh, en))
        item.setText(self.tr_pair(zh, en))
        return item

    def set_language(self, language):
        # UI preference is deliberately separate from scientific configuration.
        self.language = language
        self.language_box.blockSignals(True)
        self.language_box.setCurrentIndex(0 if language == "zh_CN" else 1)
        self.language_box.setItemText(0, "中文" if language == "zh_CN" else "Chinese")
        self.language_box.blockSignals(False)
        for widget, zh, en in self.translations:
            from shiboken6 import isValid
            if isValid(widget):
                widget.setText(self.tr_pair(zh, en))
        from .i18n import translate_open_widgets
        translate_open_widgets(self)
        for callback in self.translation_callbacks[:]:
            callback()
        self.tabs.setTabText(0, self.tr_pair("数据与项目", "Data and project"))
        self.tabs.setTabText(1, self.tr_pair("网络构建", "Network builder"))
        self.workflow.translate()
        from .data_page import translate_data_page
        translate_data_page(self)
        self.feature_input.setSpecialValueText(self.tr_pair("未知", "Unknown"))
        self.rebuild_cards()
        self.refresh()
        self.show_audit()

    def make_data_page(self):
        from .data_page import build_data_page
        return build_data_page(self)

    def make_network_page(self):
        page = QWidget()
        page_layout = QVBoxLayout(page)
        self.network_splitter = QSplitter()
        self.network_splitter.setObjectName('network_splitter')
        page_layout.addWidget(self.network_splitter, 1)
        self.network_tools = QScrollArea()
        self.network_tools.setWidgetResizable(True)
        tools_body = QWidget()
        self.network_tools.setWidget(tools_body)
        outer = QVBoxLayout(tools_body)
        self.network_splitter.addWidget(self.network_tools)
        controls = QVBoxLayout()
        self.feature_readonly = QLabel()
        self.feature_readonly.setObjectName("input_dimensions")
        controls.addWidget(self.feature_readonly)
        # Kept only as an internal compatibility adapter for old integrations;
        # users cannot type a pretend feature count into the builder.
        self.feature_input = QSpinBox(page)
        self.feature_input.setObjectName("features")
        self.feature_input.setRange(0, 2**31-1)
        self.feature_input.valueChanged.connect(self.manual_features)
        self.feature_input.hide()
        self.kind_box = QComboBox()
        self.kind_box.setObjectName("new_layer_type")
        self.kind_box.addItems(list(COMPONENTS))
        controls.addStretch()
        controls.addWidget(self.button("保存网络摘要 .md", "Save network summary .md", self.save_summary, "save_network_summary"))
        from .input_modes import show_unavailable, build_input_modes, GENERIC_TEMPLATES
        controls.addWidget(self.button("为什么选项不可用？", "Why are options unavailable?", lambda: show_unavailable(self), "unavailable_options"))
        outer.addLayout(controls)
        build_input_modes(self, outer)
        templates = QVBoxLayout()
        templates.addWidget(self.label("可编辑参考模板", "Editable reference template"))
        self.template_box = QComboBox()
        self.template_box.setObjectName("template_choice")
        self.template_box.addItems(GENERIC_TEMPLATES)
        from ..models.paper_templates import AVAILABLE
        self.template_box.addItems(list(AVAILABLE))
        self.template_box.setProperty("user_values", True)
        templates.addWidget(self.template_box)
        templates.addWidget(self.button("应用此模板", "Apply this template", self.apply_template, "apply_template"))
        templates.addWidget(self.button("论文参考架构", "Paper architectures", self.open_paper_templates, "paper_architectures"))
        self.bind_tooltip(self.template_box,"应用将替换当前网络；来源与修改记录保留在归档。", "Applying replaces the current network; provenance remains archived.")
        templates.addStretch()
        outer.addLayout(templates)
        self.current_template = QLabel()
        self.current_template.setObjectName("current_template")
        outer.addWidget(self.current_template)
        connections = QVBoxLayout()
        from .network_options import add_options, select_mode
        from .data_widgets import format_help
        add_options(self, outer)
        connections.addWidget(self.label("连接方式", "Connections"))
        self.connection_mode=QComboBox()
        self.bind_combo(self.connection_mode,[("顺序", "Sequential"),("分支", "Branches")])
        self.connection_mode.currentIndexChanged.connect(lambda i:select_mode(self,i))
        connections.addWidget(self.connection_mode)
        connections.addWidget(self.button("[?]", "[?]", lambda:format_help(self,"branches")))
        connections.addWidget(self.label("输出层", "Output layer"))
        self.output_choice = QComboBox()
        self.output_choice.setObjectName("graph_output")
        self.output_choice.currentTextChanged.connect(self.select_output)
        connections.addWidget(self.output_choice, 1)
        outer.addLayout(connections)
        encoding = QVBoxLayout()
        encoding.addWidget(self.label("模型输入表示", "Model input representation"))
        self.representation_choice = QComboBox()
        self.representation_choice.setObjectName("input_representation")
        self.representation_choice.addItems(["standardized_dosage", "genotype_categories"])
        self.representation_choice.currentTextChanged.connect(self.select_representation)
        encoding.addWidget(self.representation_choice)
        encoding.addWidget(self.label("类别模式保留缺失类别，不使用剂量填补/标准化。", "Category mode preserves missing category; no dosage imputation/scaling."), 1)
        outer.addLayout(encoding)
        graph_controls = QVBoxLayout()
        graph_controls.addWidget(self.button("导入位点图 / 查看映射", "Import locus graph / inspect mapping",
                                              self.open_graph_dialog, "import_graph"))
        graph_controls.addWidget(self.button("个体参考图协议", "Individual reference protocol",
                                              self.open_reference_dialog, "individual_graph"))
        graph_controls.addWidget(self.label("位点图可使用训练内 LD 或显式边表；不要求其他组学数据。", "Locus graphs can use training LD or explicit edges; other omics are not required."))
        self.io_body_layout.addLayout(graph_controls)
        self.dimension_note = QLabel()
        self.dimension_note.setWordWrap(True)
        outer.addWidget(self.dimension_note)
        self.layer_scroll = QScrollArea()
        self.layer_scroll.setWidgetResizable(True)
        layer_panel=QWidget();layer_layout=QVBoxLayout(layer_panel)
        self.network_editor = layer_panel
        editor_actions=QHBoxLayout()
        editor_actions.addWidget(self.button('放大编辑区 / 返回', 'Expand editor / return', self.toggle_network_editor, 'expand_network_editor'))
        editor_actions.addWidget(self.button('恢复默认布局', 'Reset layout', self.reset_network_layout, 'reset_network_layout'))
        layer_layout.addLayout(editor_actions)
        layer_layout.addWidget(self.layer_scroll)
        add_row=QHBoxLayout();add_row.addWidget(self.kind_box)
        add_row.addWidget(self.button("新增层", "Add layer", lambda: self.layer_action("add", kind=self.kind_box.currentText()), "add_layer"))
        layer_layout.addLayout(add_row);self.network_splitter.addWidget(layer_panel)
        self.network_summary = QTextBrowser()
        self.network_summary.setObjectName("network_markdown")
        self.network_summary.setOpenExternalLinks(False)
        from PySide6.QtWidgets import QGroupBox
        summary_group = QGroupBox()
        self.bind_text(summary_group, '结构尺寸与摘要', 'Shapes and summary', 'setTitle')
        summary_group.setCheckable(True); summary_group.setChecked(False)
        summary_layout=QVBoxLayout(summary_group); summary_layout.addWidget(self.network_summary)
        self.network_summary.hide(); summary_group.toggled.connect(self.network_summary.setVisible)
        outer.addWidget(summary_group)
        # Existing exported SVG artifacts remain compatible, but both diagram
        # views and their controls have been removed from the user interface.
        self.svg = QSvgWidget(page)
        self.svg.hide()
        from PySide6.QtCore import QSettings
        self.ui_settings = QSettings(str(self.root/'config'/'ui.ini'), QSettings.IniFormat)
        self.network_splitter.setSizes([360, 760])
        state=self.ui_settings.value('network/splitter')
        if isinstance(state, QByteArray):self.network_splitter.restoreState(state)
        self.network_splitter.splitterMoved.connect(lambda *_: self.ui_settings.setValue('network/splitter',self.network_splitter.saveState()))
        for label in tools_body.findChildren(QLabel):label.setWordWrap(True)
        self.summary = QLabel()
        self.summary.setWordWrap(True)
        self.summary.setTextInteractionFlags(Qt.TextSelectableByMouse)
        page_layout.addWidget(self.summary)
        return page

    def toggle_network_editor(self):
        self.network_tools.setVisible(not self.network_tools.isVisible())

    def reset_network_layout(self):
        self.network_tools.show()
        self.network_splitter.setSizes([360, 760])
        self.ui_settings.remove('network/splitter')

    def save_summary(self):
        path, _ = QFileDialog.getSaveFileName(self, self.tr_pair("保存网络摘要", "Save network summary"),
                                            str(self.root / "projects" / "network.md"), "Markdown (*.md)")
        if not path:
            return
        try:
            from ..data.genotypes import source_paths
            inputs = list(source_paths(self.document.value["data"], self.document.path or self.root / "untitled.json").values())
            if self.document.path:
                inputs.append(self.document.path)
            inputs.extend(t["path"] for t in self.document.value.get("extensions", {}).get("input_tables", []))
            protect_inputs(path, inputs)
            Path(path).write_text(self.summary_markdown, encoding="utf-8")
        except (ValueError, OSError) as error:
            self.show_error(error)

    def open_multitask(self):
        from .multitask_dialog import MultitaskDialog
        self.multitask_dialog=MultitaskDialog(self)
        self.multitask_dialog.show()

    def populate(self):
        self.workflow.settings.populate()
        value = self.document.value
        for key, widget in self.fields.items():
            widget.blockSignals(True)
            if key in ("name", "output_dir"):
                current = value[key]
            elif key in value["data"]:
                current = value["data"][key]
            else:
                current = value["data"]["phenotype_options"][key]
            if isinstance(widget, QComboBox):
                if key == "trait":
                    widget.clear()
                    widget.setEditText(current)
                else:
                    widget.setCurrentIndex(widget.findData(current))
            else:
                widget.setText(json.dumps(current, ensure_ascii=False) if isinstance(current, list) else current or "")
            widget.blockSignals(False)
        self.fields["trait"].restore(value)
        self.feature_input.blockSignals(True)
        self.feature_input.setValue(self.features)
        self.feature_input.blockSignals(False)
        from .data_page import sync_source
        sync_source(self)
        self.set_language(self.language)

    def edit_field(self, path, text):
        value = text or None if path[-1] in ("manifest", "split_groups") or (path[-1] in ("bed", "bim", "fam") and self.document.value["data"].get("matrix") is not None) else text
        self.document.change(path, value)
        if path[0] == "data":
            self.invalidate_audit()
        self.refresh()

    def edit_option(self, key, value):
        self.document.change(("data", "phenotype_options", key), value)
        self.invalidate_audit()
        self.refresh()

    def edit_json_option(self, key, widget):
        try:
            value = json.loads(widget.text())
            if not isinstance(value, list) or any(not isinstance(item, str) for item in value):
                raise ValueError("expected an array of strings")
            self.document.change(("data", "phenotype_options", key), value)
            widget.setStyleSheet("")
            self.invalidate_audit()
            self.refresh()
        except (ValueError, GPNBError) as error:
            widget.setStyleSheet("border:2px solid #bc3942")
            self.show_error(error)

    def browse(self, key, mode):
        if mode == "directory":
            selected = QFileDialog.getExistingDirectory(self, self.tr_pair("选择输出目录", "Choose output directory"), str(self.root))
        else:
            selected, _ = QFileDialog.getOpenFileName(self, self.tr_pair("选择文件", "Choose file"), str(self.root), "Files (*)")
        if selected:
            self.select_input_path(key, selected)

    def select_input_path(self, key, selected):
        from .path_fields import select_companions
        if self.document.value["data"].get("matrix") is not None:
            self.fields[key].setText(str(Path(selected)))
        else:
            self._auto_paths = select_companions(self.fields, key, selected, getattr(self, "_auto_paths", {}))

    def manual_features(self, value):
        self.features, self.feature_source = value, "manual"
        self.refresh()

    def read_columns(self):
        try:
            self.commit_json_fields()
            options = self.document.value["data"]["phenotype_options"]
            path = Path(self.fields["phenotype"].text())
            if not path.is_absolute():
                path = (self.document.path.parent if self.document.path else self.root) / path
            stream = text_table(path, options["delimiter"], options["encoding"])
            try:
                _, columns = next(stream)
            finally:
                stream.close()
            names = [c for c in columns if c not in options["id_columns"]]
            widget = self.fields["trait"]
            previous = widget.currentText()
            widget.blockSignals(True)
            widget.clear()
            from ..data.tables import read_phenotypes
            checked_options=dict(options,trait=previous if previous in names else names[0] if names else '')
            table=read_phenotypes(path,checked_options)
            names=[name for name in names if table.traits[name]['selectable']]
            widget.stats=table.traits
            widget.addItems(names)
            widget.setEditText(previous if previous in names else names[0] if names else "")
            widget.blockSignals(False)
            self.edit_field(("data", "phenotype_options", "trait"), widget.currentText())
            self.message.setText(self.tr_pair("已读取列名，请选择性状并检查数值及匹配。", "Columns loaded; select a trait and check numeric values and ID matching."))
        except (OSError, ValueError, StopIteration) as error:
            self.show_error(error)

    def invalidate_audit(self):
        self.audit = None
        if self.feature_source in ("audit", "prepared"):
            self.features = 0
            self.feature_source = "manual"
            self.feature_input.blockSignals(True)
            self.feature_input.setValue(0)
            self.feature_input.blockSignals(False)
        self.show_audit()

    def layer_action(self, action, index=0, kind="Linear"):
        try:
            self.document.layer_action(action, index, kind)
            self.rebuild_cards()
            self.refresh()
        except (ValueError, KeyError) as error:
            self.show_error(error)

    def apply_template(self):
        try:
            from ..models.paper_templates import AVAILABLE
            name = self.template_box.currentText()
            if name in AVAILABLE:
                from .paper_dialog import PaperDialog
                dialog=PaperDialog(self)
                dialog.choice.setCurrentIndex(dialog.choice.findData(name))
                dialog.exec()
                return
            else:
                self.document.apply_template(name)
            self.rebuild_cards()
            self.refresh()
        except (GPNBError, ValueError) as error:
            self.show_error(error)

    def apply_paper_template(self, name, mode="architecture", *, clear_stages=False):
        import copy
        from ..models.paper_presets import apply_preset
        previous=copy.deepcopy(self.document.value)
        value=apply_preset(previous,name,mode,clear_stages=clear_stages)
        self._paper_undo=(previous,copy.deepcopy(value))
        self.document.value=value
        self.document.dirty=True
        self.workflow.settings.populate()

    def undo_paper_template(self):
        import copy
        from ..config import fail
        saved=getattr(self,"_paper_undo",None)
        if not saved or self.document.value!=saved[1]:
            fail("E_MODEL","paper_profile.undo",self.tr_pair(
                "应用后项目已变更；为保留后续编辑，不能撤销。", "Project changed after application; undo would discard later edits."))
        self.document.value=copy.deepcopy(saved[0])
        self.document.dirty=True
        self._paper_undo=None
        self.workflow.settings.populate()

    def sync_template(self):
        """Describe the applied structure, while preserving an unapplied selection."""
        import copy
        model = self.document.value["model"]
        record = model.get("extensions", {}).get("template", {})
        name = record.get("name", "")
        baseline = record.get("baseline")
        current = copy.deepcopy(model)
        current.get("extensions", {}).pop("template", None)
        if not current.get("extensions"):
            current.pop("extensions", None)
        original = copy.deepcopy(baseline) if baseline else None
        if original is not None:
            original.get("extensions", {}).pop("template", None)
            if not original.get("extensions"):
                original.pop("extensions", None)
        modified = original is not None and current != original
        preset = model.get("extensions", {}).get("paper_preset")
        if preset:
            modified = modified or preset.get("baseline_training") != self.document.value["run"]["training"]
        display = name.removeprefix("paper:") if name else self.tr_pair("自定义网络", "Custom network")
        state = self.tr_pair("已修改", "Modified") if modified else self.tr_pair("原始模板", "Original template") if baseline else self.tr_pair("无模板基线", "No template baseline")
        if preset:
            state = self.tr_pair("GPNB_v1 参数档已修改", "GPNB_v1 preset modified") if modified else self.tr_pair("GPNB_v1 参数档未修改", "GPNB_v1 preset unchanged")
            state += self.tr_pair(" · 已核实部分", " · verified subset") if preset["mode"] == "verified" else self.tr_pair(" · 仅结构", " · architecture only")
        self.current_template.setText(self.tr_pair("当前网络：", "Current network: ") + display + " · " + state)
        fingerprint = json.dumps(model, ensure_ascii=False, sort_keys=True)
        if fingerprint != getattr(self, "_template_fingerprint", None):
            self._template_fingerprint = fingerprint
            index = self.template_box.findText(display)
            if index >= 0:
                self.template_box.setCurrentIndex(index)

    def open_paper_templates(self):
        from .paper_dialog import PaperDialog
        self.paper_dialog = PaperDialog(self)
        self.paper_dialog.show()

    def open_graph_dialog(self):
        from .graph_dialog import GraphDialog
        self.graph_dialog = GraphDialog(self)
        self.graph_dialog.show()

    def open_input_tables(self):
        from .input_tables_dialog import InputTablesDialog
        self.input_tables_dialog = InputTablesDialog(self)
        self.input_tables_dialog.show()

    def open_reference_dialog(self):
        from .reference_dialog import ReferenceDialog
        self.reference_dialog = ReferenceDialog(self)
        self.reference_dialog.show()

    def enable_dag(self):
        self.document.enable_dag()
        self.rebuild_cards()
        self.refresh()

    def select_output(self, identifier):
        if self.document.value["model"].get("graph_mode") == "dag" and identifier:
            self.document.change(("model", "output"), identifier)
            self.refresh()

    def select_representation(self, representation):
        self.document.set_representation(representation)
        self.rebuild_cards()
        self.refresh()

    def expand_component(self, index):
        try:
            self.document.expand_component(index, self.features)
            self.rebuild_cards()
            self.refresh()
        except (GPNBError, ValueError) as error:
            self.show_error(error)

    def select_connection(self, index, port, source):
        self.document.change(("model", "layers", index, "inputs", port), source)
        self.refresh()

    def show_template_diff(self):
        from ..models.core import template_diff
        try:
            report = template_diff(ModelSpec(self.document.value["model"]))
            preset=self.document.value["model"].get("extensions",{}).get("paper_preset")
            if preset:
                before=preset["baseline_training"]; after=self.document.value["run"]["training"]
                report["training_changes"]={key:dict(before=before.get(key),after=after.get(key)) for key in sorted(before.keys() | after.keys()) if before.get(key)!=after.get(key)}
                report["paper_settings_status"]=preset["status"]
            self.diff_dialog = QDialog(self)
            self.diff_dialog.setWindowTitle(self.tr_pair("模板差异（按层 ID）", "Template differences (layer IDs)"))
            layout = QVBoxLayout(self.diff_dialog)
            viewer = QPlainTextEdit()
            viewer.setReadOnly(True)
            viewer.setPlainText(json.dumps(report, ensure_ascii=False, indent=2))
            layout.addWidget(viewer)
            self.diff_dialog.resize(800, 600)
            self.diff_dialog.show()
        except ValueError as error:
            self.show_error(error)

    def rebuild_cards(self):
        body = QWidget()
        layout = QVBoxLayout(body)
        self.cards = []
        model = self.document.value["model"]
        self.representation_choice.blockSignals(True)
        self.representation_choice.setCurrentText(model.get("input_representation", "standardized_dosage"))
        self.representation_choice.blockSignals(False)
        dag = model.get("graph_mode") == "dag"
        self.output_choice.blockSignals(True)
        self.output_choice.clear()
        self.output_choice.addItems([row["id"] for row in model["layers"]])
        output = model.get("output", model["layers"][-1]["id"] if model["layers"] else "")
        if self.output_choice.findText(output) < 0:
            self.output_choice.addItem(output)
        self.output_choice.setCurrentText(output)
        self.output_choice.setEnabled(dag)
        self.output_choice.blockSignals(False)
        block_cards = {}
        for block in model.get("extensions", {}).get("blocks", []):
            toggle = QCheckBox(self.tr_pair("展开组合块：", "Expand block: ") + block["name"])
            toggle.setObjectName("block_" + block["name"])
            toggle.setChecked(True)
            members = []
            toggle.toggled.connect(lambda checked, widgets=members: [w.setVisible(checked) for w in widgets])
            layout.addWidget(toggle)
            for identifier in block["layers"]:
                block_cards[identifier] = members
        for index, layer in enumerate(self.document.value["model"]["layers"]):
            card = QFrame()
            card.setObjectName("layerCard")
            box = QVBoxLayout(card)
            top = QHBoxLayout()
            title = QLabel(f"{layer['id']}  {layer['type']}")
            title.setTextFormat(Qt.PlainText)
            title.setStyleSheet("font-size:17px; font-weight:600; border:0;")
            top.addWidget(title, 1)
            for action, zh, en in (("up", "上移", "Up"), ("down", "下移", "Down"), ("copy", "独立复制", "Copy"),
                                    ("share", "共享调用", "Shared call"), ("delete", "删除", "Delete")):
                button = QPushButton(self.tr_pair(zh, en))
                button.setObjectName(f"{action}_{index}")
                button.clicked.connect(lambda checked=False, a=action, i=index: self.layer_action(a, i))
                button.setEnabled(not (action == "up" and index == 0 or action == "down" and index == len(self.document.value["model"]["layers"])-1))
                top.addWidget(button)
            box.addLayout(top)
            if layer["type"] in EXPANDABLE:
                button = QPushButton(self.tr_pair("拆开为可编辑基础层（重新初始化）", "Expand into editable layers (new initialization)"))
                button.setObjectName(f"expand_{index}")
                button.clicked.connect(lambda checked=False, i=index: self.expand_component(i))
                box.addWidget(button)
            if dag:
                connections = QFormLayout()
                for port in COMPONENTS[layer["type"]].ports:
                    selector = QComboBox()
                    selector.setObjectName(f"input_{index}_{port}")
                    sources = ["$input", *("$input:"+name for name in model.get("external_inputs", {})),
                               *[r["id"] for r in model["layers"] if r["id"] != layer["id"]]]
                    current = layer["inputs"].get(port, "$input")
                    if current not in sources:
                        sources.append(current)
                    selector.addItems(sources)
                    selector.setCurrentText(current)
                    selector.currentTextChanged.connect(lambda text, i=index, p=port: self.select_connection(i, p, text))
                    connections.addRow(self.tr_pair("输入 ", "Input ") + port, selector)
                box.addLayout(connections)
            params = QHBoxLayout()
            if "share_with" in layer:
                params.addWidget(QLabel(self.tr_pair("参数与状态共享：", "Parameters and state shared with: ") + layer["share_with"]))
            elif layer["type"] == "Linear":
                params.addWidget(QLabel(self.tr_pair("输出单元", "Output units")))
                units = QSpinBox()
                units.setObjectName(f"units_{index}")
                units.setRange(1, 2**31-1)
                units.setValue(layer["params"]["out_features"])
                units.valueChanged.connect(lambda value, i=index: self.layer_param(i, "out_features", value))
                params.addWidget(units)
                bias = QCheckBox(self.tr_pair("偏置", "Bias"))
                bias.setObjectName(f"bias_{index}")
                bias.setChecked(layer["params"]["bias"])
                bias.toggled.connect(lambda value, i=index: self.layer_param(i, "bias", value))
                params.addWidget(bias)
            elif layer["type"] == "Dropout":
                params.addWidget(QLabel(self.tr_pair("丢弃概率", "Drop probability")))
                probability = QLineEdit(str(layer["params"]["p"]))
                probability.setObjectName(f"dropout_{index}")
                probability.textChanged.connect(lambda value, i=index: self.dropout_value(i, value))
                params.addWidget(probability)
            elif COMPONENTS[layer["type"]].parameters:
                fields = QWidget()
                form = QFormLayout(fields)
                for key, definition in COMPONENTS[layer["type"]].parameters.items():
                    current = layer["params"][key]
                    if definition.type == "bool":
                        widget = QCheckBox()
                        widget.setChecked(current)
                        widget.toggled.connect(lambda value, i=index, k=key: self.layer_param(i, k, value))
                    elif definition.type == "int":
                        widget = QSpinBox()
                        widget.setRange(int(definition.minimum or 0), int(definition.maximum or 2**31-1))
                        widget.setValue(current)
                        widget.valueChanged.connect(lambda value, i=index, k=key: self.layer_param(i, k, value))
                    elif definition.type == "choice":
                        widget = QComboBox()
                        widget.addItems(definition.choices)
                        widget.setCurrentText(current)
                        widget.currentTextChanged.connect(lambda value, i=index, k=key: self.layer_param(i, k, value))
                    else:
                        widget = QLineEdit(json.dumps(current) if definition.type == "integers" else str(current))
                        widget.textChanged.connect(lambda value, i=index, k=key, t=definition.type: self.typed_parameter(i, k, t, value))
                    widget.setObjectName(f"parameter_{index}_{key}")
                    form.addRow(self.parameter_label(key), widget)
                params.addWidget(fields)
            else:
                params.addWidget(QLabel(self.tr_pair("此部件无参数选项", "No component options")))
            params.addStretch()
            box.addLayout(params)
            shape = QLabel()
            shape.setWordWrap(True)
            shape.setStyleSheet("border:0; color:#41607d;")
            box.addWidget(shape)
            if layer["type"] in ("Conv1d", "CausalConv1d", "DepthwiseSeparableConv1d", "LocallyConnected1d"):
                from .input_modes import layer_input_roots, kernel_options
                roots = layer_input_roots(model, layer["id"])
                kernel_source = "$input:kernel" in roots or "$input" in roots and (kernel_options(self.document.value) or {}).get("mode") == "kernel"
                if kernel_source:
                    note = QLabel(self.tr_pair("核分支按保存的训练参考个体顺序；窗口不代表 SNP、染色体距离或遗传邻接。",
                                              "Kernel branches follow saved training reference order; windows do not represent SNPs, chromosome distance or genetic adjacency."))
                elif any(source.startswith("$input:") for source in roots):
                    note = QLabel(self.tr_pair("窗口按该数值分支的特征顺序，不自动代表基因组位置。",
                                              "Windows follow this numeric branch's feature order, not inferred genomic positions."))
                else:
                    note = QLabel(self.tr_pair("窗口按保留标记顺序；不自动代表物理距离或 LD 区块。",
                                              "Windows follow retained marker order, not inferred physical distance or LD blocks."))
                note.setWordWrap(True)
                box.addWidget(note)
            if layer["type"] in ("RNN", "LSTM", "GRU", "SequenceReadout"):
                note = QLabel(self.tr_pair(
                    "序列轴为个体内有序特征，不是个体轴。循环状态每次清零；final_state 拼接各方向末状态，last 是最后位置。",
                    "Sequence axis is ordered features within each individual. State resets each call. final_state concatenates direction endpoints; last selects the last position."))
                note.setWordWrap(True)
                box.addWidget(note)
            self.cards.append(shape)
            layout.addWidget(card)
            if layer["id"] in block_cards:
                block_cards[layer["id"]].append(card)
        layout.addStretch()
        old = self.layer_scroll.takeWidget()
        if old:
            old.deleteLater()
        self.layer_scroll.setWidget(body)

    def layer_param(self, index, key, value):
        self.document.change(("model", "layers", index, "params", key), value)
        self.refresh()

    def typed_parameter(self, index, key, kind, text):
        try:
            value = json.loads(text) if kind == "integers" else float(text)
        except ValueError:
            value = text
        self.layer_param(index, key, value)

    def parameter_label(self, key):
        labels = {"out_channels": "输出通道", "kernel_size": "窗口大小", "stride": "步长", "padding": "两侧填充",
                  "padding_left": "左填充", "padding_right": "右填充", "dilation": "膨胀率", "groups": "卷积分组",
                  "bias": "偏置", "ceil_mode": "向上取整", "count_include_pad": "均值包含填充值",
                  "output_size": "输出长度", "num_groups": "归一化分组", "eps": "数值稳定常数",
                  "momentum": "运行统计更新系数", "affine": "可学习缩放/偏移", "elementwise_affine": "逐元素可学习缩放",
                  "track_running_stats": "保存运行统计", "p": "丢弃概率", "shape": "每个体目标尺寸",
                  "axes": "非样本轴排列", "layout": "输出布局", "mode": "模式", "init": "斜率初值",
                  "negative_slope": "负半轴斜率", "boundary": "窗口边界含义", "axis": "拼接轴（不含样本）",
                  "hidden_size": "隐藏单元", "num_layers": "内部层数", "bidirectional": "双向",
                  "dropout": "丢弃概率", "readout": "输出选择", "nonlinearity": "激活函数",
                  "embedding_dim": "嵌入宽度", "patch_size": "每窗口特征数", "pad_tokens": "额外空 token 数",
                  "valid_length": "有效长度（-1 全部有效）", "max_length": "位置容量", "num_heads": "注意力头数",
                  "dim_feedforward": "前馈隐藏单元", "norm_first": "前置归一化", "activation": "激活函数",
                  "causal": "禁止关注后方位置", "max_score_elements": "每次调用 score 元素上限"}
        labels.update(num_experts="专家数量（全部执行）", out_features="输出单元", token_hidden="token 混合隐藏单元",
                      channel_hidden="通道混合隐藏单元", start="起始位置", stop="结束位置（不包含）")
        return self.tr_pair(labels.get(key, key), key)

    def dropout_value(self, index, text):
        try:
            value = float(text)
        except ValueError:
            value = text
        # Invalid intermediate text remains a draft, visibly invalid and unsavable.
        self.layer_param(index, "p", value)

    def refresh(self):
        from .input_modes import sync_inputs, refresh_choices, kernel_options
        from ..models.summary import markdown_summary
        if self.feature_source == "prepared" and getattr(self, "resolved_display_fingerprint", None) is not None:
            fingerprint = json.dumps(self.document.value, ensure_ascii=False, sort_keys=True)
            if fingerprint != self.resolved_display_fingerprint:
                self.resolved_display_model = None
                self.features = (self.audit or {}).get("markers", 0)
                self.feature_source = "audit" if self.audit else "manual"
        sync_inputs(self)
        self.workflow.refresh()
        from .network_options import refresh_options
        refresh_options(self)
        self.setWindowTitle(f"{APP_NAME} — {self.document.value['name']}{' *' if self.document.dirty else ''}")
        self.plan = None
        self.svg.hide()
        for shape in self.cards:
            shape.setText(self.tr_pair("尺寸待核验", "Shape not yet validated"))
        mode = (kernel_options(self.document.value) or {}).get("mode", "snp")
        prep = self.document.value["run"]["preprocessing"]
        filtering = prep.get("enabled", True) and any(prep.get(k) is not None for k in ("maf_min", "marker_missing_max"))
        pending = None
        if self.feature_source == "prepared":
            note = self.tr_pair("当前训练分区已解析的实际输入；其他折可能不同。", "Resolved inputs for the current training partition; other folds may differ.")
            resolved = getattr(self, "resolved_display_model", None)
            resolved_value = resolved.to_dict() if isinstance(resolved, ModelSpec) else resolved or {}
            if mode == "snp_kernel":
                references = resolved_value.get("external_inputs", {}).get("kernel")
                count = str(references) if references is not None else self.tr_pair("待确定", "Pending")
                self.feature_readonly.setText(self.tr_pair("当前 SNP 输入宽度：", "Current SNP input width: ") + str(self.features) +
                                             self.tr_pair("；核参考个体 T：", "; kernel references T: ") + count)
            elif mode == "kernel":
                self.feature_readonly.setText(self.tr_pair("当前核参考个体 T：", "Current kernel references T: ") + str(self.features))
            else:
                self.feature_readonly.setText(self.tr_pair("当前输入宽度：", "Current input width: ") + str(self.features))
        else:
            prefix = self.tr_pair("导入位点数：", "Imported marker count: ")
            count = str(self.features) if self.features else self.tr_pair("请先检查数据", "Check data first")
            self.feature_readonly.setText(prefix + count)
            if mode != "snp":
                self.feature_readonly.setText(self.feature_readonly.text() + self.tr_pair("；核参考个体 T：待训练分区确定", "; kernel references T: pending training partition"))
            note = self.tr_pair("P 为训练内保留位点数，T 为训练参考个体数；不使用全体样本提前拟合。", "P is the retained marker count and T is the training reference count; no full-cohort fitting is used for preview.")
            if mode != "snp":
                pending = self.tr_pair("核输入宽度 T 将在每个训练分区确定。", "Kernel width T is determined within each training partition.")
            elif filtering:
                pending = self.tr_pair("启用了训练内位点筛选；最终输入宽度 P 待确定。", "Training marker filtering is enabled; final width P is pending.")
            elif not self.features:
                pending = self.tr_pair("检查数据后自动取得位点数。", "Check data to obtain the marker count automatically.")
        self.dimension_note.setText(note)
        try:
            spec = ModelSpec(self.document.value["model"])
            display_spec = spec
            if self.feature_source == "prepared" and getattr(self, "resolved_display_model", None) is not None:
                # A fold resolution can change a kernel branch width without
                # changing the user's reusable project recipe.
                resolved = self.resolved_display_model
                display_spec = resolved if isinstance(resolved, ModelSpec) else ModelSpec(resolved)
            if self.features:
                state = self.graph_state if self.feature_source == "prepared" and "graph_spec" in display_spec.to_dict() else None
                ref = self.reference_state if self.feature_source == "prepared" and "individual_graph_spec" in display_spec.to_dict() else None
                from ..models.core import inspect_model
                self.plan = inspect_model(display_spec, self.features, graph_state=state, reference_state=ref)
            self.summary_markdown = markdown_summary(display_spec, None if pending else self.plan,
                                                       language=self.language, pending_reason=pending,
                                                       input_context=kernel_options(self.document.value))
            self.network_summary.setMarkdown(self.summary_markdown)
            if self.plan and not pending:
                for widget, row in zip(self.cards, self.plan["layers"]):
                    shapes = {p: t["shape"] for p, t in row.get("input_types", {}).items()}
                    widget.setText(f"{shapes or row['input_shape']}  →  {row['output_shape']}   |   {row['parameters']:,} " + self.tr_pair("参数", "parameters"))
                self.summary.setText(self.tr_pair("可训练参数", "Trainable parameters") + f": {self.plan['trainable_parameters']:,}; " +
                                     self.tr_pair("缓冲区", "buffers") + f": {self.plan.get('buffer_bytes', 0):,} bytes")
                # This hidden compatibility artifact is not a diagram UI entry.
                self.svg.load(QByteArray(structure_svg(self.plan).encode("utf-8")))
            else:
                self.summary.setText(pending or self.tr_pair("检查数据后显示实际尺寸。", "Check data to display dimensions."))
            self.summary.setStyleSheet("color:#23475c")
        except (GPNBError, ValueError) as error:
            self.train_button.setEnabled(False)
            self.plan = None
            self.summary.setText(self.error_text(error))
            self.summary.setStyleSheet("color:#af2635")
            try:
                self.summary_markdown = markdown_summary(self.document.value["model"], language=self.language,
                    pending_reason=self.tr_pair("当前配置不兼容；原有网络保留，请修正连接或另存修改。", "Current configuration is incompatible. The existing network is preserved; fix connections or save changes separately."),
                    input_context=kernel_options(self.document.value))
            except ValueError:
                self.summary_markdown = self.tr_pair("网络定义待修正。", "The network definition needs correction.")
            self.network_summary.setMarkdown(self.summary_markdown)
        refresh_choices(self)
        self.sync_template()

    def error_text(self, error):
        if isinstance(error, GPNBError):
            item = error.as_dict(self.language)
            return f"{item['code']} · {item['path']}\n{item['message']} — {item['detail']}"
        return str(error)

    def show_error(self, error):
        if isinstance(error, GPNBError):
            zh, en = error.as_dict('zh_CN'), error.as_dict('en_US')
            caption = lambda item: f"{item['code']} · {item['path']}\n{item['message']} — {item['detail']}"
            self.message.setText(self.tr_pair(caption(zh), caption(en)))
        else:
            self.message.setText(self.error_text(error))
        self.message.setStyleSheet("color:#af2635; padding:6px")

    def show_audit(self):
        self.update_check_folder_button()
        from .data_page import render_audit
        render_audit(self)
        if self.audit is None:
            data = self.document.value["data"]
            required = ("phenotype",) if data.get("matrix") else ("bed", "bim", "fam", "phenotype")
            if data.get("matrix") and data["matrix"].get("counted_allele") == "BIM_A1":
                required += ("bim",)
            missing = [k for k in required
                       if not self.document.value["data"][k] or not Path(self.document.value["data"][k]).is_file()]
            self.audit_label.setText(self.tr_pair("尚未检查当前数据；", "Current data not checked; ") +
                                     (self.tr_pair("缺少文件：", "missing files: ") + ", ".join(missing) if missing else
                                      self.tr_pair("文件存在，但内容和匹配尚未核验。", "files exist, contents and matching unverified.")))
        else:
            a = self.audit
            self.audit_label.setText(
                self.tr_pair("样本 / 标记：", "Samples / markers: ") + f"{a['samples']} / {a['markers']}\n" +
                self.tr_pair("匹配情况：", "Matching: ") + json.dumps(a["matching"], ensure_ascii=False) + "\n" +
                self.tr_pair("基因型缺失率尚未扫描；训练导入时完整检查。", "Genotype missingness not scanned; full check during training import.") +
                "\n" + "\n".join(a.get("warnings", [])))

    def commit_json_fields(self):
        for key in ("id_columns", "missing_tokens"):
            value = json.loads(self.fields[key].text())
            if not isinstance(value, list) or any(not isinstance(v, str) for v in value):
                raise ValueError(f"{key}: expected JSON string array")
            self.document.change(("data", "phenotype_options", key), value)

    def update_check_folder_button(self):
        folder = getattr(self, "last_check_directory", None)
        current = getattr(self, "last_check_generation", None) == self.document_generation
        if hasattr(self, "open_check_button"):
            self.open_check_button.setEnabled(bool(current and folder and Path(folder).is_dir()))

    def open_check_folder(self):
        from PySide6.QtCore import QUrl
        from PySide6.QtGui import QDesktopServices
        folder = getattr(self, "last_check_directory", None)
        if (getattr(self, "last_check_generation", None) != self.document_generation
                or not folder or not Path(folder).is_dir()):
            self.show_error(self.tr_pair("尚无可打开的检查目录，请先检查数据。", "No check folder is available. Check the data first."))
            return
        if not QDesktopServices.openUrl(QUrl.fromLocalFile(str(Path(folder).resolve()))):
            self.show_error(self.tr_pair("无法打开检查目录：", "Could not open check folder: ") + str(folder))

    def record_audit_failure(self, process, destination, error):
        from .output_paths import persist_audit_failure
        try:
            folder = persist_audit_failure(destination, error,
                inputs=getattr(process, "audit_inputs", ()), project=getattr(process, "audit_project", None))
            self.last_check_directory = folder
            self.last_check_generation = getattr(process, "audit_generation", self.document_generation)
            self.update_check_folder_button()
        except (OSError, ValueError) as write_error:
            self.show_error(str(error) + "\n" + self.tr_pair("失败记录无法写入：", "Could not write failure record: ") + str(write_error))
            return False
        return True

    def start_audit(self):
        if self.process is not None or self.workflow.jobs.busy:
            return
        try:
            self.commit_json_fields()
            spec = self.document.spec()
            self.invalidate_audit()
            self.refresh()
            name = "gui_audit_" + uuid.uuid4().hex
            config = self.root / "tmp" / (name + ".json")
            spec.save(config)
            from .i18n import project_output
            from ..data.genotypes import source_paths
            destination = project_output(self, "checks", "audit")
            process = QProcess(self)
            process.audit_destination = destination
            process.audit_project = spec.to_dict()
            process.audit_inputs = [config, *source_paths(process.audit_project["data"], config).values()]
            process.audit_inputs.extend(Path(item["path"]) for item in process.audit_project.get("extensions", {}).get("input_tables", []))
            process.audit_generation = self.document_generation
            self.process = process
            self.workflow.refresh()
            self.check_button.setEnabled(False)
            self.message.setText(self.tr_pair("正在检查文件、ID 和表型…", "Checking files, IDs and phenotypes…"))
            fingerprint = (self.document_generation, json.dumps(self.document.value["data"], sort_keys=True))
            process.finished.connect(lambda code, status: self.audit_finished(process, destination, fingerprint, code))
            process.errorOccurred.connect(lambda error: self.audit_process_error(process))
            process.start(sys.executable, ["-m", "gpnb", "inspect", str(config), "--output", str(destination),
                                           "--lang", self.language])
        except (GPNBError, OSError, ValueError) as error:
            self.show_error(error)

    def audit_process_error(self, process):
        if process.error() == QProcess.FailedToStart:
            error = process.errorString()
            if self.record_audit_failure(process, process.audit_destination, error):
                self.show_error(error)
            self.process = None
            self.check_button.setEnabled(True)
            self.workflow.refresh()
            process.deleteLater()

    def audit_finished(self, process, destination, fingerprint, code):
        self.process = None
        self.check_button.setEnabled(True)
        self.workflow.refresh()
        try:
            raw = bytes(process.readAllStandardOutput()).decode("utf-8", errors="replace")
            try:
                response = json.loads(raw)
            except (ValueError, TypeError):
                response = {"ok": False, "error": self.tr_pair("检查进程未返回有效 JSON。", "Inspection process did not return valid JSON."),
                            "stdout": raw, "stderr": bytes(process.readAllStandardError()).decode("utf-8", errors="replace")}
            if not isinstance(response, dict):
                response = {"ok": False, "error": "Expected a JSON object", "response": response}
            if code != 0 or not response.get("ok"):
                if not self.record_audit_failure(process, destination, response):
                    return
            if fingerprint != (self.document_generation, json.dumps(self.document.value["data"], sort_keys=True)):
                self.message.setText(self.tr_pair("检查期间数据配置已改变，请重新检查。", "Data settings changed during inspection; check again."))
                return
            if destination.is_dir():
                self.last_check_directory = destination
                self.last_check_generation = self.document_generation
                self.update_check_folder_button()
            if code != 0 or not response.get("ok"):
                if (destination / "audit.json").is_file():
                    self.audit = read_json(destination / "audit.json")
                    self.audit_directory = destination
                    self.show_audit()
                else:
                    self.audit = None
                self.show_error(json.dumps(response, ensure_ascii=False))
                return
            audit = read_json(destination / "audit.json")
            descriptor = read_json(destination / "descriptor.json")
            changed = [k for k, record in self.baseline_files.items()
                       if k in descriptor["source_files"] and record["sha256"] != descriptor["source_files"][k]["sha256"]]
            self.baseline_files = descriptor["source_files"]
            self.audit = audit
            self.audit_directory = destination
            self.features, self.feature_source = audit["markers"], "audit"
            self.feature_input.blockSignals(True)
            self.feature_input.setValue(self.features)
            self.feature_input.blockSignals(False)
            trait = self.fields["trait"]
            selected = trait.currentText()
            trait.blockSignals(True)
            trait.clear()
            trait.stats=audit["traits"]
            trait.addItems([name for name, info in audit["traits"].items() if info["selectable"]])
            trait.setEditText(selected)
            trait.blockSignals(False)
            self.message.setText(self.tr_pair("检查完成：" + str(destination) +
                ("\n相对已保存检查记录，文件内容已改变：" + ", ".join(changed) if changed else ""),
                "Inspection complete: " + str(destination) +
                ("\nFiles changed since saved inspection: " + ", ".join(changed) if changed else "")))
            self.show_audit()
            self.refresh()
        except (OSError, ValueError, KeyError) as error:
            if self.record_audit_failure(process, destination, str(error)):
                self.show_error(error)
        finally:
            process.deleteLater()

    def save_project(self, path, *, overwrite=False):
        self.commit_json_fields()
        sidecar = Path(str(Path(path).resolve()) + ".ui.json")
        inputs = [Path(v).resolve() for k, v in self.document.value["data"].items()
                  if k in ("bed", "bim", "fam", "phenotype", "manifest", "split_groups") and v]
        from ..data.genotypes import source_paths
        inputs.extend(source_paths(self.document.value["data"],self.document.path or self.root/"untitled.json").values())
        protect_inputs(sidecar, inputs)
        self.document.save(path, overwrite=overwrite)
        # Scientific config remains GUI-independent. Sidecar only stores UI/evidence.
        ui = {"schema_version": 1, "language": self.language, "tab": self.tabs.currentIndex(),
              "manual_features": self.features if self.feature_source == "manual" else 0,
              "source_files": self.baseline_files}
        write_json(sidecar, ui)
        self.message.setText(self.tr_pair("已保存：" + str(self.document.path), "Saved: " + str(self.document.path)))
        self.refresh()

    def save_dialog(self, save_as=False):
        path = self.document.path
        if save_as or path is None:
            name, _ = QFileDialog.getSaveFileName(self, self.tr_pair("保存项目", "Save project"),
                                                 str(path or self.root / "projects/project.json"), "GPNB_v1 project (*.json)")
            if not name:
                return False
            path = Path(name)
        try:
            self.save_project(path, overwrite=path.exists())
            return True
        except (OSError, ValueError) as error:
            self.show_error(error)
            return False

    def confirm_discard(self):
        if not self.document.dirty:
            return True
        response = QMessageBox.question(self, "GPNB_v1", self.tr_pair("保存未保存的项目修改？", "Save unsaved project changes?"),
                                         QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel)
        return self.save_dialog() if response == QMessageBox.Save else response == QMessageBox.Discard

    def open_project(self, path):
        new = Document(self.root)
        new.load(path)
        self.document_generation += 1
        self.document = new
        self._kernel_recipe_draft = None
        self._input_mode_fingerprint = None
        self.resolved_display_model = None
        self.resolved_display_fingerprint = None
        self._auto_paths = {}
        self._plink_paths = {k:new.value["data"].get(k) for k in ("bed","fam")}
        self.audit, self.baseline_files, self.features, self.feature_source = None, {}, 0, "manual"
        sidecar = Path(str(new.path) + ".ui.json")
        if sidecar.is_file():
            try:
                ui = read_json(sidecar)
                if ui.get("schema_version") == 1:
                    self.language = ui.get("language") if ui.get("language") in ("zh_CN", "en_US") else new.value["language"]
                    self.features = ui.get("manual_features", 0)
                    if type(self.features) is not int or not 0 <= self.features < 2**31:
                        self.features = 0
                    records = ui.get("source_files", {})
                    if isinstance(records, dict) and all(isinstance(r, dict) and isinstance(r.get("sha256"), str)
                                                         for r in records.values()):
                        self.baseline_files = records
                    self.tabs.setCurrentIndex(ui["tab"] if type(ui.get("tab")) is int and 0 <= ui["tab"] < self.tabs.count() else 0)
            except (OSError, ValueError, AttributeError, TypeError):
                self.message.setText(self.tr_pair("界面状态文件不可用，项目本身已打开。", "UI state unavailable; project opened."))
        else:
            self.language = new.value["language"]
        self.populate()

    def open_dialog(self):
        if not self.confirm_discard():
            return
        path, _ = QFileDialog.getOpenFileName(self, self.tr_pair("打开项目", "Open project"), str(self.root / "projects"), "GPNB_v1 project (*.json)")
        if path:
            try:
                self.open_project(path)
            except (OSError, ValueError) as error:
                self.show_error(error)

    def new_project(self):
        if not self.confirm_discard():
            return
        self.document = Document(self.root)
        self._kernel_recipe_draft = None
        self._input_mode_fingerprint = None
        self.resolved_display_model = None
        self.resolved_display_fingerprint = None
        self._auto_paths = {}
        self._plink_paths = {"bed":"", "fam":""}
        self.document_generation += 1
        self.audit, self.baseline_files, self.features, self.feature_source = None, {}, 0, "manual"
        self.populate()

    def closeEvent(self, event: QCloseEvent):
        if self.workflow.close_pending:
            if self.workflow.jobs.busy:
                event.ignore()
            else:
                event.accept()
            return
        if self.workflow.jobs.busy:
            response = QMessageBox.question(self, "GPNB_v1", self.tr_pair(
                "停止当前任务并关闭？未完成结果将保留为中断记录。",
                "Stop the current job and close? Incomplete output remains an interruption record."),
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if response != QMessageBox.Yes or not self.confirm_discard():
                event.ignore()
                return
            self.workflow.close_pending = True
            self.workflow.cancel()
            event.ignore()
            return
        if not self.confirm_discard():
            event.ignore()
            return
        if self.process is not None:
            self.process.kill()
            self.process.waitForFinished(1000)
        event.accept()
