"""Explicit kernel recipes for training and descriptive matrix export."""
from __future__ import annotations

import copy

from PySide6.QtWidgets import (QCheckBox, QComboBox, QDialog, QDoubleSpinBox, QFileDialog,
                               QFormLayout, QHBoxLayout, QLabel, QLineEdit, QSpinBox, QVBoxLayout)


class KernelDialog(QDialog):
    def __init__(self, window, *, independent=False):
        super().__init__(window)
        from ..data.kernels import default_recipe
        from .input_modes import kernel_options
        self.window, self.independent = window, independent
        window.bind_text(self, "关系 / 相似度矩阵" if independent else "训练内核计算配方",
                         "Relationship / similarity matrix" if independent else "Training kernel recipe", "setWindowTitle")
        self.resize(650, 600)
        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.form = form
        layout.addLayout(form)
        recipe = copy.deepcopy(getattr(window, "_kernel_recipe_draft", None) or
                               (kernel_options(window.document.value) or {}).get("kernel") or default_recipe())
        self.kind = QComboBox()
        choices = [("加性 GRM · VanRaden 方法一", "Additive GRM · VanRaden method 1", "vanraden"),
                   ("线性核", "Linear kernel", "linear"), ("余弦相似度", "Cosine similarity", "cosine"),
                   ("高斯 RBF（平方欧氏距离）", "Gaussian RBF (squared Euclidean)", "rbf"),
                   ("指数距离（欧氏距离）", "Exponential distance (Euclidean)", "exponential"),
                   ("Laplacian（L1 距离）", "Laplacian (L1 distance)", "laplacian"),
                   ("多项式核", "Polynomial kernel", "polynomial")]
        for cn, en, key in choices:
            self.kind.addItem(window.tr_pair(cn, en), key)
        window.bind_combo(self.kind, [(cn, en) for cn, en, _ in choices])
        self.kind.setCurrentIndex(self.kind.findData(recipe["kind"]))
        form.addRow(window.label("算法", "Algorithm"), self.kind)
        self.imputation = QComboBox()
        self.imputation.addItem(window.tr_pair("参考个体均值", "Reference mean"), "mean")
        self.imputation.addItem(window.tr_pair("不填补（有缺失则停止）", "None (missing values stop computation)"), "none")
        window.bind_combo(self.imputation, [("参考个体均值", "Reference mean"), ("不填补（有缺失则停止）", "None (missing values stop computation)")])
        effective = recipe["imputation"] if independent else window.document.value["run"]["preprocessing"]["imputation"]
        self.imputation.setCurrentIndex(self.imputation.findData(effective))
        for key, zh, en in (("mode", "参考众数", "Reference mode"), ("median", "参考中位数", "Reference median"), ("knn", "训练参考 KNN", "Training-reference KNN")):
            self.imputation.addItem(window.tr_pair(zh,en), key)
        self.imputation.setCurrentIndex(self.imputation.findData(effective))
        window.bind_combo(self.imputation,[("参考个体均值","Reference mean"),("不填补（有缺失则停止）","None (missing values stop computation)"),("参考众数","Reference mode"),("参考中位数","Reference median"),("训练参考 KNN","Training-reference KNN")])
        self.imputation.setEnabled(independent)
        form.addRow(window.label("缺失值填补", "Missing-value imputation"), self.imputation)
        self.knn_button=window.button("KNN 参数…", "KNN options…", self.configure_knn)
        form.addRow(self.knn_button)
        self.imputation.currentIndexChanged.connect(self.update_controls)
        self.center, self.standardize, self.normalize_features = QCheckBox(), QCheckBox(), QCheckBox()
        for key, widget, cn, en in (("center", self.center, "按参考均值中心化", "Center by reference means"),
                                     ("standardize", self.standardize, "按参考标准差缩放", "Scale by reference standard deviations"),
                                     ("normalize_features", self.normalize_features, "线性核除以特征数", "Divide linear kernel by feature count")):
            window.bind_text(widget, cn, en)
            widget.setChecked(recipe[key])
            form.addRow(widget)
        self.gamma = QDoubleSpinBox()
        self.gamma.setDecimals(10)
        self.gamma.setRange(0.0000000001, 1e9)
        self.gamma.setValue(recipe["gamma"])
        form.addRow(window.label("γ（gamma）", "γ (gamma)"), self.gamma)
        self.coef0 = QDoubleSpinBox()
        self.coef0.setRange(0, 1e9)
        self.coef0.setDecimals(6)
        self.coef0.setValue(recipe["coef0"])
        form.addRow(window.label("多项式常数 c", "Polynomial constant c"), self.coef0)
        self.degree = QSpinBox()
        self.degree.setRange(1, 1000)
        self.degree.setValue(recipe["degree"])
        form.addRow(window.label("多项式次数 d", "Polynomial degree d"), self.degree)
        self.block_rows = QSpinBox()
        self.block_rows.setRange(1, 4096)
        self.block_rows.setValue(recipe["block_rows"])
        form.addRow(window.label("每块个体数", "Rows per block"), self.block_rows)
        self.block_markers = QSpinBox()
        self.block_markers.setRange(1, 65536)
        self.block_markers.setValue(recipe["block_markers"])
        form.addRow(window.label("每块位点数", "Markers per block"), self.block_markers)
        self.reference_mib, self.matrix_mib = QSpinBox(), QSpinBox()
        for widget, key, cn, en in ((self.reference_mib, "max_reference_bytes", "参考状态预算（MiB）", "Reference-state budget (MiB)"),
                                     (self.matrix_mib, "max_matrix_bytes", "矩阵预算（MiB）", "Matrix budget (MiB)")):
            widget.setRange(1, 2**20)
            widget.setValue(max(1, recipe[key] // 1024**2))
            form.addRow(window.label(cn, en), widget)
        self.advanced = QCheckBox(window.tr_pair("高级资源设置", "Advanced resource settings"))
        form.addRow(self.advanced)
        self.advanced.toggled.connect(self.update_controls)
        self.original = recipe
        self.note = QLabel()
        self.note.setWordWrap(True)
        from .form_helpers import help_button
        self.note.hide()
        layout.addWidget(help_button(window, ("矩阵用途与训练边界", "Matrix purpose and training boundary"),
            ("独立矩阵使用全队列，只用于描述。正式训练每折仅使用训练参考，填补继承训练设置。VanRaden 的频率中心化不能关闭。距离核旧项目的中心化设置保留。", "Independent matrices use the full cohort for description. Training fits references within each fold and inherits training imputation. VanRaden frequency centering is required. Legacy distance-kernel centering settings are preserved.")))
        if not independent:
            self.form.setRowVisible(self.imputation, False)
            layout.addWidget(window.button("查看训练内填补设置", "View training imputation", lambda: window.tabs.setCurrentIndex(2)))
        self.output_root = QLineEdit()
        self.text_export = QCheckBox()
        if independent:
            window.bind_text(self.text_export, "同时输出文本 CSV（大矩阵可能很慢）", "Also export CSV text (may be slow for large matrices)")
            row = QHBoxLayout()
            row.addWidget(self.output_root, 1)
            row.addWidget(window.button("选择输出根目录…", "Choose output root…", self.browse))
            form.addRow(window.label("可选输出根目录", "Optional output root"), row)
            form.addRow(self.text_export)
            layout.addWidget(window.button("开始独立计算", "Start independent computation", self.export, "start_matrix_export"))
        else:
            layout.addWidget(window.button("保存配方草稿", "Save recipe draft", self.save, "save_kernel_recipe"))
            if kernel_options(window.document.value):
                layout.addWidget(window.button("应用配方，保留当前网络", "Apply recipe, preserve current network", self.apply_recipe, "apply_kernel_recipe"))
        self.message = QLabel()
        self.message.setWordWrap(True)
        layout.addWidget(self.message)
        self.kind.currentIndexChanged.connect(self.update_controls)
        window.translation_callbacks.append(self.translate_if_alive)
        self.update_controls()

    def translate_if_alive(self):
        from shiboken6 import isValid
        if isValid(self):
            self.update_controls()

    def update_controls(self):
        w, kind = self.window, self.kind.currentData()
        self.form.setRowVisible(self.knn_button,self.independent and self.imputation.currentData()=="knn")
        visible = {self.center: kind in ("linear", "cosine", "polynomial"),
                   self.standardize: kind != "vanraden", self.normalize_features: kind == "linear",
                   self.gamma: kind in ("rbf", "exponential", "laplacian", "polynomial"),
                   self.coef0: kind == "polynomial", self.degree: kind == "polynomial"}
        for widget, show in visible.items():
            self.form.setRowVisible(widget, show)
            widget.setMaximumWidth(300)
        for widget in (self.block_rows, self.block_markers, self.reference_mib, self.matrix_mib):
            self.form.setRowVisible(widget, self.advanced.isChecked())
            widget.setMaximumWidth(300)
        if self.independent:
            count = (w.audit or {}).get("samples")
            estimate = (f"{count:,} × {count:,}; {count * count * 4:,} bytes (float32)" if count else w.tr_pair("检查数据后显示规模", "Check data to display size"))
            self.note.setText(w.tr_pair(
                "独立导出以全体导入个体为参考，仅用于描述。它不能替代每折训练内拟合。默认二进制矩阵；最低矩阵存储：",
                "Independent export uses all imported individuals as references, for description only. It does not replace fitting inside each training fold. Binary output is the default; minimum matrix storage: ") + estimate + "\n" +
                w.tr_pair("估算不包含参考状态、临时工作区和模型内存。", "Estimate excludes reference state, temporary workspace and model memory."))
        else:
            self.note.setText(w.tr_pair(
                "正式训练每折只用训练参考个体拟合，验证/测试/新个体计算 K(Q,T)。填补继承训练设置。VanRaden 按公式频率中心化，不能关闭；核输入神经网络不等于 GBLUP。保存后需在网络页应用输入。",
                "Each fold fits only its training references; validation/test/new individuals use K(Q,T). Imputation follows training settings. VanRaden frequency centering is required by its formula. A kernel-input network is not GBLUP. Apply inputs on the builder after saving."))

    def configure_knn(self):
        from .imputation_dialog import ImputationDialog
        dialog=ImputationDialog(self.window,self.original.get('imputation_options',{}))
        if dialog.exec():self.original['imputation_options']=dialog.value()

    def value(self):
        from ..data.kernels import validate_recipe
        result = copy.deepcopy(self.original)
        kind = self.kind.currentData()
        result.update(kind=kind, imputation=self.imputation.currentData(), center=self.center.isChecked() and kind != "vanraden",
                      standardize=self.standardize.isChecked() and kind != "vanraden",
                      normalize_features=self.normalize_features.isChecked() and kind == "linear", gamma=self.gamma.value(),
                      coef0=self.coef0.value(), degree=self.degree.value(), block_rows=self.block_rows.value(),
                      block_markers=self.block_markers.value(), max_reference_bytes=self.reference_mib.value() * 1024**2,
                      max_matrix_bytes=self.matrix_mib.value() * 1024**2)
        if result["imputation"]!="knn":result.pop("imputation_options",None)
        return validate_recipe(result)

    def save(self):
        try:
            self.window._kernel_recipe_draft = self.value()
            self.message.setText(self.window.tr_pair("配方草稿已保存；在网络页点击“应用输入并创建基础网络”。",
                                                      "Recipe draft saved; click Apply inputs and build a basic network on the builder."))
        except (ValueError, OSError) as error:
            self.message.setText(self.window.error_text(error))

    def browse(self):
        root = QFileDialog.getExistingDirectory(self, self.window.tr_pair("选择输出根目录", "Choose output root"), self.output_root.text())
        if root:
            self.output_root.setText(root)

    def apply_recipe(self):
        try:
            from .input_modes import kernel_options
            current = kernel_options(self.window.document.value)
            if not current:
                raise ValueError(self.window.tr_pair("请先配置核输入模式。", "Configure a kernel input mode first."))
            recipe = self.value()
            self.window.document.change(("run", "extensions", "kernel_features", "kernel"), recipe)
            self.window._kernel_recipe_draft = copy.deepcopy(recipe)
            self.window.refresh()
            self.message.setText(self.window.tr_pair("配方已应用；当前网络层和连接保持不变，请重新运行预检。",
                                                      "Recipe applied; layers and connections are preserved. Run preflight again."))
        except (ValueError, OSError) as error:
            self.message.setText(self.window.error_text(error))

    def export(self):
        try:
            self.window.workflow.start_matrix_export(self.value(), output_root=self.output_root.text() or None,
                                                     text=self.text_export.isChecked())
        except (ValueError, OSError) as error:
            self.message.setText(self.window.error_text(error))
