"""Qt process owner; protocol logs live outside immutable experiment archives."""
from __future__ import annotations

import json
import os
import sys
import uuid
from pathlib import Path

import psutil
from PySide6.QtCore import QObject, QProcess, QProcessEnvironment, QTimer, Signal

from ..data.files import write_json


class JobController(QObject):
    event = Signal(dict)
    finished = Signal(dict)
    log = Signal(str)

    def __init__(self, root, parent=None):
        super().__init__(parent)
        self.root = Path(root)
        self.process = None
        self.last_result = None
        self.cancel_timer = QTimer(self)
        self.cancel_timer.setSingleShot(True)
        self.cancel_timer.timeout.connect(self.force_stop)

    @property
    def busy(self):
        return self.process is not None

    def start(self, kind, options, *, device="cpu", executable=None):
        if self.busy:
            raise ValueError("A job is already running")
        self.directory = self.root / "jobs" / uuid.uuid4().hex
        self.directory.mkdir(parents=True)
        request = self.directory / "request.json"
        write_json(request, {"kind": kind, "options": options})
        from .runtime_profile import device_python
        executable = executable or str(device_python(self.root,device))
        self.buffer = b""
        self.terminal = None
        self.last_result = None
        self.cancel_requested = self.forced = False
        self.start_error = None
        self.kind = kind
        process = self.process = QProcess(self)
        process.setWorkingDirectory(str(self.root))
        environment = QProcessEnvironment.systemEnvironment()
        environment.insert("PYTHONIOENCODING", "utf-8")
        environment.insert("GPNB_ROOT", str(self.root))
        process.setProcessEnvironment(environment)
        process.readyReadStandardOutput.connect(self.read_stdout)
        process.readyReadStandardError.connect(self.read_stderr)
        process.finished.connect(self.on_finished)
        process.errorOccurred.connect(self.on_error)
        process.start(executable, ["-m", "gpnb.worker", "--request", str(request),
                                  "--parent-pid", str(os.getpid()),
                                  "--parent-created", str(psutil.Process().create_time())])

    def read_stdout(self):
        if self.process is None:
            return
        chunk = bytes(self.process.readAllStandardOutput())
        with (self.directory / "events.jsonl").open("ab") as stream:
            stream.write(chunk)
        self.buffer += chunk
        while b"\n" in self.buffer:
            line, self.buffer = self.buffer.split(b"\n", 1)
            try:
                event = json.loads(line.decode("utf-8"))
                if not isinstance(event, dict) or "event" not in event:
                    raise ValueError("invalid event")
                if event["event"] == "result":
                    self.terminal = event
                self.event.emit(event)
            except (ValueError, UnicodeError) as error:
                self.log.emit(f"Protocol error: {error}")

    def read_stderr(self):
        if self.process is not None:
            chunk = bytes(self.process.readAllStandardError())
            with (self.directory / "stderr.log").open("ab") as stream:
                stream.write(chunk)
            self.log.emit(chunk.decode("utf-8", errors="replace"))

    def on_error(self, error):
        if self.process is None:
            return
        self.start_error = self.process.errorString()
        if error == QProcess.FailedToStart:
            self.on_finished(-1, QProcess.CrashExit)

    def on_finished(self, code, exit_status):
        if self.process is None:
            return
        self.cancel_timer.stop()
        self.read_stdout()
        self.read_stderr()
        result = self.terminal
        if result is None or (result.get("status") == "completed" and
                              (code != 0 or exit_status != QProcess.NormalExit)):
            result = {"status": "cancelled" if self.cancel_requested else "failed",
                      "error": self.start_error or "Worker exited without a successful terminal event"}
        result = {**result, "exit_code": code, "forced": self.forced,
                  "job_directory": str(self.directory), "kind": self.kind}
        write_json(self.directory / "result.json", result)
        old, self.process = self.process, None
        old.deleteLater()
        self.last_result = result
        self.finished.emit(result)

    def cancel(self):
        if self.process is not None and not self.cancel_requested:
            self.cancel_requested = True
            self.process.write(b"cancel\n")
            self.cancel_timer.start(10000)
            self.log.emit("Cancel requested; waiting for a safe boundary (10 s maximum).")

    def force_stop(self):
        if self.process is not None:
            self.forced = True
            self.process.kill()
