"""Compact native objective controls backed by the same RunSpec as CLI."""
import copy
from PySide6.QtWidgets import QDialog, QVBoxLayout, QFormLayout, QComboBox, QLineEdit, QCheckBox, QLabel
from ..config import RunSpec


class ObjectiveDialog(QDialog):
    def __init__(self,window):
        super().__init__(window)
        self.window=window
        self.setWindowTitle(window.tr_pair("损失与优化器高级设置", "Objective and optimizer settings"))
        self.setMinimumWidth(500)
        layout=QVBoxLayout(self);self.form=QFormLayout();layout.addLayout(self.form)
        self.training=copy.deepcopy(window.document.value["run"]["training"])
        self.loss=QComboBox();self.loss.addItems(["mse","mae","focal_mae"])
        self.loss.setCurrentText(self.training["loss"]);self.loss.setObjectName("objective_loss")
        self.form.addRow(window.tr_pair("损失函数", "Loss"),self.loss)
        self.momentum=QLineEdit(str(self.training.get("momentum",0)))
        self.form.addRow("SGD momentum",self.momentum)
        self.beta=QLineEdit(str(self.training.get("focal_beta",.5)));self.gamma=QLineEdit(str(self.training.get("focal_gamma",1.)))
        self.form.addRow("Focal β",self.beta);self.form.addRow("Focal γ (≥1)",self.gamma)
        self.schedule=QComboBox();self.schedule.addItems(["None","ExponentialLR","StepLR"])
        options=self.training.get("scheduler") or {}
        self.schedule.setCurrentText(options.get("type","None"))
        self.form.addRow(window.tr_pair("学习率调度", "Learning-rate schedule"),self.schedule)
        self.decay=QLineEdit(str(options.get("gamma",.95)))
        self.steps=QLineEdit(str(options.get("step_size",90)))
        self.form.addRow(window.tr_pair("每次衰减乘数", "Decay multiplier"),self.decay)
        self.form.addRow(window.tr_pair("衰减间隔（轮）", "Decay every epochs"),self.steps)
        self.clip=QLineEdit(str(self.training.get("gradient_clip_norm") or ""))
        self.form.addRow(window.tr_pair("梯度范数上限（空白关闭）", "Gradient norm cap (blank disables)"),self.clip)
        help_text=window.tr_pair(
            "MSE 是平方误差；MAE 是绝对误差；focal MAE = tanh(β×绝对误差)^γ×绝对误差。损失使用项目的训练目标尺度。β=.5、γ=1 来自 GPformer；指数衰减 .95 只是可编辑示例，不是论文值。每轮训练后衰减，分阶段训练每阶段重新初始化调度。",
            "MSE uses squared error; MAE absolute error; focal MAE = tanh(β×absolute error)^γ×absolute error on the project's training target scale. β=.5 and γ=1 are reported by GPformer; exponential decay .95 is an editable example, not a paper setting. Schedulers step after each training epoch and reset at each stage.")
        label=QLabel(help_text);label.setWordWrap(True);layout.addWidget(label)
        layout.addWidget(window.button("保存", "Save",self.save,"save_objective"))
        self.loss.currentIndexChanged.connect(self.visibility);self.schedule.currentIndexChanged.connect(self.visibility)
        self.visibility()

    def visibility(self,*_):
        self.form.setRowVisible(self.momentum,self.training["optimizer"]=="SGD")
        self.form.setRowVisible(self.beta,self.loss.currentText()=="focal_mae")
        self.form.setRowVisible(self.gamma,self.loss.currentText()=="focal_mae")
        self.form.setRowVisible(self.decay,self.schedule.currentText()!="None")
        self.form.setRowVisible(self.steps,self.schedule.currentText()=="StepLR")

    def save(self):
        try:
            training=copy.deepcopy(self.training)
            training["loss"]=self.loss.currentText()
            if training["optimizer"]=="SGD":training["momentum"]=float(self.momentum.text())
            if training["loss"]=="focal_mae":training.update(focal_beta=float(self.beta.text()),focal_gamma=float(self.gamma.text()))
            kind=self.schedule.currentText()
            if kind=="None":training.pop("scheduler",None)
            else:
                training["scheduler"]=dict(type=kind,gamma=float(self.decay.text()))
                if kind=="StepLR":training["scheduler"]["step_size"]=int(self.steps.text())
            training["gradient_clip_norm"]=float(self.clip.text()) if self.clip.text().strip() else None
            run=copy.deepcopy(self.window.document.value["run"]);run["training"]=training
            RunSpec(run)
            self.window.document.change(("run","training"),training)
            self.window.refresh();self.accept()
        except ValueError as error:
            self.window.show_error(error)
