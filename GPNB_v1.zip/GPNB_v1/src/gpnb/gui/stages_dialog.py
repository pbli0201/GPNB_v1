import copy
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QDialog,QVBoxLayout,QHBoxLayout,QListWidget,QListWidgetItem,
    QComboBox,QSpinBox,QDoubleSpinBox,QFormLayout,QLabel,QPushButton)


class StagesDialog(QDialog):
    def __init__(self,window):
        super().__init__(window)
        self.window=window
        self.setWindowTitle(window.tr_pair("训练阶段", "Training stages"))
        self.resize(780,650)
        self.stages=copy.deepcopy(window.document.value["run"]["training"].get("stages",[]))
        layout=QVBoxLayout(self)
        note=QLabel(window.tr_pair("阶段设置替代总轮数。每阶段重置优化器和早停；有验证集时恢复最佳权重，固定轮数时保留最后权重。\n冻结按实际共享模块同时作用于参数和运行统计；测试集不参与预训练或调参。", "Stages replace global epochs. Each stage resets the optimizer and early stopping; validation restores the best state, while fixed-epoch stages keep the final state.\nFreezing applies to shared-module parameters and running statistics. Test data never participate in pretraining or tuning."))
        note.setWordWrap(True); layout.addWidget(note)
        self.list=QListWidget(); layout.addWidget(self.list)
        form=QFormLayout()
        self.mode=QComboBox(); self.mode.addItems(["pretrain","joint","regression"])
        self.epochs=QSpinBox(); self.epochs.setRange(1,1_000_000); self.epochs.setValue(10)
        self.regression=QDoubleSpinBox(); self.reconstruction=QDoubleSpinBox()
        for control in (self.regression,self.reconstruction):
            control.setRange(0,1e6); control.setDecimals(6)
        self.regression.setValue(1); self.reconstruction.setValue(.1)
        for name,control in (("Mode",self.mode),("Epochs",self.epochs),
                             ("Regression weight",self.regression),("Reconstruction weight",self.reconstruction)):
            form.addRow(window.tr_pair({"Mode":"模式", "Epochs":"轮数", "Regression weight":"回归损失权重", "Reconstruction weight":"重建损失权重"}[name],name),control)
        self.freeze=QListWidget()
        for row in window.document.value["model"]["layers"]:
            item=QListWidgetItem(row["id"]+" · "+row["type"])
            item.setData(Qt.UserRole,row["id"]); item.setCheckState(Qt.Unchecked); self.freeze.addItem(item)
        form.addRow(window.tr_pair("冻结的层 ID", "Freeze layer IDs"),self.freeze); layout.addLayout(form)
        buttons=QHBoxLayout()
        for label,fn in (("新增 / Add",self.add),("更新 / Update",self.update_stage),
                         ("删除 / Remove",self.remove),("上移 / Up",lambda:self.move(-1)),
                         ("下移 / Down",lambda:self.move(1)),("应用 / Apply",self.apply)):
            zh,en=label.split(" / "); button=QPushButton(window.tr_pair(zh,en)); button.clicked.connect(fn); buttons.addWidget(button)
        layout.addLayout(buttons)
        self.message=QLabel(); self.message.setWordWrap(True); layout.addWidget(self.message)
        self.list.currentRowChanged.connect(self.select)
        window.translation_callbacks.append(self.translate)
        self.refresh()

    def translate(self):
        from shiboken6 import isValid
        if isValid(self):
            # Do not select the stage again: its form may contain unsaved edits.
            for i, stage in enumerate(self.stages):
                self.list.item(i).setText(self.stage_text(i, stage))

    def stage_text(self, i, s):
        return self.window.tr_pair(f"{i+1}. {s['mode']}，轮数={s['epochs']}，回归权重={s['regression_weight']}，重建权重={s['reconstruction_weight']}，冻结={s['freeze']}", f"{i+1}. {s['mode']}, epochs={s['epochs']}, regression={s['regression_weight']}, reconstruction={s['reconstruction_weight']}, freeze={s['freeze']}")

    def refresh(self,index=0):
        self.list.blockSignals(True); self.list.clear()
        for i,s in enumerate(self.stages):
            self.list.addItem(self.stage_text(i, s))
        self.list.blockSignals(False)
        if self.stages:
            self.list.setCurrentRow(min(index,len(self.stages)-1))

    def select(self,index):
        if index<0:
            return
        s=self.stages[index]
        self.mode.setCurrentText(s["mode"]); self.epochs.setValue(s["epochs"])
        self.regression.setValue(s["regression_weight"]); self.reconstruction.setValue(s["reconstruction_weight"])
        for i in range(self.freeze.count()):
            item=self.freeze.item(i)
            item.setCheckState(Qt.Checked if item.data(Qt.UserRole) in s["freeze"] else Qt.Unchecked)

    def draft(self):
        return dict(mode=self.mode.currentText(),epochs=self.epochs.value(),
            regression_weight=self.regression.value(),reconstruction_weight=self.reconstruction.value(),
            freeze=[self.freeze.item(i).data(Qt.UserRole) for i in range(self.freeze.count())
                    if self.freeze.item(i).checkState()==Qt.Checked])

    def add(self):
        self.stages.append(self.draft()); self.refresh(len(self.stages)-1)

    def update_stage(self):
        index=self.list.currentRow()
        if index>=0:
            self.stages[index]=self.draft(); self.refresh(index)

    def remove(self):
        index=self.list.currentRow()
        if index>=0:
            self.stages.pop(index); self.refresh(max(0,index-1))

    def move(self,delta):
        index=self.list.currentRow(); other=index+delta
        if index>=0 and 0<=other<len(self.stages):
            self.stages[index],self.stages[other]=self.stages[other],self.stages[index]
            self.refresh(other)

    def apply(self):
        try:
            from ..config import ProjectSpec
            value=copy.deepcopy(self.window.document.value)
            if self.stages:
                value["run"]["training"]["stages"]=copy.deepcopy(self.stages)
            else:
                value["run"]["training"].pop("stages",None)
            ProjectSpec(value)
            self.window.document.value=value; self.window.document.dirty=True
            self.window.refresh()
            self.message.setText(self.window.tr_pair("已应用", "Applied"))
        except Exception as error:
            self.message.setText(self.window.error_text(error))
