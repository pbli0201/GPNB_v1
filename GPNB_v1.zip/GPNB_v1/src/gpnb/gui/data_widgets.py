"""Small reusable data-entry widgets; scientific state stays in ProjectSpec."""
import json
from pathlib import Path

from PySide6.QtCore import Signal, Qt
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QScrollArea, QGridLayout, QTabWidget, QTableWidget, QTableWidgetItem, QHeaderView,
    QMessageBox, QComboBox, QFormLayout, QDialog, QDialogButtonBox)


class TraitSelector(QWidget):
    currentTextChanged = Signal(str)

    def __init__(self, window=None):
        from PySide6.QtWidgets import QListWidget,QCheckBox
        super().__init__();self.window=window;self.names=[];self.stats={};self._chosen=[]
        layout=QVBoxLayout(self);layout.setContentsMargins(0,0,0,0)
        self.current=QLineEdit();self.current.setMaximumWidth(400)
        self.current.textChanged.connect(self.currentTextChanged)
        self.current.setPlaceholderText('Primary trait');layout.addWidget(self.current)
        self.filter=QLineEdit();self.filter.setPlaceholderText(window.tr_pair('搜索性状','Search traits') if window else 'Search traits')
        self.filter.textChanged.connect(self.filter_rows);layout.addWidget(self.filter)
        if window:window.bind_text(self.filter,'搜索性状','Search traits','setPlaceholderText')
        self.list=QListWidget();self.list.setMaximumHeight(180);layout.addWidget(self.list)
        self.list.itemChanged.connect(self.selection_changed)
        row=QHBoxLayout();layout.addLayout(row)
        for zh,en,fn in [('全选可用性状','Select all available',self.select_all),('清空','Clear',self.unselect_all)]:
            button=QPushButton(window.tr_pair(zh,en) if window else en);button.clicked.connect(fn);row.addWidget(button)
            if window:window.bind_text(button,zh,en)
        self.count=QLabel();row.addWidget(self.count)
        if window:
            from .form_helpers import help_button
            row.addWidget(help_button(window,('性状选择与人数','Trait selection and counts'),
                ('n 为表型表中的有效数、NA 为缺失数；实际匹配与划分人数见运行前预览。数值列也可能是协变量，请只勾选目标性状。分别训练每个性状保存一个模型；联合训练需确认共享输出、单位和权重。','n is valid values in the phenotype table and NA is missing values; actual matched partition counts appear in the pre-run preview. Numeric columns may be covariates: select intended targets only. Separate training saves one model per trait; joint training requires explicit output, unit and weight settings.')))
        self.mode=QComboBox();self.mode.addItem(window.tr_pair('分别训练（每性状一个模型）','Separate training (one model/trait)') if window else 'Separate','separate')
        self.mode.addItem(window.tr_pair('联合训练（共享多输出网络）','Joint training (shared multi-output model)') if window else 'Joint','joint')
        if window:window.bind_combo(self.mode,[('分别训练（每性状一个模型）','Separate training (one model/trait)'),('联合训练（共享多输出网络）','Joint training (shared multi-output model)')])
        layout.addWidget(self.mode)
        apply=QPushButton(window.tr_pair('应用所选性状与任务模式','Apply selected traits and task mode') if window else 'Apply')
        apply.clicked.connect(self.apply_selection);layout.addWidget(apply)
        if window:window.bind_text(apply,'应用所选性状与任务模式','Apply selected traits and task mode')
        self.rebuild()

    def rebuild(self):
        from PySide6.QtWidgets import QListWidgetItem
        self.list.blockSignals(True);self.list.clear()
        for name in self.names:
            stats=self.stats.get(name,{})
            suffix=f"  [n={stats.get('numeric','?')}, NA={stats.get('missing','?')}, {stats.get('unit','—')}]"
            item=QListWidgetItem(name+suffix);item.setData(Qt.UserRole,name)
            item.setFlags(item.flags()|Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Checked if name in self._chosen else Qt.Unchecked)
            item.setToolTip(name+suffix);self.list.addItem(item)
        self.list.blockSignals(False);self.filter_rows()
        self.count.setText(str(len(self._chosen)))

    def filter_rows(self,*_):
        query=self.filter.text().casefold()
        for i in range(self.list.count()):
            item=self.list.item(i);item.setHidden(query not in item.data(Qt.UserRole).casefold())

    def selection_changed(self,*_):
        self._chosen=[self.list.item(i).data(Qt.UserRole) for i in range(self.list.count()) if self.list.item(i).checkState()==Qt.Checked]
        self.count.setText(str(len(self._chosen)) + (' 已选' if self.window and self.window.language=='zh_CN' else ' selected'))

    def select_all(self):
        for i in range(self.list.count()):self.list.item(i).setCheckState(Qt.Checked)

    def unselect_all(self):
        for i in range(self.list.count()):self.list.item(i).setCheckState(Qt.Unchecked)

    def restore(self, project):
        batch=project.get('extensions',{}).get('trait_batch')
        joint=project.get('extensions',{}).get('multitask')
        self._chosen=batch['traits'][:] if batch else [t['column'] for t in joint['targets']] if joint else [project['data']['phenotype_options']['trait']]
        self.mode.setCurrentIndex(1 if joint else 0)
        if self.names:self.rebuild()

    def apply_selection(self):
        if not self.window:return
        try:
            import copy
            from ..config import ProjectSpec,ModelSpec
            w=self.window;value=copy.deepcopy(w.document.value)
            if not self._chosen:raise ValueError(w.tr_pair('请勾选至少一个数值性状。','Select at least one numeric trait.'))
            value['data']['phenotype_options']['trait']=self._chosen[0]
            ext=value.setdefault('extensions',{})
            if self.mode.currentData()=='separate':
                if ext.get('multitask'):raise ValueError(w.tr_pair('请先在多目标窗口恢复单目标网络，再应用分别训练。','Restore a single-output model in the multi-target dialog before separate training.'))
                ext['trait_batch']=dict(mode='separate',traits=self._chosen[:])
                if len(self._chosen)==1:ext.pop('trait_batch',None)
                value['run']['split']['reuse_manifest']=None
                cv=value['run'].get('extensions',{}).get('cross_validation')
                if cv:cv['reuse_manifest']=None
                ProjectSpec(value);w.document.value=value;w.document.dirty=True
                w.invalidate_audit();w.populate();w.refresh()
            else:
                from .multitask_dialog import MultitaskDialog
                dialog=MultitaskDialog(w);dialog.table.setRowCount(0);dialog.protocol.setCurrentIndex(1)
                for i,name in enumerate(self._chosen):dialog.add(dict(id=f'target{i+1}',column=name,trait=name,environment='unspecified',unit='unspecified',correction='unspecified',weight=1.))
                w.multitask_dialog=dialog;dialog.show()
        except (ValueError,KeyError) as error:self.window.show_error(error)

    def currentText(self):return self.current.text()
    def setEditText(self,value):self.current.setText(value)
    def setText(self,value):self.setEditText(value)
    def setCurrentText(self,value):self.setEditText(value)
    def findText(self,value):return self.names.index(value) if value in self.names else -1
    def clear(self):self.names=[];self.rebuild()
    def addItems(self,values):self.names.extend(values);self.rebuild()


def table_widget():
    table=QTableWidget()
    table.setEditTriggers(QTableWidget.NoEditTriggers)
    table.setAlternatingRowColors(True)
    table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
    table.setMinimumHeight(180)
    return table


def fill_table(table, headers, rows, statuses=None):
    table.clear(); table.setColumnCount(len(headers)); table.setHorizontalHeaderLabels(headers)
    table.setRowCount(len(rows))
    for i,row in enumerate(rows):
        status = statuses[i] if statuses else ""
        color = "#fee2e2" if status in ("genotype_only","phenotype_only","matched_invalid_label","error") else "#fff3cd" if status=="matched_missing_label" else None
        for j,value in enumerate(row):
            item=QTableWidgetItem("—" if value is None else str(value))
            if color: item.setBackground(QColor(color)); item.setForeground(QColor("#172b40"))
            table.setItem(i,j,item)


class MatrixFields(QWidget):
    changed = Signal()
    def __init__(self, window):
        super().__init__(); self.window=window
        form=QFormLayout(self)
        self.path=QLineEdit(); self.path.setObjectName("matrix_path")
        row=QHBoxLayout(); browse=window.button("选择…","Browse…",self.browse)
        row.addWidget(browse); row.addWidget(self.path,1)
        form.addRow(window.label("基因型矩阵","Genotype matrix"),row)
        self.delimiter=QComboBox()
        for label,value in [("CSV (,)",","),("TSV (Tab)","\t"),("Whitespace","whitespace")]:self.delimiter.addItem(label,value)
        window.bind_combo(self.delimiter,[("逗号 CSV (,)","Comma CSV (,)"),("制表符 Tab","Tab"),("空白分隔 TXT","Whitespace TXT")])
        self.encoding=QComboBox(); self.encoding.addItems(["utf-8","utf-8-sig","gb18030"])
        self.coding=QComboBox()
        self.coding.addItem("0 / 1 / 2","012");self.coding.addItem("-1 / 0 / 1","-101")
        self.alleles=QComboBox();self.alleles.addItem("BIM A1","BIM_A1");self.alleles.addItem("Declared","DECLARED")
        window.bind_combo(self.alleles,[("计数 BIM 中的 A1（需 BIM）","Count BIM A1 (BIM required)"),("使用来源编码声明（不提供 BIM）","Use source coding declaration (without BIM)")])
        self.declaration=QLineEdit();self.declaration.setObjectName("allele_declaration")
        window.bind_text(self.declaration,"例如：育种面板A_供应商编码_v1；新数据必须使用同一编码来源","Example: panelA_vendor_encoding_v1; new data must use the same coding source",setter="setPlaceholderText")
        self.ids=QLineEdit('["FID", "IID"]'); self.missing=QLineEdit('["", "NA", "NaN"]')
        for zh,en,widget in [("矩阵分隔符","Matrix delimiter",self.delimiter),("文件字符编码","Text encoding",self.encoding),
            ("基因型数值编码","Genotype coding",self.coding),("等位基因依据","Allele basis",self.alleles),
            ("ID 列（一个 IID 或 FID、IID；JSON）","ID columns (IID alone or FID, IID; JSON)",self.ids),("缺失标记（JSON）","Missing tokens (JSON)",self.missing)]:
            form.addRow(window.label(zh,en),widget)
        self.declaration_label=window.label("编码来源声明","Coding source declaration")
        form.addRow(self.declaration_label,self.declaration)
        self.hint=window.label("每行一个个体、每列一个唯一位点。-1/0/1 转换为 0/1/2；缺失必须另行指定。无 BIM 时不能验证生物学等位基因方向或使用位置相关功能。","One individual per row and one uniquely named marker per column. -1/0/1 becomes 0/1/2; missing calls use separate tokens. Without BIM, allele direction and position-dependent features cannot be verified.")
        self.hint.setWordWrap(True);form.addRow(self.hint)
        form.addRow(window.button("预览前 8 行","Preview first 8 rows",self.preview,"preview_matrix"))
        for widget in (self.path,self.ids,self.missing,self.declaration): widget.textChanged.connect(self.changed)
        for widget in (self.delimiter,self.encoding,self.coding): widget.currentIndexChanged.connect(self.changed)
        self.alleles.currentIndexChanged.connect(self.allele_changed)
        self.translate()

    def allele_changed(self):
        self.translate();self.changed.emit()

    def translate(self):
        declared=self.alleles.currentData()=="DECLARED"
        self.declaration.setVisible(declared);self.declaration_label.setVisible(declared)

    def preview(self):
        from ..data.genotypes import preview_matrix
        try:
            options=self.value()
            from ..config import resolve_project_path
            project_path=self.window.document.path or (self.window.root/"project.json")
            options["path"]=str(resolve_project_path(project_path,options["path"]))
            result=preview_matrix(options)
            dialog=QDialog(self);self.window.bind_text(dialog,"矩阵预览","Matrix preview",setter="setWindowTitle")
            dialog.resize(900,400);layout=QVBoxLayout(dialog)
            label=self.window.label("仅检查前 8 行，最多显示 40 列；训练前请执行完整数据检查。","Only the first 8 rows are checked; up to 40 columns displayed. Run the full data check before training.")
            label.setWordWrap(True);layout.addWidget(label)
            table=table_widget();fill_table(table,result["columns"],result["rows"]);layout.addWidget(table)
            close=QDialogButtonBox(QDialogButtonBox.Close);close.rejected.connect(dialog.reject);layout.addWidget(close)
            dialog.exec()
        except Exception as error:self.window.show_error(str(error))

    def browse(self):
        from PySide6.QtWidgets import QFileDialog
        path,_=QFileDialog.getOpenFileName(self,self.window.tr_pair("选择基因型矩阵","Select genotype matrix"),str(self.window.root),"CSV / TXT (*.csv *.tsv *.txt)")
        if path: self.path.setText(str(Path(path))); self.path.setToolTip(path)

    def value(self):
        value=dict(path=self.path.text(),delimiter=self.delimiter.currentData(),encoding=self.encoding.currentText(),
            id_columns=json.loads(self.ids.text()),missing_tokens=json.loads(self.missing.text()),
            coding=self.coding.currentData(),counted_allele=self.alleles.currentData())
        if value["counted_allele"]=="DECLARED":value["allele_declaration"]=self.declaration.text()
        return value

    def populate(self, value):
        self.blockSignals(True)
        self.path.setText(value.get("path","")); self.delimiter.setCurrentIndex(self.delimiter.findData(value.get("delimiter",",")))
        self.encoding.setCurrentText(value.get("encoding","utf-8"))
        self.coding.setCurrentIndex(self.coding.findData(value.get("coding","012")))
        self.alleles.setCurrentIndex(self.alleles.findData(value.get("counted_allele","BIM_A1")))
        self.declaration.setText(value.get("allele_declaration",""))
        self.ids.setText(json.dumps(value.get("id_columns",["FID","IID"])))
        self.missing.setText(json.dumps(value.get("missing_tokens",["","NA","NaN"])))
        self.blockSignals(False)
        self.translate()


def format_help(parent, kind):
    texts={
      "plink": ("PLINK：SNP-major BED + BIM + FAM。\nBIM 六列：染色体、位点 ID、遗传位置、物理位置、A1、A2。\nFAM 六列：FID、IID、父本、母本、性别、表型。\n基因型计数 A1：0/1/2；ID 始终按字符串保存。FID 不自动视为家系。", "PLINK: SNP-major BED + BIM + FAM.\nBIM: chromosome, marker ID, cM, bp, A1, A2 (6 columns).\nFAM: FID, IID, father, mother, sex, phenotype (6 columns).\nCalls count A1: 0/1/2; IDs remain strings. FID is not assumed to be family."),
      "matrix": ('CSV 或 TXT：每行一个个体，每列一个位点。\nIID,rs1,rs2\n0001,0,NA\n0002,2,1\n\n可用一个 IID 或 FID+IID。选择 0/1/2 或 -1/0/1 编码，后者按加 1 转换。有效基因型不能同时用作缺失标记；空白分隔请用 NA 等明确标记。\n有 BIM：位点名与顺序必须相同，数值计数 A1。\n无 BIM：必须提供唯一位点名和编码来源声明；预测时核对声明，但无法独立验证等位基因方向。请勿将两种来源编码混用。', 'CSV or TXT: one individual per row, one marker per column.\nIID,rs1,rs2\n0001,0,NA\n0002,2,1\n\nUse IID alone or FID+IID. Select 0/1/2 or -1/0/1 coding; the latter is shifted by +1. Observed calls cannot also be missing tokens. Whitespace TXT needs explicit tokens such as NA.\nWith BIM: marker names and order must match, and values count A1.\nWithout BIM: unique marker names and a coding source declaration are required. Prediction checks this declaration, but cannot independently verify allele direction. Do not mix coding sources.'),
      "phenotype": ('CSV/TXT：每行一个个体，每列一个性状。\nFID,IID,height,yield\nF01,0001,12.4,3.8\nF01,0002,NA,4.1\n\nID 列：["FID", "IID"] 或 ["IID"]。基因型只有 IID 时，表型也选择 IID 匹配。缺失标签不参与监督评估，不填补为真值。前导零始终保留。', 'CSV/TXT: one individual per row, named traits in columns.\nFID,IID,height,yield\nF01,0001,12.4,3.8\nF01,0002,NA,4.1\n\nID columns: ["FID", "IID"] or ["IID"]. An IID-only genotype matrix requires IID phenotype matching. Missing labels are excluded from supervised evaluation, never filled as true labels. Leading zeros are preserved.'),
      "advanced": ("来源清单：可选的输入哈希与上游处理记录。\n基因型等价组：记录原始基因型相同的样本；不等于家系或群体。仅在明确选择等价组划分时约束划分。\n列：FID,IID,genotype_equivalence_group,group_size,basis。准备数据时核对等价性。普通用户可留空。", "Provenance: optional input hashes and upstream processing evidence.\nGenotype-equivalence groups record identical raw genotypes; they are not families or populations. They constrain splitting only when equivalence-group splitting is explicitly selected.\nColumns: FID,IID,genotype_equivalence_group,group_size,basis. Preparation verifies equivalence. Ordinary users may leave both files empty."),
      "branches": ("顺序：上一层 → 下一层。\n分支：显式连接端口支持跳跃连接、Add/Concat、多输入、交叉注意力及重建输出。\n分支有向无环图本身并不是图神经网络。共享调用共享参数与缓冲区。", "Sequential: previous layer → next layer.\nBranches: explicit ports allow skip connections, Add/Concat, multiple inputs, CrossAttention and reconstruction heads.\nA branch DAG is not itself a graph neural network. Shared calls share parameters and buffers.")
    }
    QMessageBox.information(parent,parent.tr_pair("格式与用途","Format and meaning"),parent.tr_pair(*texts[kind]))
