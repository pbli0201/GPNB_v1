"""Explicit graph import runs in a subprocess, keeping the editor responsive."""
import json
import sys
import uuid
from pathlib import Path

from PySide6.QtCore import QProcess
from PySide6.QtWidgets import (QDialog, QFileDialog, QFormLayout, QHBoxLayout, QLineEdit,
                              QComboBox, QPushButton, QPlainTextEdit, QVBoxLayout, QSpinBox, QDoubleSpinBox, QCheckBox)
from ..config import load_spec
from ..graphs.spec import GraphSpec
from ..graphs.state import resolve_graph
from ..models.migration import migrate_model


class GraphDialog(QDialog):
    def __init__(self, window):
        super().__init__(window)
        self.window, self.process = window, None
        self.setWindowTitle(window.tr_pair("位点图定义", "Locus graph definition"))
        self.resize(760, 640)
        layout = QVBoxLayout(self)
        form = QFormLayout()
        layout.addLayout(form)
        self.source_kind = QComboBox()
        self.source_kind.addItems(["external", "training_ld"])
        form.addRow(window.tr_pair("图来源", "Graph source"), self.source_kind)
        self.fields = {}
        for key, zh, en in (("bim", "当前数据 BIM", "Input BIM"), ("edges", "边 CSV：source,target,weight", "Edges CSV: source,target,weight"),
                            ("mapping", "可选分组 CSV：node_id,marker_id", "Optional groups CSV: node_id,marker_id")):
            row = QHBoxLayout()
            edit = self.fields[key] = QLineEdit()
            if key == "bim":
                edit.setText(window.document.value["data"]["bim"] or "")
            row.addWidget(edit)
            button = QPushButton(window.tr_pair("选择", "Browse"))
            button.clicked.connect(lambda checked=False, k=key: self.browse(k))
            row.addWidget(button)
            form.addRow(window.tr_pair(zh, en), row)
        self.options = {}
        for key, choices in (("direction", ["undirected", "directed"]), ("self_loops", ["add_unit", "none", "preserve"]),
                             ("duplicate_edges", ["error", "sum"]), ("filtered_nodes", ["drop", "error"]),
                             ("aggregation", ["mean", "sum"]), ("declaration", ["unknown", "external_fixed"])):
            box = self.options[key] = QComboBox()
            box.addItems(choices)
            labels = {"direction":"方向", "self_loops":"自环", "duplicate_edges":"重复边", "filtered_nodes":"筛选后空节点", "aggregation":"聚合", "declaration":"来源声明"}
            form.addRow(window.tr_pair(labels[key], key.replace("_", " ")), box)
        self.note = QLineEdit()
        form.addRow(window.tr_pair("来源与独立性说明", "Source / independence note"), self.note)
        self.ld = {}
        for key, default, minimum, maximum in (("window", 16, 1, 256), ("max_pairs", 500_000, 1, 2_000_000),
                                             ("max_edges", 200_000, 1, 1_000_000)):
            edit = self.ld[key] = QSpinBox()
            edit.setRange(minimum, maximum)
            edit.setValue(default)
            form.addRow(window.tr_pair({"window":"LD：窗口位点数", "max_pairs":"LD：位点对上限", "max_edges":"LD：边数上限"}[key], "LD: " + key.replace("_", " ")), edit)
        self.r2 = QDoubleSpinBox()
        self.r2.setDecimals(6)
        self.r2.setRange(.000001, 1.)
        self.r2.setValue(.2)
        form.addRow("LD: r² ≥", self.r2)
        self.same_chromosome = QCheckBox(window.tr_pair("仅同染色体标签内连边", "Edges within identical chromosome labels"))
        self.same_chromosome.setChecked(True)
        form.addRow(self.same_chromosome)
        self.ld_weight = QComboBox()
        self.ld_weight.addItems(["r2", "binary"])
        form.addRow(window.tr_pair("LD：权重", "LD: weight"), self.ld_weight)
        self.text = QPlainTextEdit()
        self.text.setReadOnly(True)
        layout.addWidget(self.text)
        self.text.setPlainText(window.tr_pair(
            "外部固定图声明不是无泄漏证明。节点 ID 保留字符串；必须覆盖全部 BIM 标记。筛选后空节点按所选策略处理。导入后可选择 GCN / GraphSAGE / GIN / GAT。",
            "Declaring external_fixed is not proof against leakage. String node IDs must cover BIM markers. Empty filtered nodes follow the selected policy. After import choose GCN / GraphSAGE / GIN / GAT."))
        row = QHBoxLayout()
        self.import_button = QPushButton(window.tr_pair("导入并附加到项目", "Import and attach"))
        self.import_button.clicked.connect(self.start_import)
        row.addWidget(self.import_button)
        self.load_button = QPushButton(window.tr_pair("打开已有 GraphSpec", "Open GraphSpec"))
        self.load_button.clicked.connect(self.open_existing)
        row.addWidget(self.load_button)
        self.cancel_button = QPushButton(window.tr_pair("取消导入", "Cancel import"))
        self.cancel_button.clicked.connect(lambda: self.process.kill() if self.process else None)
        self.cancel_button.setEnabled(False)
        row.addWidget(self.cancel_button)
        layout.addLayout(row)
        existing = window.document.value["model"].get("graph_spec")
        if existing:
            self.describe(GraphSpec(existing))
        self.source_kind.currentTextChanged.connect(self.change_source)
        self.change_source(self.source_kind.currentText())

    def change_source(self, kind):
        external = kind == "external"
        for key in ("edges", "mapping"):
            self.fields[key].setEnabled(external)
        for box in self.options.values():
            box.setEnabled(external)
        self.note.setEnabled(external)
        for box in [*self.ld.values(), self.r2, self.same_chromosome, self.ld_weight]:
            box.setEnabled(not external)

    def browse(self, key):
        path, _ = QFileDialog.getOpenFileName(self, key, self.fields[key].text())
        if path:
            self.fields[key].setText(path)

    def describe(self, spec):
        state = resolve_graph(spec)
        degree = [0]*len(state["nodes"])
        for a, b, _ in state["edges"]:
            if a != b:
                degree[b] += 1
        summary = dict(name=spec.to_dict()["name"], sha256=spec.sha256, nodes=len(degree),
                       directed_edges=len(state["edges"]), nodes_without_nonself_incoming=sum(d == 0 for d in degree),
                       min_in_degree=min(degree), max_in_degree=max(degree),
                       preview="Before training marker selection; first 100 nodes only.",
                       nodes_preview=[dict(id=n, retained_marker_indices=g) for n, g in zip(state["nodes"][:100], state["groups"][:100])])
        if spec.to_dict()["source"]["kind"] == "training_ld":
            summary.update(directed_edges=None, nodes_without_nonself_incoming=None, min_in_degree=None, max_in_degree=None,
                           preview="LD not fitted: topology statistics unknown until inner-training fit.", ld=spec.to_dict()["source"]["ld"])
        self.text.setPlainText(json.dumps(summary, ensure_ascii=False, indent=2))

    def attach(self, path):
        try:
            spec = load_spec(path)
            if not isinstance(spec, GraphSpec):
                raise ValueError("Expected GraphSpec")
            model = self.window.document.value["model"]
            if model["schema_version"] == 1:
                from ..config import ModelSpec
                model = migrate_model(ModelSpec(model)).to_dict()
            model["graph_spec"] = spec.to_dict()
            self.window.document.change(("model",), model)
            self.window.graph_state = None
            self.window.features = len(spec.to_dict()["markers"])
            self.window.feature_source = "manual"
            self.window.feature_input.blockSignals(True)
            self.window.feature_input.setValue(self.window.features)
            self.window.feature_input.blockSignals(False)
            self.describe(spec)
            self.window.rebuild_cards()
            self.window.refresh()
        except (ValueError, OSError) as error:
            self.text.setPlainText(self.window.error_text(error))

    def open_existing(self):
        path, _ = QFileDialog.getOpenFileName(self, "GraphSpec", str(self.window.root), "*.json")
        if path:
            self.attach(Path(path))

    def start_import(self):
        from .i18n import project_output
        try:
            destination = project_output(self.window, "checks", "graph")
        except (ValueError, OSError) as error:
            self.text.setPlainText(self.window.error_text(error))
            return
        if self.source_kind.currentText() == "external":
            args = ["-m", "gpnb", "import-graph", "--output", str(destination), "--note", self.note.text()]
            for key, edit in self.fields.items():
                if edit.text():
                    args.extend(["--" + key, edit.text()])
            for key, box in self.options.items():
                args.extend(["--" + key.replace("_", "-"), box.currentText()])
        else:
            args = ["-m", "gpnb", "define-ld-graph", "--output", str(destination), "--bim", self.fields["bim"].text(),
                    "--r2-min", str(self.r2.value()), "--weight", self.ld_weight.currentText(),
                    "--same-chromosome" if self.same_chromosome.isChecked() else "--no-same-chromosome"]
            for key, edit in self.ld.items():
                args.extend(["--"+key.replace("_", "-"), str(edit.value())])
        self.process = QProcess(self)
        self.process.setWorkingDirectory(str(self.window.root))
        self.process.setProcessChannelMode(QProcess.MergedChannels)
        self.process.readyReadStandardOutput.connect(lambda: self.text.appendPlainText(bytes(self.process.readAllStandardOutput()).decode("utf-8", errors="replace")))
        self.process.finished.connect(lambda code, status: self.finished_import(code, destination))
        self.process.errorOccurred.connect(self.process_error)
        self.import_button.setEnabled(False)
        self.load_button.setEnabled(False)
        self.cancel_button.setEnabled(True)
        self.text.clear()
        self.process.start(sys.executable, args)

    def finished_import(self, code, destination):
        self.import_button.setEnabled(True)
        self.load_button.setEnabled(True)
        self.cancel_button.setEnabled(False)
        if code == 0:
            self.attach(destination / "graph.json")

    def process_error(self, error):
        self.text.appendPlainText(self.process.errorString())
        if error == QProcess.FailedToStart:
            self.import_button.setEnabled(True)
            self.load_button.setEnabled(True)
            self.cancel_button.setEnabled(False)

    def closeEvent(self, event):
        if self.process and self.process.state() != QProcess.NotRunning:
            event.ignore()
            return
        event.accept()
