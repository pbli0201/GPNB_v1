"""Offline guidance uses training/validation history only; never changes a run."""
from PySide6.QtWidgets import QDialog, QVBoxLayout, QTextBrowser, QDialogButtonBox


def history_hints(history, language='en'):
    t = lambda zh,en: zh if language == 'zh' else en
    rows = [r for r in history if r.get('validation_loss', r.get('validation_mse')) is not None]
    if not rows:
        return [t('当前没有验证记录；固定轮数模式不使用验证早停。', 'No validation records; fixed-epoch training does not use validation early stopping.')]
    latest = rows[-1]
    loss = lambda r: r.get('validation_loss', r.get('validation_mse'))
    best = min(rows, key=loss)
    notes = [t(f"最佳已记录验证轮次：{best['epoch']}；当前轮次：{latest['epoch']}。",
               f"Best recorded validation epoch: {best['epoch']}; current epoch: {latest['epoch']}.")]
    if len(rows) >= 5 and loss(latest) > loss(best):
        notes.append(t('当前验证损失高于已记录最小值；结合连续未改善轮数检查早停。一次波动不能证明过拟合。',
                       'Validation loss is above its recorded minimum. Check patience; one fluctuation does not establish overfitting.'))
    if latest.get('bad_epochs') is not None:
        notes.append(t(f"连续未达到改善阈值：{latest['bad_epochs']} 轮。", f"Epochs without the required improvement: {latest['bad_epochs']}.") )
    return notes


def show_training_guide(flow):
    w = flow.window
    zh = w.tr_pair('zh', 'en') == 'zh'
    dialog = QDialog(w); dialog.setWindowTitle(w.tr_pair('模型训练指南', 'Training guide')); dialog.resize(760, 620)
    layout = QVBoxLayout(dialog); text = QTextBrowser(); layout.addWidget(text)
    import html
    hints = ''.join('<li>'+html.escape(s)+'</li>' for s in history_hints(flow.history, 'zh' if zh else 'en'))
    rows = [
        ('训练下降、验证变差', 'Training improves, validation worsens', '查看最佳验证轮次与早停；下一次比较较小网络或适度正则化。', 'Inspect the best validation epoch and patience. Compare a smaller network or regularization in a new run.'),
        ('两条曲线改善慢', 'Both curves improve slowly', '先核对标签、输入和尺度，再在训练内验证中比较学习率。不能直接归因于层数不足。', 'Check labels, inputs and scaling, then compare learning rates using inner validation. More layers are not automatically the answer.'),
        ('剧烈震荡或非有限损失', 'Oscillating or nonfinite loss', '检查异常数据和学习率；优先定位错误，不以增加轮数掩盖问题。', 'Inspect outliers and learning rate. Locate errors before adding epochs.'),
        ('显存不足', 'Out of GPU memory', '先减小 batch；再检查序列长度、层宽与模型大小。大 batch 不保证更准确。', 'Reduce batch size, then inspect sequence length, widths and model size. Larger batches do not guarantee accuracy.'),
        ('Pearson 高但误差大', 'High Pearson but large errors', '查看平均偏差、校准与散点；相关性不能代替误差。', 'Inspect bias, calibration and scatter. Correlation does not replace error measurements.'),
        ('多折波动较大', 'Variation across folds', '查看各折人数与标签分布；群体/家系验证需可靠分组信息。', 'Inspect fold sizes and label distributions. Population/family validation needs reliable grouping information.')]
    table='<table border="1" cellpadding="7"><tr><th>'+('现象' if zh else 'Observation')+'</th><th>'+('下一步' if zh else 'Next step')+'</th></tr>'
    for a,b,c,d in rows: table+='<tr><td>'+(a if zh else b)+'</td><td>'+(c if zh else d)+'</td></tr>'
    intro = ('这些是诊断线索，不是保证提升性能的规则。建议仅使用训练/验证记录；不读取测试指标，不自动修改参数。'
             if zh else 'These are diagnostic clues, not performance guarantees. Guidance uses training/validation records only, reads no test metrics and changes no parameters.')
    detail = ('早停 patience 是连续没有达到 min_delta 改善的轮数；保存实际最小验证损失对应的权重。学习率控制更新幅度，batch 影响更新噪声与内存。Dropout/BatchNorm 的训练与验证模式不同，曲线不可机械比较。固定轮数没有验证早停。调整下一次实验时先保存配置，并保持独立测试边界。'
              if zh else 'Patience counts epochs without min_delta improvement; the true minimum-validation checkpoint is restored. Learning rate controls update size; batch size affects noise and memory. Dropout/BatchNorm differ in training and evaluation, so curve ordering alone is not a diagnosis. Fixed epochs do not use validation early stopping. Save a new configuration and preserve the independent test boundary.')
    text.setHtml('<h2>'+('本次记录' if zh else 'Current records')+'</h2><ul>'+hints+'</ul><p>'+intro+'</p>'+table+'</table><p>'+detail+'</p>')
    buttons=QDialogButtonBox(QDialogButtonBox.Close); buttons.rejected.connect(dialog.reject); layout.addWidget(buttons)
    dialog.exec()
