"""Accessible compact help controls shared by forms."""
from PySide6.QtCore import Qt, QEvent
from PySide6.QtWidgets import QPushButton, QMessageBox, QSpinBox, QDoubleSpinBox, QComboBox


class HelpButton(QPushButton):
    """Font-scaled glyph, with a slightly larger keyboard-accessible hit area."""
    def __init__(self, parent=None):
        super().__init__("?", parent)
        self.setFocusPolicy(Qt.StrongFocus)
        self.update_size()

    def update_size(self):
        size = max(20, self.fontMetrics().height() + 6)
        self.setFixedSize(size, size)
        self.setStyleSheet(f"QPushButton {{ padding:0; border:1px solid #607d8b; border-radius:{size//2}px; }} QPushButton:focus {{ border:2px solid #196da5; }}")

    def changeEvent(self, event):
        super().changeEvent(event)
        if event.type() in (QEvent.FontChange, QEvent.ApplicationFontChange):
            self.update_size()


def help_button(window, title, text):
    button = HelpButton()
    window.bind_text(button, *title, setter='setAccessibleName')
    window.bind_tooltip(button, *title)
    button.clicked.connect(lambda: QMessageBox.information(window, window.tr_pair(*title), window.tr_pair(*text)))
    return button
