from __future__ import annotations

import csv
import json
import uuid
from datetime import datetime
from pathlib import Path

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QAbstractItemView, QCheckBox, QComboBox, QFileDialog, QFormLayout,
    QHBoxLayout, QLabel, QLineEdit, QPlainTextEdit, QProgressBar, QPushButton,
    QScrollArea, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget, QListWidget,
)
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
from matplotlib.figure import Figure

from ..data.files import read_json
from .jobs import JobController
from .settings import RunSettings


class Workflow:
    def __init__(self, window):
        self.window = w = window
        self.jobs = JobController(w.root, w)
        self.history = []
        self.history_key = None
        self.current_context = {}
        self.close_pending = False
        self.preflight_report = None
        self.preflight_directory = None
        self.settings = RunSettings(w)
        w.tabs.addTab(self.settings, "")
        self.monitor = QWidget()
        layout = QVBoxLayout(self.monitor)
        self.status = QLabel()
        self.status.setTextFormat(Qt.PlainText)
        self.progress = QProgressBar()
        self.trait_status = w.label('当前性状：等待任务', 'Current trait: waiting for a task')
        self.trait_status.setObjectName('current_trait'); self.trait_status.setWordWrap(True)
        self.project_status = w.label('总体进度按计划工作单元计数，并非耗时百分比。', 'Overall progress counts planned work units, not elapsed-time percentage.')
        self.project_status.setWordWrap(True)
        self.project_progress = QProgressBar(); self.project_progress.setObjectName('project_progress')
        self.project_progress.setRange(0, 1); self.project_progress.setValue(0)
        self.resources = QLabel()
        self.resources.setWordWrap(True)
        self.figure = Figure(figsize=(6, 3), layout="constrained")
        self.canvas = FigureCanvasQTAgg(self.figure)
        self.axes = self.figure.subplots()
        self.logs = QPlainTextEdit()
        self.logs.setReadOnly(True)
        self.logs.setMaximumBlockCount(1500)
        self.logs.setMaximumHeight(150)
        self.cancel_button = w.button("取消当前任务", "Cancel current job", self.cancel, "cancel_job")
        self.cancel_button.setEnabled(False)
        for item in (self.trait_status, self.project_status, self.project_progress, self.status, self.progress, self.resources, self.canvas, self.logs, self.cancel_button):
            layout.addWidget(item)
        layout.addWidget(w.button("训练指南 ?", "Training guide ?", lambda: self.open_training_guide(), "training_guide"))
        w.tabs.addTab(self.monitor, "")
        self.results_page = self.make_results()
        w.tabs.addTab(self.results_page, "")
        w.tabs.addTab(self.prediction_page, "")
        self.jobs.event.connect(self.on_event)
        self.jobs.log.connect(self.logs.appendPlainText)
        self.jobs.finished.connect(self.on_finished)
        self.receipt_timer = QTimer(w)
        self.receipt_timer.setInterval(1000)
        self.receipt_timer.timeout.connect(self.refresh)
        self.receipt_timer.start()

    def open_training_guide(self):
        from .training_guide import show_training_guide
        show_training_guide(self)

    def export_destination(self,kind):
        import re
        root=Path(self.export_output.text().strip())
        if not self.export_output.text().strip():raise ValueError(self.window.tr_pair('请选择保存位置。','Choose a save location.'))
        name=self.export_name.text().strip()
        if name:
            if name in ('.','..') or re.search(r'[<>:"/\\|?*]',name) or name.endswith(('.', ' ')):
                raise ValueError(self.window.tr_pair('名称不能含路径分隔符或 Windows 保留字符。','Name cannot contain path separators or Windows-reserved characters.'))
            root=root/name
        return self.new_output(str(root),kind)

    def translate(self):
        w = self.window
        if hasattr(self.settings, 'translate'):
            self.settings.translate()
        for index, zh, en in ((2, "训练设置", "Training settings"), (3, "运行监视", "Run monitor"), (4, "训练结果", "Training results"), (5, "新个体预测", "New individual prediction")):
            w.tabs.setTabText(index, w.tr_pair(zh, en))
        self.translate_results()
        from .preflight_ui import render_checklist
        render_checklist(self.settings)
        from .result_text import draw_history
        draw_history(self)

    def translate_results(self):
        from .result_text import format_result, model_info, prediction_info, deployment_info
        if self.model_description:
            self.model_info.setText(deployment_info(self.window, self.model_description))
        elif hasattr(self, 'displayed_model'):
            self.model_info.setText(model_info(self.window, *self.displayed_model))
        if hasattr(self, 'displayed_result'):
            self.result_text.setText(format_result(self.window, self.displayed_result, self.displayed_split_counts))
        if hasattr(self, 'displayed_prediction'):
            self.prediction_text.setText(prediction_info(self.window, *self.displayed_prediction))
        from .result_pages import refresh_result_view
        refresh_result_view(self)
        if self.fold_selector.count():
            self.fold_selector.setItemText(0, self.window.tr_pair('所有成员等权平均（默认）', 'Equal average of all members (default)'))
            for i in range(1, self.fold_selector.count()):
                fold = self.fold_selector.itemData(i)
                self.fold_selector.setItemText(i, self.window.tr_pair(f'仅折 {fold}', f'Fold {fold} only'))

    def make_results(self):
        from .result_pages import build_pages
        return build_pages(self)

    def browse(self, key, directory):
        w = self.window
        if directory:
            path = QFileDialog.getExistingDirectory(w, "GPNB_v1", str(w.root))
        else:
            path, _ = QFileDialog.getOpenFileName(w, "GPNB_v1", str(w.root), "PLINK files (*.bed *.bim *.fam)")
        if path:
            from .path_fields import select_companions
            if self.prediction_format.currentIndex():
                self.predict_fields[key].setText(str(Path(path)))
            else:
                self._auto_paths=select_companions(self.predict_fields,key,path,getattr(self,"_auto_paths",{}))

    def new_output(self, root, kind):
        if not str(root).strip():
            raise ValueError("Output root is required")
        category = {'train': 'experiments', 'split_preview': 'splits', 'preflight': 'checks',
                    'predict': 'predictions', 'export': 'exports', 'model-package': 'models',
                    'final-refit': 'final_models', 'comparison': 'comparisons',
                    'export_genotypes': 'genotype_exports', 'export_matrices': 'matrices',
                    'export_plots': 'plots', 'plot_export': 'plots'}.get(kind, kind)
        return str(Path(root).resolve() / category / f"{datetime.now():%Y%m%d_%H%M%S}_{uuid.uuid4().hex[:10]}")

    def set_input_tables(self, configs):
        while self.input_form.rowCount():
            self.input_form.removeRow(0)
        self.input_fields = {}
        self.input_group.setVisible(bool(configs))
        for config in configs:
            name = config["id"]
            entry = self.input_fields[name] = QLineEdit()
            entry.setObjectName("predict_input_" + name)
            entry.setPlaceholderText(self.window.tr_pair("请选择新个体表；不会沿用训练表", "Select query table; training table is not reused"))
            row = QHBoxLayout()
            row.addWidget(entry)
            button = self.window.button("选择", "Browse", lambda checked=False, n=name: self.browse_input_table(n))
            row.addWidget(button)
            self.input_form.addRow(name, row)

    def browse_input_table(self, name):
        path, _ = QFileDialog.getOpenFileName(self.window, name, str(self.window.root), "Tables (*.csv *.txt *.tsv);;All (*)")
        if path:
            self.input_fields[name].setText(path)

    def browse_prediction_phenotype(self):
        path, _ = QFileDialog.getOpenFileName(self.window, self.window.tr_pair('选择新个体表型', 'Select query phenotypes'),
            str(self.window.root), 'Tables (*.csv *.txt *.tsv);;All (*)')
        if path:
            self.phenotype_path.setText(path)

    def refresh(self):
        w = self.window
        self.settings.check_preview()
        valid = True
        try:
            w.document.spec()
            # Kernel widths and filtered marker widths are fold-local. The
            # preflight worker resolves them; a placeholder must not block it.
            kernel = w.document.value['run'].get('extensions', {}).get('kernel_features')
            preprocessing = w.document.value['run']['preprocessing']
            pending_filter = any(preprocessing[k] is not None for k in ('maf_min', 'marker_missing_max'))
            if w.features and not kernel and not pending_filter:
                state = w.graph_state if w.feature_source == "prepared" and "graph_spec" in w.document.value["model"] else None
                ref = w.reference_state if w.feature_source == "prepared" and "individual_graph_spec" in w.document.value["model"] else None
                w.document.plan(w.features, state, ref)
            # Include uncommitted JSON text in validity feedback.
            for key in ("id_columns", "missing_tokens"):
                value = json.loads(w.fields[key].text())
                if not isinstance(value, list) or any(not isinstance(v, str) for v in value):
                    raise ValueError(f"{key}: expected JSON string array")
            self.settings.validation.setText("")
        except (ValueError, OSError) as error:
            valid = False
            self.settings.validation.setText(w.error_text(error))
        idle = not self.jobs.busy and w.process is None
        cv=w.document.value["run"].get("extensions",{}).get("cross_validation",{})
        acknowledged=cv.get("method","five_fold") in ("five_fold", "ten_fold") or bool(cv.get("approved_folds"))
        checked = False
        if valid and self.preflight_report:
            try:
                from ..preflight import verify_preflight
                receipt = verify_preflight(w.document.path or w.root/'untitled.json', self.preflight_report,
                                 quick=True, value=w.document.spec().to_dict())
                checked = True
            except (ValueError, OSError, KeyError, TypeError):
                pass
        w.train_button.setEnabled(valid and idle and acknowledged and checked)
        if hasattr(self.settings, 'preflight_button'):
            self.settings.preflight_button.setEnabled(valid and idle and acknowledged)
            self.settings.preflight_status.setText(w.tr_pair(
                "检查通过：可以开始训练。", "Checks passed: ready to train.") if checked else w.tr_pair(
                "尚未检查或配置/文件已变化，请运行前检查。", "Not checked or configuration/files changed; run preflight."))
            if checked and receipt.get('failed_candidates'):
                self.settings.preflight_status.setText(self.settings.preflight_status.text() + w.tr_pair(
                    f" 有 {receipt['failed_candidates']} 项候选检查失败，将按搜索规则跳过；请查看报告。",
                    f" {receipt['failed_candidates']} candidate checks failed and will be skipped by search; inspect the report."))
        if valid and not acknowledged:
            self.settings.validation.setText(w.tr_pair("请预览并确认留一法的实际模型数。", "Preview and acknowledge the leave-out model count."))
        self.settings.preview_button.setEnabled(valid and idle)
        for button in (self.view_button, self.predict_button, self.export_button, self.package_button, self.compare_button):
            button.setEnabled(idle)
        self.final_refit_button.setEnabled(valid and idle)
        if getattr(self,'displayed_result',{}).get('summary',{}).get('kind')=='trait_batch':
            self.package_button.setEnabled(False);self.export_button.setEnabled(False);self.plot_export_button.setEnabled(idle)

    def set_busy(self, busy):
        w = self.window
        for page in (w.data_page, w.network_page, self.settings, self.results_page, self.prediction_page):
            page.setEnabled(not busy)
        for name in ("new", "open", "save", "save_as"):
            w.findChild(QPushButton, name).setEnabled(not busy)
        self.cancel_button.setEnabled(busy)
        self.refresh()

    def launch(self, kind, options, device="cpu"):
        if self.jobs.busy or self.window.process is not None:
            raise ValueError("Another task is running")
        self.history = []
        self.search_history_key = None
        self.history_key = None
        self.current_context = {}
        self.project_progress.setRange(0,0)
        self.project_status.setText(self.window.tr_pair('正在生成任务计划；暂不估计剩余时间。','Building the work plan; remaining time is not yet estimated.'))
        self.trait_status.setText(self.window.tr_pair('当前性状：等待任务', 'Current trait: waiting for a task'))
        self.logs.clear()
        self.window.message.clear()
        self.resources.clear()
        self.axes.clear()
        self.canvas.draw_idle()
        self.progress.setRange(0, 0)
        self.status.setText(self.window.tr_pair("正在启动独立进程…", "Starting independent worker…"))
        self.jobs.start(kind, options, device=device)
        self.set_busy(True)
        self.window.tabs.setCurrentIndex(3)

    def start_preview(self):
        w=self.window
        try:
            w.commit_json_fields()
            spec=w.document.spec()
            snapshot=w.root/"jobs"/("preview_"+uuid.uuid4().hex+".json")
            spec.save(snapshot)
            self.launch("preview_split",dict(project_path=str(snapshot),output=self.new_output(spec.to_dict()['output_dir'],"split_preview")))
        except (OSError,ValueError) as error:w.show_error(error)

    def start_preflight(self):
        w = self.window
        try:
            if self.jobs.busy or w.process is not None:
                return
            w.commit_json_fields()
            spec = w.document.spec()
            value = spec.to_dict()
            path = w.root / 'jobs' / ('preflight_' + uuid.uuid4().hex + '.json')
            spec.save(path)
            self.preflight_report = None
            self.preflight_directory = self.new_output(value['output_dir'], 'preflight')
            self.settings.preflight_items = {}
            from .preflight_ui import render_checklist
            render_checklist(self.settings)
            self.settings.open_preflight_button.setEnabled(False)
            self.launch('preflight', dict(project_path=str(path), output=self.preflight_directory),
                        value['run']['training']['device'])
        except (OSError, ValueError) as error:
            w.show_error(error)

    def open_preflight_folder(self):
        from PySide6.QtCore import QUrl
        from PySide6.QtGui import QDesktopServices
        if self.preflight_directory and Path(self.preflight_directory).is_dir():
            QDesktopServices.openUrl(QUrl.fromLocalFile(self.preflight_directory))

    def start_genotype_export(self):
        w = self.window
        try:
            w.commit_json_fields()
            spec = w.document.spec()
            path = w.root / 'jobs' / ('genotypes_' + uuid.uuid4().hex + '.json')
            spec.save(path)
            self.launch('export_genotypes', dict(project_file=str(path),
                output=self.new_output(spec.to_dict()['output_dir'], 'export_genotypes')))
        except (OSError, ValueError) as error:
            w.show_error(error)

    def start_matrix_export(self, recipe, *, output_root=None, text=False):
        w = self.window
        try:
            if self.jobs.busy or w.process is not None:
                return
            w.commit_json_fields()
            spec = w.document.spec()
            path = w.root/'jobs'/('matrix_' + uuid.uuid4().hex + '.json')
            spec.save(path)
            self.launch('export_matrices', dict(project_file=str(path), recipe=recipe, text=text,
                output=self.new_output(output_root or spec.to_dict()['output_dir'], 'export_matrices')))
        except (OSError, ValueError) as error:
            w.show_error(error)

    def start_training(self):
        w = self.window
        try:
            if self.jobs.busy or w.process is not None:
                return
            w.commit_json_fields()
            spec = w.document.spec()
            if not self.preflight_report:
                raise ValueError(w.tr_pair("请先完成运行前检查。", "Complete preflight before training."))
            from ..preflight import verify_preflight
            verify_preflight(w.document.path or w.root/'untitled.json', self.preflight_report,
                             quick=True, value=spec.to_dict())
            snapshot = w.root / "jobs" / ("project_" + uuid.uuid4().hex + ".json")
            spec.save(snapshot)
            value = spec.to_dict()
            self.launch("train", {"project_path": str(snapshot),
                                 "preflight_report": self.preflight_report,
                                 "output": self.new_output(value["output_dir"], "train")},
                        value["run"]["training"]["device"])
        except (OSError, ValueError) as error:
            w.show_error(error)

    def start_batch_retry(self):
        try:
            result=getattr(self,'displayed_result',None)
            if not result or result['summary'].get('kind')!='trait_batch':
                raise ValueError(self.window.tr_pair('请先打开批量性状结果。','Open a trait batch result first.'))
            archived=read_json(Path(result['output'])/'project.json')
            self.launch('retry-batch',dict(retry_from=result['output'],output=self.new_output(self.window.document.value['output_dir'],'train')),
                        archived['run']['training']['device'])
        except (OSError,ValueError) as error:self.window.show_error(error)

    def start_prediction(self):
        try:
            fields = {key: field.text().strip() for key, field in self.predict_fields.items()}
            loaded_path = getattr(self, 'loaded_model_path', None)
            if loaded_path is None or not fields['bundle'] or Path(fields['bundle']).resolve() != loaded_path:
                raise ValueError(self.window.tr_pair('请先点击“加载并检查模型”，再填写该模型所需的新个体输入。', 'Click Load and check model first, then provide the query inputs required by that model.'))
            matrix=self.prediction_matrix.value() if self.prediction_format.currentIndex() else None
            required=(("bundle", "output") if matrix.get('counted_allele') == 'DECLARED' else
                      ("bundle","bim","output")) if matrix else tuple(fields)
            if not all(fields[k] for k in required):
                raise ValueError(self.window.tr_pair('请选择模型、基因型输入、BIM 和输出根目录（BED 还需要 FAM）。', 'Select model, genotype input, BIM and output root (FAM is required for BED).'))
            input_tables = {name: edit.text().strip() for name, edit in self.input_fields.items()}
            if any(not value for value in input_tables.values()):
                raise ValueError(self.window.tr_pair('请为每个额外分支选择新个体输入表；不会自动沿用训练表。', 'Select a query table for every additional branch; training tables are never reused automatically.'))
            fold = None
            if self.cv_root and Path(fields["bundle"]).resolve() == self.cv_root:
                fold = self.fold_selector.currentData()
            phenotype, phenotype_options = None, None
            if self.score_enabled.isChecked():
                phenotype = self.phenotype_path.text().strip()
                if not phenotype:
                    raise ValueError(self.window.tr_pair('已启用评分，请选择表型文件，或关闭评分以直接预测。', 'Scoring is enabled: select phenotypes or disable scoring to predict without labels.'))
                ids = json.loads(self.phenotype_ids.text())
                missing = json.loads(self.phenotype_missing.text())
                if not isinstance(ids, list) or len(ids) not in (1, 2) or any(not isinstance(v, str) or not v for v in ids):
                    raise ValueError(self.window.tr_pair('ID 列应为一个 IID 或 FID、IID 两列的 JSON 数组。', 'ID columns must be a JSON array containing IID or FID and IID.'))
                if not isinstance(missing, list) or any(not isinstance(v, str) for v in missing):
                    raise ValueError(self.window.tr_pair('缺失标记应为 JSON 字符串数组。', 'Missing tokens must be a JSON string array.'))
                phenotype_options = dict(delimiter=self.phenotype_delimiter.currentData(), encoding=self.phenotype_encoding.currentText(),
                    id_mode='iid' if len(ids) == 1 else 'fid_iid', id_columns=ids,
                    trait=self.phenotype_trait.text().strip(), missing_tokens=missing)
            relation, note = self.identity_relation.currentData(), self.identity_note.text().strip()
            if relation == 'confirmed_new' and not note:
                raise ValueError(self.window.tr_pair('确认新个体需要填写独立核实依据；无法确认时请选择来源关系不明。', 'Confirmed new individuals require a verification basis; choose unknown if identity cannot be confirmed.'))
            self.launch("predict", {"bundle": fields["bundle"], "bed": None if matrix else fields["bed"],
                                   "bim": None if matrix and matrix.get('counted_allele') == 'DECLARED' else fields["bim"], "fam": None if matrix else fields["fam"], "matrix": matrix,
                                   "output": self.new_output(fields["output"], "predict"),
                                   "dataset_id": self.cohort.text(), "device": self.predict_device.currentText(),
                                   "input_tables": input_tables, "fold": fold, 'phenotype': phenotype,
                                   'phenotype_options': phenotype_options, 'identity_relation': relation,
                                   'identity_note': note, 'sort_direction': self.sort_direction.currentData()},
                        self.predict_device.currentText())
        except (OSError, ValueError) as error:
            self.window.show_error(error)

    def add_comparison(self):
        path = QFileDialog.getExistingDirectory(self.window, "CV result", str(self.window.root / "runs"))
        existing = [self.comparison_list.item(i).text() for i in range(self.comparison_list.count())]
        if path and path not in existing:
            self.comparison_list.addItem(path)

    def remove_comparison(self):
        row = self.comparison_list.currentRow()
        if row >= 0:
            self.comparison_list.takeItem(row)

    def start_comparison(self):
        try:
            paths = [self.comparison_list.item(i).text() for i in range(self.comparison_list.count())]
            if len(paths) < 2:
                raise ValueError("Select at least two completed cross-validation result directories")
            self.launch("compare_cv", dict(paths=paths,
                        output=self.export_destination("comparison")))
        except (ValueError, OSError) as error:
            self.window.show_error(error)

    def view_result(self):
        try:
            self.view_destination = self.window.tabs.currentIndex()
            bundle = self.predict_fields["bundle"].text().strip()
            if not bundle:
                raise ValueError("Select a model directory")
            self.launch("view", {"bundle": bundle, "device": self.predict_device.currentText()},
                        self.predict_device.currentText())
        except (OSError, ValueError) as error:
            self.window.show_error(error)

    def start_export(self):
        try:
            bundle = self.predict_fields["bundle"].text().strip()
            if not bundle:
                raise ValueError("Select a model directory")
            self.launch("export", {"bundle": bundle,
                                  "output": self.export_destination("export"),
                                  "include_data": self.include_data.isChecked()})
        except (OSError, ValueError) as error:
            self.window.show_error(error)

    def start_model_package(self):
        try:
            bundle = self.predict_fields['bundle'].text().strip()
            if not bundle:
                raise ValueError(self.window.tr_pair('请先选择已完成的模型结果目录。', 'Select a completed model result first.'))
            self.launch('model-package', {'bundle': bundle,
                'output': self.export_destination('model-package')})
        except (OSError, ValueError) as error:
            self.window.show_error(error)

    def start_final_refit(self):
        w = self.window
        try:
            if self.jobs.busy or w.process is not None:
                return
            w.commit_json_fields()
            spec = w.document.spec()
            snapshot = w.root / 'jobs' / ('final_refit_' + uuid.uuid4().hex + '.json')
            spec.save(snapshot)
            value = spec.to_dict()
            self.launch('final-refit', {'project_path': str(snapshot),
                'output': self.new_output(value['output_dir'], 'final-refit')}, value['run']['training']['device'])
        except (OSError, ValueError) as error:
            w.show_error(error)

    def cancel(self):
        self.jobs.cancel()
        self.cancel_button.setEnabled(False)
        self.status.setText(self.window.tr_pair("正在取消…", "Cancelling…"))

    def on_event(self, event):
        w = self.window
        kind = event["event"]
        if kind == "resource":
            gpu = event["cuda_allocated_bytes"]
            self.resources.setText(w.tr_pair("进程耗时 / 内存 RSS：", "Process elapsed / RSS: ") +
                                   f"{event['elapsed_seconds']:.1f} s / {event['rss_bytes']/2**20:.1f} MiB\n" +
                                   w.tr_pair("PyTorch 显存 已分配 / 保留：", "PyTorch CUDA allocated / reserved: ") +
                                   ("—" if gpu is None else f"{gpu/2**20:.1f} / {event['cuda_reserved_bytes']/2**20:.1f} MiB"))
            return
        self.logs.appendPlainText(json.dumps(event, ensure_ascii=False))
        from .monitor_context import update_context
        update_context(self, event)
        if kind == 'project_progress':
            total=event['planned_units'];done=event['completed_units']
            self.project_progress.setRange(0,max(total,1));self.project_progress.setValue(done)
            self.project_status.setText(w.tr_pair(
                f"总体工作单元 {done}/{total} · 成功 {event.get('succeeded_units',0)} · 失败 {event.get('failed_units',0)} · 取消 {event.get('cancelled_units',0)} · 跳过 {event.get('skipped_units',0)} · 沿用 {event.get('reused_units',0)}（不是耗时百分比）",
                f"Overall work units {done}/{total} · succeeded {event.get('succeeded_units',0)} · failed {event.get('failed_units',0)} · cancelled {event.get('cancelled_units',0)} · skipped {event.get('skipped_units',0)} · reused {event.get('reused_units',0)} (not elapsed-time percentage)"))
            return
        if kind == 'batch_task':
            self.status.setText(w.tr_pair(f"性状 {event['index']}/{event['total']}：{event['trait']}",f"Trait {event['index']}/{event['total']}: {event['trait']}"))
        if kind == 'preflight_check':
            key=(event.get('trait'),event.get('fold'),event.get('trial'),event['key']) if event.get('trait') else event['key']
            self.settings.preflight_items[key] = event
            from .preflight_ui import render_checklist
            render_checklist(self.settings)
        elif kind == "search_selected":
            if w.document.value.get("extensions",{}).get("trait_batch"):
                self.history=[]
                return
            w.document.value['model']=event['model']
            w.document.value['run']['training']=event['training']
            w.document.dirty=True
            w.rebuild_cards();self.settings.populate();w.refresh()
            self.history=[]
        elif kind in ('search_trial','search_epoch'):
            key = (event.get('trait'),event.get('fit_purpose'),event.get('fold'), event['trial'],event.get('stage'))
            if kind == 'search_epoch':
                if getattr(self, 'search_history_key', None) != key:
                    self.history = []
                    self.search_history_key = key
                self.history.append(event)
                from .result_text import draw_history
                draw_history(self)
            self.progress.setRange(0,event.get('epoch_limit',0) if kind=='search_epoch' else event['trials'])
            self.progress.setValue(event['epoch'] if kind=='search_epoch' else event['trial'])
            prefix = w.tr_pair('折 ', 'Fold ') + f"{event['fold']} / {event['folds']} · " if 'folds' in event else ''
            self.status.setText(prefix + w.tr_pair('搜索 ', 'Search ') + f"{event['trial']} / {event['trials']} · "+
                               (w.tr_pair('训练轮次 ', 'epoch ') + str(event['epoch'])+'/'+str(event.get('epoch_limit','?')) if kind=='search_epoch' else event['status']))
        elif kind == "fold_start":
            self.history = []
            self.axes.clear()
            self.canvas.draw_idle()
            self.status.setText(w.tr_pair('折 ', 'Fold ') + f"{event['fold']} / {event['folds']}")
        elif kind == "prepared":
            if event.get('model'):
                from ..config import ModelSpec
                w.resolved_display_model = ModelSpec(event['model'])
                w.resolved_display_fingerprint = json.dumps(w.document.value, sort_keys=True, ensure_ascii=False)
            w.graph_state = read_json(Path(event["graph_state_path"])) if event.get("graph_state_path") else None
            w.reference_state = read_json(Path(event["reference_state_path"])) if event.get("reference_state_path") else None
            w.features, w.feature_source = event["features"], "prepared"
            w.feature_input.blockSignals(True)
            w.feature_input.setValue(w.features)
            w.feature_input.blockSignals(False)
            w.refresh()
        elif kind == "epoch":
            key=(event.get('trait'),event.get('fit_purpose'),event.get('fold'),event.get('trial'),event.get('stage'))
            if self.history_key != key:self.history=[];self.history_key=key
            self.history.append(event)
            maximum = event.get('epoch_limit',0)
            self.progress.setRange(0, maximum)
            self.progress.setValue(event["epoch"])
            prefix = w.tr_pair('折 ', 'Fold ') + f"{event['fold']} / {event['folds']} · " if "folds" in event else ""
            self.status.setText(prefix + w.tr_pair(f"训练轮次 {event['epoch']} / {maximum or '?'} · 最佳 {event['best_epoch']}",
                                                  f"Epoch {event['epoch']} / {maximum or '?'} · best {event['best_epoch']}"))
            losses=[r.get('validation_loss',r.get('validation_mse')) for r in self.history]
            finite=[x for x in losses if x is not None]
            details=[]
            if finite:details.append(w.tr_pair('最佳验证损失 ','Best validation loss ')+f'{min(finite):.6g}')
            if event.get('bad_epochs') is not None:details.append(w.tr_pair('未改善轮数 ','Non-improving epochs ')+str(event['bad_epochs']))
            if event.get('learning_rate') is not None:details.append('lr='+f"{event['learning_rate']:.6g}")
            if details:self.status.setText(self.status.text()+'\n'+' · '.join(details))
            from .result_text import draw_history
            draw_history(self)
        elif kind == "stage":
            stage = event['stage']
            if stage in ('final_internal_selection', 'final_all_data_refit'):
                self.history = []
                self.axes.clear()
                self.canvas.draw_idle()
            stages = {'verifying_inputs':('正在核验输入是否变化','Verifying input changes'), 'reusing_preflight':('复用有效检查；开始正式任务','Reusing valid checks; starting task'), 'loading':('加载任务','Loading task'), 'final_internal_selection': ('全数据最终模型：内部验证选择', 'Final model: internal validation selection'),
                'final_all_data_refit': ('全数据最终模型：全部个体重拟合', 'Final model: refit on all individuals'),
                'ensemble_member': ('逐成员预测', 'Predicting ensemble members'),
                'post_prediction_scoring': ('预测完成后评分', 'Post-prediction scoring')}
            prefix = w.tr_pair('折 ', 'Fold ') + f"{event['fold']} / {event['folds']} · " if 'folds' in event else ''
            caption = w.tr_pair(*stages.get(stage, (stage, stage)))
            if event.get('seconds') is not None:caption += f" · {event['seconds']:.3f} s"
            if stage == 'ensemble_member': caption += f" {event.get('done', 0) + 1} / {event.get('total', 0)}"
            self.status.setText(prefix + w.tr_pair("阶段：", "Stage: ") + caption)
            total = event.get("total", 0)
            self.progress.setRange(0, total)
            self.progress.setValue(event.get("done", 0))

    def on_finished(self, result):
        w = self.window
        self.set_busy(False)
        self.progress.setRange(0, 1)
        self.progress.setValue(1 if result["status"] == "completed" else 0)
        if self.project_progress.maximum()==0:
            self.project_progress.setRange(0,1);self.project_progress.setValue(0)
            self.project_status.setText(w.tr_pair('任务已结束；此操作没有完整工作单元计划。','Task ended; this operation did not provide a full work-unit plan.'))
        status = {"completed": ("已完成", "Completed"), "cancelled": ("已取消", "Cancelled"), "failed": ("失败", "Failed")}
        self.status.setText(w.tr_pair(status[result['status']][0] + '\n' + result['job_directory'],
                                     status[result['status']][1] + '\n' + result['job_directory']))
        if result.get('kind') == 'preflight':
            self.settings.open_preflight_button.setEnabled(bool(self.preflight_directory and Path(self.preflight_directory).is_dir()))
        if result["status"] == "completed":
            try:
                if result['kind'] == 'preflight':
                    self.preflight_report = str(Path(result['output']) / 'summary.json')
                    self.refresh()
                    w.tabs.setCurrentIndex(2)
                elif result["kind"]=="preview_split":
                    if result['summary'].get('kind')=='batch_preview':
                        self.settings.preview_summary=result['summary']
                        self.settings.preview_fingerprint=self.settings.fingerprint()
                        self.settings.preview_table.show()
                        self.settings.scale_ack.setEnabled(True)
                        self.settings.render_preview()
                    else:self.settings.show_preview(result["summary"])
                    w.tabs.setCurrentIndex(2)
                elif result['kind'] == 'export_plots':
                    w.tabs.setCurrentIndex(4)
                    if result.get('summary',{}).get('ok') is False:
                        self.status.setText(w.tr_pair('报告已生成，含失败或未导出项；请查看 summary.json 和报告。','Report generated with failed or unexported items; inspect summary.json and the report.'))
                elif result['kind'] == 'export_matrices':
                    w.tabs.setCurrentIndex(0)
                else:
                    self.show_result(result)
                    w.tabs.setCurrentIndex(5 if result["kind"]=="predict" or
                        (result["kind"]=="view" and getattr(self,"view_destination",4)==5) else 4)
                w.message.setText(w.tr_pair("结果已保存：" + result['output'], "Result saved: " + result['output']))
            except (OSError, ValueError, KeyError) as error:
                w.show_error(error)
        else:
            w.show_error(result.get("error", result["status"]))
        self.refresh()
        if self.close_pending:
            QTimer.singleShot(0, w.close)

    def show_result(self, result):
        output, summary = Path(result["output"]), result["summary"]
        if summary.get('kind')=='trait_batch':
            from .result_pages import show_batch_result
            show_batch_result(self,result)
            self.status.setText(self.window.tr_pair('批量完成' if summary.get('ok') else '批量部分完成，请查看各性状状态','Batch completed' if summary.get('ok') else 'Batch partially completed; inspect trait statuses'))
            return
        if result['kind'] == 'model-package':
            # Saving a lean package must not replace the full experiment shown
            # here or make the full-reproduction button target that lean copy.
            return
        split_counts = None
        if result["kind"] in ("train", "view", 'final-refit'):
            loaded = result.get('project')
            if loaded is None:
                project_path = output / 'project.json'
                if not project_path.is_file(): project_path = output / 'run/project.json'
                if project_path.is_file(): loaded = read_json(project_path)
            self.model_description = result.get('model_description')
            if loaded is None:
                loaded = {'name': self.model_description.get('name', 'GPNB_v1') if self.model_description else 'GPNB_v1',
                    'data': {'phenotype_options': {'trait': summary.get('trait', '')}}, 'model': {}, 'extensions': {}}
            configs = loaded.get('extensions', {}).get('input_tables', [])
            if self.model_description:
                configs = [dict(config, id=name) for name, config in self.model_description.get('required_input_tables', {}).items()]
            self.set_input_tables(configs)
            self.displayed_model = (loaded, output)
            self.predict_fields["bundle"].setText(str(output))
            self.loaded_model_path = output.resolve()
            self.populate_scoring_options(loaded.get('data', {}).get('phenotype_options', {}))
            self.fold_selector.clear()
            members = self.model_description.get('members', []) if self.model_description else summary.get('fold_runs', [])
            self.fold_advanced.setVisible(len(members) > 1)
            if len(members) > 1:
                self.cv_root = output.resolve()
                self.fold_selector.addItem(self.window.tr_pair('所有成员等权平均（默认）', 'Equal average of all members (default)'), None)
                for item in members:
                    self.fold_selector.addItem(str(item['fold']), item['fold'])
                self.fold_selector.setEnabled(True)
            else:
                self.cv_root = None
                self.fold_selector.setEnabled(False)
                report = output / "prepared/report.json"
                if not report.is_file():
                    report = output / "run/prepared/report.json"
                if report.is_file():
                    split_counts = read_json(report)["split"]["counts"]
        if result["kind"] == "predict":
            self.displayed_prediction = (output, summary)
            target_table = self.prediction_table
        else:
            self.displayed_result = result
            self.displayed_split_counts = split_counts
            target_table = self.table
            self.scatter.clear()
            image = output / "test_scatter.png"
            if image.is_file():
                self.scatter.setPixmap(QPixmap(str(image)).scaledToWidth(440, Qt.SmoothTransformation))
        self.translate_results()
        target_table.clear()
        target_table.setRowCount(0)
        target_table.setColumnCount(0)
        path = output / ("metrics.csv" if summary.get("kind") == "cv_comparison" else "predictions.csv")
        if path.is_file():
            with path.open(encoding="utf-8-sig", newline="") as stream:
                reader = csv.reader(stream)
                columns = next(reader)
                target_table.setColumnCount(len(columns))
                target_table.setHorizontalHeaderLabels(columns)
                for i, row in enumerate(reader):
                    if i >= 2000:
                        break
                    target_table.insertRow(i)
                    for j, value in enumerate(row):
                        target_table.setItem(i, j, QTableWidgetItem(value))
            target_table.resizeColumnsToContents()
        if result['kind'] in ('train', 'view', 'final-refit'):
            from .result_pages import refresh_result_view
            refresh_result_view(self, result, reset=True)

    def populate_scoring_options(self, options):
        """Only column conventions are suggested; never reuse training labels."""
        self.phenotype_delimiter.setCurrentIndex(max(0, self.phenotype_delimiter.findData(options.get('delimiter', ','))))
        self.phenotype_encoding.setCurrentText(options.get('encoding', 'utf-8'))
        self.phenotype_ids.setText(json.dumps(options.get('id_columns', ['FID', 'IID']), ensure_ascii=False))
        self.phenotype_missing.setText(json.dumps(options.get('missing_tokens', ['', 'NA', 'NaN']), ensure_ascii=False))
        self.phenotype_trait.setText(options.get('trait', ''))
        multi = bool(self.model_description and len(self.model_description.get('targets', [])) > 1)
        self.phenotype_trait.setEnabled(not multi)
