from pathlib import Path
from PySide6.QtWidgets import QFileDialog
from ..models.diagrams import topology_svg,workflow_svg


def diagram(w):
    if w.diagram_mode.currentIndex():
        preview=w.workflow.settings.preview_summary if w.workflow.settings.preview_fingerprint else None
        return workflow_svg(w.document.value,preview,language=w.language)
    return topology_svg(w.plan,w.compact_diagram.isChecked(),language=w.language)


def export_diagram(w):
    if w.plan is None and not w.diagram_mode.currentIndex():
        w.show_error(w.tr_pair("先检查数据和网络", "Validate data and model first"));return
    target,_=QFileDialog.getSaveFileName(w,w.tr_pair("导出 SVG", "Export SVG"),str(w.root/"projects/network.svg"),"SVG (*.svg)")
    if not target:return
    from ..data.genotypes import source_paths
    from ..data.files import protect_inputs
    try:
        protect_inputs(Path(target),list(source_paths(w.document.value["data"],w.document.path or w.root/"untitled.json").values()))
        Path(target).write_text(diagram(w),encoding="utf-8")
        w.message.setText(target)
    except (OSError,ValueError) as error:w.show_error(error)


def details(w,identifier):
    if not w.plan:return
    import json
    row=next((r for r in w.plan["layers"] if r["id"]==identifier),None)
    if row:
        w.node_detail.setPlainText(json.dumps({k:row[k] for k in ("id","type","inputs","input_shape","output_shape","parameters","kwargs","share_with") if k in row},ensure_ascii=False,indent=2))
