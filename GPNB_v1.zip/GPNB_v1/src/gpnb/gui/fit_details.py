"""Readable archived fit and candidate tables; detailed JSON remains available."""
import json
from PySide6.QtWidgets import QDialog,QVBoxLayout,QTabWidget,QTextBrowser,QLabel
from ..batch_results import archived_fit_details
from .data_widgets import table_widget,fill_table


def show_fit_details(window,source):
    try:
        records=archived_fit_details(source)
        dialog=QDialog(window);dialog.resize(1050,720)
        dialog.setWindowTitle(window.tr_pair('训练与搜索详情','Training and search details'))
        layout=QVBoxLayout(dialog)
        note=QLabel(window.tr_pair('候选仅显示用于选择的验证成绩；没有按候选计算外层测试成绩。各折训练目标量纲可能不同。','Candidates show selection-validation scores only, with no candidate-level outer-test scores. Training objective scales can differ between folds.'))
        note.setWordWrap(True);layout.addWidget(note);tabs=QTabWidget();layout.addWidget(tabs)
        fits=table_widget();candidates=table_widget();raw=QTextBrowser()
        fit_rows=[];trial_rows=[]
        for record in records:
            training=record.get('configuration',{}).get('run',{}).get('training',{})
            fit_rows.append([record['fold'],record['epochs_ran'],record['best_epoch'],record['stop_reason'],training.get('loss'),training.get('optimizer'),training.get('learning_rate'),training.get('seed')])
            for trial in record.get('search/trials.json',[]):
                trial_rows.append([record['fold'],trial['trial'],trial['status'],trial.get('loss_name'),trial.get('validation_loss',trial.get('validation_mse')),trial.get('best_epoch'),json.dumps(trial.get('parameters',{}),ensure_ascii=False),trial.get('error','')])
        fill_table(fits,[window.tr_pair(*x) for x in [('外层折','Outer fold'),('实际轮数','Epochs run'),('最佳轮次','Best epoch'),('停止原因','Stop reason'),('损失','Loss'),('优化器','Optimizer'),('学习率','Learning rate'),('种子','Seed')]],fit_rows)
        fill_table(candidates,[window.tr_pair(*x) for x in [('外层折','Outer fold'),('候选','Trial'),('状态','Status'),('损失','Loss'),('验证损失','Validation loss'),('最佳轮次','Best epoch'),('参数','Parameters'),('问题','Error')]],trial_rows)
        raw.setPlainText(json.dumps(records,ensure_ascii=False,indent=2))
        tabs.addTab(fits,window.tr_pair('实际模型','Actual fits'));tabs.addTab(candidates,window.tr_pair('搜索候选','Search candidates'));tabs.addTab(raw,window.tr_pair('完整归档配置','Complete archived configuration'))
        dialog.exec()
    except (ValueError,OSError,KeyError) as error:window.show_error(error)
