from pathlib import Path


def select_companions(fields, key, selected, automatic):
    """Preserve manual paths; only empty or previously automatic slots can follow."""
    automatic=dict(automatic)
    path=Path(selected)
    fields[key].setText(str(path))
    fields[key].setToolTip(str(path))
    automatic.pop(key,None)
    if key in ("bed","bim","fam"):
        for other in ("bed","bim","fam"):
            if other==key:continue
            edit=fields[other];current=edit.text()
            if current and current!=automatic.get(other):continue
            candidate=path.with_suffix("."+other)
            value=str(candidate) if candidate.is_file() else ""
            edit.setText(value);automatic[other]=value
            window = edit.window()
            prefix = window.tr_pair("未找到：", "Not found: ") if hasattr(window, "tr_pair") else "Not found: "
            edit.setProperty("missing_companion", str(candidate) if not value else None)
            edit.setToolTip(str(candidate) if value else prefix+str(candidate))
    return automatic
