from pathlib import Path
import csv
import json
import shutil
import uuid

from PySide6.QtWidgets import QWidget,QScrollArea,QVBoxLayout,QFormLayout,QHBoxLayout,QLineEdit,QComboBox,QGroupBox,QTabWidget,QLabel,QFileDialog
from .data_widgets import TraitSelector,MatrixFields,format_help,table_widget,fill_table


def build_data_page(w):
    scroll=QScrollArea(); scroll.setWidgetResizable(True)
    body=QWidget(); layout=QVBoxLayout(body); scroll.setWidget(body)
    general=QFormLayout(); layout.addLayout(general)
    def field(form,key,path,zh,en,mode=None):
        edit=QLineEdit(); edit.setObjectName(key); edit.setMinimumWidth(200); edit.setMaximumWidth(900)
        w.fields[key]=edit
        edit.textChanged.connect(lambda value,p=path: w.edit_field(p,value))
        edit.textChanged.connect(edit.setToolTip)
        row=QWidget(); box=QHBoxLayout(row);box.setContentsMargins(0,0,0,0)
        if mode:
            browse=w.button("选择…","Browse…",lambda checked=False,k=key,m=mode:w.browse(k,m));browse.setFixedWidth(90);box.addWidget(browse)
        box.addWidget(edit,1)
        form.addRow(w.label(zh,en),row)
        return row
    field(general,"name",("name",),"项目名称","Project name")
    field(general,"dataset_id",("data","dataset_id"),"数据集名称","Dataset identifier")
    field(general,"output_dir",("output_dir",),"运行输出目录","Run output directory","directory")
    genotype=QGroupBox();w.bind_text(genotype,"基因型","Genotypes",setter="setTitle");layout.addWidget(genotype);gf=QFormLayout(genotype)
    w.source_format=QComboBox();w.bind_combo(w.source_format,[("PLINK BED/BIM/FAM","PLINK BED/BIM/FAM"),("数值矩阵 CSV / TXT","Numeric matrix CSV / TXT")])
    row=QHBoxLayout();row.addWidget(w.source_format);row.addWidget(w.button("?","?",lambda:format_help(w,"matrix" if w.source_format.currentIndex() else "plink")))
    gf.addRow(w.label("基因型格式","Genotype format"),row)
    w.bed_row=field(gf,"bed",("data","bed"),"BED","BED","file")
    w.fam_row=field(gf,"fam",("data","fam"),"FAM","FAM","file")
    w.bim_row=field(gf,"bim",("data","bim"),"位点信息 BIM","Markers BIM","file")
    w.matrix_fields=MatrixFields(w);gf.addRow(w.matrix_fields)
    w.matrix_fields.hide()
    w.source_format.currentIndexChanged.connect(lambda _:source_changed(w))
    w.matrix_fields.changed.connect(lambda:matrix_changed(w))
    matrices=QGroupBox();w.bind_text(matrices,"计算关系 / 相似度矩阵","Compute relationship / similarity matrices","setTitle")
    matrices.setCheckable(True);matrices.setChecked(False);layout.addWidget(matrices)
    matrix_layout=QVBoxLayout(matrices);matrix_body=QWidget();matrix_inner=QVBoxLayout(matrix_body);matrix_layout.addWidget(matrix_body)
    matrix_body.hide();matrices.toggled.connect(matrix_body.setVisible)
    matrix_inner.addWidget(w.label("独立导出为描述性矩阵；正式训练请在网络页选择训练内核配方。","Independent export is descriptive; choose a training-fitted kernel recipe on the builder for model inputs."))
    def open_matrix_tool():
        from .kernel_dialog import KernelDialog
        w.matrix_dialog=KernelDialog(w,independent=True);w.matrix_dialog.show()
    matrix_inner.addWidget(w.button("配置并计算 GRM / 核矩阵…","Configure and compute GRM / kernel matrix…",open_matrix_tool,"matrix_tool"))
    phenotype=QGroupBox();w.bind_text(phenotype,"表型","Phenotypes",setter="setTitle");layout.addWidget(phenotype);pf=QFormLayout(phenotype)
    row=QHBoxLayout();row.addWidget(w.label("CSV / TXT","CSV / TXT"));row.addWidget(w.button("?","?",lambda:format_help(w,"phenotype")));row.addStretch();pf.addRow(row)
    field(pf,"phenotype",("data","phenotype"),"表型文件","Phenotype file","file")
    for key,zh,en,items in [
        ("delimiter","表型分隔符","Phenotype delimiter",[("CSV (,)",","),("TSV (Tab)","\t"),("Whitespace","whitespace")]),
        ("encoding","表型编码","Phenotype encoding",[(s,s) for s in ("utf-8","utf-8-sig","gb18030")]),
        ("id_mode","ID 匹配方式","ID matching",[("FID + IID","fid_iid"),("IID","iid")])]:
        edit=QComboBox();edit.setObjectName(key)
        for label,value in items:edit.addItem(label,value)
        if key=="delimiter":w.bind_combo(edit,[("逗号 CSV (,)","Comma CSV (,)"),("制表符 Tab","Tab"),("空白分隔 TXT","Whitespace TXT")])
        edit.currentIndexChanged.connect(lambda _,k=key,c=edit:w.edit_option(k,c.currentData()))
        w.fields[key]=edit;pf.addRow(w.label(zh,en),edit)
    for key,zh,en in [("id_columns","表型 ID 列（JSON 数组）","Phenotype ID columns (JSON)"),("missing_tokens","表型缺失标记（JSON 数组）","Phenotype missing tokens (JSON)")]:
        edit=QLineEdit();edit.setObjectName(key);w.fields[key]=edit
        edit.textEdited.connect(lambda _:setattr(w.document,"dirty",True))
        edit.editingFinished.connect(lambda k=key,e=edit:w.edit_json_option(k,e))
        pf.addRow(w.label(zh,en),edit)
    trait=TraitSelector(w);trait.setObjectName("trait");w.fields["trait"]=trait
    trait.currentTextChanged.connect(lambda s:w.edit_field(("data","phenotype_options","trait"),s))
    row=QHBoxLayout();row.addWidget(w.label("目标性状","Target trait"));row.addStretch();row.addWidget(w.button("读取表型列名","Read phenotype columns",w.read_columns,"read_columns"));pf.addRow(row);pf.addRow(trait)
    advanced=QGroupBox();w.bind_text(advanced,"高级：来源与重复样本检查","Advanced: provenance and duplicate samples",setter="setTitle")
    advanced.setCheckable(True);advanced.setChecked(False);layout.addWidget(advanced)
    outer=QVBoxLayout(advanced);inner=QWidget();af=QFormLayout(inner);outer.addWidget(inner);inner.hide();advanced.toggled.connect(inner.setVisible)
    field(af,"manifest",("data","manifest"),"来源清单（可选）","Source manifest (optional)","file")
    field(af,"split_groups",("data","split_groups"),"基因型等价组（非家系，可选）","Genotype equivalence (not family, optional)","file")
    af.addRow(w.button("?","?",lambda:format_help(w,"advanced")))
    row=QHBoxLayout();w.check_button=w.button("检查数据与匹配","Check data and matching",w.start_audit,"check_data");row.addWidget(w.check_button)
    row.addWidget(w.button("导出检查表","Export audit tables",lambda:export_tables(w)))
    w.open_check_button=w.button("打开最近检查文件夹","Open latest check folder",w.open_check_folder,"open_check_folder")
    w.open_check_button.setEnabled(False);row.addWidget(w.open_check_button)
    row.addWidget(w.button("导出原始 012 矩阵","Export raw 012 matrix",lambda:w.workflow.start_genotype_export(),"export_genotypes"));layout.addLayout(row)
    w.audit_label=QLabel();w.audit_label.setWordWrap(True);layout.addWidget(w.audit_label)
    w.audit_tabs=QTabWidget();layout.addWidget(w.audit_tabs)
    w.audit_tables={}
    for key,title in [("summary","检查摘要"),("samples","个体匹配"),("traits","性状统计")]:
        t=table_widget();w.audit_tables[key]=t;w.audit_tabs.addTab(t,title)
    w.audit_filter=QComboBox();w.bind_combo(w.audit_filter,[("全部记录","All records"),("仅未匹配与缺失","Unmatched or missing only")])
    w.audit_filter.currentIndexChanged.connect(lambda _:render_audit(w));layout.addWidget(w.audit_filter)
    layout.addWidget(w.label("表格最多显示 2000 行；完整记录可导出。缺失标签不填补为真值。","Table displays up to 2000 rows; export full records. Missing labels are never imputed as truth."))
    translate_data_page(w)
    return scroll


def source_changed(w):
    data=w.document.value["data"]
    if w.source_format.currentIndex():
        w._plink_paths={k:data.get(k) for k in ("bed","fam","bim")}
        data.update(bed=None,fam=None,manifest=None)
        matrix_changed(w)
    else:
        data.pop("matrix",None)
        data.update(getattr(w,"_plink_paths",{"bed":"","fam":"","bim":""}))
    w.document.dirty=True
    w.populate(); w.invalidate_audit();w.refresh()


def matrix_changed(w):
    if not w.source_format.currentIndex():return
    try:
        data=w.document.value["data"];data["matrix"]=w.matrix_fields.value()
        if data["matrix"]["counted_allele"]=="DECLARED":
            if data.get("bim"):w._matrix_bim=data["bim"]
            data["bim"]=None
        elif not data.get("bim"):
            data["bim"]=getattr(w,"_matrix_bim",w.fields["bim"].text()) or ""
    except ValueError:
        w.document.value["data"]["matrix"]={"invalid_draft":True}
    w.document.dirty=True
    _bim_visible(w)
    if hasattr(w,"workflow"):w.invalidate_audit();w.refresh()


def sync_source(w):
    value=w.document.value["data"].get("matrix")
    w.source_format.blockSignals(True);w.source_format.setCurrentIndex(1 if value is not None else 0);w.source_format.blockSignals(False)
    for row in (w.bed_row,w.fam_row):
        row.setVisible(value is None)
        label=row.parentWidget().layout().labelForField(row)
        if label:label.setVisible(value is None)
    w.matrix_fields.setVisible(value is not None)
    if value is not None:w.matrix_fields.populate(value)
    _bim_visible(w)


def _bim_visible(w):
    matrix=w.document.value["data"].get("matrix")
    show=matrix is None or matrix.get("counted_allele")!="DECLARED"
    w.bim_row.setVisible(show)
    label=w.bim_row.parentWidget().layout().labelForField(w.bim_row)
    if label:label.setVisible(show)


def translate_data_page(w):
    if not hasattr(w,"audit_tabs"):return
    for i,pair in enumerate([("检查摘要","Summary"),("个体匹配","Individuals"),("性状统计","Traits")]):
        w.audit_tabs.setTabText(i,w.tr_pair(*pair))
    w.matrix_fields.translate()
    if hasattr(w,"audit"):render_audit(w)


def render_audit(w):
    a=w.audit
    if not a:
        for t in w.audit_tables.values():fill_table(t,[],[])
        return
    labels={"samples":("个体数","Samples"),"markers":("位点数","Markers"),"matched":("匹配","Matched"),
        "genotype_only":("仅基因型","Genotype only"),"phenotype_only":("仅表型","Phenotype only"),
        "matched_finite_label":("已匹配有效标签","Matched with valid label"),"matched_missing_label":("已匹配但标签缺失","Matched with missing label"),
        "matched_invalid_label":("已匹配但标签无效","Matched with invalid label"),"observed":("有效观测","Observed"),
        "unavailable":("不可用","Unavailable"),"mean":("均值","Mean"),"sd":("标准差","SD"),"minimum":("最小值","Minimum"),
        "q25":("下四分位数","Q25"),"median":("中位数","Median"),"q75":("上四分位数","Q75"),"maximum":("最大值","Maximum")}
    display=lambda key:w.tr_pair(*labels.get(key,(key,key)))
    summary=[(display(k),v) for k,v in [("samples",a["samples"]),("markers",a["markers"]),*a["matching"].items()]]
    fill_table(w.audit_tables["summary"],[w.tr_pair("项目","Item"),w.tr_pair("数量","Value")],summary)
    stats=a.get("trait_statistics",{})
    columns=["matched","observed","unavailable","mean","sd","minimum","q25","median","q75","maximum"]
    rows=[[name,*[round(s[k],6) if isinstance(s.get(k),float) else s.get(k) for k in columns],
           a["traits"][name]["missing"],a["traits"][name]["invalid"]] for name,s in stats.items()]
    fill_table(w.audit_tables["traits"],[w.tr_pair("性状","Trait"),*[display(k) for k in columns],w.tr_pair("全表缺失","All-table missing"),w.tr_pair("全表无效","All-table invalid")],rows)
    w.audit_tables["traits"].setToolTip(w.tr_pair("统计使用 ID 匹配后的有效观测；标准差自由度为 n-1，分位数线性插值。另列出全表缺失和无效计数。","Statistics: ID-matched finite observations; SD ddof=1, quantile=linear. All-table missing/invalid counts labelled separately."))
    folder=getattr(w,"audit_directory",None)
    if folder:
        rows=[];statuses=[]
        for filename in ("samples.csv","phenotype_only.csv"):
            p=folder/filename
            if not p.exists():continue
            with p.open(encoding="utf-8",newline="") as f:
                for r in csv.DictReader(f):
                    status=r.get("match_status",r.get("status",""))
                    if w.audit_filter.currentIndex() and status=="matched_finite_label":continue
                    opts=a["phenotype_options"]; ids=opts["id_columns"]
                    rows.append([r.get("FID",r.get(ids[0],"") if len(ids)==2 else ""),r.get("IID",r.get(ids[-1],"")),display(status),r.get("value",""),r.get("phenotype_line",r.get("source_line",""))])
                    statuses.append(status)
                    if len(rows)>=2000:break
            if len(rows)>=2000:break
        fill_table(w.audit_tables["samples"],["FID","IID",w.tr_pair("状态","Status"),w.tr_pair("观测值","Value"),w.tr_pair("表型行号","Phenotype line")],rows,statuses)


def export_tables(w):
    folder=getattr(w,"audit_directory",None)
    if not w.audit or not folder:
        w.show_error(w.tr_pair("请先检查数据","Inspect data first"));return
    root=QFileDialog.getExistingDirectory(w,w.tr_pair("导出检查表","Export audit tables"),str(w.root))
    if not root:return
    dest=Path(root)/("audit_"+uuid.uuid4().hex[:10]);dest.mkdir()
    for name in ("samples.csv","phenotype_only.csv","invalid_traits.csv","trait_statistics.csv","audit.json"):
        if (folder/name).exists():shutil.copyfile(folder/name,dest/name)
    w.message.setText(str(dest))
