"""Explicit opt-in individual graph protocol; no research setting inferred from files."""
import json
from PySide6.QtWidgets import (QComboBox, QDialog, QDoubleSpinBox, QFormLayout, QLabel, QPushButton, QSpinBox, QVBoxLayout, QPlainTextEdit)
from ..data.additional import table_widths
from ..graphs.individual import IndividualGraphSpec, reference_defaults
from ..models.templates import reference_template


class ReferenceDialog(QDialog):
    def __init__(self, window):
        super().__init__(window)
        self.window = w = window
        self.setWindowTitle(w.tr_pair("个体参考图协议", "Individual reference graph protocol"))
        self.resize(680, 530)
        layout = QVBoxLayout(self)
        note = QLabel(w.tr_pair(
            "请明确选择评估协议。归纳模式：仅训练个体作参考，可接入独立新个体。传导模式：整队列基因型可见，只支持固定队列内预测，拒绝未知个体。图不接收标签；早停仍用验证集。模型权重会保存预测所需的参考基因型特征。关系采用明确的 RBF kNN，不自动等于亲缘系数。",
            "Choose the evaluation protocol explicitly. Inductive: training references only, independent new queries allowed. Transductive: all fixed-cohort genotypes visible; unknown individuals rejected. No graph labels; validation still controls early stopping. Model weights contain reference genotype features required for prediction. Relationship is explicit RBF kNN, not an inferred pedigree/kinship coefficient."))
        note.setWordWrap(True)
        layout.addWidget(note)
        form = QFormLayout()
        layout.addLayout(form)
        self.protocol = QComboBox()
        self.protocol.addItem(w.tr_pair("请选择协议", "Choose protocol"), None)
        for value, zh, en in (("inductive_train_reference", "归纳：仅训练参考个体", "Inductive: training references only"), ("transductive_fixed_cohort", "传导：固定队列", "Transductive: fixed cohort")):
            self.protocol.addItem(w.tr_pair(zh, en), value)
        form.addRow(w.tr_pair("基因型可见性 / 新个体接入", "Genotype visibility / query admission"), self.protocol)
        existing = w.document.value["model"].get("individual_graph_spec")
        defaults = existing or reference_defaults()
        self.fields = {}
        labels = dict(neighbors=("邻居数", "Neighbors"), temperature=("RBF 温度", "RBF temperature"),
                      minimum_weight=("最低原始相似度", "Minimum raw similarity"),
                      max_reference_individuals=("参考个体上限", "Reference individual limit"),
                      max_reference_cells=("参考基因型单元上限", "Reference cell limit"),
                      max_pair_products=("距离乘积计算预算", "Distance product budget"))
        for name in ("neighbors", "temperature", "minimum_weight", "max_reference_individuals", "max_reference_cells", "max_pair_products"):
            if name in ("temperature", "minimum_weight"):
                box = QDoubleSpinBox()
                box.setDecimals(6)
                box.setRange(.000001 if name == "temperature" else 0., 1e6 if name == "temperature" else 1.)
            else:
                box = QSpinBox()
                box.setRange(2 if name in ("max_reference_cells", "max_reference_individuals") else 1,
                             {"neighbors": 64, "max_reference_individuals": 16384, "max_reference_cells": 50_000_000,
                              "max_pair_products": 2**31-1}[name])
            box.setValue(defaults[name])
            self.fields[name] = box
            form.addRow(w.tr_pair(*labels[name]), box)
        self.message = QLabel()
        self.message.setWordWrap(True)
        layout.addWidget(self.message)
        state = getattr(w, "reference_state", None)
        if state and existing:
            preview = QPlainTextEdit()
            preview.setReadOnly(True)
            preview.setMaximumHeight(130)
            preview.setPlainText(json.dumps(dict(protocol=state["protocol"], references=state["feature_shape"][0],
                features=state["feature_shape"][1], neighbors=state["neighbors"],
                reference_ids_first_20=state["reference_ids"][:20], labels_in_graph=False), ensure_ascii=False, indent=2))
            layout.addWidget(preview)
        self.apply_button = QPushButton(w.tr_pair("应用协议并替换为参考图网络", "Apply protocol and replace with reference network"))
        self.apply_button.setEnabled(False)
        self.apply_button.clicked.connect(self.apply)
        layout.addWidget(self.apply_button)
        self.protocol.currentIndexChanged.connect(lambda: self.apply_button.setEnabled(self.protocol.currentData() is not None))
        if existing:
            self.protocol.setCurrentIndex(self.protocol.findData(existing["protocol"]))

    def apply(self):
        try:
            if self.protocol.currentData() is None:
                raise ValueError(self.window.tr_pair("请选择明确的协议", "Choose an explicit protocol"))
            value = reference_defaults(self.protocol.currentData())
            value.update({name: box.value() for name, box in self.fields.items()})
            IndividualGraphSpec(value)
            w = self.window
            model = reference_template(value, table_widths(w.document.value))
            if w.document.value.get("extensions",{}).get("multitask"):
                from ..models.templates import with_targets
                model=with_targets(model,w.document.value["extensions"]["multitask"]["targets"])
            w.document.change(("model",), model.to_dict())
            w.reference_state = None
            w.feature_source = "manual"
            w.rebuild_cards()
            w.refresh()
            self.message.setText(w.tr_pair("已应用，参考群体将在训练划分确定后拟合。", "Applied; references are fitted after the training split is fixed."))
        except ValueError as error:
            self.message.setText(self.window.error_text(error))
