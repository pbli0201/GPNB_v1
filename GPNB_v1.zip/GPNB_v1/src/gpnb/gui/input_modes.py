"""Data requirements and explicit input-mode changes for the desktop builder."""
from __future__ import annotations

import copy

from PySide6.QtWidgets import QCheckBox, QComboBox, QHBoxLayout, QLabel, QVBoxLayout, QWidget

from ..config import ModelSpec
from ..models.registry import COMPONENTS


GENERIC_TEMPLATES = ["MLP", "CNN", "Local", "Residual", "RNN", "LSTM", "GRU", "Tokens", "Categorical",
                     "SelfAttention", "Transformer", "CrossAttention", "GatedAdd", "GatedMLP", "SE", "TCN",
                     "Mixer", "AttentionPool", "DenseMoE", "GCN", "GraphSAGE", "GIN", "GAT", "MultiInput",
                     "ReferenceGraph", "GridCNN", "FeatureAffine", "Autoencoder", "KernelMLP", "SNP+Kernel"]


def kernel_options(value):
    return value.get("run", {}).get("extensions", {}).get("kernel_features")


def layer_input_roots(model, identifier):
    """Describe branch provenance without claiming transformed features are loci."""
    rows = {row["id"]: row for row in model["layers"]}
    roots, seen = set(), set()
    def visit(source):
        if source.startswith("$input"):
            roots.add(source)
        elif source in rows and source not in seen:
            seen.add(source)
            row = rows[source]
            if model.get("graph_mode", "sequential") == "sequential":
                index = model["layers"].index(row)
                visit(model["layers"][index - 1]["id"] if index else "$input")
            else:
                for incoming in row.get("inputs", {}).values():
                    visit(incoming)
    visit(identifier)
    return roots


def input_widths(value):
    from ..data.additional import table_widths
    widths = table_widths(value)
    if (kernel_options(value) or {}).get("mode") == "snp_kernel":
        widths["kernel"] = 1  # Resolved to the exact training reference count by the shared backend.
    return widths


def input_template(value, name):
    from ..models.templates import basic_template, numeric_fusion_template, with_targets
    widths = input_widths(value)
    mode = (kernel_options(value) or {}).get("mode", "snp")
    if name == "KernelMLP" and mode != "kernel":
        raise ValueError("Select kernel-only inputs before applying KernelMLP")
    if name == "SNP+Kernel" and mode != "snp_kernel":
        raise ValueError("Select SNP + kernel inputs before applying SNP+Kernel")
    if name in ("KernelMLP", "SNP+Kernel", "MultiInput"):
        spec = numeric_fusion_template(widths) if widths else basic_template("MLP")
        item = spec.to_dict()
        item["name"] = {"KernelMLP": "Kernel feature regression", "SNP+Kernel": "SNP and kernel feature fusion",
                        "MultiInput": "Numeric multi-input regression"}[name]
        spec = ModelSpec(item)
    else:
        return None
    if value.get("extensions", {}).get("multitask"):
        spec = with_targets(spec, value["extensions"]["multitask"]["targets"])
    return spec


def build_input_modes(w, layout):
    box = QWidget()
    outer = QVBoxLayout(box)
    outer.setContentsMargins(0, 0, 0, 0)
    row = QVBoxLayout()
    w.extra_data = QCheckBox()
    w.bind_text(w.extra_data, "还使用基因组以外的数据", "Also use data beyond genotypes")
    w.extra_data.setObjectName("use_external_data")
    row.addWidget(w.extra_data)
    w.edit_extra = w.button("配置数值表…", "Configure numeric tables…", w.open_input_tables, "configure_numeric_tables")
    row.addWidget(w.edit_extra)
    row.addStretch()
    outer.addLayout(row)
    row = QVBoxLayout()
    row.addWidget(w.label("基因组输入", "Genomic inputs"))
    w.input_mode = QComboBox()
    for cn, en, key in (("SNP 剂量", "SNP dosage", "snp"), ("仅 GRM / 核特征", "GRM / kernel features only", "kernel"),
                        ("SNP + GRM / 核特征", "SNP + GRM / kernel features", "snp_kernel")):
        w.input_mode.addItem(w.tr_pair(cn, en), key)
    w.bind_combo(w.input_mode, [("SNP 剂量", "SNP dosage"), ("仅 GRM / 核特征", "GRM / kernel features only"),
                               ("SNP + GRM / 核特征", "SNP + GRM / kernel features")])
    w.input_mode.setObjectName("genomic_input_mode")
    row.addWidget(w.input_mode)
    w.kernel_settings = w.button("核计算配方…", "Kernel recipe…", lambda: open_kernel_dialog(w), "kernel_recipe")
    row.addWidget(w.kernel_settings)
    row.addWidget(w.button("应用输入并创建基础网络", "Apply inputs and build a basic network", lambda: apply_inputs(w), "apply_input_mode"))
    outer.addLayout(row)
    w.input_note = QLabel()
    w.input_note.setWordWrap(True)
    outer.addWidget(w.input_note)
    w.extra_data.toggled.connect(lambda _: update_input_controls(w))
    w.input_mode.currentIndexChanged.connect(lambda _: update_input_controls(w))
    layout.addWidget(box)


def update_input_controls(w):
    w.edit_extra.setEnabled(w.extra_data.isChecked())
    w.kernel_settings.setEnabled(w.input_mode.currentData() != "snp")
    w.input_note.setText(w.tr_pair(
        "其他数据须为每行一个体的数值表，按 ID 匹配。核列对应训练参考个体，不代表染色体位置。高级连接可在层卡片中逐端口编辑；投影层必须显式添加。",
        "Other inputs must be numeric tables with one individual per row, matched by ID. Kernel columns represent training references, not chromosome positions. Edit advanced ports on layer cards; add projection layers explicitly."))


def sync_inputs(w):
    mode = (kernel_options(w.document.value) or {}).get("mode", "snp")
    fingerprint = (mode, bool(w.document.value.get("extensions", {}).get("input_tables")))
    if fingerprint != getattr(w, "_input_mode_fingerprint", None):
        w._input_mode_fingerprint = fingerprint
        w.input_mode.blockSignals(True)
        w.input_mode.setCurrentIndex(w.input_mode.findData(mode))
        w.input_mode.blockSignals(False)
        w.extra_data.setChecked(fingerprint[1])
    update_input_controls(w)


def open_kernel_dialog(w):
    from .kernel_dialog import KernelDialog
    w.kernel_dialog = KernelDialog(w, independent=False)
    w.kernel_dialog.show()


def apply_inputs(w):
    """The button explicitly replaces the network, never a passive data change."""
    from ..data.kernels import default_recipe
    try:
        mode = w.input_mode.currentData()
        value = copy.deepcopy(w.document.value)
        tables = value.get("extensions", {}).get("input_tables", [])
        if tables and not w.extra_data.isChecked():
            raise ValueError(w.tr_pair("已存在额外数值表。请在数值表设置中显式移除，或勾选使用其他数据。",
                                       "Numeric tables are already configured. Remove them explicitly in table settings or enable other data."))
        ext = value["run"].setdefault("extensions", {})
        if mode == "snp":
            ext.pop("kernel_features", None)
        else:
            recipe = getattr(w, "_kernel_recipe_draft", None) or (kernel_options(value) or {}).get("kernel") or default_recipe()
            ext["kernel_features"] = {"mode": mode, "kernel": copy.deepcopy(recipe)}
        name = "SNP+Kernel" if mode == "snp_kernel" else "KernelMLP" if mode == "kernel" else "MultiInput" if tables else "MLP"
        old = w.document.value
        w.document.value = value
        try:
            w.document.apply_template(name)
        except Exception:
            w.document.value = old
            raise
        if w.feature_source == "prepared":
            w.invalidate_audit()
        w.rebuild_cards()
        w.refresh()
    except (ValueError, OSError) as error:
        w.show_error(error)


def template_reasons(value, language="en_US"):
    from ..models.paper_templates import AVAILABLE
    choose = lambda cn, en: cn if language == "zh_CN" else en
    model = value["model"]
    mode = (kernel_options(value) or {}).get("mode", "snp")
    widths = input_widths(value)
    reasons = {}
    for name in GENERIC_TEMPLATES + list(AVAILABLE):
        if name == "KernelMLP" and mode != "kernel":
            reasons[name] = choose("需要仅核输入", "Requires kernel-only inputs")
        elif name == "SNP+Kernel" and mode != "snp_kernel":
            reasons[name] = choose("需要 SNP + 核输入", "Requires SNP + kernel inputs")
        elif name == "MultiInput" and not widths:
            reasons[name] = choose("需要额外数值表或核分支", "Requires numeric tables or a kernel branch")
        elif widths and name not in ("MultiInput", "SNP+Kernel", "KernelMLP", "ReferenceGraph"):
            reasons[name] = choose("当前有多个输入；先使用融合网络，再编辑层", "Multiple inputs configured; start with fusion and edit layers")
        elif mode == "kernel" and name in set(AVAILABLE) | {"Categorical", "GCN", "GraphSAGE", "GIN", "GAT", "ReferenceGraph", "Autoencoder"}:
            reasons[name] = choose("此模板要求原始位点输入；核列为参考个体", "This template requires marker inputs; kernel columns are references")
        elif name in ("GCN", "GraphSAGE", "GIN", "GAT") and "graph_spec" not in model:
            reasons[name] = choose("先配置位点图；可使用训练内 LD 图，无需外部组学", "Configure a locus graph first; training LD needs no external omics")
        elif name == "ReferenceGraph" and "individual_graph_spec" not in model:
            reasons[name] = choose("先配置个体参考图协议", "Configure the individual reference protocol first")
    return reasons


def layer_reasons(w):
    """Filter the insertion point by declared tensor contracts, without fitting."""
    value = w.document.value
    model = value["model"]
    mode = (kernel_options(value) or {}).get("mode", "snp")
    choose = w.tr_pair
    reasons = {}
    current_type = None
    if w.plan and model.get("graph_mode", "sequential") != "dag":
        layers = w.plan["layers"]
        if layers:
            current_type = layers[-1].get("input_type", {"kind": "Vector", "shape": layers[-1]["input_shape"]})
    for name, definition in COMPONENTS.items():
        if mode == "kernel" and name in ("GraphInput", "ReferenceGraphSAGE", "GenotypeEmbedding", "GenotypeOneHot", "ReconstructMarkers"):
            reasons[name] = choose("需要位点输入；当前输入为训练参考个体", "Requires marker inputs; current inputs are training references")
        elif name == "GraphInput" and not model.get("graph_spec"):
            reasons[name] = choose("需要配置位点图", "A locus graph must be configured")
        elif name == "ReferenceGraphSAGE" and not model.get("individual_graph_spec"):
            reasons[name] = choose("需要个体图协议", "An individual graph protocol is required")
        elif name == "AdaptiveMaxPool1d" and value["run"]["training"]["device"] == "cuda" and value["run"]["training"].get("adaptive_max_pool_strict") and value["run"]["training"]["deterministic"]:
            reasons[name] = choose("严格确定性 CUDA 反向不受支持；可使用 CPU", "Strict deterministic CUDA backward is unsupported; CPU is available")
        elif current_type and len(definition.ports) == 1 and current_type["kind"] not in definition.input_kinds:
            reasons[name] = choose("当前插入点类型为 ", "Insertion point type is ") + current_type["kind"] + choose("；需要 ", "; requires ") + "/".join(definition.input_kinds)
    return reasons


def refresh_choices(w):
    from ..models.paper_templates import AVAILABLE
    unavailable = template_reasons(w.document.value, w.language)
    old = w.template_box.currentText()
    allowed = [name for name in GENERIC_TEMPLATES + list(AVAILABLE) if name not in unavailable]
    if [w.template_box.itemText(i) for i in range(w.template_box.count())] != allowed:
        w.template_box.blockSignals(True)
        w.template_box.clear()
        w.template_box.addItems(allowed)
        if old in allowed:
            w.template_box.setCurrentText(old)
        w.template_box.blockSignals(False)
    layers = layer_reasons(w)
    old = w.kind_box.currentText()
    allowed_layers = [name for name in COMPONENTS if name not in layers]
    if [w.kind_box.itemText(i) for i in range(w.kind_box.count())] != allowed_layers:
        w.kind_box.blockSignals(True)
        w.kind_box.clear()
        w.kind_box.addItems(allowed_layers)
        if old in allowed_layers:
            w.kind_box.setCurrentText(old)
        w.kind_box.blockSignals(False)
    w.unavailable_options = {"templates": unavailable, "layers": layers}


def show_unavailable(w):
    from PySide6.QtWidgets import QDialog, QTextBrowser
    refresh_choices(w)
    dialog = QDialog(w)
    w.bind_text(dialog, "为什么选项不可用", "Why options are unavailable", "setWindowTitle")
    layout = QVBoxLayout(dialog)
    viewer = QTextBrowser()
    def render():
        from shiboken6 import isValid
        if not isValid(dialog):
            return
        refresh_choices(w)
        lines = [w.tr_pair("当前数据与插入点的检查结果；预检还会实测所选设备的前向和反向。显存不足可缩小模型或改用 CPU，并不代表该层永久不支持。旧网络配置保持不变。",
                           "Checks reflect current data and insertion-point types. Preflight also probes forward/backward on the selected device. For out-of-memory errors, reduce size or use CPU; a layer is not permanently unsupported. Existing models remain intact.")]
        for group, reasons in w.unavailable_options.items():
            lines += ["", w.tr_pair("模板", "Templates") if group == "templates" else w.tr_pair("新增层", "New layers")]
            lines += [f"{name}: {reason}" for name, reason in reasons.items()]
        viewer.setPlainText("\n".join(lines))
    w.translation_callbacks.append(render)
    render()
    layout.addWidget(viewer)
    dialog.resize(760, 520)
    w.unavailable_dialog = dialog
    dialog.show()
