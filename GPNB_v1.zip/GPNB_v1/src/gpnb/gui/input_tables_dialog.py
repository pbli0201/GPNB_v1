"""Numeric modality editor. Column selection is explicit, never inferred from traits."""
import copy
import json
from pathlib import Path

from PySide6.QtWidgets import (QAbstractItemView, QCheckBox, QComboBox, QDialog, QFileDialog, QFormLayout,
    QHBoxLayout, QLabel, QLineEdit, QListWidget, QPushButton, QSpinBox, QVBoxLayout)

from ..config import ModelSpec
from ..data.additional import table_defaults, validate_tables
from ..data.tables import text_table
from ..models.migration import migrate_model


class InputTablesDialog(QDialog):
    def __init__(self, window):
        super().__init__(window)
        self.window = w = window
        self.configs = copy.deepcopy(w.document.value.get("extensions", {}).get("input_tables", []))
        self.setWindowTitle(w.tr_pair("额外数值输入", "Additional numeric inputs"))
        self.resize(800, 760)
        layout = QVBoxLayout(self)
        self.list = QListWidget()
        self.list.setMaximumHeight(85)
        layout.addWidget(self.list)
        form = QFormLayout()
        layout.addLayout(form)
        self.name, self.path = QLineEdit("covariates"), QLineEdit()
        form.addRow(w.tr_pair("分支名称（字母开头）", "Branch identifier (starts with letter)"), self.name)
        row = QHBoxLayout()
        row.addWidget(self.path)
        button = QPushButton(w.tr_pair("选择并读取列名", "Browse and read columns"))
        button.clicked.connect(self.browse)
        row.addWidget(button)
        form.addRow(w.tr_pair("CSV / TSV 数值表", "CSV / TSV numeric table"), row)
        self.delimiter = QComboBox()
        self.delimiter.addItem("CSV", ",")
        self.delimiter.addItem("TSV", "\t")
        self.delimiter.currentIndexChanged.connect(lambda: self.read_columns())
        form.addRow(w.tr_pair("分隔符", "Delimiter"), self.delimiter)
        self.mode = QComboBox()
        self.mode.addItems(["fid_iid", "iid"])
        self.fid, self.iid = QComboBox(), QComboBox()
        for combo in (self.fid, self.iid):
            combo.setEditable(True)
        self.fid.setCurrentText("FID")
        self.iid.setCurrentText("IID")
        form.addRow(w.tr_pair("匹配方式", "Matching"), self.mode)
        form.addRow("FID", self.fid)
        form.addRow("IID", self.iid)
        self.mode.currentTextChanged.connect(lambda mode: self.fid.setEnabled(mode == "fid_iid"))
        self.columns = QListWidget()
        self.columns.setSelectionMode(QAbstractItemView.MultiSelection)
        self.columns.setMaximumHeight(150)
        form.addRow(w.tr_pair("选择数值特征列（不选 ID 和目标）", "Select numeric features (exclude IDs/target)"), self.columns)
        self.missing = QLineEdit('["", "NA", "NaN"]')
        form.addRow(w.tr_pair("缺失标记（JSON 字符串数组）", "Missing tokens (JSON string array)"), self.missing)
        self.missing_rows, self.all_missing = QComboBox(), QComboBox()
        self.missing_rows.addItems(["error", "fill"])
        self.all_missing.addItems(["error", "zero"])
        form.addRow(w.tr_pair("缺少个体行", "Missing individual rows"), self.missing_rows)
        form.addRow(w.tr_pair("训练列全部缺失", "All missing in training column"), self.all_missing)
        self.standardize = QCheckBox(w.tr_pair("按训练集标准化", "Training-fitted standardization"))
        self.standardize.setChecked(True)
        form.addRow(self.standardize)
        self.max_cells = QSpinBox()
        self.max_cells.setRange(1, 50_000_000)
        self.max_cells.setValue(2_000_000)
        form.addRow(w.tr_pair("每张表的单元数预算", "Cell budget per table"), self.max_cells)
        row = QHBoxLayout()
        for zh, en, callback in (("加入 / 更新分支", "Add / update branch", self.upsert),
                                 ("移除选中分支", "Remove selected", self.remove)):
            button = QPushButton(w.tr_pair(zh, en))
            button.clicked.connect(callback)
            row.addWidget(button)
        layout.addLayout(row)
        self.message = QLabel(w.tr_pair("仅读取列名；数值、ID 匹配与训练边界会在训练时检查。最多 16 张表、每表 4096 列。",
            "Header preview only; numeric/ID/training checks run during training. Up to 16 tables, 4096 columns each."))
        self.message.setWordWrap(True)
        layout.addWidget(self.message)
        row = QHBoxLayout()
        for zh, en, rebuild in (("保存表定义", "Save definitions", False),
                                ("保存并替换为融合网络", "Save and replace with fusion network", True)):
            button = QPushButton(w.tr_pair(zh, en))
            button.clicked.connect(lambda checked=False, r=rebuild: self.apply(r))
            row.addWidget(button)
        layout.addLayout(row)
        self.list.currentRowChanged.connect(self.select)
        self.refresh_list()

    def refresh_list(self):
        self.list.blockSignals(True)
        self.list.clear()
        self.list.addItems([f"{c['id']} ({len(c['columns'])}) — {c['path']}" for c in self.configs])
        self.list.blockSignals(False)

    def browse(self):
        path, _ = QFileDialog.getOpenFileName(self, self.window.tr_pair("额外数值输入表", "Numeric input table"), self.path.text(), self.window.tr_pair("数值表 (*.csv *.txt *.tsv);;所有文件 (*)", "Tables (*.csv *.txt *.tsv);;All files (*)"))
        if path:
            self.path.setText(path)
            self.read_columns()

    def read_columns(self, selected=()):
        try:
            if not self.path.text():
                return
            _, header = next(iter(text_table(Path(self.path.text()), self.delimiter.currentData())))
            if len(header) != len(set(header)):
                raise ValueError(self.window.tr_pair("存在重复列名", "Duplicate column names"))
            for combo, default in ((self.fid, "FID"), (self.iid, "IID")):
                combo.clear()
                combo.addItems(header)
                combo.setCurrentText(default)
            self.columns.clear()
            self.columns.addItems(header)
            for i in range(self.columns.count()):
                self.columns.item(i).setSelected(header[i] in selected)
        except (ValueError, OSError, StopIteration) as error:
            self.message.setText(str(error))

    def select(self, index):
        if not 0 <= index < len(self.configs):
            return
        c = self.configs[index]
        self.name.setText(c["id"])
        self.path.setText(c["path"])
        self.delimiter.blockSignals(True)
        self.delimiter.setCurrentIndex(self.delimiter.findData(c["delimiter"]))
        self.delimiter.blockSignals(False)
        self.read_columns(c["columns"])
        self.mode.setCurrentText(c["id_mode"])
        if c["id_mode"] == "fid_iid":
            self.fid.setCurrentText(c["id_columns"][0])
        self.iid.setCurrentText(c["id_columns"][-1])
        self.missing.setText(json.dumps(c["missing_tokens"]))
        self.missing_rows.setCurrentText(c["missing_rows"])
        self.all_missing.setCurrentText(c["all_missing"])
        self.standardize.setChecked(c["standardize"])
        self.max_cells.setValue(c["max_cells"])

    def upsert(self):
        try:
            c = table_defaults(self.name.text(), str(Path(self.path.text()).resolve()),
                               [item.text() for item in self.columns.selectedItems()])
            # An empty selection must not substitute the default feature name.
            c["columns"] = [item.text() for item in self.columns.selectedItems()]
            c.update(id_mode=self.mode.currentText(),
                     id_columns=[self.fid.currentText(), self.iid.currentText()] if self.mode.currentText() == "fid_iid" else [self.iid.currentText()],
                     delimiter=self.delimiter.currentData(), missing_tokens=json.loads(self.missing.text()),
                     missing_rows=self.missing_rows.currentText(), all_missing=self.all_missing.currentText(),
                     standardize=self.standardize.isChecked(), max_cells=self.max_cells.value())
            new = [row for row in self.configs if row["id"] != c["id"]] + [c]
            validate_tables(new, self.window.document.value["data"]["phenotype_options"]["trait"])
            self.configs = new
            self.refresh_list()
            self.message.setText(self.window.tr_pair("分支已加入；请保存定义或创建融合网络。", "Branch added; save definitions or build fusion network."))
        except (ValueError, OSError) as error:
            self.message.setText(str(error))

    def remove(self):
        index = self.list.currentRow()
        if 0 <= index < len(self.configs):
            self.configs.pop(index)
            self.refresh_list()

    def apply(self, rebuild=False):
        try:
            w = self.window
            validate_tables(self.configs, w.document.value["data"]["phenotype_options"]["trait"])
            widths = {c["id"]: len(c["columns"]) for c in self.configs}
            from .input_modes import kernel_options
            if (kernel_options(w.document.value) or {}).get("mode") == "snp_kernel":
                if "kernel" in widths:
                    raise ValueError(w.tr_pair("kernel 已保留为核分支名称，请更改表名称。", "kernel is reserved for the kernel branch; rename this table."))
                widths["kernel"] = 1
            model = w.document.value["model"]
            if rebuild:
                from ..models.templates import numeric_fusion_template
                model = numeric_fusion_template(widths).to_dict()
                if w.document.value.get("extensions",{}).get("multitask"):
                    from ..models.templates import with_targets
                    model=with_targets(ModelSpec(model),w.document.value["extensions"]["multitask"]["targets"]).to_dict()
            else:
                model = copy.deepcopy(model)
                if model["schema_version"] == 1:
                    model = migrate_model(ModelSpec(model)).to_dict()
                model.update(graph_mode="dag", external_inputs=widths)
            ext = copy.deepcopy(w.document.value.get("extensions", {}))
            ext["input_tables"] = copy.deepcopy(self.configs)
            w.document.change(("extensions",), ext)
            w.document.change(("model",), model)
            w.rebuild_cards()
            w.refresh()
            self.message.setText(w.tr_pair("已应用。若新增端口尚未连接，请先连接所有分支再保存项目。", "Applied. Connect all new input branches before saving the project."))
        except (ValueError, OSError) as error:
            self.message.setText(str(error))
