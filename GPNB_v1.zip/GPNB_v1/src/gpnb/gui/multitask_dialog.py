import copy
from PySide6.QtWidgets import (QDialog,QVBoxLayout,QHBoxLayout,QTableWidget,QTableWidgetItem,
    QPushButton,QLabel,QComboBox)


class MultitaskDialog(QDialog):
    fields=["id","column","trait","environment","unit","correction","weight"]
    def __init__(self,window):
        super().__init__(window)
        self.window=window
        self.setWindowTitle(window.tr_pair("多性状与多环境目标", "Multiple trait and environment targets"))
        self.resize(1000,560)
        layout=QVBoxLayout(self)
        note=QLabel(window.tr_pair("宽表：每行一个个体，每个性状或环境对应一个输出头；同一个体的所有环境整体划分。\n当前支持已知环境的新个体预测，不支持未知环境外推。辅助性状仅作训练标签；预测不读取表型。", "Wide table: one individual per row and one output head per trait or environment. All environments of an individual stay in the same partition.\nPredicts new individuals in known environments, not unknown-environment extrapolation. Auxiliary traits are training labels only; prediction never reads phenotype labels."))
        note.setWordWrap(True);layout.addWidget(note)
        self.protocol=QComboBox()
        self.protocol.addItem(window.tr_pair("请选择协议", "Choose protocol"),None)
        self.protocol.addItem(window.tr_pair("新个体、固定已知环境", "New individuals, known environments"),"new_individual_known_environments")
        layout.addWidget(self.protocol)
        self.table=QTableWidget(0,len(self.fields));self.table.setHorizontalHeaderLabels([window.tr_pair(zh,en) for zh,en in zip(["目标 ID", "表型列", "性状", "环境", "单位", "校正说明", "权重"],self.fields)])
        layout.addWidget(self.table)
        buttons=QHBoxLayout()
        for label,fn in (("新增目标 / Add",self.add),("删除 / Remove",self.remove),
                         ("应用目标头 / Apply heads",self.apply),("恢复单目标 / Single target",self.disable)):
            zh,en=label.split(" / ");button=QPushButton(window.tr_pair(zh,en));button.clicked.connect(fn);buttons.addWidget(button)
        layout.addLayout(buttons)
        self.message=QLabel();self.message.setWordWrap(True);layout.addWidget(self.message)
        existing=window.document.value.get("extensions",{}).get("multitask")
        if existing:
            self.protocol.setCurrentIndex(1)
            for target in existing["targets"]:
                self.add(target)

    def add(self,target=None):
        if not isinstance(target,dict):
            i=self.table.rowCount()+1
            target=dict(id=f"target{i}",column=self.window.document.value["data"]["phenotype_options"]["trait"] if i==1 else "",
                trait=f"trait{i}",environment="unspecified",unit="unknown",correction="unknown",weight=1.)
        i=self.table.rowCount();self.table.insertRow(i)
        for j,key in enumerate(self.fields):
            self.table.setItem(i,j,QTableWidgetItem(str(target[key])))

    def remove(self):
        if self.table.currentRow()>=0:
            self.table.removeRow(self.table.currentRow())

    def apply(self):
        try:
            from ..config import ModelSpec,ProjectSpec
            from ..data.multitask import validate_contract
            from ..models.templates import with_targets
            targets=[]
            for i in range(self.table.rowCount()):
                t={key:self.table.item(i,j).text() for j,key in enumerate(self.fields)}
                t["weight"]=float(t["weight"]);targets.append(t)
            contract=dict(protocol=self.protocol.currentData(),auxiliary_visibility="training_labels_only",targets=targets)
            validate_contract(contract)
            value=copy.deepcopy(self.window.document.value)
            value.setdefault("extensions",{}).pop("trait_batch",None)
            value["extensions"]["multitask"]=contract
            value["data"]["phenotype_options"]["trait"]=targets[0]["column"]
            value["model"]=with_targets(ModelSpec(value["model"]),targets).to_dict()
            ProjectSpec(value)
            self.window.document.value=value;self.window.document.dirty=True
            self.window.invalidate_audit();self.window.populate();self.window.rebuild_cards();self.window.refresh()
            self.message.setText(self.window.tr_pair("已应用。分别保存各输出头的单位、缺失掩码和指标。", "Applied. Each head retains its units, missing-value mask and metrics."))
        except Exception as error:
            self.message.setText(self.window.error_text(error))

    def disable(self):
        try:
            from ..config import ProjectSpec
            value=copy.deepcopy(self.window.document.value)
            value.setdefault("extensions",{}).pop("multitask",None)
            model=value["model"];model["task"]="single_trait_regression";model.pop("output_targets",None)
            from ..models.registry import regression_head
            regression_head(model)["params"]["out_features"]=1
            ProjectSpec(value)
            self.window.document.value=value;self.window.document.dirty=True
            self.window.invalidate_audit();self.window.populate();self.window.rebuild_cards();self.window.refresh();self.message.setText(self.window.tr_pair("单目标", "Single target"))
        except Exception as error:
            self.message.setText(self.window.error_text(error))
