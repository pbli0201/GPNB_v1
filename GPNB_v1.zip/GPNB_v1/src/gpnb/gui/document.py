from __future__ import annotations

import copy
import uuid
from pathlib import Path

from ..config import ModelSpec, ProjectSpec, default_model, default_run, fail, load_spec, resolve_project_path
from ..data.files import protect_inputs, sha256
from ..models.core import inspect_model
from ..models.migration import migrate_model
from ..models.registry import component, regression_head
from ..models.templates import basic_template


class Document:
    """Editable draft; invalid intermediate layers cannot be saved as a project."""

    def __init__(self, root):
        self.root = Path(root).resolve()
        self.path = None
        self.disk_hash = None
        self.dirty = False
        self.value = {
            "schema_version": 1, "kind": "project", "project_id": str(uuid.uuid4()),
            "name": "Untitled", "language": "zh_CN",
            "data": {"dataset_id": "my_dataset", "bed": "", "bim": "", "fam": "", "phenotype": "",
                     "manifest": None, "split_groups": None,
                     "phenotype_options": {"delimiter": ",", "encoding": "utf-8-sig",
                                           "id_mode": "fid_iid", "id_columns": ["FID", "IID"],
                                           "trait": "trait", "missing_tokens": ["", "NA", "NaN"]}},
            "output_dir": str(self.root / "runs"), "model": default_model().to_dict(),
            "run": default_run().to_dict()}

    def load(self, path):
        path = Path(path).resolve()
        spec = load_spec(path)
        if not isinstance(spec, ProjectSpec):
            fail("E_TYPE", str(path), "desktop editor requires ProjectSpec")
        value = spec.to_dict()
        from ..data.additional import resolve_table_paths
        resolve_table_paths(value, path)
        for key in ("bed", "bim", "fam", "phenotype", "manifest", "split_groups"):
            if value["data"][key] is not None:
                value["data"][key] = str(resolve_project_path(path, value["data"][key]))
        value["output_dir"] = str(resolve_project_path(path, value["output_dir"]))
        if value["run"]["split"]["reuse_manifest"] is not None:
            value["run"]["split"]["reuse_manifest"] = str(resolve_project_path(path, value["run"]["split"]["reuse_manifest"]))
        cv = value["run"].get("extensions", {}).get("cross_validation")
        if cv and cv["reuse_manifest"]:
            cv["reuse_manifest"] = str(resolve_project_path(path, cv["reuse_manifest"]))
        self.value, self.path, self.disk_hash, self.dirty = value, path, sha256(path), False

    def spec(self):
        value = copy.deepcopy(self.value)
        base = self.path or self.root / "untitled.json"
        from ..data.additional import resolve_table_paths
        resolve_table_paths(value, base)
        for key in ("bed", "bim", "fam", "phenotype", "manifest", "split_groups"):
            if value["data"][key]:
                value["data"][key] = str(resolve_project_path(base, value["data"][key]))
        if value["output_dir"]:
            value["output_dir"] = str(resolve_project_path(base, value["output_dir"]))
        if value["run"]["split"]["reuse_manifest"]:
            value["run"]["split"]["reuse_manifest"] = str(resolve_project_path(base, value["run"]["split"]["reuse_manifest"]))
        cv = value["run"].get("extensions", {}).get("cross_validation")
        if cv and cv["reuse_manifest"]:
            cv["reuse_manifest"] = str(resolve_project_path(base, cv["reuse_manifest"]))
        return ProjectSpec(value)

    def save(self, path, *, overwrite=False):
        path = Path(path).resolve()
        spec = self.spec()
        value = spec.to_dict()
        from ..data.genotypes import source_paths
        inputs = list(source_paths(value["data"], self.path or self.root / "untitled.json").values())
        inputs.extend(Path(item["path"]) for item in value.get("extensions", {}).get("input_tables", []))
        protect_inputs(path, inputs)
        if path == self.path and self.disk_hash is not None:
            if not path.is_file() or sha256(path) != self.disk_hash:
                fail("E_CHANGED", str(path), "project changed outside the editor; reopen or save to a new file")
        from .output_paths import ensure_output_directory
        ensure_output_directory(value["output_dir"], [*inputs, path])
        spec.save(path, overwrite=overwrite)
        self.value = spec.to_dict()
        self.path, self.disk_hash, self.dirty = path, sha256(path), False

    def plan(self, features, graph_state=None, reference_state=None):
        return inspect_model(ModelSpec(self.value["model"]), features, graph_state=graph_state, reference_state=reference_state)

    def change(self, path, value):
        target = self.value
        for key in path[:-1]:
            target = target[key]
        if (isinstance(target, dict) and path[-1] not in target) or target[path[-1]] != value:
            target[path[-1]] = value
            if path[:2] == ("model", "layers") and len(path) >= 4 and path[3] == "params":
                owner = self.value["model"]["layers"][path[2]]
                for row in self.value["model"]["layers"]:
                    if row.get("share_with") == owner["id"]:
                        row["params"] = copy.deepcopy(owner["params"])
            self.dirty = True

    def enable_dag(self):
        model = self.value["model"]
        if model["schema_version"] == 1:
            original = ModelSpec(model)
            model = migrate_model(original).to_dict()
            model.setdefault("extensions", {})["migration"] = {
                "original_model": original.to_dict(), "original_sha256": original.sha256,
                "reason": "User enabled explicit branch connections"}
            self.value["model"] = model
        model["graph_mode"] = "dag"
        model.setdefault("output", model["layers"][-1]["id"])
        self.dirty = True

    def set_representation(self, value):
        if self.value["model"]["schema_version"] == 1:
            self.enable_dag()
        self.change(("model", "input_representation"), value)

    def layer_action(self, action, index=0, kind="Linear"):
        if action == "share" or action == "add" and len(component(kind).ports) > 1:
            self.enable_dag()
        model = self.value["model"]
        if action == "add" and model["schema_version"] == 1 and kind not in ("Linear", "Dropout", "ReLU", "GELU", "Tanh", "Sigmoid"):
            original = ModelSpec(model)
            self.value["model"] = migrate_model(original).to_dict()
            self.value["model"].setdefault("extensions", {})["migration"] = {
                "original_model": original.to_dict(), "original_sha256": original.sha256,
                "reason": "User added a v2 component; original model recorded before editing."}
        layers = self.value["model"]["layers"]
        if action == "add":
            params = copy.deepcopy(component(kind).defaults())
            layer = {"id": f"layer_{uuid.uuid4().hex[:12]}", "type": kind, "params": params}
            if self.value["model"]["schema_version"] == 2:
                layer.update(implementation_version=1, inputs={p: "$input" for p in component(kind).ports})
            # Place new hidden layers before the regression output, when present.
            head = regression_head(self.value["model"])
            position = layers.index(head) if head is not None else len(layers)
            layers.insert(position, layer)
        elif action in ("copy", "share"):
            layer = copy.deepcopy(layers[index])
            layer["id"] = f"layer_{uuid.uuid4().hex[:12]}"
            if action == "share":
                layer["share_with"] = layers[index].get("share_with", layers[index]["id"])
            else:
                layer.pop("share_with", None)
            layers.insert(index+1, layer)
        elif action == "delete":
            layers.pop(index)
        elif action in ("up", "down"):
            other = index + (-1 if action == "up" else 1)
            if not 0 <= other < len(layers):
                return
            layers[index], layers[other] = layers[other], layers[index]
        else:
            raise ValueError(action)
        if self.value["model"]["schema_version"] == 2 and self.value["model"].get("graph_mode", "sequential") == "sequential":
            previous = "$input"
            for row in layers:
                row["inputs"] = {"x": previous}
                previous = row["id"]
        self.dirty = True

    def apply_template(self, name):
        from ..data.additional import table_widths
        from ..models.templates import numeric_fusion_template
        from .input_modes import input_template, input_widths
        widths = input_widths(self.value)
        derived = input_template(self.value, name)
        if derived is not None:
            spec = derived
        elif name == "ReferenceGraph":
            from ..models.templates import reference_template
            protocol = self.value["model"].get("individual_graph_spec")
            if not protocol:
                fail("E_REFERENCE", "template", "choose an individual graph protocol explicitly first")
            spec = reference_template(protocol, widths)
        elif name == "MultiInput":
            spec = numeric_fusion_template(widths)
        elif widths:
            fail("E_INPUT_TABLE", "template", "select MultiInput or remove input tables explicitly before replacing with a single-input template")
        else:
            spec = basic_template(name, self.value["model"].get("graph_spec"))
        if self.value.get("extensions",{}).get("multitask"):
            from ..models.templates import with_targets
            spec=with_targets(spec,self.value["extensions"]["multitask"]["targets"])
        self.value["model"] = spec.to_dict()
        if name == "Autoencoder":
            from ..training.stages import default_stages
            self.value["run"]["training"]["stages"]=default_stages(
                self.value["run"]["training"]["epochs"],["layer_1","layer_2","layer_3","layer_4","layer_5"])
        else:
            # A replacement template cannot inherit stale frozen layer identifiers.
            self.value["run"]["training"].pop("stages",None)
        self.value["model"].setdefault("extensions", {})["template"] = {
            "name": name, "baseline": spec.to_dict(), "baseline_sha256": spec.sha256}
        self.dirty = True

    def expand_component(self, index, features):
        from ..models.expansion import expand_model
        self.value["model"] = expand_model(ModelSpec(self.value["model"]), index, features).to_dict()
        self.dirty = True
