"""One lazy canvas for a complete batch index, including failed and reused tasks."""
import json
from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QComboBox,QLabel,QTextBrowser,QDialog
from matplotlib.figure import Figure
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
from ..batch_results import batch_result_index,archived_fit_details
from ..results import load_result_data,render_combination
from .data_widgets import fill_table


class BatchExplorer(QWidget):
    def __init__(self,flow):
        super().__init__();self.flow=flow;self.index=None;self.data=None;self.record=None;self.signature=None
        w=flow.window;layout=QVBoxLayout(self)
        self.note=QLabel();self.note.setWordWrap(True);layout.addWidget(self.note)
        row=QHBoxLayout();self.fold=QComboBox();self.fold.setObjectName('batch_learning_fold')
        row.addWidget(w.label('曲线对应外层折','Learning curve outer fold'));row.addWidget(self.fold)
        row.addWidget(w.button('打开组合大图','Open large combination',self.large_plot,'batch_large_plot'))
        row.addWidget(w.button('折 / 搜索 / 实际配置','Folds / search / actual settings',self.details,'batch_fit_details'))
        layout.addLayout(row)
        self.figure=Figure(figsize=(12,8),layout='constrained');self.canvas=FigureCanvasQTAgg(self.figure)
        self.canvas.setMinimumHeight(620);layout.addWidget(self.canvas);self.canvas.hide()
        self.fold.currentIndexChanged.connect(self.draw)
        flow.batch_table.cellClicked.connect(lambda row,col:self.select(row))

    def load(self,source):
        from pathlib import Path
        from ..data.files import sha256
        signature=(str(source),sha256(Path(source)/'summary.json'),self.flow.window.language)
        if self.signature==signature:return
        self.signature=signature;self.index=batch_result_index(source);self.record=None;self.data=None;self.canvas.hide()
        w=self.flow.window
        labels=[('性状','Trait'),('单位','Unit'),('评价范围','Evaluation'),('人数','n'),('Pearson','Pearson'),('RMSE','RMSE'),('MAE','MAE'),('状态','Status'),('秒','Seconds'),('来源/问题','Origin / issue')]
        rows=[]
        for record in self.index['records']:
            m=record['metrics'];fmt=lambda x:'—' if x is None else f'{x:.5g}' if isinstance(x,float) else str(x)
            evaluation=w.tr_pair(*{'pooled_oof':('合并 OOF','Pooled OOF'),'independent_test':('独立测试','Independent test'),'no_independent_test':('无独立测试','No independent test')}.get(record['evaluation'],('—','—')))
            status=w.tr_pair(*{'completed':('完成','Completed'),'failed':('失败','Failed'),'cancelled':('取消','Cancelled'),'not_run':('未运行','Not run'),'unreadable':('读取失败','Unreadable')}.get(record['status'],(record['status'],record['status'])))
            origin=w.tr_pair('沿用先前成功结果','Reused earlier success') if record.get('reused') else record['error']
            rows.append([record['trait'],record['unit'],evaluation,*[fmt(m.get(k)) for k in ('n','pearson','rmse','mae')],status,fmt(record['seconds']),origin])
        fill_table(self.flow.batch_table,[w.tr_pair(*label) for label in labels],rows)
        self.flow.batch_table.setMinimumHeight(180)
        self.note.setText(w.tr_pair('所有性状均列在上表。单击一项按需生成组合图；双击打开完整结果。不同性状不混合排名。','All traits are listed above. Click one to generate its combined plot; double-click for full details. Traits are not pooled or ranked together.'))

    def select(self,row):
        if not self.index or not 0<=row<len(self.index['records']):return
        record=self.index['records'][row];self.record=record;self.data=None;self.canvas.hide();w=self.flow.window
        if record['status']!='completed':self.note.setText(record['trait']+' · '+record['error']);return
        try:
            self.data=load_result_data(record['source'],target_id=record['target_id'],partition=record['partition'])
            self.fold.blockSignals(True);self.fold.clear()
            for fold in record['folds']:self.fold.addItem(str(fold),fold)
            self.fold.blockSignals(False);self.fold.setEnabled(bool(record['folds']))
            self.note.setText(record['trait']+' · '+w.tr_pair('曲线仅代表选中的一个模型；不平均各折曲线。','The learning curve represents one selected fit; fold curves are not averaged.'))
            self.draw()
        except (ValueError,OSError,KeyError) as error:self.note.setText(str(error))

    def draw(self,*_):
        if self.data is None:return
        try:
            render_combination(self.figure,self.data,self.flow.window.tr_pair('zh','en'),learning_fold=self.fold.currentData())
            self.canvas.show();self.canvas.draw_idle()
        except (ValueError,OSError,KeyError) as error:self.note.setText(str(error))

    def large_plot(self):
        if self.data is None:return
        dialog=QDialog(self);dialog.resize(1200,850);dialog.setWindowTitle(self.record['trait'])
        layout=QVBoxLayout(dialog);figure=Figure(figsize=(12,9),layout='constrained');canvas=FigureCanvasQTAgg(figure);layout.addWidget(canvas)
        render_combination(figure,self.data,self.flow.window.tr_pair('zh','en'),learning_fold=self.fold.currentData());canvas.draw();dialog.exec()

    def details(self):
        if self.data is None:return
        from .fit_details import show_fit_details
        show_fit_details(self.flow.window,self.record['source'])

    def export(self):
        if not self.index:return
        try:
            target=None
            if self.flow.export_target_scope.currentData()=='selected':
                row=self.flow.batch_table.currentRow()
                if row<0:raise ValueError(self.flow.window.tr_pair('先选中要导出的性状。','Select a trait to export first.'))
                target=self.index['records'][row]['id']
            self.flow.launch('export_plots',dict(source=self.index['source'],output=self.flow.export_destination('batch_report'),
                language=self.flow.window.tr_pair('zh','en'),target_id=target))
        except (OSError,ValueError) as error:self.flow.window.show_error(error)
