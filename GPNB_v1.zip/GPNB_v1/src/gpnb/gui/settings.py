import copy
import os

from PySide6.QtWidgets import QCheckBox, QComboBox, QFormLayout, QHBoxLayout, QLineEdit, QScrollArea, QSpinBox, QWidget, QFileDialog, QVBoxLayout, QGroupBox


# Values are stored directly in the existing RunSpec, with no GUI-only defaults.
FIELDS = [
    ("training", "device", "计算设备", "Device", ["cpu", "cuda"]),
    ("training", "optimizer", "优化器", "Optimizer", ["Adam", "SGD"]),
    ("training", "learning_rate", "学习率", "Learning rate", float),
    ("training", "weight_decay", "权重衰减", "Weight decay", float),
    ("training", "batch_size", "每批样本数", "Batch size", int),
    ("training", "epochs", "最大轮数", "Maximum epochs", int),
    ("training", "patience", "早停耐心轮数", "Early stopping patience", int),
    ("training", "min_delta", "早停最小改善", "Early stopping min delta", float),
    ("training", "seed", "训练随机种子", "Training seed", "seed"),
    ("training", "threads", "计算线程数", "Compute threads", int),
    ("training", "deterministic", "确定性计算", "Deterministic computation", bool),
    ("preprocessing", "all_missing", "训练内全缺失位点", "All-missing training markers", ["drop", "error", "zero_with_warning"]),
    ("preprocessing", "imputation", "缺失基因型处理", "Missing genotypes", ["mean", "none", "mode", "median", "knn"]),
    ("preprocessing", "standardize_genotypes", "标准化基因型", "Standardize genotypes", bool),
    ("preprocessing", "standardize_target", "标准化目标", "Standardize target", bool),
    ("preprocessing", "maf_min", "训练集最低 MAF（空白=不筛选）", "Minimum train MAF (blank = off)", "optional"),
    ("preprocessing", "marker_missing_max", "训练集最高位点缺失率（空白=不筛选）", "Maximum train marker missingness (blank = off)", "optional"),
    ("split", "ratios", "训练/验证/测试比例（逗号分隔）", "Train / validation / test fractions (comma separated)", "ratios"),
    ("split", "seed", "划分随机种子", "Split seed", "seed"),
    ("split", "reuse_manifest", "复用划分文件（可选）", "Reuse split file (optional)", "path"),
]
METHODS = ("fixed", "five_fold", "ten_fold", "leave_one_individual_out")
METHOD_TEXT = {
    "fixed": ("固定划分", "Fixed split"),
    "five_fold": ("五折交叉验证", "Five-fold cross-validation"),
    "ten_fold": ("十折交叉验证", "Ten-fold cross-validation"),
    "leave_one_individual_out": ("留一个体", "Leave one individual out"),
    "leave_one_genotype_group_out": ("旧版：留一同型组", "Legacy: leave one genotype group out"),
}


def available_threads():
    """Respect process affinity where available, with a portable fallback."""
    try:
        import psutil
        return max(1, len(psutil.Process().cpu_affinity()))
    except (ImportError, AttributeError, OSError):
        return max(1, os.cpu_count() or 1)


class RunSettings(QScrollArea):
    def __init__(self, window):
        super().__init__()
        self.window, self.controls = window, {}
        self.logical_cpus = available_threads()
        self._search_saved = None
        self.preview_changed = False
        self.setWidgetResizable(True)
        body = QWidget()
        layout=QVBoxLayout(body)
        forms={}
        for section,zh,en in (("split","验证方法与实际划分","Evaluation & split"),("training","优化与训练","Optimization"),("preprocessing","训练内预处理","Train-fitted preprocessing")):
            group=QGroupBox();window.bind_text(group,zh,en,"setTitle")
            layout.addWidget(group);forms[section]=QFormLayout(group)
        self.forms=forms
        form=forms["split"]
        self.form = form
        self.fixed_rows = []
        self.setWidget(body)
        for section, key, zh, en, kind in FIELDS:
            if isinstance(kind, list):
                widget = QComboBox()
                for value in kind:widget.addItem(value,value)
                widget.currentIndexChanged.connect(lambda index, s=section, k=key, w=widget: self.change(s, k, w.itemData(index)))
            elif kind is bool:
                widget = QCheckBox()
                widget.toggled.connect(lambda value, s=section, k=key: self.change(s, k, value))
            elif kind is int:
                widget = QSpinBox()
                widget.setRange(1, self.logical_cpus if key == "threads" else 2**31-1)
                widget.valueChanged.connect(lambda value, s=section, k=key: self.change(s, k, value))
            else:
                widget = QLineEdit()
                widget.textChanged.connect(lambda text, s=section, k=key, t=kind: self.parse(s, k, t, text))
            if kind != "path": widget.setMaximumWidth(320)
            widget.setObjectName(f"{section}_{key}")
            self.controls[section, key] = widget
            if kind == "path":
                row = QHBoxLayout()
                row.addWidget(widget)
                row.addWidget(window.button("选择", "Browse", self.choose_split))
                forms[section].addRow(window.label(zh, en), row)
                if section == "split": self.fixed_rows.append(row)
            else:
                from .form_helpers import help_button
                label_box=QWidget();label_layout=QHBoxLayout(label_box);label_layout.setContentsMargins(0,0,0,0)
                label_layout.addWidget(window.label(zh,en))
                label_layout.addWidget(help_button(window,(zh,en),parameter_help(section,key,zh,en)))
                forms[section].addRow(label_box, widget)
                if section == "split": self.fixed_rows.append(widget)
        self.knn_button=window.button("训练参考 KNN 参数…", "Training-reference KNN options…", self.open_knn)
        forms["preprocessing"].addRow(self.knn_button)
        from .objective_dialog import ObjectiveDialog
        forms["training"].addRow(window.button("损失与优化器高级设置…", "Objective and optimizer settings…", lambda: ObjectiveDialog(window).exec(), "objective_settings"))
        self.method = QComboBox()
        for method in METHODS:self.method.addItem(window.tr_pair(*METHOD_TEXT[method]),method)
        self.method.setObjectName("validation_method")
        form.insertRow(0,window.label("验证方法", "Evaluation method"), self.method)
        self.cv_enabled = QCheckBox()
        self.cv_enabled.setObjectName("cv_enabled")
        self.cv_enabled.toggled.connect(self.change_cv)
        form.addRow(self.cv_enabled)
        form.setRowVisible(self.cv_enabled, False)
        self.method.currentIndexChanged.connect(self.change_method)
        self.cv_seed = QLineEdit("5209")
        self.cv_seed.setObjectName("cv_seed")
        self.cv_seed.textChanged.connect(self.change_cv)
        form.addRow(window.label("外层/内层划分种子", "Outer/inner split seed"), self.cv_seed)
        self.cv_fraction = QLineEdit("0.2")
        self.cv_fraction.setObjectName("cv_validation_fraction")
        self.cv_fraction.textChanged.connect(self.change_cv)
        form.addRow(window.label("每折外层训练集中的验证比例", "Validation fraction within each outer training set"), self.cv_fraction)
        self.cv_reuse = QLineEdit()
        self.cv_reuse.setObjectName("cv_reuse_manifest")
        self.cv_reuse.textChanged.connect(self.change_cv)
        cv_path = QHBoxLayout()
        cv_path.addWidget(self.cv_reuse)
        cv_path.addWidget(window.button("选择", "Browse", self.choose_cv))
        form.addRow(window.label("复用 cv_plan.json", "Reuse cv_plan.json"), cv_path)
        self.loo_policy=QComboBox()
        self.loo_policy.addItem(window.tr_pair("全部 N−1 个体训练，固定轮数", "Train on all N−1 individuals, fixed epochs"), "full_training")
        self.loo_policy.addItem(window.tr_pair("旧版内部验证早停", "Legacy inner holdout for early stopping"), "inner_holdout")
        self.loo_policy.currentIndexChanged.connect(self.change_cv)
        form.addRow(window.label("留一训练协议", "Leave-out training policy"), self.loo_policy)
        self.cv_rows = [self.cv_seed, self.cv_fraction, cv_path, self.loo_policy]
        self.preview_button = window.button("生成 / 预览实际划分", "Generate / preview actual split", lambda:self.window.workflow.start_preview(), "preview_split")
        form.addRow(self.preview_button)
        from .data_widgets import table_widget
        self.preview_table = table_widget()
        self.preview_table.setVisible(False)
        form.addRow(self.preview_table)
        self.preview_note = window.label("尚未生成划分；有效标签数不等于实际测试样本量。", "No plan generated; eligible labels are not actual test counts.")
        self.preview_note.setWordWrap(True); form.addRow(self.preview_note)
        self.preview_fingerprint = None
        self.preview_summary = None
        self.auto_plan = None
        self.scale_ack = QCheckBox()
        self.scale_ack.setObjectName("leave_out_acknowledgement")
        self.scale_ack.toggled.connect(self.acknowledge_scale)
        form.addRow(self.scale_ack)
        self.policy_note = window.label("", "")
        self.policy_note.setWordWrap(True);form.addRow(self.policy_note)
        self.switch_policy_button = window.button("改用按个体 ID 划分并清除旧计划", "Switch to individual IDs and clear old plans", self.switch_to_individuals, "switch_individual_policy")
        form.addRow(self.switch_policy_button)
        self.update_method_ui()
        note = window.label(
            "可选变换仅在训练集拟合；早停只用验证集。留一法默认固定轮数训练全部 N−1 个体。\n"
            "预测返回输入表型量纲，不自动等于育种值。原始数据上游处理限制随结果保留。",
            "Optional transforms fit training rows only; early stopping uses validation only. Leave-one-out defaults to fixed-epoch training on all N−1 individuals.\nPredictions use the input phenotype scale, not automatically breeding values. Upstream limitations remain in the archive.")
        note.setWordWrap(True)
        form.addRow(note)
        forms["training"].addRow(window.button("配置预训练/联合/冻结阶段", "Configure pretrain / joint / frozen stages", self.open_stages))
        self.stages_summary=window.label("","")
        self.stages_summary.setWordWrap(True)
        forms["training"].addRow(self.stages_summary)
        self.threads_note = window.label("", "");self.threads_note.setWordWrap(True)
        forms["training"].addRow(self.threads_note)
        self.search_enabled = QCheckBox()
        self.search_enabled.setObjectName("search_enabled")
        window.bind_text(self.search_enabled,"启用参数搜索","Enable hyperparameter search")
        self.search_enabled.toggled.connect(self.toggle_search)
        forms["training"].addRow(self.search_enabled)
        self.search_button = window.button("配置随机 / 网格搜索", "Configure random / grid search", self.open_search, "configure_search")
        forms["training"].addRow(self.search_button)
        self.search_summary=window.label("", "");self.search_summary.setWordWrap(True)
        forms["training"].addRow(self.search_summary)
        self.validation = window.label("", "")
        self.validation.setWordWrap(True)
        form.addRow(self.validation)
        self.preprocessing_enabled = QCheckBox()
        self.preprocessing_enabled.setObjectName("preprocessing_enabled")
        window.bind_text(self.preprocessing_enabled,"启用基因型与目标预处理","Enable genotype and target preprocessing")
        self.preprocessing_enabled.toggled.connect(self.toggle_preprocessing)
        forms["preprocessing"].insertRow(0,self.preprocessing_enabled)
        preprocess_note=window.label("关闭时基因型不填补、不标准化、不筛位点，目标不标准化；格式转换和 ID 对齐仍执行。连续剂量缺失会被阻止，专用缺失类别仍保留。附加数值表按各自配置处理。",
            "When off: no genotype imputation, scaling or marker filtering, and no target scaling. Format conversion and ID alignment still run. Missing continuous dosage is rejected; explicit missing categories remain. Additional numeric tables keep their own preprocessing settings.")
        preprocess_note.setWordWrap(True);forms["preprocessing"].addRow(preprocess_note)
        self.preflight_button=window.button("运行前检查","Check before running",lambda:self.window.workflow.start_preflight(),"preflight")
        self.preflight_status=window.label("尚未完成运行前检查。","Run checks have not completed.")
        self.preflight_status.setWordWrap(True)
        layout.addWidget(self.preflight_button);layout.addWidget(self.preflight_status)
        from .preflight_ui import build_checklist
        build_checklist(self, layout)
        layout.addWidget(window.train_button)
        window.translation_callbacks.append(self.translate)
        self.translate()

    def choose_split(self):
        path, _ = QFileDialog.getOpenFileName(self, "split.json", str(self.window.root), "JSON (*.json)")
        if path:
            self.controls["split", "reuse_manifest"].setText(path)

    def open_stages(self):
        from .stages_dialog import StagesDialog
        self.stages_dialog=StagesDialog(self.window)
        self.stages_dialog.show()

    def open_search(self):
        from .search_dialog import SearchDialog
        self.search_dialog=SearchDialog(self.window)
        self.search_dialog.show()

    def toggle_search(self, enabled):
        run=self.window.document.value["run"]
        extensions=run.setdefault("extensions",{})
        if enabled:
            extensions["search"]=copy.deepcopy(self._search_saved or dict(method="random",seed=5209,max_trials=6,
                validation_fraction=.2,parameters={"training.learning_rate":[.0001,.001,.01],"training.batch_size":[16,32]}))
        else:
            self._search_saved=copy.deepcopy(extensions.pop("search",None))
        self.window.document.dirty=True
        self.update_auxiliary_ui();self.window.refresh()

    def toggle_preprocessing(self, enabled):
        options=self.window.document.value["run"]["preprocessing"]
        options["enabled"]=bool(enabled)
        if not enabled:
            self._knn_draft=options.pop("imputation_options",getattr(self,"_knn_draft",{}))
            options.update(imputation="none",standardize_genotypes=False,standardize_target=False,
                           maf_min=None,marker_missing_max=None)
        # Re-enabling reveals the explicit choices; it does not restore hidden transforms.
        self.window.document.dirty=True
        if self.window.feature_source=="prepared":self.window.invalidate_audit()
        self.populate();self.window.refresh()

    def switch_to_individuals(self):
        run=self.window.document.value["run"]
        run["split"].update(group_policy="individual_id",reuse_manifest=None)
        cv=run.get("extensions",{}).get("cross_validation")
        if cv:
            cv["reuse_manifest"]=None;cv.pop("approved_folds",None)
            if cv.get("method")=="leave_one_genotype_group_out":
                cv.update(method="leave_one_individual_out",training_policy="full_training")
        self.window.document.dirty=True
        if self.window.feature_source=="prepared":self.window.invalidate_audit()
        self.check_preview();self.populate();self.window.refresh()

    def choose_cv(self):
        path, _ = QFileDialog.getOpenFileName(self, "cv_plan.json", str(self.window.root), "JSON (*.json)")
        if path:
            self.cv_reuse.setText(path)

    def change_cv(self, *_):
        import copy
        extensions = copy.deepcopy(self.window.document.value["run"].get("extensions", {}))
        if self.cv_enabled.isChecked():
            if self.method.currentIndex() == 0:
                self.method.blockSignals(True); self.method.setCurrentIndex(1); self.method.blockSignals(False)
            try:
                seed = int(self.cv_seed.text())
            except ValueError:
                seed = self.cv_seed.text()
            try:
                fraction = float(self.cv_fraction.text())
            except ValueError:
                fraction = self.cv_fraction.text()
            old = extensions.get("cross_validation", {})
            method = self.method.currentData()
            extensions["cross_validation"] = dict(folds={"five_fold":5,"ten_fold":10}.get(method), seed=seed, validation_fraction=fraction,
                                                  reuse_manifest=self.cv_reuse.text() or None)
            if method == "ten_fold":extensions["cross_validation"]["method"]=method
            if not method.startswith("leave_one"):
                self.scale_ack.blockSignals(True);self.scale_ack.setChecked(False);self.scale_ack.blockSignals(False)
            if method.startswith("leave_one"):
                policy=self.loo_policy.currentData()
                unchanged=(old.get("method")==method and old.get("seed")==seed and old.get("validation_fraction")==fraction and old.get("training_policy","inner_holdout")==policy)
                extensions["cross_validation"].update(method=method, training_policy=policy, approved_folds=old.get("approved_folds") if unchanged else None)
                if not unchanged:
                    self.scale_ack.blockSignals(True);self.scale_ack.setChecked(False);self.scale_ack.blockSignals(False)
        else:
            extensions.pop("cross_validation", None)
            self.method.blockSignals(True); self.method.setCurrentIndex(0); self.method.blockSignals(False)
        if self.window.document.value["run"].get("extensions", {}) != extensions:
            self.window.document.value["run"]["extensions"] = extensions
            self.window.document.dirty = True
            if self.window.feature_source == "prepared":
                self.window.invalidate_audit()
        self.update_method_ui()
        self.window.refresh()

    def change_method(self, index):
        if (self.method.itemData(index) or "").startswith("leave_one"):
            self.loo_policy.blockSignals(True);self.loo_policy.setCurrentIndex(0);self.loo_policy.blockSignals(False)
        self.cv_enabled.blockSignals(True); self.cv_enabled.setChecked(bool(index)); self.cv_enabled.blockSignals(False)
        self.change_cv()

    def acknowledge_scale(self, checked):
        cv = self.window.document.value["run"].get("extensions", {}).get("cross_validation")
        if cv and cv.get("method", "five_fold").startswith("leave_one"):
            cv["approved_folds"] = self.preview_summary["models"] if checked and self.preview_summary else None
            self.window.document.dirty = True
            self.window.refresh()

    def update_method_ui(self):
        enabled=self.cv_enabled.isChecked()
        leave=(self.method.currentData() or "").startswith("leave_one")
        for row in self.fixed_rows:self.form.setRowVisible(row,not enabled)
        for row in self.cv_rows:self.form.setRowVisible(row,enabled)
        self.form.setRowVisible(self.loo_policy,leave)
        needs_validation=not leave or self.loo_policy.currentData()=='inner_holdout'
        self.form.setRowVisible(self.cv_fraction,enabled and needs_validation)
        for key in ('patience','min_delta'):
            self.forms['training'].setRowVisible(self.controls['training',key],needs_validation)
        self.form.setRowVisible(self.scale_ack, leave)
        self.scale_ack.setEnabled(self.preview_summary is not None)

    def fingerprint(self):
        import json,copy
        v=self.window.document.value
        split=copy.deepcopy(v["run"].get("extensions",{}).get("cross_validation") or v["run"]["split"])
        split.pop("reuse_manifest",None)
        split.pop("approved_folds",None)
        if split.get("method", "five_fold").startswith("leave_one"):
            split.setdefault("training_policy","inner_holdout")
        return json.dumps([v["data"],v.get("extensions",{}).get("multitask"),v.get("extensions",{}).get("trait_batch"),
                           v["run"]["split"]["group_policy"],split],sort_keys=True)

    def check_preview(self):
        if self.preview_fingerprint and self.fingerprint()!=self.preview_fingerprint:
            from .data_widgets import fill_table
            fill_table(self.preview_table,[],[])
            self.preview_table.hide()
            self.preview_changed=True
            self.preview_note.setText(self.window.tr_pair("数据或划分配置已变更，请重新生成。", "Data or split changed; generate again."))
            self.preview_fingerprint=None
            self.preview_summary=None
            self.scale_ack.blockSignals(True); self.scale_ack.setChecked(False); self.scale_ack.blockSignals(False)
            self.scale_ack.setEnabled(False)
            cv=self.window.document.value["run"].get("extensions",{}).get("cross_validation",{})
            cv.pop("approved_folds",None)
            # Only release a plan that this preview automatically attached.
            for section in (self.window.document.value["run"]["split"],self.window.document.value["run"].get("extensions",{}).get("cross_validation",{})):
                if section.get("reuse_manifest")==self.auto_plan:section["reuse_manifest"]=None
            for field in (self.controls["split","reuse_manifest"],self.cv_reuse):
                if field.text()==self.auto_plan:
                    field.blockSignals(True);field.clear();field.blockSignals(False)
            self.auto_plan=None
        self.update_auxiliary_ui()

    def show_preview(self, summary):
        from .data_widgets import fill_table
        self.preview_table.show()
        self.preview_fingerprint=self.fingerprint()
        self.preview_summary=summary
        self.preview_changed=False
        field=self.cv_reuse if summary["method"]!="fixed" else self.controls["split","reuse_manifest"]
        self.auto_plan=summary["plan"]
        field.setText(summary["plan"])
        self.scale_ack.setEnabled(True)
        self.render_preview()

    def parse(self, section, key, kind, text):
        try:
            if kind == "path":
                value = text or None
            elif kind == "ratios":
                value = [float(part.strip()) for part in text.split(",")]
            elif kind == "seed":
                value = int(text)
            else:
                value = None if kind == "optional" and not text.strip() else float(text)
        except ValueError:
            value = text  # Invalid draft stays invalid; never silently use an old value.
        self.change(section, key, value)

    def change(self, section, key, value):
        window = self.window
        if section=='preprocessing' and key=='imputation':
            options=window.document.value['run']['preprocessing']
            if value!='knn':self._knn_draft=options.pop('imputation_options',getattr(self,'_knn_draft',{}))
            elif getattr(self,'_knn_draft',None):options['imputation_options']=self._knn_draft
        window.document.change(("run", section, key), value)
        if section in ("preprocessing", "split") and window.feature_source == "prepared":
            window.invalidate_audit()
        window.refresh()

    def render_preview(self):
        from .data_widgets import fill_table
        w=self.window;summary=self.preview_summary
        if not summary:
            self.scale_ack.setText(w.tr_pair("先预览实际模型数", "Preview model count first"))
            self.preview_note.setText(w.tr_pair("数据或划分配置已变更，请重新生成。", "Data or split changed; generate again.") if self.preview_changed else
                w.tr_pair("尚未生成划分；有效标签数不等于实际测试样本量。", "No plan generated; eligible labels are not actual test counts."))
            return
        if summary.get('kind')=='batch_preview':
            self.scale_ack.setText(w.tr_pair(f"确认合计 {summary['models']} 次性状/外层训练",f"Acknowledge {summary['models']} total trait/outer fits"))
            rows=[]
            for task in summary['tasks']:
                for row in task.get('summary',{}).get('rows',[]):rows.append([task['trait'],row['fold'],row['partition'],row['individuals']])
            fill_table(self.preview_table,[w.tr_pair('性状','Trait'),'Fold','Partition','Individuals'],rows)
            self.preview_note.setText('\n'.join(t['trait']+': '+t['status']+' '+t.get('error','') for t in summary['tasks']))
            return
        n=summary.get("models",1)
        self.scale_ack.setText(w.tr_pair(f"确认 {n} 个外层折（搜索另加候选训练）",f"Acknowledge {n} outer fits; search adds trials"))
        columns=[w.tr_pair(*pair) for pair in (("折","Fold"),("集合","Partition"),("个体数","Individuals"),
            ("划分单位数","Splitting units"),("同型类别数（质控）","Genotype patterns (QC)"),("各目标有值数","Observed per target"))]
        labels={"train":w.tr_pair("训练","Train"),"validation":w.tr_pair("验证","Validation"),"test":w.tr_pair("测试","Test")}
        fill_table(self.preview_table,columns,[[r["fold"],labels[r["partition"]],r["individuals"],
            r.get("splitting_units",r["groups"]),r["groups"],str(r["observed"])] for r in summary["rows"]])
        self.preview_note.setText(w.tr_pair(f"有标签个体：{summary['eligible']}，排除：{summary['excluded']}。\n已绑定实际计划；训练复用并校验输入。",
            f"Eligible: {summary['eligible']}; excluded: {summary['excluded']}.\nTraining reuses this plan and verifies its inputs.")+"\n"+summary["plan"])

    def open_knn(self):
        from .imputation_dialog import ImputationDialog
        options=self.window.document.value['run']['preprocessing'].get('imputation_options',{})
        dialog=ImputationDialog(self.window,options)
        if dialog.exec():
            self.window.document.value['run']['preprocessing']['imputation_options']=dialog.value()
            self.window.document.dirty=True;self.window.refresh()

    def update_auxiliary_ui(self):
        w=self.window;run=w.document.value["run"]
        self.knn_button.setVisible(run['preprocessing'].get('imputation')=='knn')
        search=run.get("extensions",{}).get("search")
        self.search_enabled.blockSignals(True);self.search_enabled.setChecked(search is not None);self.search_enabled.blockSignals(False)
        self.search_button.setEnabled(search is not None)
        self.search_summary.setText(w.tr_pair(f"{search['method']}：每个外层折最多 {search['max_trials']} 个候选 + 1 次重训。",
            f"{search['method']}: up to {search['max_trials']} trials + one final fit per outer fold.") if search else
            w.tr_pair("参数搜索关闭。启用后可设置候选值；外层测试不参与选参。", "Search is off. Enable it to configure candidates; outer tests never select parameters."))
        stages=run["training"].get("stages")
        self.stages_summary.setText(w.tr_pair("阶段设置替代总轮数：", "Stages override global epochs: ")+", ".join(
            f"{i+1}: {s['mode']} ({s['epochs']})" for i,s in enumerate(stages)) if stages else
            w.tr_pair("单阶段回归", "Standard single-stage regression"))
        configured=run["training"]["threads"]
        thread_text=w.tr_pair(f"当前进程可用 {self.logical_cpus} 个逻辑 CPU。通常先试 1–4 线程；线程越多不一定越快。",
            f"This process can use {self.logical_cpus} logical CPUs. Start with 1–4 threads; more threads are not always faster.")
        if isinstance(configured,int) and configured>self.logical_cpus:
            thread_text+="\n"+w.tr_pair(f"项目保存了 {configured} 线程，超过本机上限；请重新选择后再运行。",
                f"This project requests {configured} threads, above this machine's limit; select an available value before running.")
        self.threads_note.setText(thread_text)
        legacy=run["split"]["group_policy"]=="genotype_equivalence"
        self.policy_note.setText(w.tr_pair("此项目保留旧版同型分组语义：完全相同的原始基因型必须在同一集合。不会自动改写旧计划。",
            "This project retains legacy grouping: identical raw genotypes stay in one partition. Existing plans are not reinterpreted.") if legacy else
            w.tr_pair("按唯一个体 ID 划分。同型但不同 ID 的个体仍分别参与；同型报告仅用于质控，不代表重复个体或真实家系。",
                "Split by unique individual IDs. Distinct IDs remain separate even with identical genotypes; the pattern report is QC, not inferred duplicate individuals or pedigree."))
        self.switch_policy_button.setVisible(legacy)
        enabled=run["preprocessing"].get("enabled",True)
        self.preprocessing_enabled.blockSignals(True);self.preprocessing_enabled.setChecked(enabled);self.preprocessing_enabled.blockSignals(False)
        for (section,key),widget in self.controls.items():
            if section=="preprocessing":widget.setEnabled(enabled)

    def translate(self):
        w=self.window
        self.method.blockSignals(True)
        for i in range(self.method.count()):self.method.setItemText(i,w.tr_pair(*METHOD_TEXT[self.method.itemData(i)]))
        self.method.blockSignals(False)
        self.loo_policy.blockSignals(True)
        self.loo_policy.setItemText(0,w.tr_pair("全部 N−1 个体训练，固定轮数", "Train on all N−1 individuals, fixed epochs"))
        self.loo_policy.setItemText(1,w.tr_pair("旧版内部验证早停", "Legacy inner holdout for early stopping"))
        self.loo_policy.blockSignals(False)
        all_missing=self.controls['preprocessing','all_missing']
        all_missing.blockSignals(True)
        for key,zh,en in [('drop','剔除该位点','Drop marker'),('error','停止并报告','Stop with an error'),('zero_with_warning','旧模型：填0并警告','Legacy: zero with warning')]:all_missing.setItemText(all_missing.findData(key),w.tr_pair(zh,en))
        all_missing.blockSignals(False)
        imputation=self.controls["preprocessing","imputation"]
        imputation.blockSignals(True)
        imputation.setItemText(0,w.tr_pair("训练集均值填补", "Training-set mean imputation"))
        imputation.setItemText(1,w.tr_pair("不填补", "No imputation"))
        for key,zh,en in (("mode","训练位点众数","Training marker mode"),("median","训练位点中位数","Training marker median"),("knn","训练参考 KNN","Training-reference KNN")):
            imputation.setItemText(imputation.findData(key),w.tr_pair(zh,en))
        imputation.blockSignals(False)
        self.update_auxiliary_ui();self.render_preview()

    def populate(self):
        project_id=self.window.document.value["project_id"]
        if getattr(self,"_settings_project_id",None)!=project_id:
            self._search_saved=None;self._settings_project_id=project_id
        for section, key, _, _, kind in FIELDS:
            widget = self.controls[section, key]
            value = self.window.document.value["run"][section][key]
            widget.blockSignals(True)
            if isinstance(widget, QComboBox):
                widget.setCurrentIndex(widget.findData(value))
            elif isinstance(widget, QCheckBox):
                widget.setChecked(value)
            elif isinstance(widget, QSpinBox):
                widget.setValue(value)
            else:
                widget.setText(", ".join(map(str, value)) if kind == "ratios" else "" if value is None else str(value))
            widget.blockSignals(False)
        cv = self.window.document.value["run"].get("extensions", {}).get("cross_validation")
        self.loo_policy.blockSignals(True)
        self.loo_policy.setCurrentIndex(0 if (cv or {}).get('training_policy')=='full_training' or cv is None else 1)
        self.loo_policy.blockSignals(False)
        self.method.blockSignals(True)
        method=cv.get("method","five_fold") if cv else "fixed"
        legacy_index=self.method.findData("leave_one_genotype_group_out")
        if method=="leave_one_genotype_group_out" and legacy_index<0:
            self.method.addItem(self.window.tr_pair(*METHOD_TEXT[method]),method)
        elif method!="leave_one_genotype_group_out" and legacy_index>=0:
            self.method.removeItem(legacy_index)
        self.method.setCurrentIndex(self.method.findData(method))
        self.method.blockSignals(False)
        self.scale_ack.blockSignals(True); self.scale_ack.setChecked(bool((cv or {}).get("approved_folds"))); self.scale_ack.blockSignals(False)
        for widget, value in ((self.cv_enabled, cv is not None),
                              (self.cv_seed, (cv or {}).get("seed", 5209)),
                              (self.cv_fraction, (cv or {}).get("validation_fraction", .2)),
                              (self.cv_reuse, (cv or {}).get("reuse_manifest") or "")):
            widget.blockSignals(True)
            widget.setChecked(value) if isinstance(widget, QCheckBox) else widget.setText(str(value))
            widget.blockSignals(False)
        self.update_method_ui()
        self.update_auxiliary_ui()


def parameter_help(section,key,zh,en):
    notes={
      'learning_rate':('每次更新的步长。先比较少量候选，例如 0.0001、0.001、0.01；只用训练内验证选择。','Step size for each update. Compare a small set such as 0.0001, 0.001, 0.01 using inner validation only.'),
      'batch_size':('每次更新读取的人数。显存不足可减小，例如从 64 改为 32；结果可能变化。','Individuals per update. Reduce it for memory pressure, e.g. 64 to 32; training may change.'),
      'imputation':('只在训练数据拟合，随后冻结用于验证、测试和新个体。均值/中位数可能为小数；众数并列采用较小编码。KNN 保存训练参考。','Fit on training data, then freeze for validation, test and new individuals. Mean/median may be fractional; mode ties choose the smaller code. KNN saves training references.'),
      'standardize_genotypes':('按训练内填补后的中心和尺度转换特征，其他集合复用。类别输入使用专用规则。','Transform using the center and scale of imputed training features. Other sets reuse them; categorical inputs have separate rules.'),
      'standardize_target':('只使用训练标签拟合尺度；输出还原到表型原单位。多性状联合训练应考虑单位与权重。','Fit target scale on training labels only; predictions return to original units. Joint targets require considered scales and weights.'),
      'patience':('验证损失连续没有足够改善的轮数，达到后停止。例如 20；固定轮数协议不使用早停。','Stop after this many epochs without sufficient validation improvement, e.g. 20. Fixed-epoch protocols do not use early stopping.'),
      'min_delta':('验证损失至少改善此值才更新最佳轮次，单位为当前训练目标。0 表示任何改善。','Minimum validation-objective improvement to update the best epoch; 0 accepts any improvement.'),
      'threads':('CPU 计算线程数，先尝试 1–4；越多不保证越快。','CPU compute threads. Start with 1–4; more is not always faster.'),
      'ratios':('固定划分的训练、验证、测试比例，总和为 1。例如 0.7, 0.15, 0.15；测试不参与调参。','Fixed train, validation and test fractions must sum to 1, e.g. 0.7, 0.15, 0.15. Tests never select parameters.'),
      'maf_min':('按训练位点频率筛选；留空关闭。例如 0.01。每折保留位点可能不同。','Filter by training marker frequencies; blank disables it, e.g. 0.01. Retained markers may differ by fold.'),
      'marker_missing_max':('只按训练个体统计位点缺失率；留空关闭。例如 0.05。','Filter by marker missingness among training individuals; blank disables it, e.g. 0.05.'),
    }
    return notes.get(key,(zh+'：实际值随项目和实验保存；修改后重新运行检查。',en+': the effective value is saved in the project and experiment; recheck after changing it.'))
