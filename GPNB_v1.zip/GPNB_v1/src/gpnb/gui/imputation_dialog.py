"""Frozen-reference KNN options; no additional runtime dependencies."""
from PySide6.QtWidgets import QDialog,QFormLayout,QSpinBox,QComboBox,QDialogButtonBox,QLabel

class ImputationDialog(QDialog):
    def __init__(self,window,options=None):
        super().__init__(window);self.window=window
        self.setWindowTitle(window.tr_pair("训练参考 KNN 参数","Training-reference KNN options"))
        self.original=dict(options or {});self.controls={};form=QFormLayout(self)
        for key,zh,en,default,limit in (("k","邻居数","Neighbors",5,1000),("min_common","最少共同观测位点","Minimum jointly observed markers",1,1000000)):
            widget=QSpinBox();widget.setRange(1,limit);widget.setValue(self.original.get(key,default));self.controls[key]=widget;form.addRow(window.tr_pair(zh,en),widget)
        for key,labels,default in (("weights",[("等权","Uniform","uniform"),("反距离","Inverse distance","distance")],"uniform"),("output",[("连续均值","Continuous mean","mean"),("硬调用投票","Hard-call vote","mode")],"mean")):
            widget=QComboBox()
            for zh,en,value in labels:widget.addItem(window.tr_pair(zh,en),value)
            widget.setCurrentIndex(widget.findData(self.original.get(key,default)));self.controls[key]=widget;form.addRow(key,widget)
        for key,zh,en,default in (("max_reference_samples","最大参考人数","Maximum references",20000),("max_reference_bytes","参考内存上限(bytes)","Reference budget (bytes)",268435456),("max_working_bytes","工作内存上限(bytes)","Working budget (bytes)",67108864)):
            widget=QSpinBox();widget.setRange(1,2147483647);widget.setValue(self.original.get(key,default));self.controls[key]=widget;form.addRow(window.tr_pair(zh,en),widget)
        note=QLabel(window.tr_pair("仅冻结训练参考；查询不互作参考。无邻居使用位点后备值，具体规则随模型保存。","Only frozen training references are used. Queries never become references. Per-marker fallback rules are saved with the model."));note.setWordWrap(True);form.addRow(note)
        buttons=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel);buttons.accepted.connect(self.accept);buttons.rejected.connect(self.reject);form.addRow(buttons)
    def value(self):
        return {**self.original,**{key:widget.currentData() if isinstance(widget,QComboBox) else widget.value() for key,widget in self.controls.items()}}
