"""Protected GUI output paths, independent of Qt and model migrations."""
from pathlib import Path
import uuid

from ..data.files import protect_inputs, write_json


def ensure_output_directory(path, inputs=()):
    destination = Path(path).resolve()
    inputs = [Path(item).resolve() for item in inputs]
    protect_inputs(destination, inputs)
    destination.mkdir(parents=True, exist_ok=True)
    probe = destination / (".write_check_" + uuid.uuid4().hex)
    created = False
    try:
        with probe.open("x", encoding="utf-8") as stream:
            created = True
            stream.write("GPNB_v1 output permission check")
    finally:
        if created and probe.is_file():
            probe.unlink()
    return destination


def persist_audit_failure(destination, error, *, inputs=(), project=None):
    """Fill an early-failure gap without replacing backend evidence."""
    destination = ensure_output_directory(destination, inputs)
    reports = {"failure.json": {"ok": False, "stage": "gui_audit", "error": error}}
    if project is not None:
        reports["project_snapshot.json"] = project
    for name, value in reports.items():
        target = destination / name
        protect_inputs(target, inputs)
        protect_inputs(target.with_name(target.name + ".partial"), inputs)
        if not target.exists():
            write_json(target, value)
    return destination
