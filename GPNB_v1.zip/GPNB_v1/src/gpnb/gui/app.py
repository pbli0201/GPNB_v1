from __future__ import annotations

import argparse
from pathlib import Path

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication

from ..data.files import protect_inputs, write_json
from ..paths import configure_local_paths
from .window import MainWindow


def main(argv=None):
    parser = argparse.ArgumentParser(description="GPNB_v1 desktop project and MLP editor")
    parser.add_argument("--project", type=Path)
    parser.add_argument("--lang", choices=["zh_CN", "en_US"])
    parser.add_argument("--smoke-ms", type=int, help="Validation only: close automatically after this many milliseconds")
    parser.add_argument("--screenshot", type=Path, help="Validation only: save a new PNG of this application window")
    parser.add_argument("--report", type=Path, help="Validation only: save window state to a new JSON")
    args = parser.parse_args(argv)
    if args.smoke_ms is not None and args.smoke_ms < 100:
        parser.error("--smoke-ms must be at least 100")
    configure_local_paths()
    for path in (args.screenshot, args.report):
        if path:
            protect_inputs(path.resolve(), [args.project.resolve()] if args.project else [])
            if path.exists():
                parser.error(f"refusing to overwrite {path}")
            path.parent.mkdir(parents=True, exist_ok=True)
    app = QApplication.instance() or QApplication([])
    app.setApplicationName("GPNB_v1")
    window = MainWindow(args.project)
    if args.lang:
        window.set_language(args.lang)
    window.show()
    failed = []

    def finish():
        try:
            if args.screenshot and not window.grab().save(str(args.screenshot)):
                raise RuntimeError("cannot save screenshot")
            if args.report:
                write_json(args.report, {"ok": True, "window_visible": window.isVisible(),
                           "qt_platform": app.platformName(), "language": window.language,
                           "project": str(window.document.path) if window.document.path else None,
                           "layers": len(window.document.value["model"]["layers"]),
                           "training_enabled": window.train_button.isEnabled(),
                           "scope": "real editor startup; no training performed"})
        except Exception as error:
            failed.append(str(error))
        finally:
            window.close()
            app.quit()
    if args.smoke_ms is not None:
        QTimer.singleShot(args.smoke_ms, finish)
    result = app.exec()
    if failed:
        print("\n".join(failed))
        return 2
    return result


if __name__ == "__main__":
    raise SystemExit(main())
