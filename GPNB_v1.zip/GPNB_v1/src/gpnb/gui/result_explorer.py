"""Language-aware result views; CV training results always select one fit."""
from pathlib import Path

from PySide6.QtWidgets import QWidget, QVBoxLayout, QFormLayout, QComboBox, QLabel, QTableWidgetItem, QGridLayout, QGroupBox, QDoubleSpinBox, QCheckBox
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
from matplotlib.figure import Figure

from ..results import load_result_data, result_root, result_targets, render_plot, selected_caption, TIMING_FIELDS, _verify_artifacts
from ..data.files import read_json
from .data_widgets import table_widget
from .result_text import metric_line, fold_summary_line


class ResultExplorer(QWidget):
    def __init__(self, flow):
        super().__init__()
        self.flow, self.window, self.source, self.data = flow, flow.window, None, None
        w = self.window
        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.target = QComboBox(); self.target.setObjectName("result_target")
        self.fold = QComboBox(); self.fold.setObjectName("result_fold")
        self.partition = QComboBox(); self.partition.setObjectName("result_partition")
        self.plot = QComboBox(); self.plot.setObjectName("result_plot")
        form.addRow(w.label("性状 / 目标", "Trait / target"), self.target)
        form.addRow(w.label("评价来源", "Evaluation source"), self.fold)
        form.addRow(w.label("数据分区", "Partition"), self.partition)
        self.plot.hide()  # Compatibility selector; the standard view shows all plots together.
        layout.addLayout(form)
        from .fit_details import show_fit_details
        layout.addWidget(w.button('训练 / 搜索详情','Training / search details',lambda:show_fit_details(w,self.source) if self.source else None,'fit_details'))
        self.caption = QLabel(); self.caption.setWordWrap(True); layout.addWidget(self.caption)
        self.more_metrics=QGroupBox(w.tr_pair('更多指标与定义','More metrics and definitions'));self.more_metrics.setCheckable(True);self.more_metrics.setChecked(False)
        more_layout=QVBoxLayout(self.more_metrics);self.metrics_table=table_widget();self.metrics_table.setMaximumHeight(250);more_layout.addWidget(self.metrics_table);self.metrics_table.hide();self.more_metrics.toggled.connect(self.metrics_table.setVisible);layout.addWidget(self.more_metrics)
        self.selection_group=QGroupBox(w.tr_pair('描述性选择排序（可选）','Descriptive selection ranking (optional)'));self.selection_group.setCheckable(True);self.selection_group.setChecked(False)
        selection_layout=QVBoxLayout(self.selection_group);self.selection_body=QWidget();selection_form=QFormLayout(self.selection_body);selection_layout.addWidget(self.selection_body);self.selection_body.hide();self.selection_group.toggled.connect(self.selection_body.setVisible)
        self.selection_direction=QComboBox();self.selection_direction.addItem(w.tr_pair('性状越大越好','Larger is preferred'),'descending');self.selection_direction.addItem(w.tr_pair('性状越小越好','Smaller is preferred'),'ascending')
        self.selection_fraction=QDoubleSpinBox();self.selection_fraction.setRange(.1,100);self.selection_fraction.setValue(10);self.selection_fraction.setSuffix(' %');self.selection_fraction.setMaximumWidth(160)
        selection_form.addRow(w.label('选择方向','Selection direction'),self.selection_direction);selection_form.addRow(w.label('选留比例','Selected fraction'),self.selection_fraction)
        self.selection_note=QLabel();self.selection_note.setWordWrap(True);selection_form.addRow(self.selection_note)
        self.selection_table=table_widget();self.selection_table.setMaximumHeight(180);selection_form.addRow(self.selection_table)
        layout.addWidget(self.selection_group)
        for signal in (self.selection_group.toggled,self.selection_direction.currentIndexChanged,self.selection_fraction.valueChanged):signal.connect(self.update_selection)
        self.plot_grid=QGridLayout();layout.addLayout(self.plot_grid)
        self.figures={};self.canvases={}
        for name in ('scatter','error','learning','folds'):
            figure=Figure(figsize=(5,3.5),layout='constrained');canvas=FigureCanvasQTAgg(figure);canvas.setMinimumHeight(300)
            self.figures[name]=figure;self.canvases[name]=canvas
        self.figure=self.figures['scatter'];self.canvas=self.canvases['scatter']
        self.arrange_plots()
        self.timing_note = QLabel(); self.timing_note.setWordWrap(True); layout.addWidget(self.timing_note)
        self.timing = table_widget(); self.timing.setMaximumHeight(200); layout.addWidget(self.timing)
        self.export_button = w.button("导出结果", "Export results", self.export, "export_result_plots")
        flow.plot_export_button = self.export_button
        self.export_button.hide()  # Placed in the parent Save section when embedded.
        for combo in (self.target, self.fold, self.partition, self.plot):
            combo.currentIndexChanged.connect(self.changed)
        self.hide()

    def arrange_plots(self):
        columns=2 if self.width()>=950 else 1
        for i,canvas in enumerate(self.canvases.values()):self.plot_grid.addWidget(canvas,i//columns,i%columns)

    def resizeEvent(self,event):
        super().resizeEvent(event)
        if hasattr(self,'canvases'):self.arrange_plots()

    def load(self, source, *, reset=False):
        source = Path(source).resolve()
        if source != self.source:
            reset = True
        self.source = source
        root, summary = result_root(source)
        old = {} if reset else {key: getattr(self, key).currentData() for key in ("target", "fold", "partition", "plot")}
        t = self.window.tr_pair
        for name in ("target", "fold", "partition", "plot"):
            getattr(self, name).blockSignals(True); getattr(self, name).clear()
        for target in result_targets(summary):
            unit = f" ({target['unit']})" if target.get("unit") else ""
            self.target.addItem(target["id"] + " · " + target["trait"] + unit, target["id"])
        if summary["kind"] == "cross_validation":
            self.fold.addItem(t("合并 OOF（每个体一次外测）", "Pooled OOF (one outer test per individual)"), None)
            for member in summary["fold_runs"]:
                self.fold.addItem(t(f"折 {member['fold']}", f"Fold {member['fold']}"), member["fold"])
        elif summary.get('evaluation_status') == 'no_independent_test_set':
            self.fold.addItem(t('最终模型 / 内部选择（无独立测试）', 'Final model / internal selection (no independent test)'), None)
        else:
            self.fold.addItem(t("固定划分 / 当前模型", "Fixed split / current model"), None)
        available = {'train', 'validation', 'test'}
        if summary.get('evaluation_status') == 'no_independent_test_set':
            report = root / 'prepared/report.json'
            if report.is_file():
                _verify_artifacts(root, [report])
                counts = read_json(report)['split']['counts']
                available = {part for part in ('train', 'validation') if counts.get(part, 0) > 0}
            else:
                available = {'train', 'validation'} if summary.get('best_validation_mse') is not None else {'train'}
        for key, zh, en in (("test", "外样本测试 / OOF", "Out-of-sample test / OOF"),
                            ("validation", "验证（参与选择）", "Validation (used for selection)"),
                            ("train", "训练拟合（非外样本）", "Training fit (not out of sample)")):
            if key in available:
                self.partition.addItem(t(zh, en), key)
        for key, zh, en in (("scatter", "观测—预测", "Observed vs predicted"), ("error", "逐个体误差分布", "Individual error distribution"),
                            ("folds", "逐折 Pearson", "Fold Pearson"), ("learning", "训练 / 验证曲线", "Training / validation curve")):
            self.plot.addItem(t(zh, en), key)
        for name, value in old.items():
            combo = getattr(self, name)
            index = combo.findData(value)
            if index >= 0:
                combo.setCurrentIndex(index)
        for name in ("target", "fold", "partition", "plot"):
            getattr(self, name).blockSignals(False)
        self.show()
        self.changed()

    def changed(self, *_):
        if self.source is None or not self.target.count():
            return
        try:
            if self.partition.currentData() != "test" and self.fold.count() > 1 and self.fold.currentData() is None:
                self.fold.blockSignals(True); self.fold.setCurrentIndex(1); self.fold.blockSignals(False)
            self.data = load_result_data(self.source, target_id=self.target.currentData(),
                                         partition=self.partition.currentData(), fold=self.fold.currentData())
            w = self.window
            language = "zh" if w.tr_pair("zh", "en") == "zh" else "en"
            text = selected_caption(self.data, language) + "\n" + metric_line(w, self.data["metrics"])
            if self.data["cv"]:
                text += "\n" + fold_summary_line(w, self.data["fold_pearson"])
            self.caption.setText(text)
            for name,figure in self.figures.items():
                render_plot(figure,self.data,name,language);self.canvases[name].draw()
            self.canvases['folds'].setVisible(self.data['cv'])
            from .data_widgets import fill_table
            if hasattr(self.flow,'table'):
                rows=self.data['rows'];headers=list(rows[0]) if rows else ['FID','IID','observed','predicted']
                fill_table(self.flow.table,headers,[[row.get(key,'') for key in headers] for row in rows[:2000]])
            if hasattr(self.flow,'overview_table'):
                fill_details(self.flow.overview_table,self.data.get('overview',{}),w)
                fill_details(self.flow.configuration_table,self.data.get('configuration',{}),w)
            metric_rows=[];metrics=self.data['metrics'];unit=self.data['target'].get('unit','—')
            for key,zh,en,definition,reason in (
                ('spearman','Spearman 排序相关','Spearman rank correlation','average tied ranks','spearman_reason'),
                ('r2','R² 决定系数','R² coefficient of determination','1 - SSE / SST; may be negative','r2_reason'),
                ('bias','平均误差 Bias','Mean error / Bias','mean(predicted - observed); '+unit,None),
                ('calibration_intercept','校准截距 a','Calibration intercept a','observed = a + b * predicted; '+unit,'calibration_reason'),
                ('calibration_slope','校准斜率 b','Calibration slope b','observed = a + b * predicted','calibration_reason'),
                ('baseline_improvement','相对训练均值基线改善','Improvement over training-mean baseline','1 - model MSE / training-mean baseline MSE',None)):
                value=metrics.get(key);why=metrics.get(reason) if reason else None
                metric_rows.append([w.tr_pair(zh,en),'—' if value is None else f'{value:.6g}',w.tr_pair(*METRIC_DEFINITIONS.get(key,(definition,definition))),reason_text(w,why) if why else (w.tr_pair('未记录或分母为零','Not recorded or denominator is zero') if value is None else '')])
            fill_table(self.metrics_table,[w.tr_pair('指标','Metric'),w.tr_pair('值','Value'),w.tr_pair('定义/单位','Definition / unit'),w.tr_pair('不可计算原因','Unavailable reason')],metric_rows)
            timing = self.data["timing"]
            self.timing.clear(); self.timing.setRowCount(len(TIMING_FIELDS)); self.timing.setColumnCount(2)
            self.timing.setHorizontalHeaderLabels([w.tr_pair("阶段", "Stage"), w.tr_pair("实测秒数", "Measured seconds")])
            for row, (key, zh, en) in enumerate(TIMING_FIELDS):
                self.timing.setItem(row, 0, QTableWidgetItem(w.tr_pair(zh, en)))
                value = timing.get(key)
                self.timing.setItem(row, 1, QTableWidgetItem("—" if value is None else f"{value:.3f}"))
            self.timing.resizeColumnsToContents()
            self.timing_note.setText(w.tr_pair("多性状共享模型显示联合实测耗时，不向各性状平均分摊。未记录的阶段显示 —。",
                "Shared multi-target models show joint measured time, never an invented per-trait allocation. Unrecorded stages show —."))
            self.update_selection()
            self.export_button.setEnabled(not self.flow.jobs.busy)
        except (OSError, ValueError, KeyError) as error:
            self.caption.setText(str(error)); self.export_button.setEnabled(False)

    def selection_options(self):
        if not self.selection_group.isChecked():return None
        return dict(direction=self.selection_direction.currentData(),fraction=self.selection_fraction.value()/100)

    def update_selection(self,*_):
        if self.data is None or not self.selection_group.isChecked():return
        from ..training.metrics import selection_summary
        from .data_widgets import fill_table
        w=self.window
        result=selection_summary(self.data['observed'],self.data['predicted'],**self.selection_options())
        paired=[row for row in self.data['rows'] if row.get('observed') not in ('',None)]
        self.selection_note.setText(w.tr_pair(f"有效评分池 {result['n']} 人，向上取整保留 {result['k']} 人，观测表型前列重合 {result['overlap']} 人。并列按输入顺序。仅描述此评价池，不代表真实育种值；不用于选参。",f"Scoring pool: {result['n']}; ceil-rounded selection: {result['k']}; overlap with observed-phenotype ranking: {result['overlap']}. Ties preserve input order. Descriptive only, not true breeding values or model selection."))
        fill_table(self.selection_table,['FID','IID',w.tr_pair('预测','Predicted'),w.tr_pair('观测','Observed')],[[paired[i].get(key,'') for key in ('FID','IID','predicted','observed')] for i in result['predicted_indices'][:2000]])

    def export(self):
        if getattr(self.flow,'displayed_result',{}).get('summary',{}).get('kind')=='trait_batch':
            self.flow.batch_explorer.export();return
        if self.data is None:
            return
        try:
            output = self.flow.export_destination('plot_export') if hasattr(self.flow,'export_destination') else self.flow.new_output(self.flow.predict_fields['output'].text(),'plot_export')
            target=self.target.currentData() if hasattr(self.flow,'export_target_scope') and self.flow.export_target_scope.currentData()=='selected' else None
            self.flow.launch("export_plots", dict(source=str(self.source), output=output,
                language=self.window.tr_pair("zh", "en"), target_id=target, partition=self.partition.currentData(),
                fold=self.fold.currentData(),selection=self.selection_options()))
        except (OSError, ValueError) as error:
            self.window.show_error(error)


METRIC_DEFINITIONS={
 'spearman':('排序相关；并列取平均名次','Rank correlation; ties use average ranks'),
 'r2':('1−SSE/SST，可为负；不是 Pearson²','1−SSE/SST; may be negative; not Pearson²'),
 'bias':('mean(预测−观测)，原性状单位；正值为高估','mean(predicted−observed), original units; positive means overestimation'),
 'calibration_intercept':('拟合 观测=a+b×预测；a为原性状单位','Fit observed=a+b×predicted; a uses original units'),
 'calibration_slope':('拟合 观测=a+b×预测；诊断，不自动校正','Fit observed=a+b×predicted; diagnostic, no automatic correction'),
 'baseline_improvement':('1−模型MSE/训练均值基线MSE；不是遗传力或可靠度','1−model MSE / training-mean baseline MSE; not heritability or reliability')}


def reason_text(w,reason):
    return w.tr_pair(*{'no_samples':('无有效观测','No finite observations'),'fewer_than_two_samples':('少于两个个体','Fewer than two individuals'),'constant_observed':('观测值恒定','Constant observations'),'constant_prediction':('预测值恒定','Constant predictions'),'numerical_overflow':('数值溢出','Numerical overflow')}.get(reason,(str(reason),str(reason))))


def fill_details(table,data,w):
    from .data_widgets import fill_table
    labels={'samples':('个体数','Individuals'),'raw_markers':('原始位点数','Raw markers'),'retained_markers':('保留位点数','Retained markers'),'targets':('性状','Targets'),'missing':('缺失数','Missing'),'mean':('均值','Mean'),'std':('标准差','Standard deviation'),'min':('最小值','Minimum'),'max':('最大值','Maximum'),'unit':('单位','Unit'),'count':('数量','Count'),'split_counts':('划分人数','Partition counts'),'best_epoch':('最佳/选定轮次','Best / selected epoch'),'stop_reason':('停止原因','Stop reason'),'training':('训练','Training'),'preprocessing':('预处理','Preprocessing'),'model':('模型','Model'),'run':('运行设置','Run settings'),'split':('划分','Split'),'learning_rate':('学习率','Learning rate'),'batch_size':('批大小','Batch size'),'optimizer':('优化器','Optimizer'),'epochs':('轮数上限','Epoch limit'),'loss':('损失','Loss'),'imputation':('填补','Imputation'),'by_fold':('逐折','By fold'),'scope':('范围','Scope'),'method':('方法','Method')}
    labels.update({'model_input_features':('模型输入特征数','Model input features'),'partition_counts':('划分人数','Partition counts'),'training_marker_missing_fraction_mean':('训练位点平均缺失率','Mean training-marker missingness'),'observed':('有效观测数','Observed values'),'sd':('标准差','Standard deviation'),'minimum':('最小值','Minimum'),'maximum':('最大值','Maximum'),'sd_ddof':('标准差自由度扣除','SD ddof'),'train':('训练','Training'),'validation':('验证','Validation'),'test':('测试','Test'),'name':('名称','Name'),'layers':('网络层','Layers'),'params':('参数','Parameters'),'type':('类型','Type'),'out_features':('输出单元数','Output units'),'bias':('偏置','Bias'),'seed':('随机种子','Random seed'),'threads':('线程数','Threads'),'device':('设备','Device'),'weight_decay':('权重衰减','Weight decay'),'momentum':('动量','Momentum'),'scheduler':('学习率调度','Learning-rate scheduler'),'gamma':('gamma','gamma'),'patience':('早停耐心轮数','Early-stopping patience'),'min_delta':('最小改善量','Minimum improvement'),'all_missing':('训练内全缺失位点','All-missing training markers'),'standardize_genotypes':('标准化基因型','Standardize genotypes'),'standardize_target':('标准化目标','Standardize target'),'ratios':('训练/验证/测试比例','Train/validation/test fractions'),'group_policy':('划分单位规则','Split-unit policy'),'fit_scope':('拟合范围','Fitting scope'),'maf_min':('训练最低MAF','Minimum training MAF'),'marker_missing_max':('训练最高位点缺失率','Maximum training marker missingness'),'selection_mode':('轮次选择规则','Epoch selection mode')})
    rows=[]
    def flatten(value,path=''):
        if isinstance(value,dict):
            for key,item in value.items():flatten(item,(path+' / ' if path else '')+w.tr_pair(*labels.get(key,(key,key))))
        elif isinstance(value,list) and value and isinstance(value[0],dict):
            for i,item in enumerate(value):flatten(item,path+f' [{i+1}]')
        else:
            import json
            display=w.tr_pair('未记录','Not recorded') if value is None else json.dumps(value,ensure_ascii=False) if isinstance(value,list) else str(value)
            if display=='Descriptive matched cohort; training marker statistics fitted on training rows only':display=w.tr_pair('匹配队列描述统计；位点处理状态仅由训练个体拟合','Descriptive matched cohort; marker processing is fitted on training individuals only')
            if display=='Select a fold for its actual settings':display=w.tr_pair('选择一折查看实际配置；每折可能不同','Select a fold for actual settings; folds may differ')
            rows.append([path,display])
    flatten(data)
    if not rows:rows=[[w.tr_pair('记录','Record'),w.tr_pair('该项未记录','Not recorded')]]
    fill_table(table,[w.tr_pair('项目','Item'),w.tr_pair('实际记录','Saved value')],rows)
