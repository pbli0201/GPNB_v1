"""Small navigable preflight checklist; no scientific state lives in widgets."""
from PySide6.QtWidgets import QTableWidgetItem

CHECKS = {
    'inputs': ('输入文件与写入目录', 'Input files and writable output', 0),
    'device': ('设备与线程', 'Device and threads', 2),
    'partitions': ('完整导入与实际划分', 'Full import and actual partitions', 0),
    'preprocessing': ('训练内预处理', 'Train-only preprocessing', 2),
    'branches': ('附加输入与图状态', 'Additional inputs and graph state', 1),
    'model': ('结构、形状与预算', 'Structure, shapes and budgets', 1),
    'numerical': ('有限前向与反向计算', 'Bounded forward/backward probe', 1),
    'binding': ('配置、内容与版本核验', 'Configuration, content and version binding', 2),
}
STATES = {'pending': ('待检查', 'Pending'), 'running': ('检查中', 'Checking'),
          'passed': ('通过', 'Passed'), 'warning': ('通过，含提示', 'Passed with notes'),
          'failed': ('未通过', 'Failed')}


def build_checklist(settings, layout):
    from .data_widgets import table_widget
    w = settings.window
    settings.preflight_items = {}
    settings.preflight_table = table_widget()
    settings.preflight_table.setObjectName('preflight_checklist')
    settings.preflight_table.setMaximumHeight(270)
    settings.preflight_table.cellDoubleClicked.connect(
        lambda row, column: w.tabs.setCurrentIndex(getattr(settings,'preflight_row_pages',[])[row]))
    layout.addWidget(settings.preflight_table)
    layout.addWidget(w.label('双击检查项可前往对应页面修正。', 'Double-click a check to open its settings page.'))
    settings.open_preflight_button = w.button('打开运行检查文件夹', 'Open preflight folder',
        lambda: w.workflow.open_preflight_folder(), 'open_preflight_folder')
    settings.open_preflight_button.setEnabled(False)
    layout.addWidget(settings.open_preflight_button)
    render_checklist(settings)


def render_checklist(settings):
    w, table = settings.window, settings.preflight_table
    table.setColumnCount(3)
    entries=list(settings.preflight_items.items())
    if not any(isinstance(key,tuple) for key,_ in entries):entries=[(key,settings.preflight_items.get(key,{})) for key in CHECKS]
    table.setRowCount(len(entries));settings.preflight_row_pages=[]
    table.setHorizontalHeaderLabels([w.tr_pair('检查项', 'Check'), w.tr_pair('状态', 'Status'), w.tr_pair('详情', 'Details')])
    for i, (identity,item) in enumerate(entries):
        key=identity[-1] if isinstance(identity,tuple) else identity
        zh,en,page=CHECKS.get(key,(key,key,0));settings.preflight_row_pages.append(page)
        status = w.tr_pair(*STATES.get(item.get('status', 'pending'), STATES['pending']))
        details = item.get('detail', '')
        label=(str(item['trait'])+' · ' if item.get('trait') else '')+w.tr_pair(zh,en)
        for field,cn,en in (('fold','折','Fold'),('trial','候选','Trial')):
            if item.get(field) is not None:label+=' · '+w.tr_pair(cn,en)+' '+str(item[field])
        for j, text in enumerate((label, status, details)):
            table.setItem(i, j, QTableWidgetItem(text))
    table.resizeColumnsToContents()
