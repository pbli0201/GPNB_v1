"""Browsable evidence; UI translations do not alter model provenance."""
from PySide6.QtWidgets import QDialog, QVBoxLayout, QComboBox, QTextBrowser, QCheckBox
from ..models.paper_templates import paper_catalog

ENGLISH_MAPPING = {
    "DeepGS": ("Reference 1.2 example: Conv1d (8 channels, kernel 18), ReLU, MaxPool (4/4), Dropout .2, Dense 32, Sigmoid, Dropout .1, Dense 1. At least 21 retained markers.", "Native PyTorch adaptation of R/MXNet. No ensemble or original initializer. The source example's final Dropout .05 is omitted to keep a linear regression output."),
    "DeepGP": ("Editable MLP regression example: 64 → 32 → 1, ReLU and Dropout .2. This is an explicit example, not the paper's universally optimal setting.", "Widths and dropout are explicit choices. No Talos search, Keras initialization or per-layer L2 regularization."),
    "DLGWAS": ("HEIGHT residual CNN: 10 channels, kernels 4/20/4, shortcut and Dropout .75. Explicit asymmetric SAME padding; linear output replaces isru.", "No per-layer weight/bias regularization or saliency workflow. The historical Python 2.7/Keras environment is not imported."),
    "deepGBLUP": ("Neural subgraph only: locally connected kernels 5/3 with right padding, LayerNorm, GELU, input residual and a linear head. Training-fitted preprocessing restores target mean and scale.", "No GBLUP variance estimation or joint optimization. Uses GPNB_v1 initialization and training-fitted target standardization; this is not a full deepGBLUP reproduction."),
    "WheatGP": ("Five chunks reuse CNN weights (channels 1→2→4→8, kernels 1/3/9), concatenate into one token, then LSTM 128, Dropout .3 and regression. Sequence length is 1; at least 25 retained markers.", "Retained markers are split evenly in file order, with remainder assigned to earlier chunks. Boundaries are not chromosomes or LD blocks. No recurrence across the five chunks is claimed; freezing stages are configured separately."),
    "Cropformer": ("Conv1d, single-token projected attention, residual LayerNorm, ReLU and regression. Example choices: hidden=64, scale_dim=8, kernel=3. No multihead split; the attention matrix is 1×1.", "Preserves the audited code's single-token semantics. Test-correlation model selection is replaced by early stopping on independent validation data."),
    "DNNGP": ("Paper Figure 1A: Conv/ReLU → Dropout → BN → Conv/ReLU → Dropout → Conv/ReLU → Flatten → Dense 1. All convolutions have 64 channels and kernel 4; at least 10 retained markers.", "Independent paper-based mapping. Explicit defaults: stride=1, valid padding, Dropout=.2, BN eps=1e-5 and momentum=.1. The closed compiled core was not verified operator by operator. Paper PCA and multi-omics concatenation are not applied automatically."),
    "GPformer": ("Base GPformer: convolutional SNP embedding, position encoding, autocorrelation attention, two series decompositions, convolution, LayerNorm, two GELU/Dropout blocks, Flatten and Linear. Defaults: width 16, 4 heads, decomposition kernel 25; no separate KGM branch.", "Paper-based mapping without verifiable author source. Residual placement, convolution kernel=1, factor=2 and Dropout=.1 are explicit mapping choices, not proven operator equivalence. Per-individual FFT circular correlation uses lag d aligned to V[t-d], smaller-lag tie breaking and endpoint-padded moving means. Positions follow file order. No GWAS-guided KGM. Verified settings optionally apply focal MAE and Adam; the unreported exponential decay factor is not inferred."),
}

class PaperDialog(QDialog):
    def __init__(self, window):
        super().__init__(window)
        self.window = window
        window.bind_text(self, "论文参考架构", "Paper reference architectures", "setWindowTitle")
        self.resize(850, 600)
        layout = QVBoxLayout(self)
        self.records = [row for row in paper_catalog() if row["available"]]
        self.choice = QComboBox()
        self.choice.setObjectName("paper_architecture_choice")
        self.choice.setProperty("user_values", True)
        for row in self.records:
            self.choice.addItem(row["id"], row["id"])
        layout.addWidget(self.choice)
        self.mode = QComboBox()
        self.mode.setObjectName("paper_preset_mode")
        self.mode.addItem(window.tr_pair("应用文献已核实设置", "Apply verified literature settings"),"verified")
        self.mode.addItem(window.tr_pair("仅应用结构，保留训练设置", "Architecture only; retain training settings"),"architecture")
        layout.addWidget(self.mode)
        self.clear_stages = QCheckBox(window.tr_pair("确认移除现有分阶段设置（可撤销）", "Remove existing stages (undo available)"))
        self.clear_stages.setVisible("stages" in window.document.value["run"]["training"])
        layout.addWidget(self.clear_stages)
        self.details = QTextBrowser()
        layout.addWidget(self.details)
        self.preview = QTextBrowser()
        self.preview.setObjectName("paper_settings_preview")
        layout.addWidget(self.preview)
        self.apply = window.button("应用以上预览", "Apply preview", self.apply_selected, "apply_paper_architecture")
        layout.addWidget(self.apply)
        self.undo = window.button("撤销本次应用", "Undo application", self.undo_selected, "undo_paper_architecture")
        self.undo.setEnabled(getattr(window,"_paper_undo",None) is not None)
        layout.addWidget(self.undo)
        self.mode.currentIndexChanged.connect(self.show_details)
        self.clear_stages.toggled.connect(self.show_details)
        self.choice.currentIndexChanged.connect(self.show_details)
        window.translation_callbacks.append(self.show_details)
        self.show_details()

    def show_details(self, *_):
        from shiboken6 import isValid
        if not isValid(self):
            return
        w = self.window
        row = self.records[self.choice.currentIndex()]
        mapping, changes = ENGLISH_MAPPING[row["id"]]
        text = [w.tr_pair("论文实验状态：未复现。来源核查、结构适配和工程测试是独立状态。", "Paper experiments: not reproduced. Source review, architecture mapping and engineering tests are separate statuses."),
                row["id"] + " — " + row["title"],
                w.tr_pair("结构适配：", "Architecture mapping: ") + w.tr_pair(row["mapping"], mapping),
                w.tr_pair("差异与限制：", "Differences and limits: ") + w.tr_pair("\n".join(row["changes"]), changes + "\nInput is declared diploid hard-call dosage; imputation, filtering and scaling are fitted on training partitions. Author encoding equivalence is not established. Project optimizer, seed, epochs and inner validation are preserved; paper accuracy is not reproduced."),
                w.tr_pair("输入要求：单一二倍体硬调用剂量，单一连续回归目标。", "Input requirements: one diploid hard-call dosage input and one continuous regression target."),
                "DOI: " + row.get("doi", ""),
                w.tr_pair("论文：", "Paper: ") + row.get("paper_url", ""),
                w.tr_pair("代码仓库：", "Repository: ") + str(row.get("repository") or "—"),
                w.tr_pair("核查提交：", "Reviewed commit: ") + str(row.get("commit") or "—"),
                w.tr_pair("结构核查日期：", "Mapping review date: ") + str(row.get("mapping_review_date") or "—")]
        text += [w.tr_pair("来源证据：", "Source evidence: ") + item["url"] for item in row.get("evidence", [])]
        self.details.setPlainText("\n\n".join(text))
        import json
        from ..models.paper_presets import preview_preset
        try:
            preview=preview_preset(w.document.value,row["id"],self.mode.currentData(),clear_stages=self.clear_stages.isChecked())
            lines=[w.tr_pair("部分设置适配；不代表论文实验复现。", "Partial settings adaptation; paper experiments not reproduced.")]
            lines += [f"{r['parameter']}: {r['before']} → {r['after']}" for r in preview["changes"]]
            lines += [w.tr_pair("保持的设置：", "Retained settings: ")+json.dumps(preview["preserved"],ensure_ascii=False)]
            lines += [w.tr_pair("未应用/未报告：", "Unsupported / unreported: ")+r["parameter"]+" — "+r["reason"] for r in preview["unsupported"]]
            lines += preview["blockers"]
            lines += [w.tr_pair("预处理/划分/搜索保持项目设置；早停和筛选仍仅使用训练内验证。", "Project preprocessing, split and search settings remain; selection uses training-internal validation only.")]
            self.preview.setPlainText("\n\n".join(lines))
            self.apply.setEnabled(not preview["blockers"])
            self.details.append("<hr>"+w.tr_pair("参数来源档案（原值 → 应用值 / 状态 / 位置）", "Parameter provenance (original → applied / status / location)"))
            from html import escape
            from ..models.paper_presets import parameter_profile
            for r in parameter_profile(row["id"])["parameters"]:
                self.details.append(escape(f"{r['parameter']}: {r['original']} → {r['applied']} | {r['status']} | {r['location']} | {r['source_url']}"))
        except ValueError as error:
            self.preview.setPlainText(str(error)); self.apply.setEnabled(False)

    def apply_selected(self):
        try:
            self.window.apply_paper_template(self.records[self.choice.currentIndex()]["id"], self.mode.currentData(), clear_stages=self.clear_stages.isChecked())
            self.window.rebuild_cards()
            self.window.refresh()
            self.undo.setEnabled(True)
            self.show_details()
        except ValueError as error:
            self.window.show_error(error)

    def undo_selected(self):
        try:
            self.window.undo_paper_template()
            self.window.rebuild_cards()
            self.window.refresh()
            self.undo.setEnabled(False)
            self.show_details()
        except ValueError as error:
            self.window.show_error(error)
