"""GUI controls serialize the same bounded search contract consumed by CLI."""
import copy
import json
from PySide6.QtWidgets import (QDialog,QVBoxLayout,QFormLayout,QComboBox,QSpinBox,QDoubleSpinBox,
    QTableWidget,QLineEdit,QPushButton,QLabel,QCheckBox,QHBoxLayout)
from ..config import ProjectSpec
from ..training.search import validate_search,TRAINING_KEYS


class SearchDialog(QDialog):
    def __init__(self,window):
        super().__init__(window)
        self.window=window;self.setWindowTitle(window.tr_pair('参数搜索', 'Hyperparameter search'));self.resize(850,550)
        box=QVBoxLayout(self);form=QFormLayout();box.addLayout(form);self.form=form
        self.enabled=QCheckBox(window.tr_pair('启用搜索', 'Enable search'));form.addRow(self.enabled)
        self.method=QComboBox();self.method.addItems(['random','grid']);form.addRow(window.tr_pair('方法', 'Method'),self.method)
        self.budget=QSpinBox();self.budget.setRange(1,1000);self.budget.setValue(6);form.addRow(window.tr_pair('候选数上限（网格须覆盖全部组合）', 'Trial limit (grid must cover all combinations)'),self.budget)
        self.seed=QLineEdit('5209');form.addRow(window.tr_pair('抽样 / 内部划分种子', 'Sampling / inner-split seed'),self.seed)
        self.fraction=QDoubleSpinBox();self.fraction.setRange(.01,.49);self.fraction.setValue(.2)
        form.addRow(window.tr_pair('内部验证比例', 'Inner validation fraction'),self.fraction)
        self.table=QTableWidget(0,2);self.table.setHorizontalHeaderLabels([window.tr_pair('参数', 'Parameter'),window.tr_pair('候选值（逗号分隔）', 'Candidate values (comma separated)')])
        self.table.horizontalHeader().setStretchLastSection(True);box.addWidget(self.table)
        buttons=QHBoxLayout();box.addLayout(buttons)
        add=QPushButton(window.tr_pair('增加参数', 'Add parameter'));add.clicked.connect(lambda:self.add_row());buttons.addWidget(add)
        remove=QPushButton(window.tr_pair('删除选中行', 'Remove row'));remove.clicked.connect(lambda:self.table.removeRow(self.table.currentRow()));buttons.addWidget(remove)
        note=QLabel(window.tr_pair('random：无放回随机抽取组合；grid：遍历全部组合。例：[0.0001, 0.001, 0.01]。\n评分仅使用内部验证 MSE；外层测试不参与选参。LOO 选参后用全部 N−1 个体重训。\n每折最多候选数加一次重训；失败详情见 search/trials.json。仅支持单阶段回归。', 'random samples combinations without replacement; grid enumerates every combination. Example: [0.0001, 0.001, 0.01].\nScoring uses inner-validation MSE only. Outer tests never select parameters. LOO refits on all N−1 individuals after selection.\nEach outer fold runs at most the trial count plus one refit. Failures are recorded in search/trials.json. Single-stage regression only.'))
        note.setWordWrap(True);note.hide()
        from .form_helpers import help_button
        box.addWidget(help_button(window, ("搜索方法与评分", "Search methods and scoring"),
            ("随机搜索无放回抽样；网格遍历全部组合，超过上限须缩小范围或提高上限。候选值用逗号分隔，如 0.0001, 0.001；复杂值可用 JSON 数组。外层测试不参与选参。种子还用于需要新建内部验证集的任务。", "Random search samples combinations without replacement. Grid enumerates all combinations; exceeding the limit requires a smaller space or higher limit. Enter comma-separated values, e.g. 0.0001, 0.001; JSON arrays remain supported. Outer tests never select parameters. The seed also determines a newly created inner holdout when needed.")))
        self.status=QLabel();self.status.setWordWrap(True);box.addWidget(self.status)
        apply=QPushButton(window.tr_pair('保存设置', 'Save settings'));apply.clicked.connect(self.apply);box.addWidget(apply)
        current=window.document.value['run'].get('extensions',{}).get('search')
        self.enabled.setChecked(current is not None)
        if current:
            self.method.setCurrentText(current['method']);self.seed.setText(str(current['seed']))
            self.budget.setValue(current['max_trials']);self.fraction.setValue(current['validation_fraction'])
        for key,values in (current['parameters'] if current else {'training.learning_rate':[.0001,.001,.01],'training.batch_size':[16,32]}).items():
            self.add_row(key,values)
        self.enabled.toggled.connect(self.update_controls)
        self.method.currentTextChanged.connect(self.update_controls)
        self.budget.valueChanged.connect(self.update_controls)
        self.update_controls()

    def add_row(self,path='training.learning_rate',values=None):
        keys=['training.'+k for k in TRAINING_KEYS]
        keys += ['layers.'+row['id']+'.'+key for row in self.window.document.value['model']['layers'] for key in row['params']]
        i=self.table.rowCount();self.table.insertRow(i)
        select=QComboBox()
        labels={"learning_rate":("学习率","Learning rate"),"batch_size":("批大小","Batch size"),"epochs":("轮数","Epochs"),"weight_decay":("权重衰减","Weight decay"),"optimizer":("优化器","Optimizer")}
        for key in keys:
            parts=key.split('.')
            label=self.window.tr_pair(*labels.get(parts[-1],(parts[-1],parts[-1])))
            if parts[0]=='layers': label=f"{parts[1]} · {label}"
            select.addItem(label,key)
        select.setCurrentIndex(select.findData(path))
        self.table.setCellWidget(i,0,select)
        edit=QLineEdit(', '.join(str(x).lower() if isinstance(x,bool) else str(x) for x in (values if values is not None else [.001,.01])))
        self.table.setCellWidget(i,1,edit)
        edit.textChanged.connect(self.update_controls)

    def update_controls(self, *_):
        enabled=self.enabled.isChecked()
        cv=self.window.document.value['run'].get('extensions',{}).get('cross_validation',{})
        needs_inner=cv.get('training_policy')=='full_training'
        self.form.setRowVisible(self.method,enabled)
        self.form.setRowVisible(self.budget,enabled)
        self.form.setRowVisible(self.seed,enabled and (self.method.currentText()=='random' or needs_inner))
        self.form.setRowVisible(self.fraction,enabled and needs_inner)
        self.table.setVisible(enabled)
        for widget in (self.method,self.budget,self.seed,self.fraction): widget.setMaximumWidth(300)
        if not hasattr(self,'status'):return
        try:
            import math
            size=math.prod(len(parse_candidates(self.table.cellWidget(i,1).text())) for i in range(self.table.rowCount()))
            folds=cv.get('folds',1) if cv.get('method','five_fold') in ('five_fold','ten_fold') else cv.get('approved_folds')
            traits=len(self.window.document.value.get('extensions',{}).get('trait_batch',{}).get('traits',[None]))
            if traits>1 and cv.get('method','five_fold').startswith('leave_one'):folds=self.window.tr_pair('见每性状划分','see per-trait plans')
            trials=size if self.method.currentText()=='grid' else min(size,self.budget.value())
            self.status.setText(self.window.tr_pair(f"组合 {size}；每折候选 {trials}；外层折数 {folds or '待划分'}；性状任务 {traits}。每折另有1次正式训练；预检探测数见运行前检查。",f"Combinations {size}; trials/fold {trials}; outer folds {folds or 'pending split'}; trait tasks {traits}. One final fit/fold; probe counts appear in preflight."))
        except (ValueError,TypeError):self.status.setText(self.window.tr_pair('请输入有效候选值。','Enter valid candidate values.'))

    def apply(self):
        try:
            value=copy.deepcopy(self.window.document.value)
            extensions=value['run'].setdefault('extensions',{})
            if self.enabled.isChecked():
                params={}
                for i in range(self.table.rowCount()):
                    path=self.table.cellWidget(i,0).currentData()
                    if path in params: raise ValueError(self.window.tr_pair('重复参数：', 'Duplicate parameter: ')+path)
                    params[path]=parse_candidates(self.table.cellWidget(i,1).text())
                options=dict(method=self.method.currentText(),seed=int(self.seed.text()),max_trials=self.budget.value(),
                             validation_fraction=self.fraction.value(),parameters=params)
                size=validate_search(options)
                extensions['search']=options
                self.status.setText(self.window.tr_pair(f'组合数：{size}；每折候选数 ≤ {min(size,options["max_trials"])}', f'Combinations: {size}; trials per fold ≤ {min(size,options["max_trials"])}'))
            else: extensions.pop('search',None)
            ProjectSpec(value)
            self.window.document.value=value;self.window.document.dirty=True;self.window.refresh();self.accept()
        except Exception as error: self.status.setText(self.window.error_text(error))


def parse_candidates(text):
    text=text.strip()
    if text.startswith('['):
        result=json.loads(text)
        if not isinstance(result,list):raise ValueError('Expected candidate list')
        return result
    result=[]
    for token in text.split(','):
        token=token.strip()
        if not token:raise ValueError('Empty candidate value')
        try:result.append(json.loads(token))
        except json.JSONDecodeError:result.append(token)
    return result
