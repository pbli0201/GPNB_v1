"""Results and the ordered, label-optional deployment workflow."""
from PySide6.QtWidgets import (QWidget, QScrollArea, QVBoxLayout, QFormLayout,
    QHBoxLayout, QLineEdit, QComboBox, QCheckBox, QLabel, QListWidget, QGroupBox)
from .data_widgets import MatrixFields, table_widget


def build_pages(flow):
    w = flow.window
    def page():
        scroll = QScrollArea(); scroll.setWidgetResizable(True)
        body = QWidget(); layout = QVBoxLayout(body); scroll.setWidget(body)
        return scroll, layout
    def group(layout, zh, en):
        box = QGroupBox(); w.bind_text(box, zh, en, setter="setTitle")
        form = QFormLayout(box); layout.addWidget(box)
        return box, form
    def field_row(key, directory):
        field = QLineEdit(); field.setObjectName("predict_" + key)
        field.textChanged.connect(field.setToolTip); flow.predict_fields[key] = field
        row = QHBoxLayout()
        row.addWidget(w.button("选择…", "Browse…", lambda checked=False, k=key, d=directory: flow.browse(k, d)))
        row.addWidget(field, 1)
        return row
    results, rl = page(); predict, pl = page(); flow.prediction_page = predict
    flow.predict_fields = {}; flow.model_description = None
    rf = QFormLayout(); rl.addLayout(rf)
    _, model_form = group(pl, "1. 加载模型", "1. Load model")
    model_form.addRow(w.label("模型包或已完成结果目录", "Model package or completed result"), field_row("bundle", True))
    model_form.addRow(w.button("加载并检查模型", "Load and check model", flow.view_result, "load_prediction_model"))
    flow.model_info = w.label("请先加载完整模型包", "Load a complete model package first")
    flow.model_info.setWordWrap(True); model_form.addRow(flow.model_info)
    flow.fold_selector = QComboBox(); flow.fold_selector.setObjectName("prediction_fold")
    flow.fold_selector.setEnabled(False); flow.cv_root = None
    advanced = QGroupBox(); w.bind_text(advanced, "高级：指定单折", "Advanced: use a single fold", setter="setTitle")
    advanced.setCheckable(True); advanced.setChecked(False)
    advanced_form = QFormLayout(advanced); advanced_body = QWidget(); advanced_row = QFormLayout(advanced_body)
    advanced_row.addRow(w.label("预测策略", "Prediction strategy"), flow.fold_selector)
    note = w.label("默认使用所有成员等权平均；切勿根据外层测试成绩选折。", "All members are averaged equally by default; never choose a fold by its outer-test score.")
    note.setWordWrap(True); advanced_row.addRow(note); advanced_form.addRow(advanced_body)
    advanced_body.hide(); advanced.toggled.connect(advanced_body.setVisible)
    advanced.toggled.connect(lambda checked: None if checked else flow.fold_selector.setCurrentIndex(0))
    model_form.addRow(advanced); flow.fold_advanced = advanced; advanced.hide()
    _, pf = group(pl, "2. 新个体输入", "2. Query individuals")
    flow.prediction_form = pf
    flow.prediction_format = QComboBox()
    w.bind_combo(flow.prediction_format, [("PLINK BED/BIM/FAM", "PLINK BED/BIM/FAM"), ("数值矩阵（CSV/TSV/TXT）", "Numeric matrix (CSV/TSV/TXT)")])
    pf.addRow(w.label("新数据格式", "New data format"), flow.prediction_format)
    flow.prediction_matrix = MatrixFields(w); pf.addRow(flow.prediction_matrix); flow.prediction_matrix.hide()
    flow.prediction_rows = {}
    for key, zh, en in [("bed", "新个体 BED", "Query BED"), ("bim", "配套 BIM", "Markers BIM"), ("fam", "配套 FAM", "Samples FAM")]:
        flow.prediction_rows[key] = pf.rowCount(); pf.addRow(w.label(zh, en), field_row(key, False))
    def mode_changed(*args):
        matrix = bool(flow.prediction_format.currentIndex())
        flow.prediction_matrix.setVisible(matrix)
        for key in ("bed", "fam"):
            pf.setRowVisible(flow.prediction_rows[key], not matrix)
        pf.setRowVisible(flow.prediction_rows['bim'], not matrix or flow.prediction_matrix.alleles.currentData() != 'DECLARED')
    flow.prediction_format.currentIndexChanged.connect(mode_changed)
    flow.prediction_matrix.alleles.currentIndexChanged.connect(mode_changed)
    flow.input_group = QWidget(); flow.input_form = QFormLayout(flow.input_group); flow.input_fields = {}
    pf.addRow(flow.input_group); flow.input_group.hide()
    flow.cohort = QLineEdit("new_cohort"); pf.addRow(w.label("新队列名称", "Query cohort name"), flow.cohort)
    flow.identity_relation = QComboBox()
    for value in ('unknown', 'same_source', 'confirmed_new'): flow.identity_relation.addItem(value, value)
    w.bind_combo(flow.identity_relation, [("来源关系不明（身份待核对）", "Source relation unknown (identity uncertain)"),
        ("与训练数据同一 ID 来源", "Same ID source as training data"),
        ("已独立核实均为新个体", "Independently confirmed new individuals")])
    pf.addRow(w.label("个体身份来源", "Individual identity source"), flow.identity_relation)
    flow.identity_note = QLineEdit(); flow.identity_note.setObjectName('prediction_identity_note')
    w.bind_text(flow.identity_note, "如材料登记记录、采样批次及核对方式", "E.g. registry, collection batch and verification method", setter='setPlaceholderText')
    flow.identity_note_row = pf.rowCount(); pf.addRow(w.label("独立核实依据（确认新个体时必填）", "Verification basis (required for confirmed new individuals)"), flow.identity_note)
    pf.setRowVisible(flow.identity_note_row, False)
    flow.identity_relation.currentIndexChanged.connect(lambda: pf.setRowVisible(flow.identity_note_row, flow.identity_relation.currentData() == 'confirmed_new'))
    note = w.label("队列名称不代表身份来源。仅同名或相同基因型不能证明是同一个体；身份不明者仍可预测，但不纳入新个体评分。",
        "A cohort name does not establish identity. Matching names or genotypes alone do not establish the same individual. Uncertain individuals are predicted but excluded from new-individual scoring.")
    note.setWordWrap(True); pf.addRow(note)
    _, phenotype_form = group(pl, "3. 可选表型：仅在预测完成后评分", "3. Optional phenotypes: score only after prediction")
    flow.score_enabled = QCheckBox(); w.bind_text(flow.score_enabled, "提供观测表型用于评分", "Provide observed phenotypes for scoring")
    phenotype_form.addRow(flow.score_enabled)
    flow.phenotype_body = QWidget(); sf = QFormLayout(flow.phenotype_body); phenotype_form.addRow(flow.phenotype_body)
    flow.phenotype_path = QLineEdit(); flow.phenotype_path.setObjectName('prediction_phenotype')
    row = QHBoxLayout(); row.addWidget(w.button("选择…", "Browse…", flow.browse_prediction_phenotype)); row.addWidget(flow.phenotype_path, 1)
    sf.addRow(w.label("表型 CSV/TXT", "Phenotype CSV/TXT"), row)
    flow.phenotype_delimiter = QComboBox()
    for label, value in [('CSV (,)', ','), ('TSV (Tab)', '\t'), ('Whitespace TXT', 'whitespace')]: flow.phenotype_delimiter.addItem(label, value)
    w.bind_combo(flow.phenotype_delimiter, [("逗号 CSV (,)", "Comma CSV (,)"), ("制表符 Tab", "Tab"), ("空白分隔 TXT", "Whitespace TXT")])
    flow.phenotype_encoding = QComboBox(); flow.phenotype_encoding.addItems(['utf-8', 'utf-8-sig', 'gb18030'])
    flow.phenotype_ids = QLineEdit('["FID", "IID"]'); flow.phenotype_missing = QLineEdit('["", "NA", "NaN"]')
    flow.phenotype_trait = QLineEdit()
    for zh, en, widget in [('分隔符', 'Delimiter', flow.phenotype_delimiter), ('字符编码', 'Text encoding', flow.phenotype_encoding),
        ('ID 列（IID 或 FID、IID；JSON）', 'ID columns (IID or FID, IID; JSON)', flow.phenotype_ids),
        ('单性状观测列（多目标沿用原列名）', 'Observed trait column (multi-target keeps original columns)', flow.phenotype_trait),
        ('缺失标记（JSON）', 'Missing tokens (JSON)', flow.phenotype_missing)]: sf.addRow(w.label(zh, en), widget)
    flow.phenotype_body.hide(); flow.score_enabled.toggled.connect(flow.phenotype_body.setVisible)
    note = w.label("无需表型也能预测。未匹配或缺失的观测只影响评分；新表型不参与训练、选折或参考特征计算。",
        "Prediction works without phenotypes. Unmatched or missing observations affect scoring only; query phenotypes never fit models, select folds or construct reference features.")
    note.setWordWrap(True); phenotype_form.addRow(note)
    _, output_form = group(pl, "4. 输出与预测", "4. Output and prediction")
    output_form.addRow(w.label("输出根目录", "Output root"), field_row('output', True))
    flow.predict_fields['output'].setText(str(w.root / 'runs'))
    flow.predict_device = QComboBox(); flow.predict_device.addItems(['cpu', 'cuda'])
    output_form.addRow(w.label("预测设备", "Prediction device"), flow.predict_device)
    flow.sort_direction = QComboBox()
    for value in (None, 'descending', 'ascending'): flow.sort_direction.addItem('', value)
    w.bind_combo(flow.sort_direction, [('保持输入顺序', 'Keep input order'), ('性状越大越好（降序）', 'Larger is preferred (descending)'), ('性状越小越好（升序）', 'Smaller is preferred (ascending)')])
    output_form.addRow(w.label('候选材料排序', 'Candidate ranking'), flow.sort_direction)
    flow.predict_button = w.button('检查并预测', 'Check and predict', flow.start_prediction, 'predict'); output_form.addRow(flow.predict_button)
    note = w.label('输出保持目标原始单位，不自动等于育种值。模型间分歧不是置信区间或育种值可靠性。原训练队列的评价请查看已保存的 OOF，不能用全成员平均替代。',
        'Outputs use original target units and are not automatically breeding values. Model disagreement is not a confidence interval or breeding-value reliability. Evaluate the original cohort using archived OOF predictions, not all-member averages.')
    note.setWordWrap(True); output_form.addRow(note)
    flow.prediction_text = QLabel(); flow.prediction_text.setWordWrap(True); pl.addWidget(flow.prediction_text)
    flow.prediction_table = table_widget(); pl.addWidget(flow.prediction_table)
    # Results follow reading order; prediction inputs and export destinations are independent.
    mirror=QLineEdit();mirror.textChanged.connect(flow.predict_fields['bundle'].setText)
    flow.predict_fields['bundle'].textChanged.connect(mirror.setText)
    line=QHBoxLayout();line.addWidget(w.button('打开其他结果…','Open another result…',lambda:flow.browse('bundle',True)));line.addWidget(mirror,1)
    flow.view_button=w.button('加载结果','Load result',flow.view_result,'load_result');line.addWidget(flow.view_button);rf.addRow(line)
    flow.result_text=QLabel();flow.result_text.setWordWrap(True);rl.addWidget(flow.result_text)
    flow.batch_group=QGroupBox();w.bind_text(flow.batch_group,'按性状分别训练任务','Separate trait tasks','setTitle');batch=QVBoxLayout(flow.batch_group)
    flow.batch_table=table_widget();batch.addWidget(flow.batch_table)
    flow.batch_table.cellDoubleClicked.connect(lambda row,col:open_batch_task(flow,row))
    row=QHBoxLayout();row.addWidget(w.button('打开选中性状结果','Open selected trait result',lambda:open_batch_task(flow,flow.batch_table.currentRow())))
    flow.batch_retry_button=w.button('只重跑失败/未完成任务','Retry failed / unfinished tasks',flow.start_batch_retry);row.addWidget(flow.batch_retry_button);batch.addLayout(row)
    from .batch_explorer import BatchExplorer
    flow.batch_explorer=BatchExplorer(flow);batch.addWidget(flow.batch_explorer)
    rl.addWidget(flow.batch_group);flow.batch_group.hide()
    flow.overview_group,overview=group(rl,'1. 数据概览','1. Data overview')
    flow.overview_table=table_widget();flow.overview_table.setMaximumHeight(250);overview.addRow(flow.overview_table)
    flow.configuration_group,configuration=group(rl,'2. 实际模型与设置','2. Actual model and settings')
    flow.configuration_table=table_widget();flow.configuration_table.setMaximumHeight(260);configuration.addRow(flow.configuration_table)
    flow.results_group=QGroupBox();w.bind_text(flow.results_group,'3. 预测结果','3. Prediction results','setTitle');result_layout=QVBoxLayout(flow.results_group);rl.addWidget(flow.results_group)
    flow.scatter=QLabel();flow.scatter.hide()
    from .result_explorer import ResultExplorer
    flow.result_explorer=ResultExplorer(flow);result_layout.addWidget(flow.result_explorer)
    flow.table=table_widget();result_layout.addWidget(flow.table)
    flow.save_group,save=group(rl,'4. 保存与应用','4. Save and apply')
    flow.export_output=QLineEdit(str(w.root/'runs'));flow.export_output.setObjectName('export_output');flow.export_output.textChanged.connect(flow.export_output.setToolTip)
    row=QHBoxLayout();row.addWidget(w.button('选择位置…','Choose location…',lambda:browse_export(flow)));row.addWidget(flow.export_output,1)
    save.addRow(w.label('保存位置','Save location'),row)
    flow.export_name=QLineEdit();flow.export_name.setObjectName('export_name');flow.export_name.setMaximumWidth(340)
    w.bind_text(flow.export_name,'可选名称；自动附加唯一编号','Optional name; a unique suffix is added','setPlaceholderText')
    save.addRow(w.label('保存名称','Save name'),flow.export_name)
    flow.export_target_scope=QComboBox();flow.export_target_scope.addItem('all','all');flow.export_target_scope.addItem('selected','selected')
    w.bind_combo(flow.export_target_scope,[('全部性状','All targets'),('当前性状','Selected target')]);save.addRow(w.label('结果导出范围','Report export scope'),flow.export_target_scope)
    flow.package_button=w.button('保存模型','Save model',flow.start_model_package,'save_model_package')
    flow.export_button=w.button('导出完整实验','Export full experiment',flow.start_export,'export_run')
    row=QHBoxLayout();row.addWidget(flow.package_button);row.addWidget(flow.result_explorer.export_button);row.addWidget(flow.export_button);save.addRow(row);flow.result_explorer.export_button.show()
    flow.include_data=QCheckBox();w.bind_text(flow.include_data,'完整实验附带输入数据','Include input data in full experiment');save.addRow(flow.include_data)
    row=QHBoxLayout();row.addWidget(w.button('打开结果目录','Open result directory',lambda:open_result_folder(flow)));row.addWidget(w.button('使用此模型预测 →','Predict with this model →',lambda:w.tabs.setCurrentWidget(predict)));save.addRow(row)
    from .form_helpers import help_button
    save.addRow(help_button(w,('保存内容说明','What is saved'),('保存模型用于新个体预测；结果报告包括指标、图和预测表；完整实验包括重跑代码与记录，可附带原始输入。所有操作创建新目录，原实验不覆盖。','A model package predicts new individuals. A result report includes metrics, plots and prediction tables. A full experiment contains reproduction code and records, optionally input data. Every save creates a new directory.')))
    flow.final_refit_button=w.button('按当前项目训练全数据最终模型','Train final model from current project',flow.start_final_refit,'final_refit');save.addRow(flow.final_refit_button)
    save.addRow(help_button(w,('最终模型的评价范围','Final-model evaluation scope'),('使用当前项目独立内部选择，再用全部合格训练个体重拟合；没有新的独立测试评分。不按外层测试挑选成员。','Performs internal selection from the current project, then refits all eligible training individuals. There is no new independent test score and outer tests never choose members.')))
    compare_group=QGroupBox();w.bind_text(compare_group,'更多：比较交叉验证结果','More: compare CV results','setTitle');compare_group.setCheckable(True);compare_group.setChecked(False)
    compare_layout=QVBoxLayout(compare_group);compare_body=QWidget();compare_form=QFormLayout(compare_body);compare_layout.addWidget(compare_body);compare_body.hide();compare_group.toggled.connect(compare_body.setVisible);save.addRow(compare_group)
    flow.comparison_list=QListWidget();flow.comparison_list.setMaximumHeight(90);compare_form.addRow(flow.comparison_list)
    row=QHBoxLayout();row.addWidget(w.button('加入比较','Add run',flow.add_comparison));row.addWidget(w.button('移除选中','Remove selected',flow.remove_comparison))
    flow.compare_button=w.button('比较相同划分的结果','Compare matching folds',flow.start_comparison);row.addWidget(flow.compare_button);compare_form.addRow(row)
    return results


def refresh_result_view(flow, result=None, *, reset=False):
    result=result or getattr(flow,'displayed_result',None)
    if not result or not hasattr(flow,'result_explorer'):return
    kind=result.get('summary',{}).get('kind')
    if kind=='trait_batch':show_batch_result(flow,result);return
    flow.batch_group.hide();flow.overview_group.show();flow.configuration_group.show();flow.results_group.show()
    if kind in ('training_run','cross_validation') and result.get('kind')!='model-package':
        flow.scatter.hide();flow.result_explorer.load(result['output'],reset=reset)
    elif kind=='final_refit':
        from pathlib import Path
        source=Path(result['output'])/result['summary'].get('model_directory','model')
        flow.result_explorer.load(source,reset=reset)
    else:flow.result_explorer.hide()


def browse_export(flow):
    from PySide6.QtWidgets import QFileDialog
    path=QFileDialog.getExistingDirectory(flow.window,flow.window.tr_pair('保存位置','Save location'),flow.export_output.text())
    if path:flow.export_output.setText(path)


def open_result_folder(flow):
    from PySide6.QtCore import QUrl
    from PySide6.QtGui import QDesktopServices
    result=getattr(flow,'displayed_result',None)
    if result:QDesktopServices.openUrl(QUrl.fromLocalFile(str(result['output'])))


def open_batch_task(flow,row):
    from pathlib import Path
    result=getattr(flow,'displayed_result',None)
    if not result or result['summary'].get('kind')!='trait_batch':return
    tasks=result['summary']['tasks']
    records=flow.batch_explorer.index['records'] if flow.batch_explorer.index else []
    if not 0<=row<len(records):return
    selected=records[row]
    task=next(t for t in tasks if t['id']==selected['task_id'])
    if task['status']!='completed':
        flow.window.show_error(task.get('error',flow.window.tr_pair('该任务尚未完成。','This task has not completed.')));return
    from ..bundle import safe_member
    source=safe_member(Path(task.get('preserved_from',result['output'])),task['output'])
    flow.predict_fields['bundle'].setText(str(source));flow.view_destination=4
    flow.launch('view',{'bundle':str(source),'device':flow.predict_device.currentText()},flow.predict_device.currentText())


def show_batch_result(flow,result):
    from .data_widgets import fill_table
    flow.displayed_result=result;flow.displayed_split_counts=None
    summary=result['summary'];w=flow.window
    flow.batch_group.show();flow.result_explorer.hide()
    flow.overview_group.hide();flow.configuration_group.hide();flow.results_group.hide()
    flow.batch_explorer.load(result['output'])
    flow.batch_retry_button.setEnabled(any(r['status']!='completed' for r in summary['tasks']))
    flow.package_button.setEnabled(False);flow.export_button.setEnabled(False);flow.plot_export_button.setEnabled(not flow.jobs.busy)
    flow.result_text.setText(format_batch(w,summary)+'\n'+str(result['output']))


def format_batch(w,summary):
    done=sum(t['status']=='completed' for t in summary['tasks']);total=len(summary['tasks'])
    failed=sum(t['status']=='failed' for t in summary['tasks']);cancelled=sum(t['status']=='cancelled' for t in summary['tasks']);pending=total-done-failed-cancelled
    return w.tr_pair(f'分别训练：完成 {done}/{total}，失败 {failed}，取消 {cancelled}，未运行 {pending}。单击看组合图，双击进入详情；可导出整批结果。',f'Separate training: {done}/{total} completed, {failed} failed, {cancelled} cancelled, {pending} not run. Click for combined plots, double-click for details; export the whole batch below.')
