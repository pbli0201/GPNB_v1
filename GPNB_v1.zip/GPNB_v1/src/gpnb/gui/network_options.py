from PySide6.QtWidgets import QGroupBox,QVBoxLayout,QHBoxLayout,QWidget,QComboBox,QLabel
from .data_widgets import format_help


def add_options(w, outer):
    group=QGroupBox();w.bind_text(group,"输入与输出","Inputs and outputs","setTitle");group.setCheckable(True);group.setChecked(False)
    layout=QVBoxLayout(group);body=QWidget();body_layout=QVBoxLayout(body);row=QVBoxLayout();body_layout.addLayout(row);w.io_body_layout=body_layout;layout.addWidget(body);body.hide();group.toggled.connect(body.setVisible)
    row.addWidget(w.button("额外数值输入表（协变量 / 组学）","Additional numeric inputs (covariates / omics)",w.open_input_tables,"input_tables"))
    row.addWidget(w.button("单目标 / 多性状 / 多环境输出","Single / multiple trait / environment heads",w.open_multitask,"multitask"))
    outer.addWidget(group);w.io_group=group
    w.capability=QLabel();w.capability.setWordWrap(True);outer.addWidget(w.capability)


def select_mode(w, index):
    if index:
        w.enable_dag();return
    model=w.document.value["model"]
    if model.get("graph_mode")!="dag":return
    previous="$input"
    for layer in model["layers"]:
        if layer.get("inputs") != {"x":previous}:
            w.show_error(w.tr_pair("当前存在分支，不能自动丢弃连接。先编辑为顺序链或应用顺序模板。", "Existing branches cannot be discarded automatically. Edit them into a sequential chain or apply a sequential template."))
            w.connection_mode.blockSignals(True);w.connection_mode.setCurrentIndex(1);w.connection_mode.blockSignals(False);return
        previous=layer["id"]
    if model.get("output")!=previous or model.get("external_inputs") or model.get("reconstruction_output"):
        w.show_error(w.tr_pair("输出或额外输入需要分支模式。", "Outputs or external inputs require branch mode."))
        w.connection_mode.blockSignals(True);w.connection_mode.setCurrentIndex(1);w.connection_mode.blockSignals(False);return
    model["graph_mode"]="sequential";w.document.dirty=True;w.rebuild_cards();w.refresh()


def refresh_options(w):
    model=w.document.value["model"];config=w.document.value["run"]["training"]
    dag=model.get("graph_mode")=="dag"
    w.connection_mode.blockSignals(True);w.connection_mode.setCurrentIndex(int(dag));w.connection_mode.blockSignals(False)
    w.output_choice.setVisible(dag)
    from .input_modes import kernel_options
    external=set(model.get("external_inputs", {}))
    if (kernel_options(w.document.value) or {}).get("mode") == "snp_kernel":
        external.discard("kernel")
    needed=external or model.get("task")=="multi_target_regression"
    types={r["type"] for r in model["layers"]}
    if needed or types & {"GraphInput","ReferenceGraphSAGE"}:w.io_group.setChecked(True)
    reasons=[]
    configured={table["id"] for table in w.document.value.get("extensions",{}).get("input_tables",[])}
    if (kernel_options(w.document.value) or {}).get("mode") == "snp_kernel":
        configured.add("kernel")
    missing=set(model.get("external_inputs",{}))-configured
    if missing:reasons.append(w.tr_pair("待绑定数值输入：", "Missing numeric inputs: ")+", ".join(sorted(missing)))
    if config["device"]=="cuda":
        if "AdaptiveMaxPool1d" in types and config["deterministic"] and config.get("adaptive_max_pool_strict",False):
            reasons.append(w.tr_pair("AdaptiveMaxPool1d：不支持严格确定性 CUDA 反向传播", "AdaptiveMaxPool1d: strict deterministic CUDA backward is unsupported"))
            w.train_button.setEnabled(False)
        from .runtime_profile import device_python
        env=device_python(w.root,'cuda')
        status=w.tr_pair("训练解释器（设备在工作进程中核验）：", "Worker interpreter (device checked in worker): ")+str(env)
        if "AdaptiveMaxPool1d" in types and not config.get("adaptive_max_pool_strict",False):
            status += w.tr_pair("；此池化模型默认关闭严格确定性", "; strict determinism is disabled by default for this pooling model")
    else:status=w.tr_pair("CPU；不需要 NVIDIA GPU", "CPU; no NVIDIA GPU required")
    text=status+"\n"+"；".join(reasons) if reasons else status
    if reasons:w.train_button.setEnabled(False)
    w.capability.setText(text+"\n"+w.tr_pair("资源取决于批量、长度及图边数；参数存储量不等于峰值内存。", "Resources depend on batch size, sequence length and graph edges; parameter storage is not peak memory."))
    w.capability.setStyleSheet("color:#ad2635" if reasons else "color:#475569")
