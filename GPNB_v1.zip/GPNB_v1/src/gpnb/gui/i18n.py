"""Small widget translation helpers; scientific values are never translated."""
from PySide6.QtCore import QSignalBlocker
from PySide6.QtWidgets import QLabel, QAbstractButton, QGroupBox, QDialog, QComboBox, QTableWidget, QPlainTextEdit, QTextBrowser, QLineEdit
from shiboken6 import isValid


def translate_open_widgets(window):
    """Refresh text produced by tr_pair in already-open dialogs.

    Editable text, table cells and user model/data names are deliberately excluded.
    Explicit bindings handle labels that contain changing numeric values.
    """
    catalog = window.text_catalog
    def convert(value):
        pair = catalog.get(value)
        return pair[0 if window.language == "zh_CN" else 1] if pair else value
    for widget in window.findChildren(QLabel) + window.findChildren(QAbstractButton):
        widget.setText(convert(widget.text()))
    for widget in window.findChildren(QGroupBox):
        widget.setTitle(convert(widget.title()))
    for widget in window.findChildren(QDialog):
        widget.setWindowTitle(convert(widget.windowTitle()))
    for widget in window.findChildren(QLineEdit):
        if widget.property("missing_companion"):
            widget.setToolTip(window.tr_pair("未找到：", "Not found: ") + widget.property("missing_companion"))
    for widget in window.findChildren(QPlainTextEdit) + window.findChildren(QTextBrowser):
        if widget.isReadOnly() and widget.toPlainText() in catalog:
            widget.setPlainText(convert(widget.toPlainText()))
    for widget in window.findChildren(QComboBox):
        if widget.isEditable() or widget.property("user_values"):
            continue
        blocker = QSignalBlocker(widget)
        for i in range(widget.count()):
            widget.setItemText(i, convert(widget.itemText(i)))
        del blocker
    for widget in window.findChildren(QTableWidget):
        for column in range(widget.columnCount()):
            header = widget.horizontalHeaderItem(column)
            if header:
                header.setText(convert(header.text()))
    alive = []
    for widget, setter, zh, en in window.text_bindings:
        if isValid(widget):
            getattr(widget, setter)(window.tr_pair(zh, en))
            alive.append((widget, setter, zh, en))
    window.text_bindings[:] = alive
    for widget, choices in window.combo_bindings[:]:
        if not isValid(widget):
            window.combo_bindings.remove((widget, choices))
            continue
        blocker = QSignalBlocker(widget)
        for i, (zh, en) in enumerate(choices):
            widget.setItemText(i, window.tr_pair(zh, en))
        del blocker


def project_output(window, category, stem):
    """Prepare a writable category under the project's selected output root."""
    from pathlib import Path
    from datetime import datetime
    import uuid
    from ..data.genotypes import source_paths
    spec = window.document.spec().to_dict()
    destination = Path(spec["output_dir"]).resolve() / category
    inputs = list(source_paths(spec["data"], window.document.path or window.root / "untitled.json").values())
    inputs += [Path(item["path"]).resolve() for item in spec.get("extensions", {}).get("input_tables", [])]
    from .output_paths import ensure_output_directory
    ensure_output_directory(destination, inputs)
    return destination / f"{stem}_{datetime.now():%Y%m%d_%H%M%S}_{uuid.uuid4().hex[:10]}"
