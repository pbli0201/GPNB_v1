"""Application-local palette; never changes the Windows theme or installed fonts."""
from pathlib import Path

from PySide6.QtGui import QColor, QFont, QFontDatabase, QPalette


def configure_appearance(app):
    if getattr(app, "_gpnb_appearance", False):
        return
    app.setStyle("Fusion")
    palette = QPalette()
    for role, color in (
        (QPalette.Window, "#f3f6fa"), (QPalette.WindowText, "#23364b"),
        (QPalette.Base, "#ffffff"), (QPalette.AlternateBase, "#edf3f9"),
        (QPalette.Text, "#23364b"), (QPalette.Button, "#e4edf7"),
        (QPalette.ButtonText, "#173b61"), (QPalette.Highlight, "#2567a5"),
        (QPalette.HighlightedText, "#ffffff"), (QPalette.ToolTipBase, "#ffffff"),
        (QPalette.ToolTipText, "#23364b"), (QPalette.PlaceholderText, "#63788b"),
    ):
        palette.setColor(role, QColor(color))
    palette.setColor(QPalette.Disabled, QPalette.Text, QColor("#718096"))
    palette.setColor(QPalette.Disabled, QPalette.ButtonText, QColor("#718096"))
    app.setPalette(palette)
    app.setStyleSheet("""
        QScrollBar:vertical {background:#e2e8f0; width:15px; margin:0;}
        QScrollBar:horizontal {background:#e2e8f0; height:15px; margin:0;}
        QScrollBar::handle {background:#64748b; border-radius:5px; min-width:28px; min-height:28px;}
        QScrollBar::handle:hover {background:#334155;}
        QScrollBar::add-line,QScrollBar::sub-line {width:0; height:0;}
        QScrollBar::add-page,QScrollBar::sub-page {background:#e2e8f0;}
    """)
    font = Path("C:/Windows/Fonts/msyh.ttc")
    if font.is_file():
        handle = QFontDatabase.addApplicationFont(str(font))
        families = QFontDatabase.applicationFontFamilies(handle)
        if families:
            app.setFont(QFont(families[0], 10))
    app._gpnb_appearance = True
