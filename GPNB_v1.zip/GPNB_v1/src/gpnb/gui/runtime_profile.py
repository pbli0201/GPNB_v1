"""Resolve an explicitly selected device without silently changing it."""
import sys
from pathlib import Path
from ..data.files import read_json
from ..environment_profiles import get_profile


def device_python(root,device):
    root=Path(root)
    if device=='cuda':
        # An explicit launcher profile takes precedence over an older saved preference.
        import torch
        if torch.version.cuda is not None:return Path(sys.executable)
        active=root/'runtime/active-profile.json'
        if active.is_file():
            try:
                name=read_json(active)['profile']
                if get_profile(name,root)['device']=='cuda':
                    candidate=root/'runtime/envs'/name/'Scripts/python.exe'
                    if candidate.is_file():return candidate
            except (ValueError,OSError,KeyError):pass
    candidate=root/'runtime/envs'/device/'Scripts/python.exe'
    return candidate if candidate.is_file() else Path(sys.executable)
