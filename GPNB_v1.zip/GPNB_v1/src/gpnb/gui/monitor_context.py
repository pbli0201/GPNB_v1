"""Display worker identity independently of transient status and epoch messages."""

def update_context(flow, event):
    context=getattr(flow,'current_context',{})
    if event.get('joint_target_ids'):
        context['trait']=flow.window.tr_pair('联合目标：','Joint targets: ')+', '.join(event['joint_target_ids'])
        flow.current_context=context
        flow.trait_status.setText(context['trait'])
        return
    if event.get('trait'):
        context.update({key:event[key] for key in ('trait','trait_index','trait_count','fit_purpose') if key in event})
    elif not context.get('trait'):
        project=flow.window.document.value
        targets=project.get('extensions',{}).get('multitask',{}).get('targets')
        context['trait']=flow.window.tr_pair('联合目标','Joint targets') if targets else project['data']['phenotype_options'].get('trait','—')
    flow.current_context=context
    index=context.get('trait_index',event.get('index'));count=context.get('trait_count',event.get('total'))
    suffix=f' ({index}/{count})' if index and count else ''
    flow.trait_status.setText(flow.window.tr_pair('当前性状：','Current trait: ')+str(context.get('trait','—'))+suffix)
