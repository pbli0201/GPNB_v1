"""Desktop configuration editor; computation remains in the shared core."""
