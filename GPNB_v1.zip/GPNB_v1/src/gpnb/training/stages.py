"""Explicit auxiliary objectives and staged optimization. Schema remains torch-free."""
from ..config import choice, fail, number, object_fields, sequence, text


def validate_stages(stages):
    sequence(stages,"training.stages")
    if len(stages)>8:
        fail("E_AUXILIARY","stages","at most eight explicit training stages")
    for i,stage in enumerate(stages):
        path=f"stages[{i}]"
        object_fields(stage,path,("mode","epochs","regression_weight","reconstruction_weight","freeze"))
        choice(stage["mode"],path+".mode",("pretrain","joint","regression"))
        number(stage["epochs"],path+".epochs",1,2**31-1,integer=True)
        for key in ("regression_weight","reconstruction_weight"):
            number(stage[key],path+"."+key,0,1e6)
        r,a=stage["regression_weight"],stage["reconstruction_weight"]
        if not ((stage["mode"]=="pretrain" and r==0 and a>0) or
                (stage["mode"]=="joint" and r>0 and a>0) or
                (stage["mode"]=="regression" and r>0 and a==0)):
            fail("E_AUXILIARY",path,"weights must agree with the explicitly selected stage mode")
        sequence(stage["freeze"],path+".freeze",nonempty=False)
        for item in stage["freeze"]:
            text(item,path+".freeze")
        if len(set(stage["freeze"]))!=len(stage["freeze"]):
            fail("E_AUXILIARY",path,"duplicate frozen layer IDs")
    if stages[-1]["regression_weight"]<=0:
        fail("E_AUXILIARY","stages","final stage must train a regression objective")


def validate_stage_model(model,stages):
    if model.get("schema_version")!=2:
        fail("E_AUXILIARY","model","staged optimization requires v2 model")
    if stages is None:
        fail("E_AUXILIARY","training","reconstruction head requires explicit stage weights; no silent unused objective")
    validate_stages(stages)
    if any(s["reconstruction_weight"]>0 for s in stages) and not model.get("reconstruction_output"):
        fail("E_AUXILIARY","model","reconstruction stages require a reconstruction_output")
    ids={r["id"] for r in model["layers"]}
    for stage in stages:
        if not set(stage["freeze"])<=ids:
            fail("E_AUXILIARY","freeze","unknown frozen layer ID")


def default_stages(epochs=10,freeze=None):
    return [dict(mode="pretrain",epochs=epochs,regression_weight=0.,reconstruction_weight=1.,freeze=[]),
            dict(mode="regression",epochs=epochs,regression_weight=1.,reconstruction_weight=0.,freeze=freeze or [])]


def configure_frozen(model, identifiers):
    rows={row["id"]:row for row in model.plan["layers"]}
    owners=sorted({rows[key]["module_index"] for key in identifiers})
    for param in model.parameters():
        param.requires_grad_(True)
    modules=[model._modules[str(owner)] for owner in owners]
    for module in modules:
        for param in module.parameters():
            param.requires_grad_(False)
        module.eval()
    return modules,owners


def objective_components(model,data,rows,device,stage,config=None):
    import torch
    from .core import _inputs, _targets
    inputs=_inputs(data,rows,device,model)
    if stage["reconstruction_weight"]:
        prediction,reconstruction=model(inputs,return_auxiliary=True)
    else:
        prediction,reconstruction=model(inputs),None
    regression_sum=prediction.new_zeros(())
    regression_count=0
    if stage["regression_weight"]:
        target=_targets(data,rows,device)
        from .objectives import elementwise_loss
        regression_sum=elementwise_loss(prediction,target,config).sum()
        regression_count=target.numel()
    reconstruction_sum=prediction.new_zeros(())
    reconstruction_count=0
    if reconstruction is not None:
        raw=data.cache.batch(rows)[:,data.state.arrays["keep"]]
        observed=torch.as_tensor(raw>=0,device=device)
        target=inputs["$input"] if isinstance(inputs,dict) else inputs
        if reconstruction.shape!=target.shape or observed.shape!=target.shape:
            fail("E_AUXILIARY","reconstruction","head, target and observed mask shapes must be identical")
        reconstruction_sum=(reconstruction-target).square().masked_select(observed).sum()
        reconstruction_count=int(observed.sum())
    for value in (regression_sum,reconstruction_sum):
        if not torch.isfinite(value):
            fail("E_AUXILIARY","loss","nonfinite objective; no optimizer step")
    loss=stage["regression_weight"]*regression_sum/max(1,regression_count)+stage["reconstruction_weight"]*reconstruction_sum/max(1,reconstruction_count)
    stats=(float(regression_sum.detach()),regression_count,float(reconstruction_sum.detach()),reconstruction_count)
    return loss,stats


def aggregate(stats,stage):
    rs,rn,as_,an=stats
    if (stage["regression_weight"] and not rn) or (stage["reconstruction_weight"] and not an):
        fail("E_AUXILIARY","loss","stage has no observed targets in this partition")
    r,a=rs/max(1,rn),as_/max(1,an)
    return stage["regression_weight"]*r+stage["reconstruction_weight"]*a,r,a


def fit_staged(data,spec,config,*,progress=None,cancelled=None,max_parameter_bytes,checkpoint=None):
    import time
    import numpy as np
    import torch
    from .core import (FitResult,check_cancel,check_execution,execution_context,inspect_model,build_model)
    validate_stage_model(spec.to_dict(),config["stages"])
    fixed = config.get("selection_mode") == "fixed_epochs"
    train,validation=data.split.rows("train"),data.split.rows("validation")
    if not len(train) or (not fixed and not len(validation)) or np.intersect1d(train,validation).size:
        fail("E_AUXILIARY","split","nonempty disjoint train/validation required")
    plan=inspect_model(spec,data.input_features,graph_state=getattr(data,"graph_state",None),
                       reference_state=getattr(data,"reference_state",None))
    check_execution(plan,config["device"],config["deterministic"],config["batch_size"],len(train))
    with execution_context(config) as device:
        model=build_model(spec,data.input_features,seed=config["seed"],max_parameter_bytes=max_parameter_bytes,
            graph_state=getattr(data,"graph_state",None),reference_state=getattr(data,"reference_state",None),
            reference_data=getattr(data,"reference_features",None)).to(device)
        data.reference_spec=spec.to_dict().get("individual_graph_spec")
        history,summaries=[],[]
        rng=np.random.Generator(np.random.PCG64(config["seed"]))
        global_epoch=0
        for index,stage in enumerate(config["stages"],1):
            check_cancel(cancelled)
            frozen,owners=configure_frozen(model,stage["freeze"])
            parameters=[p for p in model.parameters() if p.requires_grad]
            if not parameters:
                fail("E_AUXILIARY","freeze","stage freezes every parameter")
            from .objectives import make_optimizer, make_scheduler, clip_gradients, objective_name
            optimizer=make_optimizer(parameters,config)
            scheduler=make_scheduler(optimizer,config)
            best,significant,bad,best_epoch=float("inf"),float("inf"),0,0
            best_state=None
            stop="epochs_completed"
            start_epoch=global_epoch+1
            for epoch in range(1,stage["epochs"]+1):
                started=time.perf_counter()
                learning_rate=optimizer.param_groups[0]["lr"]
                model.train()
                for module in frozen:
                    module.eval()
                sums=np.zeros(4,dtype=np.float64)
                order=rng.permutation(train)
                for offset in range(0,len(order),config["batch_size"]):
                    check_cancel(cancelled)
                    rows=order[offset:offset+config["batch_size"]]
                    optimizer.zero_grad(set_to_none=True)
                    loss,stats=objective_components(model,data,rows,device,stage,config)
                    if (stage["regression_weight"] and stats[1]) or (stage["reconstruction_weight"] and stats[3]):
                        if not loss.requires_grad:
                            fail("E_AUXILIARY","freeze","active objective has no trainable path")
                        loss.backward()
                        if any(p.grad is not None and not torch.isfinite(p.grad).all() for p in parameters):
                            fail("E_AUXILIARY","gradient","nonfinite gradient")
                        clip_gradients(parameters,config)
                        optimizer.step()
                    sums+=stats
                training_value,training_reg,training_rec=aggregate(sums,stage)
                model.eval()
                sums=np.zeros(4,dtype=np.float64)
                with torch.no_grad():
                    for offset in range(0,len(validation),config["batch_size"]):
                        check_cancel(cancelled)
                        _,stats=objective_components(model,data,validation[offset:offset+config["batch_size"]],device,stage,config)
                        sums+=stats
                value,val_reg,val_rec=(None,None,None) if fixed else aggregate(sums,stage)
                global_epoch+=1
                if fixed or value<best:
                    best,best_epoch=value,global_epoch
                    best_state={k:v.detach().cpu().clone() for k,v in model.state_dict().items()}
                if fixed or value<significant-config["min_delta"]:
                    significant,bad=value,0
                else:
                    bad+=1
                record=dict(epoch=global_epoch,train_online_mse=training_value,validation_mse=value,
                    best_epoch=best_epoch,bad_epochs=bad,seconds=time.perf_counter()-started,
                    stage=index,stage_epoch=epoch,stage_mode=stage["mode"],
                    train_regression_mse=training_reg,train_reconstruction_mse=training_rec,
                    validation_regression_mse=val_reg,validation_reconstruction_mse=val_rec,
                    regression_weight=stage["regression_weight"],reconstruction_weight=stage["reconstruction_weight"])
                record.update(train_loss=training_value,validation_loss=value,loss_name=objective_name(config),
                              learning_rate=learning_rate,train_regression_loss=training_reg,validation_regression_loss=val_reg,
                              epoch_limit=sum(s['epochs'] for s in config['stages']), stage_epoch_limit=stage['epochs'])
                if scheduler is not None:
                    scheduler.step()
                history.append(record)
                if progress:
                    progress(dict(record))
                if bad>=config["patience"]:
                    stop="early_stopping"; break
            model.load_state_dict(best_state,strict=True)
            summary=dict(index=index,config=stage,first_global_epoch=start_epoch,last_global_epoch=global_epoch,
                best_global_epoch=best_epoch,best_validation_objective=best,stop_reason=stop,
                frozen_owner_indices=owners,optimizer_reset=True,scheduler_reset=True,regression_loss=config["loss"],
                reconstruction_target="training-transformed retained observed genotypes only",
                checkpoint_restored_before_next_stage=True)
            summaries.append(summary)
            if checkpoint:
                checkpoint(index,best_state,summary)
        model.eval()
        result=FitResult(model,history,best_epoch,best,stop)
        result.stages=summaries
        return result
