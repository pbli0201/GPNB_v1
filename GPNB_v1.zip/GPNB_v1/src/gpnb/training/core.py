from __future__ import annotations

import os
import time
from contextlib import contextmanager
from dataclasses import dataclass

import numpy as np
import torch

from ..config import RunSpec, default_run, fail
from ..models.core import DEFAULT_PARAMETER_BYTES, build_model, inspect_model, check_execution


def validate_training(config):
    run = default_run().to_dict()
    run["training"] = config
    RunSpec(run)
    if config["device"] == "cuda" and not torch.cuda.is_available():
        fail("E_DEVICE", "cuda", "CUDA requested but unavailable; select CPU explicitly or use the validated CUDA environment")


def effective_training(config, spec):
    """Explicit policy: strict CUDA pooling is opt-in; all other models retain the request."""
    result = dict(config)
    if (config["device"] == "cuda" and not config.get("adaptive_max_pool_strict", False)
            and any(row["type"] == "AdaptiveMaxPool1d" for row in spec.to_dict()["layers"])):
        result["deterministic"] = False
    return result


@contextmanager
def execution_context(config):
    """Local RNG and backend settings. Intended for one training job per process."""
    validate_training(config)
    cuda = config["device"] == "cuda"
    previous_env = os.environ.get("CUBLAS_WORKSPACE_CONFIG")
    old = (torch.get_num_threads(), torch.are_deterministic_algorithms_enabled(),
           torch.is_deterministic_algorithms_warn_only_enabled(), torch.backends.cudnn.benchmark,
           torch.backends.cudnn.deterministic, torch.backends.cuda.matmul.allow_tf32, torch.backends.cudnn.allow_tf32)
    if config["deterministic"]:
        os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
    try:
        with torch.random.fork_rng(devices=[0] if cuda else []):
            torch.set_num_threads(config["threads"])
            torch.use_deterministic_algorithms(config["deterministic"], warn_only=False)
            torch.backends.cudnn.benchmark = False
            torch.backends.cudnn.deterministic = config["deterministic"]
            torch.backends.cuda.matmul.allow_tf32 = False
            torch.backends.cudnn.allow_tf32 = False
            torch.random.default_generator.manual_seed(config["seed"])
            if cuda:
                torch.cuda.default_generators[0].manual_seed(config["seed"])
            yield torch.device("cuda:0" if cuda else "cpu")
    finally:
        torch.set_num_threads(old[0])
        torch.use_deterministic_algorithms(old[1], warn_only=old[2])
        torch.backends.cudnn.benchmark, torch.backends.cudnn.deterministic = old[3:5]
        torch.backends.cuda.matmul.allow_tf32, torch.backends.cudnn.allow_tf32 = old[5:]
        if previous_env is None:
            os.environ.pop("CUBLAS_WORKSPACE_CONFIG", None)
        else:
            os.environ["CUBLAS_WORKSPACE_CONFIG"] = previous_env


def _inputs(data, rows, device, model=None):
    from ..data.encoding import model_inputs
    raw = data.cache.batch(rows)
    from ..data.kernel_features import transform_inputs
    x, kernel = transform_inputs(data, raw, getattr(model, "input_representation", "standardized_dosage"))
    tensor = torch.as_tensor(x, device=device)
    if not torch.isfinite(tensor).all():
        fail("E_TRAIN", "inputs", "nonfinite transformed genotype")
    external = getattr(model, "plan", {}).get("external_inputs", {})
    inputs = {"$input": tensor}
    if external:
        arrays = getattr(data, "additional_inputs", {})
        kernel_names = {"kernel"} if kernel is not None else set()
        if set(arrays) | kernel_names != set(external):
            fail("E_INPUT_TABLE", "training", "missing or extra fitted input branches")
        inputs.update({"$input:"+name: torch.as_tensor(arrays[name][rows], device=device) for name in arrays})
        if kernel is not None:
            inputs["$input:kernel"] = torch.as_tensor(kernel, device=device)
    if getattr(model, "plan", {}).get("reference_state"):
        from ..graphs.individual import query_context
        context = query_context(data.reference_spec, data.reference_state, data.reference_features,
                                x, [[data.samples[i]["FID"], data.samples[i]["IID"]] for i in rows])
        inputs["$reference"] = {key: torch.as_tensor(value, device=device) for key, value in context.items()}
    if len(inputs) > 1:
        return inputs
    return tensor


def _targets(data, rows, device):
    if hasattr(data,"target_state"):
        from ..data.multitask import transform_targets
        y=transform_targets(data.target_values[rows],data.target_state)
        tensor=torch.as_tensor(y,dtype=torch.float32,device=device)
        if torch.isinf(tensor).any():
            fail("E_MULTITASK","targets","target overflows float32")
        return tensor
    values = [float(data.samples[i]["value"]) for i in rows]
    y = data.state.transform_target(values)
    tensor = torch.as_tensor(y, dtype=torch.float32, device=device).reshape(-1, 1)
    if not torch.isfinite(tensor).all():
        fail("E_TRAIN", "targets", "target overflows float32 or is nonfinite")
    return tensor


def _loss(prediction, target, config=None):
    if prediction.shape != target.shape or prediction.ndim != 2 or prediction.shape[1] != 1:
        fail("E_TRAIN", "loss", "prediction and target must both be [batch, 1]; broadcasting is forbidden")
    from .objectives import elementwise_loss
    loss = elementwise_loss(prediction, target, config).mean()
    if not torch.isfinite(loss):
        fail("E_TRAIN", "loss", f"nonfinite {(config or {}).get('loss', 'mse').upper()}; check target scaling and learning rate")
    return loss


def check_cancel(cancelled):
    if cancelled and cancelled():
        fail("E_CANCELLED", "worker", "cancel requested at a computation boundary")


def loss_for_data(prediction,target,data,config=None):
    if hasattr(data,"target_state"):
        from ..data.multitask import masked_loss
        return masked_loss(prediction,target,[t["weight"] for t in data.target_state["contract"]["targets"]],config=config)[0]
    return _loss(prediction,target,config)


def validation_loss(model, data, rows, batch_size, device, cancelled=None, config=None):
    model.eval()
    total = 0.0
    multi=hasattr(data,"target_state")
    if multi:
        from ..data.multitask import masked_loss,aggregate_loss
        weights=[t["weight"] for t in data.target_state["contract"]["targets"]]
        sums,counts=np.zeros(len(weights)),np.zeros(len(weights))
    with torch.no_grad():
        for start in range(0, len(rows), batch_size):
            check_cancel(cancelled)
            selected = rows[start:start + batch_size]
            prediction,target=model(_inputs(data,selected,device,model)),_targets(data,selected,device)
            if multi:
                _,batch_sums,batch_counts=masked_loss(prediction,target,weights,config=config)
                sums+=batch_sums.cpu().numpy().astype(np.float64)
                counts+=batch_counts.cpu().numpy()
            else:
                total += float(_loss(prediction,target,config))*len(selected)
    if multi:
        return aggregate_loss(sums,counts,weights)
    return total / len(rows)


@dataclass
class FitResult:
    model: torch.nn.Module
    history: list
    best_epoch: int
    best_validation_loss: float | None
    stop_reason: str


def fit_model(data, spec, config, *, progress=None, cancelled=None,
              max_parameter_bytes=DEFAULT_PARAMETER_BYTES, checkpoint=None):
    """Uses only train and validation rows. No test read or test-driven decision."""
    config = effective_training(config, spec)
    validate_training(config)
    fixed = config.get("selection_mode") == "fixed_epochs"
    check_cancel(cancelled)
    if "stages" in config:
        from .stages import fit_staged
        return fit_staged(data,spec,config,progress=progress,cancelled=cancelled,
                          max_parameter_bytes=max_parameter_bytes,checkpoint=checkpoint)
    train, validation = data.split.rows("train"), data.split.rows("validation")
    if not len(train) or (not fixed and not len(validation)) or np.intersect1d(train, validation).size:
        fail("E_TRAIN", "split", "training and validation must be nonempty and disjoint")
    data.reference_spec = spec.to_dict().get("individual_graph_spec")
    if data.reference_spec and (getattr(data, "reference_state", None) is None or getattr(data, "reference_features", None) is None):
        fail("E_REFERENCE", "training", "fit reference state/data before model training; architecture zeros cannot train")
    check_execution(inspect_model(spec, data.input_features, graph_state=getattr(data, "graph_state", None),
                                  reference_state=getattr(data, "reference_state", None)), config["device"], config["deterministic"],
                    config["batch_size"], len(train))
    with execution_context(config) as device:
        model = build_model(spec, data.input_features, seed=config["seed"],
                            max_parameter_bytes=max_parameter_bytes, graph_state=getattr(data, "graph_state", None),
                            reference_state=getattr(data, "reference_state", None), reference_data=getattr(data, "reference_features", None)).to(device)
        from .objectives import make_optimizer, make_scheduler, clip_gradients, objective_name
        optimizer = make_optimizer(model.parameters(), config)
        scheduler = make_scheduler(optimizer, config)
        rng = np.random.Generator(np.random.PCG64(config["seed"]))
        best, significant_best, best_epoch, bad = float("inf"), float("inf"), 0, 0
        best_state, history, stop = None, [], "epochs_completed"
        for epoch in range(1, config["epochs"] + 1):
            started = time.perf_counter()
            learning_rate = optimizer.param_groups[0]["lr"]
            model.train()
            order = rng.permutation(train)
            total = 0.0
            for start in range(0, len(order), config["batch_size"]):
                if cancelled and cancelled():
                    fail("E_CANCELLED", "training", "cancel requested at batch boundary")
                selected = order[start:start + config["batch_size"]]
                optimizer.zero_grad(set_to_none=True)
                loss = loss_for_data(model(_inputs(data, selected, device, model)), _targets(data, selected, device),data,config)
                loss.backward()
                if any(p.grad is not None and not torch.isfinite(p.grad).all() for p in model.parameters()):
                    fail("E_TRAIN", "gradients", "nonfinite gradient; no optimizer step performed")
                clip_gradients(model.parameters(), config)
                optimizer.step()
                total += float(loss.detach()) * len(selected)
            value = None if fixed else validation_loss(model, data, validation, config["batch_size"], device, cancelled, config)
            # Always preserve the true minimum. min_delta affects patience only.
            if fixed or value < best:
                best, best_epoch = value, epoch
                best_state = {key: tensor.detach().cpu().clone() for key, tensor in model.state_dict().items()}
            if fixed or value < significant_best - config["min_delta"]:
                significant_best, bad = value, 0
            else:
                bad += 1
            record = {"epoch": epoch, "train_online_mse": total / len(train), "validation_mse": value,
                      "best_epoch": best_epoch, "bad_epochs": bad, "seconds": time.perf_counter() - started}
            record.update(train_loss=total / len(train), validation_loss=value,
                          loss_name=objective_name(config), learning_rate=learning_rate,
                          epoch_limit=config['epochs'])
            # Legacy *_mse columns remain aliases for existing result readers.
            # loss_name is authoritative; new displays use *_loss.
            if scheduler is not None:
                scheduler.step()
            history.append(record)
            if progress:
                progress(dict(record))
            if bad >= config["patience"]:
                stop = "early_stopping"
                break
        model.load_state_dict(best_state, strict=True)
        model.eval()
        return FitResult(model, history, best_epoch, best, stop)


def predict_rows(model, data, rows, batch_size, device, cancelled=None):
    """Predict without accessing labels. Returned values are on input phenotype scale."""
    model.eval()
    if not len(rows):
        return np.empty((0, len(data.target_state["mean"]))) if hasattr(data, "target_state") else np.empty(0)
    predictions = []
    with torch.no_grad():
        for start in range(0, len(rows), batch_size):
            check_cancel(cancelled)
            result = model(_inputs(data, rows[start:start + batch_size], device, model))
            width=len(data.target_state["mean"]) if hasattr(data,"target_state") else 1
            if result.shape != (min(batch_size, len(rows) - start), width) or not torch.isfinite(result).all():
                fail("E_TRAIN", "prediction", "invalid shape or nonfinite prediction")
            predictions.extend(result.detach().cpu().numpy().astype(np.float64) if hasattr(data,"target_state")
                               else result.detach().cpu().numpy().reshape(-1).astype(np.float64))
    if hasattr(data,"target_state"):
        from ..data.multitask import transform_targets
        return transform_targets(np.asarray(predictions),data.target_state,inverse=True)
    return data.state.inverse_target(np.asarray(predictions))
