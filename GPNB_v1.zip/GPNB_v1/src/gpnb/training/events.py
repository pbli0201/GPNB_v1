"""Compatible event identities and completed-work progress (never a time estimate)."""
from contextlib import contextmanager
from contextvars import ContextVar
from functools import wraps
from pathlib import Path
from uuid import uuid4

_context = ContextVar('gpnb_event_context', default={})
_tracker = ContextVar('gpnb_work_tracker', default=None)


@contextmanager
def event_context(**values):
    token = _context.set({**_context.get(), **values})
    try:
        yield
    finally:
        _context.reset(token)


def enrich(event):
    result = {**_context.get(), **event}
    if result.get('event') in ('search_epoch', 'search_trial'):
        result['fit_purpose'] = 'search_candidate'
    else:
        result.setdefault('fit_purpose', 'model_fit')
    return result


class WorkTracker:
    """Count explicitly planned fits/candidates/publications; terminal != success."""
    def __init__(self, sink):
        self.sink, self.units, self.seen = sink, {}, set()

    def plan(self, task, folds=1, trials=0, operation='train'):
        if operation in ('preflight', 'preview'):
            self.units[(task, 0, operation, 0)] = 'pending'
        else:
            for fold in range(1, folds + 1):
                for trial in range(1, (0 if operation == 'final-refit' and fold == 2 else trials) + 1):
                    self.units[(task, fold, 'candidate', trial)] = 'pending'
                self.units[(task, fold, 'fit', 0)] = 'pending'
                self.units[(task, fold, 'publication', 0)] = 'pending'
            self.units[(task, 0, 'summary', 0)] = 'pending'

    def snapshot(self, status='running'):
        states = list(self.units.values())
        return dict(**_context.get(), event='project_progress', planned_units=len(states),
                    completed_units=sum(s != 'pending' for s in states),
                    **{s + '_units': states.count(s) for s in ('succeeded', 'failed', 'cancelled', 'skipped', 'reused')},
                    progress_basis='planned_work_units_not_elapsed_time', status=status)

    def publish(self, status='running'):
        if self.sink:
            self.sink(enrich(self.snapshot(status)))

    def finish_task(self, task, state):
        pending = [k for k, value in self.units.items() if k[0] == task and value == 'pending']
        for index, key in enumerate(pending):
            self.units[key] = 'skipped' if state in ('failed', 'cancelled') and index > 0 else state
        self.publish()

    def receive(self, event):
        event = enrich(event)
        if self.sink:
            self.sink(event)
        task, fold = event.get('task_id', 'task_001'), event.get('fold', 1) or 1
        kind = event.get('event')
        key = None
        if kind == 'search_trial':
            key = (task, fold, 'candidate', event['trial'])
        elif kind == 'best_restored':
            key = (task, fold, 'fit', 0)
        elif kind == 'completed':
            key = (task, fold, 'publication', 0)
        if key in self.units and self.units[key] == 'pending':
            self.units[key] = 'failed' if event.get('status') == 'failed' else 'succeeded'
            self.publish()


@contextmanager
def tracking(tracker):
    token = _tracker.set(tracker)
    try:
        yield tracker
    finally:
        _tracker.reset(token)


def tracked_operation(operation):
    """Provide the same progress contract to direct CLI and nested GUI jobs."""
    def decorate(fn):
        @wraps(fn)
        def wrapped(project_path, output, **kwargs):
            from ..config import load_spec
            value = load_spec(project_path).to_dict()
            if _tracker.get() is not None or value.get('extensions', {}).get('trait_batch'):
                return fn(project_path, output, **kwargs)
            from .search import candidates
            cv = value['run'].get('extensions', {}).get('cross_validation', {})
            folds = (cv.get('approved_folds') or cv.get('folds') or 1) if operation != 'final-refit' else 2
            options = value['run'].get('extensions', {}).get('search')
            trials = len(list(candidates(options))) if options else 0
            tracker = WorkTracker(kwargs.get('progress'))
            tracker.plan('task_001', folds, trials, operation)
            kwargs['progress'] = tracker.receive
            joint=value.get('extensions',{}).get('multitask',{}).get('targets',[])
            with event_context(run_id=uuid4().hex, task_id='task_001',
                               trait=value['data']['phenotype_options']['trait'], trait_index=1, trait_count=1,
                               joint_target_ids=[target['id'] for target in joint],
                               target_scope='joint_targets' if joint else 'single_trait'), tracking(tracker):
                tracker.publish()
                try:
                    result = fn(project_path, output, **kwargs)
                    tracker.finish_task('task_001', 'succeeded' if result.get('ok') else 'failed')
                    tracker.publish('completed' if result.get('ok') else 'failed')
                    return result
                except BaseException as error:
                    state = 'cancelled' if isinstance(error, KeyboardInterrupt) or getattr(error, 'code', '') == 'E_CANCELLED' else 'failed'
                    tracker.finish_task('task_001', state)
                    tracker.publish(state)
                    raise
        return wrapped
    return decorate
