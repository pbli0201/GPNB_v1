from __future__ import annotations

import numpy as np

from ..config import fail


def regression_metrics(y, prediction):
    y, prediction = np.asarray(y, dtype=np.float64), np.asarray(prediction, dtype=np.float64)
    if y.ndim != 1 or y.shape != prediction.shape or not np.isfinite(y).all() or not np.isfinite(prediction).all():
        fail("E_TRAIN", "metrics", "expected matching finite 1D observations and predictions")
    n = len(y)
    if not n:
        return {"n": 0, "pearson": None, "pearson_reason": "no_samples", "rmse": None, "mae": None,
                **extended_metrics(y, prediction)}
    with np.errstate(over="ignore", invalid="ignore"):
        diff = y - prediction
        scale = np.max(np.abs(diff))
        mae = float(scale * np.mean(np.abs(diff) / scale)) if scale else 0.0
        rmse = float(scale * np.sqrt(np.mean(np.square(diff / scale)))) if scale else 0.0
        a, b = y - y.mean(), prediction - prediction.mean()
    if not np.isfinite([mae, rmse]).all() or not np.isfinite(a).all() or not np.isfinite(b).all():
        fail("E_TRAIN", "metrics", "float64 numerical overflow")
    reason, correlation = None, None
    if n < 2:
        reason = "fewer_than_two_samples"
    elif np.ptp(y) == 0:
        reason = "constant_observed"
    elif np.ptp(prediction) == 0:
        reason = "constant_prediction"
    else:
        # Normalize before dot products to avoid squaring very large values.
        a, b = a / np.max(np.abs(a)), b / np.max(np.abs(b))
        correlation = float(np.clip(np.dot(a / np.linalg.norm(a), b / np.linalg.norm(b)), -1, 1))
    return {"n": n, "pearson": correlation, "pearson_reason": reason, "rmse": rmse, "mae": mae,
            **extended_metrics(y, prediction)}


def average_ranks(values):
    """One-based average ranks; stable, exact ties and no scipy dependency."""
    order = np.argsort(values, kind='stable')
    ranks = np.empty(len(order), dtype=np.float64)
    start = 0
    while start < len(order):
        end = start + 1
        while end < len(order) and values[order[end]] == values[order[start]]:
            end += 1
        ranks[order[start:end]] = (start + 1 + end) / 2
        start = end
    return ranks


def extended_metrics(y, prediction):
    result = dict(mse=None, spearman=None, spearman_reason=None, r2=None, r2_reason=None,
                  bias=None, calibration_intercept=None, calibration_slope=None, calibration_reason=None)
    n = len(y)
    if not n:
        result.update(spearman_reason='no_samples', r2_reason='no_samples', calibration_reason='no_samples')
        return result
    def finite(value):
        return float(value) if np.isfinite(value) else None
    with np.errstate(over='ignore', invalid='ignore', divide='ignore'):
        error = prediction - y
        result['bias'] = finite(np.mean(error))
        result['mse'] = finite(np.mean(error ** 2))
        if n < 2:
            result.update(spearman_reason='fewer_than_two_samples', r2_reason='fewer_than_two_samples', calibration_reason='fewer_than_two_samples')
            return result
        a, b = y - y.mean(), prediction - prediction.mean()
        if np.ptp(y) == 0:
            result['r2_reason'] = 'constant_observed'
        else:
            scale = max(np.max(np.abs(a)), np.max(np.abs(error)))
            result['r2'] = finite(1 - np.sum((error / scale) ** 2) / np.sum((a / scale) ** 2))
            if result['r2'] is None: result['r2_reason'] = 'numerical_overflow'
        if np.ptp(prediction) == 0:
            result['calibration_reason'] = 'constant_prediction'
        else:
            scale = max(np.max(np.abs(a)), np.max(np.abs(b)))
            slope = np.dot(a / scale, b / scale) / np.dot(b / scale, b / scale)
            result['calibration_slope'] = finite(slope)
            result['calibration_intercept'] = finite(y.mean() - slope * prediction.mean())
            if result['calibration_slope'] is None or result['calibration_intercept'] is None:
                result['calibration_reason'] = 'numerical_overflow'
        if np.ptp(y) == 0 or np.ptp(prediction) == 0:
            result['spearman_reason'] = 'constant_observed' if np.ptp(y) == 0 else 'constant_prediction'
        else:
            ra, rb = average_ranks(y), average_ranks(prediction)
            ra -= ra.mean(); rb -= rb.mean()
            result['spearman'] = float(np.clip(np.dot(ra / np.linalg.norm(ra), rb / np.linalg.norm(rb)), -1, 1))
    return result


def baseline_improvement(model_mse, baseline_mse):
    """Fractional MSE reduction, not R-squared or heritability."""
    if baseline_mse is None or model_mse is None:
        return dict(value=None, reason='unavailable')
    if baseline_mse == 0:
        return dict(value=None, reason='zero_baseline_error')
    value = 1 - model_mse / baseline_mse
    return dict(value=float(value) if np.isfinite(value) else None,
                reason=None if np.isfinite(value) else 'numerical_overflow')


def selection_summary(observed, predicted, *, direction, fraction=.1):
    """Descriptive selection on the supplied evaluation pool; never selects a model."""
    y, p = np.asarray(observed, dtype=float), np.asarray(predicted, dtype=float)
    if direction not in ('ascending', 'descending') or not 0 < fraction <= 1:
        fail('E_VALUE', 'ranking', 'choose ascending/descending and a fraction in (0,1]')
    if y.ndim != 1 or y.shape != p.shape or not np.isfinite(y).all() or not np.isfinite(p).all():
        fail('E_VALUE', 'ranking', 'expected paired finite one-dimensional values')
    k = int(np.ceil(len(y) * fraction))
    sign = 1 if direction == 'ascending' else -1
    chosen = np.argsort(sign * p, kind='stable')[:k]
    reference = np.argsort(sign * y, kind='stable')[:k]
    overlap = len(set(chosen) & set(reference))
    return dict(n=len(y), k=k, direction=direction, fraction=fraction, predicted_indices=chosen.tolist(),
                observed_indices=reference.tolist(), overlap=overlap,
                overlap_fraction=overlap / k if k else None, ties='stable_input_order', rounding='ceil',
                interpretation='Observed phenotype ranking, not true breeding-value selection; descriptive only')


def fold_pearson_summary(fold_metrics, *, method="five_fold"):
    """Describe fold variation, never a confidence interval or pooled accuracy.

    Undefined correlations are excluded, not replaced by zero. Leave-one-out
    uses pooled out-of-fold predictions; its one-row folds cannot have Pearson r.
    """
    items = list(fold_metrics)
    result = dict(mean=None, sample_sd=None, ddof=1, valid_folds=0,
                  total_folds=len(items), reason=None,
                  interpretation="Descriptive between-fold variation; folds are not independent replicates and this is not a confidence interval.")
    if method in ("leave_one_individual_out", "leave_one_genotype_group_out"):
        result["reason"] = ("leave_out_use_pooled_oof" if method == "leave_one_individual_out"
                            else "leave_group_use_pooled_oof")
        return result
    values = []
    for metric in items:
        value = metric.get("pearson")
        if value is not None:
            if isinstance(value, bool) or not np.isfinite(value) or not -1 <= value <= 1:
                fail("E_TRAIN", "fold Pearson", "expected a finite correlation in [-1,1] or null")
            values.append(float(value))
    result["valid_folds"] = len(values)
    if values:
        result["mean"] = float(np.mean(values))
    if len(values) >= 2:
        result["sample_sd"] = float(np.std(values, ddof=1))
    else:
        result["reason"] = "fewer_than_two_valid_folds"
    return result
