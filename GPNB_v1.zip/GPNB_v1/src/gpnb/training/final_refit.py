"""Independent internal selection followed by an all-labelled-data deployment fit.

Never selects a fold using its outer test score. Query phenotypes are not inputs.
"""
from __future__ import annotations

import copy
import time
from pathlib import Path

from ..bundle import capture_source, seal, verify_bundle, verify_source
from ..config import ProjectSpec, fail, load_spec, resolve_project_path
from ..data.files import protect_inputs, read_json, snapshot, verify_snapshots, write_json
from .core import check_cancel
from .run import train_project
from .events import tracked_operation, event_context


@tracked_operation('final-refit')
def final_refit_project(project_path, output, *, cache_root=None,
                        max_parameter_bytes=256 * 2**20, progress=None, cancelled=None):
    project_path, output = Path(project_path).resolve(), Path(output).resolve()
    if output.exists():
        fail('E_EXISTS', str(output), 'choose a new final model task directory')
    original = load_spec(project_path)
    if original.to_dict().get('extensions', {}).get('trait_batch'):
        from .trait_batch import run_batch
        return run_batch(project_path, output, operation='final-refit', cache_root=cache_root,
                         max_parameter_bytes=max_parameter_bytes, progress=progress, cancelled=cancelled)
    if not isinstance(original, ProjectSpec):
        fail('E_TYPE', str(project_path), 'a project configuration is required')
    source_snapshot = snapshot(project_path)
    project = original.to_dict()
    from ..data.additional import resolve_table_paths
    resolve_table_paths(project, project_path)
    for name in ('bed', 'bim', 'fam', 'phenotype', 'manifest', 'split_groups'):
        if project['data'][name]:
            project['data'][name] = str(resolve_project_path(project_path, project['data'][name]))
    project['output_dir'] = str(resolve_project_path(project_path, project['output_dir']))
    input_paths = [Path(project['data'][name]) for name in ('bed', 'bim', 'fam', 'phenotype', 'manifest', 'split_groups') if project['data'][name]]
    if project['data'].get('matrix'):
        input_paths.append(Path(project['data']['matrix']['path']))
    input_paths.extend(Path(item['path']) for item in project.get('extensions', {}).get('input_tables', []))
    protect_inputs(output, [project_path, *input_paths])
    input_snapshots = {str(i): snapshot(path) for i, path in enumerate(input_paths)}
    extensions = project['run'].setdefault('extensions', {})
    original_cv = extensions.pop('cross_validation', None)
    selection_fraction = extensions.get('search', {}).get('validation_fraction', .2)
    project['run']['split'].update(method='final_selection', ratios=[1-selection_fraction, selection_fraction, 0.], reuse_manifest=None)
    project['run']['training']['selection_mode'] = 'validation'
    provenance = dict(protocol='internal_holdout_then_all_eligible_refit_v1',
        source_project_sha256=original.sha256, original_cross_validation=original_cv,
        selection='Fresh internal training/validation; never outer-test ranking',
        independent_test_metrics=None, query_phenotypes_used=False,
        interpretation='Prior cross-validation scores describe that evaluated process, not a new independent score of this final model.')
    project.setdefault('extensions', {})['final_refit'] = provenance
    ProjectSpec(project)
    check_cancel(cancelled)
    output.mkdir(parents=True)
    (output/'INCOMPLETE').write_text('Final model task in progress\n', encoding='utf-8')
    started = time.perf_counter()
    def emit(stage):
        check_cancel(cancelled)
        if progress:
            progress(dict(event='stage', stage=stage))
    try:
        source_hashes = capture_source(output)
        original.save(output/'project_original.json')
        ProjectSpec(project).save(output/'selection_project.json')
        emit('final_internal_selection')
        with event_context(fold=1, fit_purpose='internal_selection'):
            selected_summary = train_project(output/'selection_project.json', output/'selection', cache_root=cache_root,
                max_parameter_bytes=max_parameter_bytes, progress=progress, cancelled=cancelled)
        selection_sources = read_json(output/'selection/prepared/input_descriptor.json')['source_files']
        verify_snapshots(input_snapshots)
        selected = read_json(output/'selection/project.json')
        selected['run'].setdefault('extensions', {}).pop('search', None)
        selected['run']['split'].update(method='final_training', ratios=[1., 0., 0.], reuse_manifest=None)
        training = selected['run']['training']
        training['selection_mode'] = 'fixed_epochs'
        training['epochs'] = selected_summary['best_epoch']
        if 'training_stages' in selected_summary:
            # Each stage restores its own minimum; use that stage's local epoch.
            for stage, evidence in zip(training['stages'], selected_summary['training_stages'], strict=True):
                stage['epochs'] = evidence['best_global_epoch'] - evidence['first_global_epoch'] + 1
            training['epochs'] = sum(stage['epochs'] for stage in training['stages'])
        provenance.update(selected_epochs=training['epochs'],
            selected_stage_epochs=[s['epochs'] for s in training.get('stages', [])],
            selection_member='selection', all_data_member='model', refit_preprocessing=True,
            refit_kernel_reference=True, weights_reinitialized=True)
        selected.setdefault('extensions', {})['final_refit'] = copy.deepcopy(provenance)
        ProjectSpec(selected).save(output/'final_project.json')
        emit('final_all_data_refit')
        # A change between the two individually guarded fits must not be accepted
        # as a new training dataset for the already-selected hyperparameters.
        verify_snapshots(input_snapshots)
        verify_snapshots(selection_sources)
        with event_context(fold=2, fit_purpose='final_refit'):
            final_summary = train_project(output/'final_project.json', output/'model', cache_root=cache_root,
                max_parameter_bytes=max_parameter_bytes, progress=progress, cancelled=cancelled)
        verify_bundle(output/'selection', 'training_run')
        verify_bundle(output/'model', 'training_run')
        verify_snapshots({'source_project': source_snapshot})
        verify_snapshots(input_snapshots)
        verify_snapshots(selection_sources)
        final_sources = read_json(output/'model/prepared/input_descriptor.json')['source_files']
        if {k: v['sha256'] for k, v in final_sources.items()} != {k: v['sha256'] for k, v in selection_sources.items()}:
            fail('E_CHANGED', 'final_refit.inputs', 'selection and final fitting consumed different source files')
        verify_source(source_hashes)
        summary = dict(ok=True, schema_version=1, kind='final_refit', model_directory='model',
            internal_selection_directory='selection', provenance=provenance,
            dataset_id=final_summary['dataset_id'], trait=final_summary['trait'],
            input_features=final_summary['input_features'], model_sha256=final_summary['model_sha256'],
            elapsed_seconds=time.perf_counter()-started, independent_test_metrics=None,
            training_count=read_json(output/'model/prepared/report.json')['split']['counts']['train'])
        write_json(output/'summary.json', summary)
        check_cancel(cancelled)
        seal(output, 'final_refit')
        (output/'INCOMPLETE').unlink()
        return summary
    except BaseException as error:
        write_json(output/'failure.json', dict(ok=False, error=str(error),
            status='cancelled' if isinstance(error, KeyboardInterrupt) or getattr(error,'code','') == 'E_CANCELLED' else 'failed'))
        raise
