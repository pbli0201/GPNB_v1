"""Independent outer fits; test rows never guide preprocessing or early stopping."""
from __future__ import annotations

import copy
import json
import time
from pathlib import Path

import numpy as np

from ..bundle import capture_source, seal, verify_bundle, verify_source
from ..config import ProjectSpec, fail, load_spec, resolve_project_path
from ..data import inspect_project
from ..data.cache import identity_key, load_cache
from ..data.descriptor import load_descriptor
from ..data.files import protect_inputs, read_json, snapshot, verify_snapshots, write_csv, write_json
from ..data.folds import fold_value, load_plan, make_plan, save_plan, fold_count
from ..data.prepare import prepare_project, table
from ..data.split import SplitManifest, genotype_groups, context_for_policy
from .core import check_cancel
from .metrics import regression_metrics, fold_pearson_summary
from .events import enrich, event_context


def cv_project(project_path, output, *, cache_root, max_parameter_bytes, progress=None, cancelled=None):
    from .run import train_project
    project_path, output, cache_root = map(lambda p: Path(p).resolve(), (project_path, output, cache_root))
    if output.exists():
        fail("E_EXISTS", str(output), "choose a new cross-validation output directory")
    source = snapshot(project_path)
    project = load_spec(project_path).to_dict()
    from ..data.additional import resolve_table_paths
    resolve_table_paths(project, project_path)
    options = project["run"]["extensions"]["cross_validation"]
    protect_inputs(output, [project_path])
    if output.is_relative_to(cache_root) or cache_root.is_relative_to(output):
        fail("E_IO", str(output), "CV output and raw cache must not overlap")
    for key, value in project["data"].items():
        if key in ("bed", "bim", "fam", "phenotype", "manifest", "split_groups") and value is not None:
            project["data"][key] = str(resolve_project_path(project_path, value))
    if options["reuse_manifest"]:
        options["reuse_manifest"] = str(resolve_project_path(project_path, options["reuse_manifest"]))
    output.mkdir(parents=True)
    (output / "INCOMPLETE").write_text("Cross validation incomplete", encoding="utf-8")
    started = time.perf_counter()
    completed = 0
    preparation_seconds = 0.0

    def emit(event):
        event = enrich(event)
        check_cancel(cancelled)
        with (output / "events.jsonl").open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(event, ensure_ascii=False, allow_nan=False) + "\n")
        if progress:
            progress(event)

    try:
        def stage(name, done=0, total=0):
            emit(dict(event="stage", stage=name, done=done, total=total))
        source_hashes = capture_source(output)
        preparing_started = time.perf_counter()
        ProjectSpec(project).save(output / "project.json")
        report = inspect_project(output / "project.json", output / "import", scan=True, cache_root=cache_root, progress=stage)
        if not report["ok"]:
            fail("E_FORMAT", str(output / "import"), "cross-validation import failed")
        descriptor = load_descriptor(output / "import")
        cache = load_cache(Path(descriptor["cache"]["path"]))
        samples = table(output / "import/samples.csv")
        groups = genotype_groups(cache, [s["genotype_equivalence_group"] for s in samples], progress=stage)
        context = dict(dataset_id=descriptor["dataset_id"], trait=project["data"]["phenotype_options"]["trait"],
                       cache_key=cache.metadata["key"], phenotype_sha256=descriptor["source_files"]["phenotype"]["sha256"],
                       phenotype_options=project["data"]["phenotype_options"],
                       sample_ids=[[s["FID"], s["IID"]] for s in samples],
                       groups=groups, eligible=[s["match_status"] == "matched_finite_label" for s in samples])
        from ..data.multitask import contract
        multitask=contract(project)
        if multitask:
            context["multitask"]=multitask
        context = context_for_policy(context, project["run"]["split"])
        from ..data.batch_split import bind_context
        context = bind_context(context, project, project_path)
        plan = (load_plan(Path(options["reuse_manifest"]), context, options) if options["reuse_manifest"]
                else make_plan(context, options))
        save_plan(plan, output / "cv_plan.json")
        total_folds = fold_count(plan)
        method = options.get("method", "five_fold")
        if method not in ("five_fold", "ten_fold") and options.get("approved_folds") != total_folds:
            fail("E_SPLIT", "approved_folds", f"preview and acknowledge {total_folds} independent models before leave-out training; set approved_folds={total_folds}")
        # Check every inner partition before fitting the first model, including sparse multi-target labels.
        from ..data.multitask import read_targets
        values = (read_targets(project, Path(project["data"]["phenotype"]), context["sample_ids"]) if multitask else
                  np.asarray([float(s["value"]) if s["match_status"] == "matched_finite_label" else np.nan for s in samples])[:, None])
        for fold in range(1, total_folds + 1):
            stage("validate_fold", fold, total_folds)
            partitions = fold_value(plan, fold)["partitions"]
            for part in ("train", "validation"):
                if part == "validation" and not partitions[part]:
                    continue
                if np.any(np.isfinite(values[partitions[part]]).sum(0) == 0):
                    fail("E_SPLIT", f"fold {fold}/{part}", "a selected target has no observations")
        preparation_seconds += time.perf_counter() - preparing_started
        runs, rows, seen = [], [], set()
        (output / "splits").mkdir()
        (output / "projects").mkdir()
        for fold in range(1, total_folds + 1):
            emit(dict(event="fold_start", fold=fold, folds=total_folds))
            split = SplitManifest(fold_value(plan, fold))
            split.validate(context)
            split_path = output / "splits" / f"fold_{fold}.json"
            split.save(split_path)
            current = copy.deepcopy(project)
            current["run"]["extensions"].pop("cross_validation")
            current["run"]["split"].update(seed=options["seed"], ratios=split.value["requested_ratios"],
                                            reuse_manifest=str(split_path))
            if not len(split.rows("validation")):
                current["run"]["training"]["selection_mode"] = "fixed_epochs"
            fold_project = output / "projects" / f"fold_{fold}.json"
            ProjectSpec(current).save(fold_project)
            prepared = output / "prepared" / f"fold_{fold}"
            preparing_started = time.perf_counter()
            prepare_project(fold_project, output / "import", prepared, progress=stage)
            preparation_seconds += time.perf_counter() - preparing_started
            check_cancel(cancelled)
            run = output / "folds" / f"fold_{fold}"
            with event_context(fold=fold, folds=total_folds):
                summary = train_project(fold_project, run, prepared_dir=prepared, cache_root=cache_root,
                                        max_parameter_bytes=max_parameter_bytes,
                                        progress=lambda e, f=fold: emit({**e, "fold": f, "folds": total_folds}),
                                        cancelled=cancelled)
            runs.append(dict(fold=fold, directory=run.relative_to(output).as_posix(), summary=summary))
            for row in table(run / "predictions.csv"):
                if row["partition"] != "test":
                    continue
                i = int(row["fam_index"])
                key=(i,row["target_id"]) if multitask else i
                if key in seen or i not in split.value["partitions"]["test"] or [row["FID"], row["IID"]] != context["sample_ids"][i]:
                    fail("E_SPLIT", "OOF", "duplicate, mismatched or non-test prediction")
                seen.add(key)
                rows.append(row)
            completed = fold
            elapsed = time.perf_counter() - started
            write_json(output / "progress.json", dict(completed_folds=completed, folds=total_folds, elapsed_seconds=elapsed,
                       remaining_seconds_estimate=elapsed / completed * (total_folds-completed),
                       estimate_basis="elapsed / completed folds; includes initial import; fold sizes and early stopping may differ"))
            emit(dict(event="fold_completed", fold=fold, folds=total_folds, test_metrics=summary["test_metrics"]))
        eligible = {i for i, e in enumerate(context["eligible"]) if e}
        expected={(i,t["id"]) for i in eligible for t in multitask["targets"]} if multitask else eligible
        if seen != expected:
            fail("E_SPLIT", "OOF", "every eligible individual must have exactly one outer-test prediction")
        rows.sort(key=lambda r: int(r["fam_index"]))
        fields = list(rows[0])
        write_csv(output / "predictions.csv", fields, ([r[k] for k in fields] for r in rows))
        display_rows=([r for r in rows if r["target_id"]==multitask["targets"][0]["id"] and r["observed"]!=""] if multitask else rows)
        observed = np.array([float(r["observed"]) for r in display_rows])
        predicted = np.array([float(r["predicted"]) for r in display_rows])
        metrics = regression_metrics(observed, predicted)
        summary = dict(ok=True, schema_version=1, kind="cross_validation", dataset_id=context["dataset_id"],
                       trait=context["trait"], seed=project["run"]["training"]["seed"],
                       split_seed=options["seed"], folds=total_folds, method=method, model_sha256=rows[0]["model_sha256"],
                       plan_sha256=identity_key(plan), oof_metrics=metrics,
                       fold_runs=runs, excluded=len(samples)-len(eligible),
                       evaluation=f"{method} outer OOF; policy={options.get('training_policy', 'inner_holdout')}; search={'search' in project['run'].get('extensions', {})}; no outer-test tuning.",
                       elapsed_seconds=time.perf_counter()-started,
                       metric_aggregation="pooled OOF predictions; never mean of per-fold Pearson correlations",
                       interpretation="Input phenotype scale; OOF pooled metrics are not a breeding-value accuracy estimate.",
                       no_single_model=True)
        summary['model_sha256_scope'] = 'first fold only; search may select different models in other folds'
        summary['model_sha256_by_fold'] = {str(r['fold']):r['summary']['model_sha256'] for r in runs}
        fold_mae=[r['summary']['test_metrics']['mae'] for r in runs]
        summary['fold_mean_mae'] = float(np.mean(fold_mae)) if all(v is not None for v in fold_mae) else None
        summary['fold_mean_mae_note'] = 'Equal-fold mean; equals pooled MAE only for equal-size fully observed test folds.'
        summary['fold_pearson'] = fold_pearson_summary(
            [r['summary']['test_metrics'] for r in runs], method=method)
        by_target={}
        if multitask:
            for target in multitask["targets"]:
                selected=[r for r in rows if r["target_id"]==target["id"] and r["observed"]!=""]
                by_target[target["id"]]=regression_metrics([float(r["observed"]) for r in selected],
                                                          [float(r["predicted"]) for r in selected])
            summary.update(multitask=multitask,oof_metrics_by_target=by_target,display_target=multitask["targets"][0]["id"])
            summary['fold_pearson_by_target'] = {
                target['id']: fold_pearson_summary(
                    [r['summary']['test_metrics_by_target'][target['id']] for r in runs], method=method)
                for target in multitask['targets']}
        timing = {key: sum(r['summary'].get('timing', {}).get(key, 0.0) for r in runs)
                  for key in ('preparation_seconds', 'search_seconds', 'fit_seconds', 'prediction_seconds')}
        timing['preparation_seconds'] += preparation_seconds
        timing['scope'] = 'joint_multi_target' if multitask else 'single_target'
        timing['basis'] = 'Measured monotonic wall time through plot generation, input verification and all fold archive checks; excludes the final CV manifest hashing. Shared-target time is not divided among traits.'
        write_json(output / "metrics.json", {"oof_pooled": metrics,
                                            "oof_by_target":by_target,
                                            "fold_pearson":summary['fold_pearson'],
                                            "fold_pearson_by_target":summary.get('fold_pearson_by_target', {}),
                                            "fold_test": [r["summary"]["test_metrics"] for r in runs]})
        environment = read_json(output / runs[0]["directory"] / "environment.json")
        environment.update(original_project_sha256=load_spec(project_path).sha256,
                           source_sha256=source_hashes, evaluation="cross_validation")
        write_json(output / "environment.json", environment)
        _scatter(output, observed, predicted)
        verify_snapshots({"project": source, **descriptor["source_files"]})
        verify_source(source_hashes)
        for r in runs:
            verify_bundle(output / r["directory"], "training_run")
        check_cancel(cancelled)
        timing['total_seconds'] = time.perf_counter() - started
        timing['archival_overhead_seconds'] = max(0.0, timing['total_seconds'] - sum(timing[k] for k in (
            'preparation_seconds', 'search_seconds', 'fit_seconds', 'prediction_seconds')))
        summary['elapsed_seconds'] = timing['total_seconds']
        summary['timing'] = timing
        write_json(output / 'timing.json', timing)
        write_json(output / "summary.json", summary)
        seal(output, "cross_validation")
        (output / "INCOMPLETE").unlink()
        return summary
    except BaseException as error:
        write_json(output / "failure.json", dict(ok=False, error=str(error),
                   completed_folds=completed, elapsed_seconds=time.perf_counter()-started,
                   status="cancelled" if isinstance(error, KeyboardInterrupt) or getattr(error, "code", "") == "E_CANCELLED" else "failed"))
        raise


def _scatter(output, observed, predicted):
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    from matplotlib.figure import Figure
    figure = Figure(figsize=(5, 5), layout="constrained")
    FigureCanvasAgg(figure)
    axes = figure.subplots()
    axes.scatter(observed, predicted, s=12, alpha=.6)
    lo, hi = min(observed.min(), predicted.min()), max(observed.max(), predicted.max())
    axes.plot([lo, hi], [lo, hi], "--", color="gray")
    axes.set(xlabel="Observed", ylabel="OOF predicted", title="Outer-test predictions")
    figure.savefig(output / "test_scatter.png", dpi=140)
