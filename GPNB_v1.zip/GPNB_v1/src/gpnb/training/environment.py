"""Observed environment evidence; never infer a profile from an env folder name."""
from pathlib import Path
import platform
import subprocess
import sys


def environment_evidence(archive, device):
    import torch
    from .. import __version__
    from ..branding import APP_NAME
    from ..environment_profiles import load_profiles
    from ..data.files import sha256
    requirements = Path(archive) / 'requirements'
    result = dict(application_name=APP_NAME, application_version=__version__,
                  python_executable=sys.executable, environment_profile=None,
                  profile_match_basis='exact installed torch build; package versions recorded separately',
                  profile_manifest_sha256=None, dependency_lock_sha256=None)
    if (requirements/'profiles.json').is_file():
        policy = load_profiles(archive)
        matches = [(key, value) for key, value in policy['profiles'].items() if value['torch'] == str(torch.__version__)]
        result['profile_manifest_sha256'] = sha256(requirements/'profiles.json')
        if len(matches) == 1:
            key, value = matches[0]
            result.update(environment_profile=key, environment_profile_definition=value,
                          profile_python_matches=platform.python_version()==policy['python'],
                          dependency_lock_file=value['lock'],
                          dependency_lock_sha256=sha256(requirements/value['lock']))
    result['gpu_devices'] = []
    if device == 'cuda':
        props = torch.cuda.get_device_properties(0)
        result['gpu_devices'].append(dict(logical_index=0, name=props.name,
            capability=list(torch.cuda.get_device_capability(0)), total_memory_bytes=props.total_memory))
    try:
        probe = subprocess.run(['nvidia-smi', '--query-gpu=index,name,driver_version', '--format=csv,noheader'],
            capture_output=True, text=True, encoding='utf8', errors='replace', timeout=5,
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        result['nvidia_driver_inventory'] = probe.stdout.strip() if probe.returncode == 0 else None
        result['driver_query_status'] = 'available' if probe.returncode == 0 else 'unavailable'
    except (OSError, subprocess.TimeoutExpired):
        result.update(nvidia_driver_inventory=None, driver_query_status='unavailable')
    return result
