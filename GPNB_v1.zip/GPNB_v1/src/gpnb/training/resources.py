from __future__ import annotations

import threading
import time

import psutil
import torch


class ResourceMonitor:
    """RSS samples are a lower bound on peak; CUDA counters are allocator peaks."""
    def __init__(self, device, interval=.1):
        self.device, self.interval = device, interval
        self.process = psutil.Process()
        self.samples = []
        self.event = threading.Event()

    def start(self):
        self.started = time.perf_counter()
        self.cpu_started = sum(self.process.cpu_times()[:2])
        self.gpu_baseline = None
        if self.device == "cuda":
            torch.cuda.synchronize(0)
            torch.cuda.reset_peak_memory_stats(0)
            self.gpu_baseline = {"allocated": torch.cuda.memory_allocated(0), "reserved": torch.cuda.memory_reserved(0)}
        self._sample()
        self.thread = threading.Thread(target=self._run, daemon=True, name="gpnb-resource-monitor")
        self.thread.start()
        return self

    def _sample(self):
        self.samples.append({"elapsed_seconds": time.perf_counter() - self.started,
                             "rss_bytes": self.process.memory_info().rss})

    def _run(self):
        while not self.event.wait(self.interval):
            self._sample()

    def stop(self):
        if self.device == "cuda":
            torch.cuda.synchronize(0)
        self.event.set()
        self.thread.join()
        self._sample()
        return {"elapsed_seconds": time.perf_counter() - self.started,
                "process_cpu_seconds": sum(self.process.cpu_times()[:2]) - self.cpu_started,
                "rss_sampled_peak_bytes": max(s["rss_bytes"] for s in self.samples),
                "sampling_interval_seconds": self.interval, "sample_count": len(self.samples),
                "rss_scope": "whole current process; sampled lower bound, not guaranteed exact peak",
                "cuda_baseline_bytes": self.gpu_baseline,
                "cuda_peak_allocated_bytes": torch.cuda.max_memory_allocated(0) if self.device == "cuda" else None,
                "cuda_peak_reserved_bytes": torch.cuda.max_memory_reserved(0) if self.device == "cuda" else None,
                "cuda_scope": "PyTorch allocator on cuda:0; excludes driver/other processes",
                "scope": "data import/preparation if needed, archive, fit, final evaluation and plotting"}
