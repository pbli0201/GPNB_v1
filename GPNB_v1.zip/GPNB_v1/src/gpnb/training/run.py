from __future__ import annotations

import importlib.metadata
import json
import platform
import shutil
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import torch

from ..config import ModelSpec, ProjectSpec, fail, load_spec, resolve_project_path
from ..data import inspect_project
from ..data.files import protect_inputs, read_json, sha256, snapshot, verify_snapshots, write_csv, write_json
from ..data.prepare import PreparedDataset, prepare_project
from ..data.split import PARTS, SplitManifest
from ..models.core import DEFAULT_PARAMETER_BYTES
from ..models.export import export_inspection
from ..paths import configure_local_paths
from .core import check_cancel, execution_context, fit_model, predict_rows, validate_training
from .metrics import regression_metrics
from .resources import ResourceMonitor
from .events import enrich, tracked_operation


def _binding(project, project_path, prepared, prepared_dir):
    data = project["data"]
    context = prepared.split.value["context"]
    if data["dataset_id"] != context["dataset_id"] or data["phenotype_options"] != context["phenotype_options"]:
        fail("E_MANIFEST", "project.data", "project differs from prepared dataset/trait interpretation")
    if project.get("extensions",{}).get("multitask")!=context.get("multitask"):
        fail("E_MULTITASK","prepared","multi-target observation contract differs from preparation")
    if project["run"]["preprocessing"] != prepared.state.metadata["options"]:
        fail("E_PREPROCESS", "project.run.preprocessing", "options changed; create a new prepared bundle before training")
    prepared.split.validate(context, project["run"]["split"])
    reuse = project["run"]["split"]["reuse_manifest"]
    if reuse:
        split = SplitManifest.load(resolve_project_path(project_path, reuse), context, project["run"]["split"])
        if split.value != prepared.split.value:
            fail("E_SPLIT", "reuse_manifest", "requested split differs from prepared bundle")
    descriptor = read_json(prepared_dir / "input_descriptor.json")
    imported = read_json(prepared_dir / "project_snapshot.json")
    from ..data.genotypes import verify_matrix_binding
    requested = verify_matrix_binding(data, imported["data"], descriptor["source_files"], project_path)
    for key in ("bed", "bim", "fam", "phenotype", "manifest", "split_groups"):
        value = data[key]
        if value is None:
            if imported["data"][key] is not None:
                fail("E_MANIFEST", key, "project removed imported source")
            continue
        requested[key] = snapshot(resolve_project_path(project_path, value))
        if key not in descriptor["source_files"] or requested[key]["sha256"] != descriptor["source_files"][key]["sha256"]:
            fail("E_MANIFEST", key, "project source differs from prepared input")
    return requested


def _plots(directory, history, observed, predicted, multi=False):
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    from matplotlib.figure import Figure
    figure = Figure(figsize=(7, 4), layout="constrained")
    FigureCanvasAgg(figure)
    axes = figure.subplots()
    epochs = [row["epoch"] for row in history]
    axes.plot(epochs, [row["train_online_mse"] for row in history], label="Train (online)")
    if any(row['validation_mse'] is not None for row in history):
        axes.plot(epochs, [row["validation_mse"] for row in history], label="Validation")
    axes.set(xlabel="Epoch", ylabel="Weighted stage objective" if "stage" in history[0] else
             "Weighted masked target loss" if multi else "Loss on training target scale", title="Training history")
    if "stage" in history[0]:
        for previous,current in zip(history,history[1:]):
            if current["stage"] != previous["stage"]:
                axes.axvline(current["epoch"]-.5,color="gray",linestyle=":",linewidth=1)
    axes.legend()
    figure.savefig(directory / "learning_curve.png", dpi=140)
    figure = Figure(figsize=(5, 5), layout="constrained")
    FigureCanvasAgg(figure)
    axes = figure.subplots()
    axes.scatter(observed, predicted, s=14, alpha=.65)
    if len(observed)==0:
        axes.set(title="No observed test labels for this target",xlabel="Observed",ylabel="Predicted")
        figure.savefig(directory/"test_scatter.png",dpi=140)
        return
    lo, hi = min(np.min(observed), np.min(predicted)), max(np.max(observed), np.max(predicted))
    if lo == hi:
        lo, hi = lo - .5, hi + .5
    axes.plot([lo, hi], [lo, hi], "--", color="gray", label="y = x")
    axes.set(xlabel="Observed (input phenotype scale)", ylabel="Predicted (input phenotype scale)",
             title="Held-out test set — engineering run", xlim=(lo, hi), ylim=(lo, hi))
    axes.legend()
    figure.savefig(directory / "test_scatter.png", dpi=140)


@tracked_operation('train')
def train_project(project_path, output, *, prepared_dir=None, cache_root=None,
                  max_parameter_bytes=DEFAULT_PARAMETER_BYTES, progress=None, cancelled=None):
    started = time.perf_counter()
    timing = dict(preparation_seconds=0., search_seconds=0., fit_seconds=0., prediction_seconds=0.)
    root = configure_local_paths()
    project_path, output = Path(project_path).resolve(), Path(output).resolve()
    if output.exists():
        fail("E_EXISTS", str(output), "choose a new run directory; completed and failed experiments are preserved")
    protect_inputs(output, [project_path])
    project_before = snapshot(project_path)
    spec = load_spec(project_path)
    if spec.to_dict().get('extensions', {}).get('trait_batch'):
        from .trait_batch import run_batch
        return run_batch(project_path, output, operation='train', cache_root=cache_root,
                         max_parameter_bytes=max_parameter_bytes, progress=progress, cancelled=cancelled)
    if not isinstance(spec, ProjectSpec):
        fail("E_TYPE", str(project_path), "train requires ProjectSpec")
    project = spec.to_dict()
    if "cross_validation" in project["run"].get("extensions", {}):
        if prepared_dir is not None:
            fail("E_SPLIT", "cross_validation", "each fold requires its own fitted preprocessing; cannot reuse one prepared bundle")
        from .cross_validation import cv_project
        return cv_project(project_path, output, cache_root=cache_root or root / "cache/genotypes",
                          max_parameter_bytes=max_parameter_bytes, progress=progress, cancelled=cancelled)
    from .core import effective_training
    config = effective_training(project["run"]["training"], ModelSpec(project["model"]))
    validate_training(config)
    cache_root = Path(cache_root).resolve() if cache_root else root / "cache/genotypes"
    protect_inputs(cache_root, [project_path])
    if cache_root.is_relative_to(output) or output.is_relative_to(cache_root):
        fail("E_IO", str(output), "run and raw cache roots must not overlap")
    original_prepared = Path(prepared_dir).resolve() if prepared_dir else None
    if original_prepared and (output.is_relative_to(original_prepared) or original_prepared.is_relative_to(output)):
        fail("E_IO", str(output), "run and existing prepared directory must not overlap")
    # Bind and validate existing prepared data before creating an experiment.
    data = PreparedDataset.load(original_prepared) if original_prepared else None
    requested = _binding(project, project_path, data, original_prepared) if data else None
    output.mkdir(parents=True)
    (output / "INCOMPLETE").write_text("Training run not complete\n", encoding="utf-8")
    monitor, resource_report = None, None
    log = output / "events.jsonl"
    def event(kind, **values):
        check_cancel(cancelled if kind not in ("cancelled", "failed") else None)
        payload = enrich({"event": kind, "time_utc": datetime.now(timezone.utc).isoformat(), **values})
        with log.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(payload, ensure_ascii=False, allow_nan=False) + "\n")
        if progress:
            progress(payload)
    def stage(name, done=0, total=0):
        event("stage", stage=name, done=done, total=total)
    try:
        from ..bundle import capture_source, verify_source
        source_hashes = capture_source(output)
        monitor = ResourceMonitor(config["device"]).start()
        event("started", dataset=project["data"]["dataset_id"], device=config["device"])
        prepared_dir = output / "prepared"
        if data is None:
            stage("import")
            inspect_project(project_path, output / "import", cache_root=cache_root, progress=stage)
            stage("preprocessing")
            prepare_project(project_path, output / "import", prepared_dir, progress=stage)
            data = PreparedDataset.load(prepared_dir)
            requested = _binding(project, project_path, data, prepared_dir)
        else:
            shutil.copytree(original_prepared, prepared_dir)
            # Verify copied evidence before using it; never refit on archive copy.
            data = PreparedDataset.load(prepared_dir)
        spec.save(output / "project_original.json")
        timing['preparation_seconds'] = time.perf_counter() - started
        if "search" in project["run"].get("extensions", {}):
            search_started = time.perf_counter()
            from .search import search_project
            project = search_project(data, project, project_path, output / "search",
                max_parameter_bytes=max_parameter_bytes,
                progress=lambda e:event(e['event'],**{k:v for k,v in e.items() if k!='event'}), cancelled=cancelled)
            config = effective_training(project["run"]["training"], ModelSpec(project["model"]))
            event('search_selected',model=project['model'],training=config,
                  summary=read_json(output/'search/summary.json'))
            timing['search_seconds'] = time.perf_counter() - search_started
        branch_started = time.perf_counter()
        from ..data.kernel_features import bind_kernel, options as kernel_options
        model_spec = bind_kernel(project, data, output=output/'kernel', progress=stage, cancelled=cancelled)
        project['model'] = model_spec.to_dict()
        # Archive usable paths: copying relative paths to a new directory changes
        # their meaning. Retain the original alongside an explicitly resolved copy.
        import copy
        archived = copy.deepcopy(project)
        archived["run"]["training"] = dict(config)
        from ..data.additional import resolve_table_paths
        resolve_table_paths(archived, project_path)
        for key in ("bed", "bim", "fam", "phenotype", "manifest", "split_groups"):
            if archived["data"][key] is not None:
                archived["data"][key] = str(resolve_project_path(project_path, archived["data"][key]))
        archived["output_dir"] = str(resolve_project_path(project_path, archived["output_dir"]))
        if archived["run"]["split"]["reuse_manifest"] is not None:
            archived["run"]["split"]["reuse_manifest"] = str(
                resolve_project_path(project_path, archived["run"]["split"]["reuse_manifest"]))
        ProjectSpec(archived).save(output / "project.json")
        model_spec = ModelSpec(project["model"])
        from ..data.additional import fit_tables
        input_states, data.additional_inputs, input_sources = fit_tables(project, project_path, data)
        if input_states:
            write_json(output / "input_states.json", input_states)
        from ..graphs.state import fit_graph
        data.graph_state = fit_graph(model_spec, data, stage, cancelled)
        if data.graph_state is not None:
            write_json(output / "graph_state.json", data.graph_state)
        from ..graphs.individual import fit_reference
        data.reference_state, data.reference_features = fit_reference(model_spec, data, cancelled)
        if data.reference_state is not None:
            write_json(output/"reference_state.json", data.reference_state)
        shape_input = ({'input_features': data.input_features} if getattr(data, 'kernel_mode', None) == 'kernel'
                       else {'prepared_dir': prepared_dir})
        export_inspection(output / "project.json", output / "architecture", **shape_input,
                          seed=config["seed"], max_parameter_bytes=max_parameter_bytes, graph_state=data.graph_state,
                          reference_state=data.reference_state)
        timing['preparation_seconds'] += time.perf_counter() - branch_started
        event("prepared", features=data.input_features, model=model_spec.to_dict(), counts=data.report["split"]["counts"],
              kernel_mode=getattr(data, 'kernel_mode', None),
              kernel_reference_count=data.kernel_state.reference_count if getattr(data, 'kernel_state', None) else None,
              graph_state_path=str(output / "graph_state.json") if data.graph_state is not None else None,
              reference_state_path=str(output/"reference_state.json") if data.reference_state is not None else None)
        def checkpoint(index,weights,summary):
            directory=output/"stages"/f"{index:02d}"
            directory.mkdir(parents=True)
            torch.save(weights,directory/"weights.pt")
            write_json(directory/"summary.json",summary)
        fit_started = time.perf_counter()
        result = fit_model(data, model_spec, config, max_parameter_bytes=max_parameter_bytes,
                           progress=lambda row: event("epoch", **row), cancelled=cancelled,checkpoint=checkpoint)
        timing['fit_seconds'] = time.perf_counter() - fit_started
        event("best_restored", epoch=result.best_epoch, validation_mse=result.best_validation_loss)
        weights = {key: value.detach().cpu().clone() for key, value in result.model.state_dict().items()}
        torch.save(weights, output / "weights.pt")
        write_csv(output / "history.csv", list(result.history[0]), (list(row.values()) for row in result.history))
        metrics, records = {}, []
        prediction_started = time.perf_counter()
        stage("evaluation")
        multi=hasattr(data,"target_state")
        if multi:
            targets=data.target_state["contract"]["targets"]
            train_means=np.nanmean(data.target_values[data.split.rows("train")],axis=0)
        else:
            train_mean = float(np.mean([float(data.samples[i]["value"]) for i in data.split.rows("train")]))
        with execution_context(config) as device:
            for part in PARTS:
                rows = data.split.rows(part)
                prediction = predict_rows(result.model, data, rows, config["batch_size"], device, cancelled)
                if multi:
                    metrics[part]={"targets":{}}
                    for j,target in enumerate(targets):
                        observed=data.target_values[rows,j]
                        valid=np.isfinite(observed)
                        result_metrics=dict(model=regression_metrics(observed[valid],prediction[valid,j]),
                            training_mean_baseline=regression_metrics(observed[valid],np.full(int(valid.sum()),train_means[j])))
                        metrics[part]["targets"][target["id"]]=result_metrics
                        if j==0:
                            metrics[part].update(result_metrics)
                            if part=="test":
                                test_y,test_prediction=observed[valid],prediction[valid,j]
                        for i,actual,estimate in zip(rows,observed,prediction[:,j]):
                            sample=data.samples[i]
                            records.append((project["data"]["dataset_id"],target["trait"],
                                data.split.value.get("cross_validation",{}).get("fold",0),config["seed"],
                                model_spec.sha256,part,int(i),sample["FID"],sample["IID"],
                                float(actual) if np.isfinite(actual) else "",float(estimate),
                                target["id"],target["environment"],target["unit"]))
                    continue
                # Labels are read only after prediction; test is first evaluated here.
                y = np.array([float(data.samples[i]["value"]) for i in rows], dtype=np.float64)
                metrics[part] = {"model": regression_metrics(y, prediction),
                                 "training_mean_baseline": regression_metrics(y, np.full(len(y), train_mean))}
                for i, actual, estimate in zip(rows, y, prediction):
                    sample = data.samples[i]
                    records.append((project["data"]["dataset_id"], data.report["trait"],
                                    data.split.value.get("cross_validation", {}).get("fold", 0), config["seed"],
                                    model_spec.sha256, part, int(i), sample["FID"], sample["IID"], actual, estimate))
                if part == "test":
                    test_y, test_prediction = y, prediction
        timing['prediction_seconds'] = time.perf_counter() - prediction_started
        write_json(output / "metrics.json", metrics)
        write_csv(output / "predictions.csv", ["dataset_id", "trait", "fold", "seed", "model_sha256", "partition",
                  "fam_index", "FID", "IID", "observed", "predicted"]+(["target_id","environment","unit"] if multi else []), records)
        _plots(output, result.history, test_y, test_prediction,multi=multi)
        stage("archive_verification")
        # Recheck original inputs and the consumed preparation after computation.
        PreparedDataset.load(prepared_dir)
        verify_snapshots({"project": project_before, **requested})
        verify_snapshots(input_sources)
        verify_source(source_hashes)
        from .. import __version__
        environment = {"python": platform.python_version(), "platform": platform.platform(),
                       "packages": {name: importlib.metadata.version(name) for name in
                                    ("torch", "numpy", "bed-reader", "matplotlib", "psutil")},
                       "gpnb_version": __version__,
                       "cuda_runtime": torch.version.cuda,
                       "device": config["device"],
                       "device_name": torch.cuda.get_device_name(0) if config["device"] == "cuda" else platform.processor(),
                       "deterministic": config["deterministic"], "threads": config["threads"],
                       "seed": config["seed"], "tf32": False,
                       "shuffle": "NumPy PCG64(seed), fresh permutation of training row indices each epoch",
                       "original_project_sha256": spec.sha256,
                       "source_sha256": source_hashes,
                       "cublas_workspace_config_during_fit": ":4096:8" if config["deterministic"] else None}
        from .environment import environment_evidence
        environment.update(environment_evidence(output, config['device']))
        write_json(output / "environment.json", environment)
        resource_report = monitor.stop()
        write_csv(output / "resource_samples.csv", ["elapsed_seconds", "rss_bytes"],
                  ((s["elapsed_seconds"], s["rss_bytes"]) for s in monitor.samples))
        monitor = None
        write_json(output / "resources.json", resource_report)
        # Keep the architecture-only code distinct from fitted state_dict weights.
        summary = {"ok": True, "schema_version": 1, "kind": "training_run",
                   "dataset_id": data.report["dataset_id"], "trait": data.report["trait"],
                   "fold": data.split.value.get("cross_validation", {}).get("fold", 0),
                   "seed": config["seed"], "model_sha256": model_spec.sha256,
                   "input_features": data.input_features, "best_epoch": result.best_epoch,
                   "epochs_ran": len(result.history), "best_validation_mse": result.best_validation_loss,
                   "stop_reason": result.stop_reason, "test_metrics": metrics["test"]["model"],
                   "loss_scale": "training-fitted target scale; no weight-decay term included in reported MSE",
                   "metric_scale": "input phenotype file scale",
                   "optimizer_semantics": "Adam coupled L2 weight_decay, default betas/eps; SGD momentum=0; foreach=False",
                   "early_stopping": "validation objective only; min_delta controls patience, checkpoint is absolute minimum",
                   "provenance": data.report["provenance"], "warnings": data.report["warnings"],
                   "resources": resource_report, "scope": "Engineering validation, not a confirmed scientific benchmark",
                   "archive_scope": "frozen predictor, preprocessing, source snapshot and locks; export --include-data for portable retraining",
                   "prediction_interpretation": "predicted target on input phenotype scale; not automatically an estimated breeding value",
                   "project_extensions": project.get("extensions", {})}
        if data.reference_state is not None:
            ref = data.reference_state
            summary["individual_graph"] = dict(protocol=ref["protocol"], references=len(ref["reference_ids"]),
                neighbors=ref["neighbors"], labels_in_graph=False,
                permits_unknown_individuals=ref["protocol"] == "inductive_train_reference",
                archive_contains_reference_genotype_features=True)
        target_arrays = data.target_values if multi else np.array([float(s['value']) if s['value'] not in ('', None) else np.nan for s in data.samples])[:, None]
        def describe_values(values):
            valid = values[np.isfinite(values)]
            return dict(observed=len(valid), missing=int(len(values)-len(valid)), mean=float(valid.mean()) if len(valid) else None,
                        sd=float(valid.std()) if len(valid) else None, minimum=float(valid.min()) if len(valid) else None,
                        maximum=float(valid.max()) if len(valid) else None, sd_ddof=0)
        summary['data_statistics'] = dict(samples=len(data.samples), raw_markers=data.report['raw_features'],
            retained_markers=data.state.input_features, model_input_features=data.input_features,
            partition_counts=data.report['split']['counts'],
            training_marker_missing_fraction_mean=float(data.state.arrays['missing_rate'].mean()),
            targets={t['id']:describe_values(target_arrays[:, j]) for j,t in enumerate(targets if multi else [dict(id=data.report['trait'])])},
            scope='Descriptive matched cohort; training marker statistics fitted on training rows only')
        summary['training_objective'] = config['loss']
        summary['best_validation_loss'] = result.best_validation_loss
        summary['optimizer_semantics'] = dict(name=config['optimizer'], momentum=config.get('momentum',0),
            learning_rate=config['learning_rate'], weight_decay=config['weight_decay'], scheduler=config.get('scheduler'), foreach=False)
        summary['loss_scale'] = 'Configured objective on training-fitted target scale; original-unit regression metrics reported separately'
        summary["determinism_policy"] = dict(requested=project["run"]["training"]["deterministic"],
            effective=config["deterministic"], adaptive_max_pool_strict=config.get("adaptive_max_pool_strict",False))
        if config.get("selection_mode") == "fixed_epochs":
            summary["early_stopping"] = "disabled: fixed epochs; final epoch weights; no validation selection"
        if (output / "search/summary.json").exists():
            summary["search"] = read_json(output / "search/summary.json")
        if hasattr(result,"stages"):
            summary["training_stages"]=result.stages
            summary["loss_scale"]="weighted stage objective: per-observed-value reconstruction MSE and configured regression objective on training-fitted target scale; weights saved per stage"
            summary["early_stopping"]="each stage uses its validation objective only; optimizer/patience reset; best stage state restored"
        if multi:
            summary["multitask"]=data.target_state["contract"]
            summary["test_metrics_by_target"]={key:value["model"] for key,value in metrics["test"]["targets"].items()}
            summary["display_target"]=targets[0]["id"]
            summary["loss_scale"]="weighted mean of per-target masked objective on each training-fitted target scale"
            summary["early_stopping"]="aggregate per-target validation sums/counts then explicit weighted mean; no test selection"
        if config.get("selection_mode") == "fixed_epochs":
            summary["early_stopping"] = "disabled: fixed epochs, final epoch weights; validation not used"
        timing['total_seconds'] = time.perf_counter() - started
        timing['archival_overhead_seconds'] = max(0., timing['total_seconds'] - sum(timing[k] for k in
            ('preparation_seconds', 'search_seconds', 'fit_seconds', 'prediction_seconds')))
        timing['scope'] = 'joint_multi_target' if multi else 'single_target'
        timing['measurement'] = 'Wall clock through result generation and verification; excludes final manifest hashing. No division across targets.'
        summary['timing'] = timing
        write_json(output/'timing.json', timing)
        if kernel_options(project):
            summary['kernel_features'] = dict(mode=data.kernel_mode, reference_count=data.kernel_state.reference_count,
                reference_state='kernel', scope='current training partition only',
                columns='saved training reference individuals; K(Q,T)', raw_marker_features=data.state.input_features)
        if project['run']['split']['method'] in ('final_selection', 'final_training'):
            summary['evaluation_status'] = 'no_independent_test_set'
            summary['scope'] = 'Internal selection for deployment' if project['run']['split']['method'] == 'final_selection' else 'Final deployment model fitted on all eligible labelled individuals'
            summary['final_refit'] = project.get('extensions', {}).get('final_refit', {})
            summary['test_metrics'] = None
            if multi:
                summary['test_metrics_by_target'] = {}
        write_json(output / "summary.json", summary)
        event("completed", best_epoch=result.best_epoch, epochs=len(result.history))
        artifacts = {p.relative_to(output).as_posix(): sha256(p) for p in output.rglob("*")
                     if p.is_file() and p.name != "INCOMPLETE"}
        check_cancel(cancelled)
        write_json(output / "complete.json", {"schema_version": 1, "kind": "training_run", "files": artifacts})
        (output / "INCOMPLETE").unlink()
        return summary
    except BaseException as error:
        if monitor is not None:
            try:
                write_json(output / "resources.json", monitor.stop())
            except Exception:
                pass
        state = "cancelled" if isinstance(error, KeyboardInterrupt) or getattr(error, "code", "") == "E_CANCELLED" else "failed"
        write_json(output / "failure.json", {"ok": False, "status": state, "type": type(error).__name__, "error": str(error)})
        event(state, detail=str(error))
        raise
