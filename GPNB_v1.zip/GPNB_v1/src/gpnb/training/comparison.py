"""Descriptive paired comparison only; no automatic significance claims."""
from pathlib import Path

from ..bundle import seal, verify_bundle
from ..config import fail
from ..data.files import read_json, write_csv, write_json
from ..data.prepare import table
from .core import check_cancel
from .metrics import regression_metrics


def compare_cv(paths, output, *, progress=None, cancelled=None):
    paths, output = [Path(p).resolve() for p in paths], Path(output).resolve()
    if len(paths) < 2 or len(set(paths)) != len(paths):
        fail("E_VALUE", "comparison", "select at least two distinct completed CV archives")
    if output.exists() or any(output.is_relative_to(p) or p.is_relative_to(output) for p in paths):
        fail("E_EXISTS", str(output), "choose a new comparison directory outside the input archives")
    summaries, predictions, sources, plan_sha = [], [], [], None
    reference = None
    for p in paths:
        check_cancel(cancelled)
        manifest = verify_bundle(p, "cross_validation", required=("summary.json", "cv_plan.json", "predictions.csv", "project.json"))
        summary, project = read_json(p / "summary.json"), read_json(p / "project.json")
        rows = table(p / "predictions.csv")
        multitask=summary.get("multitask")
        identity = [(r["FID"], r["IID"], r["fold"], r["observed"],
                     *([r["target_id"],r["environment"],r["unit"]] if multitask else [])) for r in rows]
        if reference is not None and (identity != reference or summary["plan_sha256"] != plan_sha):
            fail("E_SPLIT", str(p), "comparison needs identical individuals, labels, outer/inner folds and context")
        reference, plan_sha = identity, summary["plan_sha256"]
        for target in (multitask["targets"] if multitask else [None]):
            selected=[r for r in rows if r["observed"]!="" and (target is None or r["target_id"]==target["id"])]
            m = regression_metrics([float(r["observed"]) for r in selected], [float(r["predicted"]) for r in selected])
            summaries.append(dict(run=str(p), dataset=summary["dataset_id"], trait=target["trait"] if target else summary["trait"],
                **(dict(target_id=target["id"],environment=target["environment"],unit=target["unit"]) if target else {}),
                model_sha256=summary["model_sha256"], training_seed=summary["seed"], **m))
        predictions.append(rows)
        sources.append(dict(directory=str(p), manifest=manifest, model=project["model"], run=project["run"]))
    output.mkdir(parents=True)
    (output / "INCOMPLETE").write_text("CV comparison in progress", encoding="utf-8")
    try:
        fields = list(summaries[0])
        write_csv(output / "metrics.csv", fields, ([r[k] for k in fields] for r in summaries))
        fields = ["FID", "IID", "fold", "observed", *(["target_id","environment","unit"] if multitask else []),
                  *[f"prediction_{i+1}" for i in range(len(paths))]]
        write_csv(output / "paired_predictions.csv", fields,
                  ([*key, *[rows[i]["predicted"] for rows in predictions]] for i, key in enumerate(reference)))
        report = dict(ok=True, kind="cv_comparison", runs=len(paths), plan_sha256=plan_sha, metrics=summaries,
                      scope="Same outer/inner plan and labelled cohort. Descriptive paired comparison, no automatic significance test.")
        write_json(output / "summary.json", report)
        write_json(output / "sources.json", sources)
        for p, old in zip(paths, sources):
            if verify_bundle(p, "cross_validation") != old["manifest"]:
                fail("E_CHANGED", str(p), "input CV archive changed during comparison")
        check_cancel(cancelled)
        seal(output, "cv_comparison")
        (output / "INCOMPLETE").unlink()
        return report
    except BaseException as error:
        write_json(output / "failure.json", dict(ok=False, error=str(error)))
        raise
