"""Bounded discrete grid/random search; candidate fitting never scores outer test rows."""
from __future__ import annotations
import copy
import json
import math
import time
from pathlib import Path
import numpy as np

from ..config import ModelSpec, ProjectSpec, choice, fail, number, object_fields, resolve_project_path
from ..data.files import write_json
from ..data.split import SplitManifest, unit_groups
from .core import check_cancel, effective_training, fit_model

TRAINING_KEYS = ('optimizer', 'learning_rate', 'weight_decay', 'batch_size', 'epochs', 'patience', 'min_delta', 'momentum')


def validate_search(value):
    object_fields(value, 'search', ('method', 'seed', 'max_trials', 'validation_fraction', 'parameters'))
    choice(value['method'], 'search.method', ('random', 'grid'))
    number(value['seed'], 'search.seed', 0, 2**32-1, integer=True)
    number(value['max_trials'], 'search.max_trials', 1, 1000, integer=True)
    number(value['validation_fraction'], 'search.validation_fraction', .01, .49)
    params = value['parameters']
    if not isinstance(params, dict) or not 1 <= len(params) <= 12:
        fail('E_SEARCH', 'parameters', 'choose 1..12 parameter paths with discrete candidate lists')
    for path, values in params.items():
        parts = path.split('.')
        if not ((len(parts)==2 and parts[0]=='training' and parts[1] in TRAINING_KEYS) or
                (len(parts)==3 and parts[0]=='layers' and all(parts[1:]))):
            fail('E_SEARCH', path, 'use training.<parameter> or layers.<layer_id>.<parameter>')
        if not isinstance(values, list) or not 1 <= len(values) <= 100:
            fail('E_SEARCH', path, 'expected 1..100 explicit candidate values')
        try:
            tokens=[json.dumps(x,sort_keys=True,allow_nan=False) for x in values]
        except (TypeError, ValueError):
            fail('E_SEARCH', path, 'candidate values must be finite JSON values')
        if len(set(tokens)) != len(tokens):
            fail('E_SEARCH', path, 'duplicate candidate values')
    size=math.prod(map(len, params.values()))
    if size > 1_000_000:
        fail('E_SEARCH', 'space', 'candidate product exceeds 1,000,000; narrow the search')
    if value['method']=='grid' and size > value['max_trials']:
        fail('E_SEARCH', 'max_trials', f'grid requires {size} trials; raise budget or reduce the space')
    return size


def candidates(options):
    size=validate_search(options)
    keys=sorted(options['parameters'])
    values=[options['parameters'][k] for k in keys]
    indices=(range(size) if options['method']=='grid' else
             np.random.Generator(np.random.PCG64(options['seed'])).choice(size,min(size,options['max_trials']),replace=False))
    for index in indices:
        selected=[]
        for items in reversed(values):
            index,offset=divmod(int(index),len(items));selected.append(items[offset])
        yield dict(zip(keys,reversed(selected)))


def apply_candidate(project, parameters):
    value=copy.deepcopy(project)
    value['run'].setdefault('extensions',{}).pop('search',None)
    value['run']['training']['selection_mode']='validation'
    if 'stages' in value['run']['training']:
        fail('E_SEARCH','stages','v0.4.1 search requires single-stage regression; disable stages first')
    for path,item in parameters.items():
        parts=path.split('.')
        if parts[0]=='training':
            value['run']['training'][parts[1]]=item
        else:
            layer=next((row for row in value['model']['layers'] if row['id']==parts[1]),None)
            if layer is None or parts[2] not in layer['params']:
                fail('E_SEARCH',path,'layer or registered parameter no longer exists')
            layer['params'][parts[2]]=item
    ProjectSpec(value)
    return value


def selection_partitions(data, options):
    """Existing holdout, or a grouped inner holdout from N-1 outer-training rows only."""
    if len(data.split.rows('validation')):
        return copy.deepcopy(data.split.value['partitions'])
    members={}
    units=unit_groups(data.split.value['context'])
    for i in data.split.rows('train'):
        members.setdefault(units[i],[]).append(int(i))
    if len(members)<2:
        fail('E_SEARCH','split','inner search needs at least two outer-training splitting units')
    names=sorted(members)
    rng=np.random.Generator(np.random.PCG64(options['seed']))
    names=[names[i] for i in rng.permutation(len(names))]
    target=max(1,round(len(data.split.rows('train'))*options['validation_fraction']))
    validation=[]
    for name in names[:-1]:
        if len(validation)>=target: break
        validation.extend(members[name])
    return dict(train=sorted(set(map(int,data.split.rows('train')))-set(validation)),
                validation=sorted(validation),test=data.split.rows('test').tolist())


def search_project(data, project, project_path, output, *, max_parameter_bytes, progress=None, cancelled=None):
    from ..data.preprocessing import PreprocessorState
    from ..data.multitask import fit_target_state
    from ..data.additional import fit_tables,resolve_table_paths
    from ..graphs.state import fit_graph
    from ..graphs.individual import fit_reference
    project=copy.deepcopy(project)
    resolve_table_paths(project,project_path)
    for key in ('bed','bim','fam','phenotype','manifest','split_groups'):
        if project['data'][key] is not None:
            project['data'][key]=str(resolve_project_path(project_path,project['data'][key]))
    project['output_dir']=str(resolve_project_path(project_path,project['output_dir']))
    if project['run']['split']['reuse_manifest']:
        project['run']['split']['reuse_manifest']=str(resolve_project_path(project_path,project['run']['split']['reuse_manifest']))
    options=project['run']['extensions']['search']
    validate_search(options)
    output=Path(output);output.mkdir()
    partitions=selection_partitions(data, options)
    write_json(output/'selection_split.json',dict(partitions=partitions,
        sample_ids=data.split.value['context']['sample_ids'],
        use='Only train/validation are read by trial loss. Test rows excluded from all candidate scoring.'))
    inner=copy.copy(data)
    # Internal selection partition is not a reusable final evaluation manifest.
    inner.split=SplitManifest({**data.split.value,'partitions':partitions})
    train,validation=inner.split.rows('train'),inner.split.rows('validation')
    multi=hasattr(data,'target_state')
    inner.state=PreprocessorState.fit(data.cache,train,None if multi else [float(data.samples[i]['value']) for i in train],
        data.state.metadata['input_markers'],project['run']['preprocessing'],provenance=data.state.metadata['provenance'])
    inner.state.save(output/'preprocessor')
    if multi:
        context=data.split.value['context']
        inner.target_state=fit_target_state(data.target_values,train,validation,project,context['sample_ids'],context['phenotype_sha256'])
        write_json(output/'target_state.json',inner.target_state)
    records=[];winner=None;started=time.perf_counter()
    choices=list(candidates(options))
    for index,parameters in enumerate(choices,1):
        check_cancel(cancelled)
        directory=output/f'trial_{index:04d}';directory.mkdir()
        record=dict(trial=index,parameters=parameters,status='failed')
        try:
            current=apply_candidate(project,parameters)
            write_json(directory/'candidate.json',dict(kind='search_candidate_record',model=current['model'],
                training=current['run']['training'],data=current['data'],
                selection_split='../selection_split.json',preprocessor='../preprocessor',
                directly_runnable_project=False))
            from ..data.kernel_features import bind_kernel
            spec=bind_kernel(current,inner,output=directory/'kernel',cancelled=cancelled)
            spec.save(directory/'resolved_model.json')
            input_states,inner.additional_inputs,_=fit_tables(current,project_path,inner)
            if input_states: write_json(directory/'input_states.json',input_states)
            inner.graph_state=fit_graph(spec,inner,None,cancelled)
            inner.reference_state,inner.reference_features=fit_reference(spec,inner,cancelled)
            if inner.graph_state is not None: write_json(directory/'graph_state.json',inner.graph_state)
            if inner.reference_state is not None: write_json(directory/'reference_state.json',inner.reference_state)
            fitted=fit_model(inner,spec,current['run']['training'],max_parameter_bytes=max_parameter_bytes,
                cancelled=cancelled,progress=(lambda e: progress(dict(event='search_epoch',trial=index,trials=len(choices),**e))) if progress else None)
            score=float(fitted.best_validation_loss)
            if not math.isfinite(score): fail('E_SEARCH','score','nonfinite validation score')
            write_json(directory/'history.json',fitted.history)
            record.update(status='completed',validation_loss=score,loss_name=project['run']['training']['loss'],validation_mse=score,best_epoch=fitted.best_epoch,
                          effective_training=effective_training(current['run']['training'],spec))
            if winner is None or score<winner[0]: winner=(score,index,current,fitted.best_epoch)
            del fitted
        except Exception as error:
            from ..errors import GPNBError
            if not isinstance(error,(GPNBError,ValueError,RuntimeError)) or getattr(error,'code','')=='E_CANCELLED': raise
            record['error']=str(error)
        records.append(record);write_json(directory/'result.json',record)
        write_json(output/'trials.json',records)
        if progress: progress(dict(event='search_trial',trials=len(choices),**record))
    if winner is None: fail('E_SEARCH',str(output),'no valid candidate completed; see trials.json')
    _,index,selected,epoch=winner
    full_refit=not len(data.split.rows('validation'))
    if full_refit:
        selected['run']['training'].update(selection_mode='fixed_epochs',epochs=epoch)
    ProjectSpec(selected).save(output/'selected_project.json')
    write_json(output/'summary.json',dict(method=options['method'],options=options,selected_trial=index,
        selected_validation_mse=winner[0],selection_metric=project['run']['training']['loss']+' on inner-training-fitted target scale',
        completed=sum(r['status']=='completed' for r in records),failed=sum(r['status']=='failed' for r in records),
        full_outer_training_refit=full_refit,selected_epochs=epoch,elapsed_seconds=time.perf_counter()-started,
        outer_test_used_for_selection=False,refit='N-1 fixed selected epochs' if full_refit else 'original train + validation checkpoint selection'))
    return selected
