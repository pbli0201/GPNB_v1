"""Serial, failure-isolated trait tasks consumed by GUI and CLI."""
from __future__ import annotations
import copy
import time
from pathlib import Path
from ..config import ProjectSpec,fail
from ..data.files import read_json,write_json,write_csv
from .events import WorkTracker, tracking, event_context, enrich
from uuid import uuid4


def validate_batch(project):
    extension=project.get('extensions',{})
    batch=extension.get('trait_batch')
    if batch is None:return
    if set(batch)!={'mode','traits'} or batch['mode']!='separate':fail('E_BATCH','trait_batch','expected mode separate and ordered traits')
    traits=batch['traits']
    if not isinstance(traits,list) or not traits or len(set(traits))!=len(traits) or any(not isinstance(t,str) or not t.strip() for t in traits):fail('E_BATCH','traits','select distinct named traits')
    metadata=extension.get('trait_metadata',{})
    if not isinstance(metadata,dict) or any(not isinstance(name,str) or not isinstance(item,dict) for name,item in metadata.items()):
        fail('E_BATCH','trait_metadata','expected a mapping from trait column names to target metadata objects')
    if extension.get('multitask') or project['model'].get('task')!='single_trait_regression':fail('E_BATCH','model','separate training requires a single-output model; switch off joint targets first')
    if project['data']['phenotype_options']['trait']!=traits[0]:fail('E_BATCH','trait','primary trait must equal first selected trait')
    if project['run']['split'].get('reuse_manifest') or project['run'].get('extensions',{}).get('cross_validation',{}).get('reuse_manifest'):
        fail('E_BATCH','reuse_manifest','batch uses its shared ID plan; clear single-trait reused plans')


def child_projects(value):
    validate_batch(value)
    traits=value['extensions']['trait_batch']['traits']
    for index,trait in enumerate(traits,1):
        current=copy.deepcopy(value)
        current['extensions'].pop('trait_batch')
        current['extensions']['batch_split_traits']=list(traits)
        if trait in value.get('extensions',{}).get('trait_metadata',{}):
            current['extensions']['target']=copy.deepcopy(value['extensions']['trait_metadata'][trait])
        elif trait != value['data']['phenotype_options']['trait']:
            current['extensions'].pop('target',None)
        current['data']['phenotype_options']['trait']=trait
        current['name']=value['name']+' / '+trait
        yield f'trait_{index:03d}',trait,current


def _run_batch(project_path,output,*,operation='train',cache_root=None,max_parameter_bytes=256*2**20,progress=None,cancelled=None,retry_from=None):
    from ..preflight import resolved_project,preflight_project,digest,computation_digest,source_files,code_digest,environment
    from ..data.files import snapshot,verify_snapshots
    from ..data.preview import preview_split
    from .run import train_project
    from .core import check_cancel
    from ..bundle import seal,capture_source,verify_source
    output=Path(output).resolve()
    if output.exists():fail('E_EXISTS',str(output),'choose a new batch output; previous tasks are preserved')
    value=resolved_project(Path(project_path));validate_batch(value)
    from ..data.files import protect_inputs
    protect_inputs(output,[Path(project_path),*source_files(value,Path(project_path)).values()])
    from ..paths import configure_local_paths
    cache_root=Path(cache_root or configure_local_paths()/'cache/genotypes').resolve()
    if output.is_relative_to(cache_root) or cache_root.is_relative_to(output):fail('E_IO',str(output),'batch/cache overlap')
    tasks=list(child_projects(value));output.mkdir(parents=True)
    (output/'INCOMPLETE').write_text('Trait batch running',encoding='utf8')
    # Publish the validated task inventory before the first cancellable hash so
    # immediate cancellation can still describe every pending trait.
    ProjectSpec(value).save(output/'project.json')
    sources={k:snapshot(p) for k,p in source_files(value,Path(project_path)).items()}
    source_code=code_digest();runtime=environment()
    captured=capture_source(output) if operation in ('train','final-refit') else None
    if operation in ('train','final-refit'):
        (output/'REPRODUCE.py').write_text("import sys\nfrom pathlib import Path\nroot=Path(__file__).resolve().parent\nsys.path.insert(0,str(root/'source'))\nfrom gpnb.training.trait_batch import run_batch\nif len(sys.argv)!=2:raise SystemExit('Usage: python REPRODUCE.py NEW_OUTPUT_DIRECTORY')\nrun_batch(root/'project.json',sys.argv[1])\n".replace("sys.argv[1])","sys.argv[1],operation="+repr(operation)+")"),encoding='utf8')
    summary=dict(schema_version=1,kind='trait_batch' if operation in ('train','final-refit') else 'batch_'+operation,ok=False,operation=operation,tasks=[],task_count=len(tasks),completed=0,failed=0,cancelled=0,sources=sources,code_digest=source_code,environment=runtime)
    plans={}
    for task_index,(task_id,trait,current) in enumerate(tasks,1):
        check_cancel(cancelled)
        path=output/(task_id+'.json');ProjectSpec(current).save(path)
        try:
            identity=dict(task_id=task_id,trait=trait,trait_index=task_index,trait_count=len(tasks),fit_purpose='preflight')
            with event_context(**identity):
                plans[task_id]=dict(ok=True,models=2) if operation=='final-refit' else preview_split(path,output/'plans'/task_id,cache_root=cache_root,
                    progress=(lambda event:progress(enrich(event))) if progress else None,cancelled=cancelled)
        except Exception as error:
            if getattr(error,'code','')=='E_CANCELLED':raise
            plans[task_id]={'ok':False,'error':str(error)}
    cv=value['run'].get('extensions',{}).get('cross_validation',{})
    is_leave=cv.get('method','').startswith('leave_one')
    total_models=sum(plan.get('models',0) for plan in plans.values())
    summary['models']=total_models
    from .search import candidates
    options=value['run'].get('extensions',{}).get('search')
    trials=len(list(candidates(options))) if options else 0
    tracker=WorkTracker(progress)
    for task_id,trait,current in tasks:
        tracker.plan(task_id,plans[task_id].get('models',1),trials,operation)
    tracker.units[('batch',0,'publication',0)]='pending'
    write_json(output/'task_plan.json',enrich(dict(schema_version=1,basis='planned_work_units_not_elapsed_time',
        traits=[dict(task_id=t[0],trait=t[1],trait_index=i) for i,t in enumerate(tasks,1)],
        units=[dict(task_id=k[0],fold=k[1],kind=k[2],trial=k[3]) for k in tracker.units])))
    tracker.publish()
    if operation not in ('preview','final-refit') and is_leave and cv.get('approved_folds')!=total_models:
        fail('E_BATCH','approved_folds',f'preview and acknowledge {total_models} total trait/fold fits first')
    previous={}
    if retry_from:
        previous_report=read_json(Path(retry_from)/'summary.json')
        if previous_report.get('kind')!='trait_batch' or read_json(Path(retry_from)/'project.json')!=value:fail('E_BATCH','retry_from','retry requires the exact saved batch project')
        if {key:item['sha256'] for key,item in previous_report.get('sources',{}).items()}!={key:item['sha256'] for key,item in sources.items()}:
            fail('E_BATCH','retry_from','input contents changed; start a new independent batch instead of combining results')
        if previous_report.get('code_digest')!=source_code or previous_report.get('environment')!=runtime:fail('E_BATCH','retry_from','code or dependency versions changed; start a new independent batch')
        previous={r['trait']:r for r in previous_report['tasks']}
    try:
        for task_id,trait,current in tasks:
            check_cancel(cancelled)
            old=previous.get(trait)
            if old and old['status']=='completed':
                from ..bundle import verify_bundle
                preserved_root=Path(old.get('preserved_from',retry_from))
                verify_bundle(preserved_root/old['output'])
                summary['tasks'].append(dict(old,preserved_from=old.get('preserved_from',str(Path(retry_from).resolve()))));summary['completed']+=1
                tracker.finish_task(task_id,'reused')
                continue
            path=output/(task_id+'.json')
            if is_leave:current['run']['extensions']['cross_validation']['approved_folds']=plans[task_id].get('models')
            ProjectSpec(current).save(path,overwrite=True)
            directory=output/task_id
            identity=dict(task_id=task_id,trait=trait,trait_index=len(summary['tasks'])+1,trait_count=len(tasks),
                          fit_purpose='preflight' if operation=='preflight' else 'model_fit')
            if progress:progress(enrich(dict(event='batch_task',task=task_id,index=len(summary['tasks'])+1,total=len(tasks),**identity)))
            row=dict(id=task_id,trait=trait,output=task_id,status='running')
            task_started=time.perf_counter()
            try:
                from .final_refit import final_refit_project
                fn={'train':train_project,'preflight':preflight_project,'preview':preview_split,'final-refit':final_refit_project}[operation]
                kwargs=dict(cache_root=cache_root,progress=tracker.receive,cancelled=cancelled)
                if operation!='preview':kwargs['max_parameter_bytes']=max_parameter_bytes
                if not plans[task_id].get('ok'):raise ValueError(plans[task_id].get('error'))
                if operation=='preflight':kwargs['_preview']=plans[task_id]
                with event_context(**identity),tracking(tracker):
                    result=plans[task_id] if operation=='preview' else fn(path,directory,**kwargs)
                if not result.get('ok'):raise ValueError(result.get('error','Task checks failed; see child summary'))
                row.update(status='completed',folds=result.get('folds',1),summary=result)
                summary['completed']+=1
            except Exception as error:
                if getattr(error,'code','')=='E_CANCELLED':raise
                row.update(status='failed',error=str(error));summary['failed']+=1
            summary['tasks'].append(row)
            row['elapsed_seconds']=time.perf_counter()-task_started
            tracker.finish_task(task_id,'succeeded' if row['status']=='completed' else 'failed')
            write_json(output/'summary.json',summary)
        verify_snapshots(sources)
        from ..data.shared import current as shared_current
        shared=shared_current()
        if shared:
            shared.verify()
            summary['shared_checks']=shared.report()
        if source_code!=code_digest():fail('E_CHANGED','source','source changed while batch was running')
        summary['ok']=summary['failed']==0
        if operation=='preflight':
            summary.update(kind='preflight',batch=True,ok=summary['failed']==0 and summary['completed']==len(tasks),
                check_status='all_passed' if summary['completed']==len(tasks) else 'partial_passed' if summary['completed'] else 'failed',
                project_digest=digest(value),computation_digest=computation_digest(value),sources=sources,code_digest=source_code,environment=runtime,max_parameter_bytes=max_parameter_bytes,failed_candidates=sum(r.get('summary',{}).get('failed_candidates',0) for r in summary['tasks']))
        tracker.units[('batch',0,'publication',0)]='succeeded'
        summary['task_progress']=tracker.snapshot('completed' if summary['ok'] else 'failed')
        write_json(output/'summary.json',summary)
        write_csv(output/'tasks.csv',['id','trait','status','output','error'],([r.get(k,'') for k in ('id','trait','status','output','error')] for r in summary['tasks']))
        if operation in ('train','final-refit'):
            verify_source(captured)
            (output/'INCOMPLETE').unlink()
            seal(output,'trait_batch')
        (output/'INCOMPLETE').unlink(missing_ok=True)
        tracker.publish('completed' if summary['ok'] else 'failed')
        return summary
    except BaseException as error:
        tracker.units[('batch',0,'publication',0)]='failed'
        if getattr(error,'code','')=='E_CHANGED':
            # Previously sealed child runs used shared input facts. A failed end
            # check invalidates this job's own children, never preserved retries.
            for task_id,_,_ in tasks:
                directory=output/task_id
                if directory.is_dir():
                    for completion in directory.rglob('complete.json'):
                        (completion.parent/'INCOMPLETE').write_text('Shared batch input/source verification failed: '+str(error),encoding='utf8')
            for row in summary['tasks']:
                if not row.get('preserved_from') and row.get('status')=='completed':
                    row.update(status='failed',error=str(error),invalidated=True)
            summary['completed']=sum(row['status']=='completed' for row in summary['tasks'])
            summary['failed']=sum(row['status']=='failed' for row in summary['tasks'])
        state='cancelled' if isinstance(error,KeyboardInterrupt) or getattr(error,'code','')=='E_CANCELLED' else 'failed'
        for task_id,_,_ in tasks:tracker.finish_task(task_id,state)
        tracker.publish(state)
        summary.update(ok=False,error=str(error),cancelled=len(tasks)-len(summary['tasks']))
        write_json(output/'summary.json',summary)
        raise


def run_batch(project_path,output,**kwargs):
    """Leave explicit incomplete state even if cancelled during shared planning."""
    output=Path(output).resolve();was_absent=not output.exists()
    from ..preflight import resolved_project,source_files
    from ..data.shared import shared_facts
    value=resolved_project(Path(project_path))
    try:
        with shared_facts(source_files(value,Path(project_path)).values(),kwargs.get('cancelled')),event_context(run_id=uuid4().hex):
            return _run_batch(project_path,output,**kwargs)
    except BaseException as error:
        if was_absent and output.is_dir() and (output/'project.json').is_file():
            project=read_json(output/'project.json')
            summary=read_json(output/'summary.json') if (output/'summary.json').is_file() else dict(kind='trait_batch',tasks=[])
            cancelled=isinstance(error,KeyboardInterrupt) or getattr(error,'code','')=='E_CANCELLED'
            done={row['trait'] for row in summary['tasks']}
            for task_id,trait,_ in child_projects(project):
                if trait not in done:summary['tasks'].append(dict(id=task_id,trait=trait,status='cancelled' if cancelled else 'not_run',error=str(error),output=task_id))
            summary.update(ok=False,error=str(error),cancelled=sum(row['status']=='cancelled' for row in summary['tasks']))
            write_json(output/'summary.json',summary)
        raise
