"""Native PyTorch objectives and optimizers; shared by train, search and preflight.

Focal MAE follows GPformer, doi:10.1093/bib/bbad438, Methods. Its beta
acts on the *configured training target scale*, not silently on original units.
"""
from ..config import fail


def objective_name(config=None):
    return (config or {}).get("loss", "mse")


def elementwise_loss(prediction, target, config=None):
    import torch
    config = config or {}
    if prediction.shape != target.shape:
        fail("E_TRAIN", "loss", "broadcasting prediction and target is forbidden")
    error = prediction - target
    name = objective_name(config)
    if name == "mse":
        return error.square()
    if name == "mae":
        return error.abs()
    if name == "focal_mae":
        absolute = error.abs()
        return torch.tanh(config.get("focal_beta", .5) * absolute).pow(config.get("focal_gamma", 1.)) * absolute
    fail("E_TRAIN", "loss", "unsupported objective")


def make_optimizer(parameters, config):
    import torch
    options = dict(lr=config["learning_rate"], weight_decay=config["weight_decay"], foreach=False)
    if config["optimizer"] == "Adam":
        return torch.optim.Adam(parameters, **options)
    if config["optimizer"] == "SGD":
        return torch.optim.SGD(parameters, momentum=config.get("momentum", 0.), **options)
    fail("E_TRAIN", "optimizer", "unsupported optimizer")


def make_scheduler(optimizer, config):
    import torch
    options = config.get("scheduler")
    if options is None:
        return None
    if options["type"] == "ExponentialLR":
        return torch.optim.lr_scheduler.ExponentialLR(optimizer, gamma=options["gamma"])
    if options["type"] == "StepLR":
        return torch.optim.lr_scheduler.StepLR(optimizer, step_size=options["step_size"], gamma=options["gamma"])
    fail("E_TRAIN", "scheduler", "unsupported scheduler")


def clip_gradients(parameters, config):
    import torch
    if config.get("gradient_clip_norm") is not None:
        torch.nn.utils.clip_grad_norm_(parameters, config["gradient_clip_norm"], error_if_nonfinite=True, foreach=False)
