"""Read-only, trait-specific result views and reproducible plot exports.

Training rows from different CV fits are deliberately never pooled. The same
reader and plotting function serve the desktop view and the CLI export worker.
"""
from __future__ import annotations

import csv
from pathlib import Path

import numpy as np

from .bundle import safe_member, verify_bundle
from .config import fail
from .data.files import read_json, snapshot, verify_snapshots, write_csv, write_json, protect_inputs, sha256
from .training.metrics import regression_metrics, fold_pearson_summary, baseline_improvement


TIMING_FIELDS = (
    ("preparation_seconds", "数据准备", "Data preparation"),
    ("search_seconds", "参数搜索", "Parameter search"),
    ("fit_seconds", "最终训练", "Final fitting"),
    ("prediction_seconds", "预测与评分", "Prediction and scoring"),
    ("archival_overhead_seconds", "归档及其他开销", "Archiving and other overhead"),
    ("total_seconds", "总耗时", "Total elapsed time"),
)


def _rows(path):
    with Path(path).open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def _verify_artifacts(root, paths):
    """Verify consumed result files without rehashing all model weights per click.

    Loading a model through the worker verifies the whole bundle; interactive
    plot selection rechecks the actual result artifacts against that manifest.
    """
    manifest = read_json(root / "complete.json")
    if manifest.get("schema_version") != 1 or manifest.get("kind") not in ("training_run", "cross_validation"):
        fail("E_BUNDLE", str(root), "unsupported result completion manifest")
    for path in paths:
        name = path.relative_to(root).as_posix()
        expected = manifest.get("files", {}).get(name)
        if not expected or not path.is_file() or sha256(path) != expected:
            fail("E_BUNDLE", str(path), "missing result artifact or SHA256 mismatch")


def result_root(source):
    root = Path(source).resolve()
    if not (root / "summary.json").is_file() and (root / "run/summary.json").is_file():
        root /= "run"
    _verify_artifacts(root, [root / "summary.json"])
    summary = read_json(root / "summary.json")
    if summary.get("kind") not in ("training_run", "cross_validation"):
        fail("E_FORMAT", str(root), "select a completed training or cross-validation result")
    if (root / "INCOMPLETE").exists() or not summary.get("ok"):
        fail("E_FORMAT", str(root), "result is incomplete")
    return root, summary


def result_targets(summary):
    targets = summary.get("multitask", {}).get("targets")
    if targets:
        return targets
    metadata = summary.get('project_extensions', {}).get('target', {})
    if not metadata and summary.get('fold_runs'):
        metadata = summary['fold_runs'][0]['summary'].get('project_extensions', {}).get('target', {})
    if not isinstance(metadata, dict):
        metadata = {}
    return [dict(id=summary["trait"], trait=summary["trait"],
                 unit=metadata.get('unit', metadata.get('units', '')),
                 environment=metadata.get('environment', ''))]


def load_result_data(source, *, target_id=None, partition="test", fold=None):
    root, summary = result_root(source)
    if partition not in ("train", "validation", "test"):
        fail("E_VALUE", "partition", "expected train, validation, or test")
    targets = result_targets(summary)
    target = next((t for t in targets if t["id"] == target_id), None) if target_id is not None else targets[0]
    if target is None:
        fail("E_VALUE", "target", f"unknown target: {target_id}")
    cv = summary.get("kind") == "cross_validation"
    selected_root, selected_summary = root, summary
    if cv:
        if fold is None and partition != "test":
            fail("E_VALUE", "fold", "select one fold for training/validation results; repeated training individuals must not be pooled")
        if fold is not None:
            if isinstance(fold, bool) or not isinstance(fold, int):
                fail("E_VALUE", "fold", "expected an integer fold number")
            member = next((r for r in summary["fold_runs"] if r["fold"] == fold), None)
            if member is None:
                fail("E_VALUE", "fold", f"unknown fold: {fold}")
            selected_root = safe_member(root, member["directory"])
            selected_summary = read_json(selected_root / "summary.json")
    elif fold not in (None, summary.get("fold", 0)):
        fail("E_VALUE", "fold", "this is a single fitted model")
    if partition == 'test' and selected_summary.get('evaluation_status') == 'no_independent_test_set':
        fail('E_VALUE', 'partition', 'This final fit has no independent test set. Select training results or the original evaluation experiment.')
    path = selected_root / "predictions.csv"
    consumed = [root / "summary.json", selected_root / "summary.json", path]
    if (selected_root / "history.csv").is_file():
        consumed.append(selected_root / "history.csv")
    _verify_artifacts(root, consumed)
    rows = [r for r in _rows(path) if r["partition"] == partition and
            (r.get("target_id", target["id"]) == target["id"])]
    observed, predicted = [], []
    for row in rows:
        try:
            estimate = float(row["predicted"])
            if not np.isfinite(estimate):
                raise ValueError("nonfinite prediction")
            if row["observed"] != "":
                actual = float(row["observed"])
                if not np.isfinite(actual):
                    raise ValueError("nonfinite observation")
                observed.append(actual)
                predicted.append(estimate)
        except (ValueError, KeyError) as error:
            fail("E_FORMAT", str(path), f"invalid prediction record: {error}")
    fold_metrics = []
    if cv:
        for run in summary["fold_runs"]:
            metrics = run["summary"].get("test_metrics_by_target", {}).get(target["id"], run["summary"]["test_metrics"])
            fold_metrics.append(dict(fold=run["fold"], **metrics))
    metric = regression_metrics(observed, predicted)
    baseline_sum, baseline_n = 0., 0
    members = summary['fold_runs'] if cv and fold is None else [dict(directory='.', summary=selected_summary)]
    for member in members:
        base_root = safe_member(root, member['directory']) if cv and fold is None else selected_root
        path_metrics = base_root / 'metrics.json'
        if path_metrics.is_file():
            _verify_artifacts(root, [path_metrics]); consumed.append(path_metrics)
            part_metrics = read_json(path_metrics).get(partition, {})
            part_metrics = part_metrics.get('targets', {}).get(target['id'], part_metrics)
            base = part_metrics.get('training_mean_baseline', {})
            if base.get('rmse') is not None:
                baseline_sum += base['n'] * base['rmse'] ** 2
                baseline_n += base['n']
    baseline = baseline_sum / baseline_n if baseline_n and baseline_n == metric['n'] and np.isfinite(baseline_sum) else None
    metric['baseline_mse'] = baseline
    metric['baseline_improvement'] = baseline_improvement(metric['mse'], baseline)['value']
    overview = selected_summary.get('data_statistics', {})
    configuration = {}
    if cv and fold is None:
        overview = {'by_fold': {str(r['fold']):r['summary'].get('data_statistics', {}) for r in summary['fold_runs']}}
        configuration = {'scope': 'Select a fold for its actual settings',
                         'model_sha256_by_fold': summary.get('model_sha256_by_fold', {})}
    else:
        path_project = selected_root / 'project.json'
        if path_project.is_file():
            _verify_artifacts(root, [path_project]); consumed.append(path_project)
            actual = read_json(path_project)
            configuration = {k: actual.get(k, {}) for k in ('model', 'run')}
            configuration['best_epoch'] = selected_summary.get('best_epoch')
            configuration['stop_reason'] = selected_summary.get('stop_reason')
            configuration['search'] = selected_summary.get('search')
    return dict(root=root, selected_root=selected_root, summary=summary, selected_summary=selected_summary,
                target=target, partition=partition, fold=fold, cv=cv, rows=rows,
                observed=np.asarray(observed), predicted=np.asarray(predicted),
                metrics=metric, fold_metrics=fold_metrics, overview=overview, configuration=configuration,
                fold_pearson=fold_pearson_summary(fold_metrics, method=summary.get("method", "five_fold")) if cv else None,
                timing=selected_summary.get("timing", {}),
                snapshots={str(i): snapshot(path) for i, path in enumerate(dict.fromkeys(consumed))})


def _text(language, zh, en):
    return zh if language == "zh" else en


def selected_caption(data, language="en"):
    t = lambda zh, en: _text(language, zh, en)
    partition = data["partition"]
    caption = {"train": t("训练拟合（非外样本）", "Training fit (not out of sample)"),
               "validation": t("验证（参与模型选择）", "Validation (used for model selection)"),
               "test": t("外样本测试", "Out-of-sample test")}[partition]
    if data["cv"] and data["fold"] is None:
        caption = t("外层 OOF（每个体一次）", "Outer OOF (one prediction per individual)")
    elif data["fold"] is not None:
        caption += t(f" · 折 {data['fold']}", f" · fold {data['fold']}")
    if data.get('selected_summary', {}).get('evaluation_status') == 'no_independent_test_set':
        caption += t(' · 无独立测试', ' · no independent test set')
    return caption


def _font(language):
    from matplotlib.font_manager import FontProperties
    if language == "zh":
        for filename in ("C:/Windows/Fonts/msyh.ttc", "C:/Windows/Fonts/simhei.ttf"):
            if Path(filename).is_file():
                return FontProperties(fname=filename)
    return FontProperties(family="DejaVu Sans")


def render_plot(figure, data, kind="scatter", language="en", *, axes=None):
    if language not in ("zh", "en"):
        fail("E_VALUE", "language", "expected zh or en")
    if axes is None:
        figure.clear()
        axes = figure.subplots()
    t = lambda zh, en: _text(language, zh, en)
    target = data["target"]
    unit = f" ({target['unit']})" if target.get("unit") else ""
    caption = selected_caption(data, language)
    y, prediction = data["observed"], data["predicted"]
    title = target["trait"] + " · " + caption
    empty = False
    if kind == "scatter":
        if len(y):
            axes.scatter(y, prediction, s=20, alpha=.65)
            lo, hi = min(y.min(), prediction.min()), max(y.max(), prediction.max())
            if lo == hi:
                lo, hi = lo - .5, hi + .5
            axes.plot([lo, hi], [lo, hi], "--", color="gray", label=t("相等参考线", "Equality line"))
        else:
            empty = True
        axes.set(xlabel=t("观测值", "Observed") + unit, ylabel=t("预测值", "Predicted") + unit)
    elif kind == 'residual':
        if len(y):
            axes.scatter(prediction,prediction-y,s=20,alpha=.65)
            axes.axhline(0,color='gray',linestyle='--')
        else:empty=True
        axes.set(xlabel=t('预测值','Predicted')+unit,ylabel=t('预测值 − 观测值','Predicted - observed')+unit)
    elif kind == "error":
        if len(y):
            axes.hist(prediction - y, bins=min(20, max(1, int(np.sqrt(len(y))))), color="#427ca8", edgecolor="white")
            axes.axvline(0, color="gray", linestyle="--")
        else:
            empty = True
        axes.set(xlabel=t("预测值 − 观测值", "Predicted - observed") + unit,
                 ylabel=t("个体数", "Individuals"))
    elif kind == "folds":
        stats = data["fold_pearson"]
        if not data["cv"] or stats["reason"] in ("leave_out_use_pooled_oof", "leave_group_use_pooled_oof"):
            if not data["cv"]:
                message = t("固定划分只有一次测试评价。", "A fixed split has one test evaluation.")
            elif stats["reason"] == "leave_group_use_pooled_oof":
                message = t("旧版留组协议使用合并 OOF 指标，\n不汇总逐组 Pearson SD；每组可能包含多个个体。", "Legacy leave-group-out uses pooled OOF metrics,\nwithout group Pearson SD; groups may contain several individuals.")
            else:
                message = t("留一法使用合并 OOF 相关；\n单个测试个体不能计算 Pearson 或折间 SD。", "Leave-one-out uses pooled OOF correlation;\na single test individual has no Pearson or fold SD.")
            axes.text(.5, .5, message, ha="center", va="center", transform=axes.transAxes)
        else:
            rows = [r for r in data["fold_metrics"] if r["pearson"] is not None]
            axes.scatter([r["fold"] for r in rows], [r["pearson"] for r in rows], s=35)
            for r in rows:axes.annotate(f"n={r['n']}",(r['fold'],r['pearson']),fontsize=8,xytext=(0,7),textcoords='offset points')
            if stats["mean"] is not None:
                axes.axhline(stats["mean"], color="gray", linestyle="--", label=t("有效折均值", "Valid-fold mean"))
            axes.set_xticks([r["fold"] for r in data["fold_metrics"]])
            axes.set_ylim(-1.05, 1.05)
        axes.set(xlabel=t("外层测试折", "Outer test fold"), ylabel="Pearson r")
        title = target["trait"] + " · " + t("逐折测试相关（描述性波动）", "Fold test correlations (descriptive variation)")
    elif kind == "learning":
        path = data["selected_root"] / "history.csv"
        if path.is_file() and not (data["cv"] and data["fold"] is None):
            rows = _rows(path)
            axes.plot([float(r["epoch"]) for r in rows], [float(r.get('train_loss') or r["train_online_mse"]) for r in rows],
                      label=t("训练（在线）", "Training (online)"))
            val = [r for r in rows if r.get('validation_loss',r.get("validation_mse")) not in (None, "")]
            if val:
                axes.plot([float(r["epoch"]) for r in val], [float(r.get('validation_loss') or r["validation_mse"]) for r in val], label=t("验证", "Validation"))
            objective=rows[-1].get('loss_name','mse') if rows else 'loss'
            axes.set_ylabel(objective.upper()+t('（训练目标量纲）',' (training objective scale)'))
        else:
            axes.text(.5, .5, t("选择一折查看该模型的训练曲线。", "Select one fold to view its learning curve."), ha="center", va="center", transform=axes.transAxes)
        axes.set_xlabel(t("训练轮次", "Epoch"))
        title = target['trait']+' · '+t("训练与验证；不逐轮评估测试集", "Training and validation; no test monitoring")
        if data['summary'].get('multitask'):title=t('联合目标共享损失','Joint-target shared loss')+' · '+title
        if data.get('fold') is not None:title+=t(' · 外层折 ',' · outer fold ')+str(data['fold'])
    else:
        fail("E_VALUE", "plot", f"unknown plot: {kind}")
    if empty:
        axes.text(.5, .5, t("没有有效观测", "No finite observations"), ha="center", va="center", transform=axes.transAxes)
    axes.set_title(title, fontsize=10, wrap=True)
    font = _font(language)
    for item in (axes.title, axes.xaxis.label, axes.yaxis.label, *axes.texts):
        item.set_fontproperties(font)
    handles, labels = axes.get_legend_handles_labels()
    if handles:
        axes.legend(prop=font)
    return axes


def render_combination(figure, data, language='en', *, learning_fold=None):
    """Four axes share one figure; CV learning always represents one actual fit."""
    figure.clear()
    axes=figure.subplots(2,2)
    render_plot(figure,data,'scatter',language,axes=axes[0,0])
    render_plot(figure,data,'residual',language,axes=axes[0,1])
    learning=data
    if data['cv'] and data['fold'] is None:
        fold=learning_fold or data['summary']['fold_runs'][0]['fold']
        learning=load_result_data(data['root'],target_id=data['target']['id'],partition='test',fold=fold)
        data['snapshots'].update({f'learning_{key}':value for key,value in learning['snapshots'].items()})
    render_plot(figure,learning,'learning',language,axes=axes[1,0])
    render_plot(figure,data,'folds' if data['cv'] else 'error',language,axes=axes[1,1])
    metrics=data['metrics'];p=metrics.get('pearson')
    fmt=lambda x:'—' if x is None else f'{x:.5g}'
    title=f"{data['target']['trait']} · {selected_caption(data,language)} · n={metrics['n']} · r={fmt(p)} · RMSE={fmt(metrics.get('rmse'))}"
    figure.suptitle(title,fontproperties=_font(language),fontsize=11)
    return axes


def export_result_plots(source, output, *, language="en", target_id=None, partition="test", fold=None,
                        formats=("png", "svg", "pdf"), selection=None, progress=None, cancelled=None):
    """Export all targets by default; output is separate from the sealed model.

    Uses source snapshots instead of rewriting a run when changing its language.
    """
    from matplotlib import rc_context
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    from matplotlib.figure import Figure
    from .training.core import check_cancel
    source_summary=Path(source)/'summary.json'
    if source_summary.is_file() and read_json(source_summary).get('kind')=='trait_batch':
        from .batch_results import export_batch_results
        return export_batch_results(source,output,language=language,target_id=target_id,formats=formats,progress=progress,cancelled=cancelled)
    root, summary = result_root(source)
    verify_bundle(source, required=("run/complete.json",) if root != Path(source).resolve() else ("summary.json", "predictions.csv"))
    output = Path(output).resolve()
    if output.exists():
        fail("E_EXISTS", str(output), "choose a new plot output directory")
    archive_root = Path(source).resolve()
    if output.is_relative_to(archive_root) or archive_root.is_relative_to(output):
        fail("E_IO", str(output), "plot output must not overlap the archived result")
    protect_inputs(output, [root])
    if not formats or any(f not in ("png", "svg", "pdf") for f in formats) or len(set(formats)) != len(formats):
        fail("E_VALUE", "formats", "select PNG, SVG, PDF, or a nonduplicate subset")
    if language not in ("zh", "en"):
        fail("E_VALUE", "language", "expected zh or en")
    targets = result_targets(summary)
    if target_id is not None:
        targets = [t for t in targets if t["id"] == target_id]
        if not targets:
            fail("E_VALUE", "target", "unknown target ID")
    output.mkdir(parents=True)
    (output / "INCOMPLETE").write_text("Plot export incomplete", encoding="utf-8")
    artifacts, metrics = [], []
    try:
        for index, target in enumerate(targets, 1):
            check_cancel(cancelled)
            data = load_result_data(root, target_id=target["id"], partition=partition, fold=fold)
            directory = output / f"target_{index:03}"
            directory.mkdir()
            if selection is not None:
                from .training.metrics import selection_summary
                selected = selection_summary(data['observed'], data['predicted'], **selection)
                paired = [r for r in data['rows'] if r.get('observed') not in ('', None)]
                selected['selected_individuals'] = [{k:paired[i].get(k) for k in ('FID','IID','observed','predicted')}
                    for i in selected['predicted_indices']]
                selected['scope'] = selected_caption(data, language)
                write_json(directory / 'selection_summary.json', selected)
            fields = list(data["rows"][0]) if data["rows"] else ["FID", "IID", "observed", "predicted", "partition", "target_id", "fold"]
            write_csv(directory / "predictions.csv", fields, ([r[k] for k in fields] for r in data["rows"]))
            if data["fold_metrics"]:
                fields = ["fold", "n", "pearson", "pearson_reason", "rmse", "mae"]
                write_csv(directory / "fold_metrics.csv", ["partition", *fields], (["test", *[r[k] for k in fields]] for r in data["fold_metrics"]))
            kinds = ["scatter", "error"]
            with rc_context({'svg.fonttype':'none','pdf.fonttype':42}):
                combined=Figure(figsize=(12,9),layout='constrained');FigureCanvasAgg(combined)
                render_combination(combined,data,language)
                for fmt in formats:
                    check_cancel(cancelled)
                    destination=directory/f'combination.{fmt}';combined.savefig(destination,dpi=150)
                    artifacts.append(destination.relative_to(output).as_posix())
            if data["cv"] and data["fold_pearson"]["reason"] not in ("leave_out_use_pooled_oof", "leave_group_use_pooled_oof"):
                kinds.append("folds")
            if (data["selected_root"] / "history.csv").is_file():
                kinds.append("learning")
            for kind in kinds:
                check_cancel(cancelled)
                with rc_context({"svg.fonttype": "none", "pdf.fonttype": 42}):
                    figure = Figure(figsize=(6.2, 4.8), layout="constrained")
                    FigureCanvasAgg(figure)
                    render_plot(figure, data, kind, language)
                    for fmt in formats:
                        check_cancel(cancelled)
                        destination = directory / f"{kind}.{fmt}"
                        figure.savefig(destination, dpi=150)
                        artifacts.append(destination.relative_to(output).as_posix())
                if progress:
                    progress(dict(event="stage", stage="export_plots", done=index, total=len(targets), plot=kind))
            timing = data["timing"]
            write_csv(directory / "timing.csv", ["category", "label", "seconds", "scope"],
                      ((key, _text(language, zh, en), timing.get(key), timing.get("scope", "unavailable")) for key, zh, en in TIMING_FIELDS))
            details = dict(target=target, partition=partition, fold=fold,
                           evaluation=selected_caption(data, language), metrics=data["metrics"],
                           fold_pearson=data["fold_pearson"], fold_metrics_partition="test" if data["cv"] else None, timing=timing,
                           overview=data['overview'], configuration=data['configuration'],
                           timing_note="Joint model time is not divided among traits; absent timing was not recorded.",
                           source_snapshots=data["snapshots"])
            write_json(directory / "summary.json", details)
            metrics.append(dict(target_id=target["id"], trait=target["trait"], unit=target.get("unit", ""), **data["metrics"]))
            verify_snapshots(data["snapshots"])
        fields = ["target_id", "trait", "unit", *metrics[0].keys()]
        fields = list(dict.fromkeys(fields))
        write_csv(output / "metrics.csv", fields, ([m[k] for k in fields] for m in metrics))
        from .result_report import write_report
        write_report(output, summary, metrics, language=language, partition=partition, fold=fold)
        result = dict(ok=True, schema_version=1, kind="result_plot_export", language=language,
                      source=str(root), partition=partition, fold=fold, selection=selection, targets=len(targets), artifacts=artifacts)
        write_json(output / "summary.json", result)
        (output / "INCOMPLETE").unlink()
        return result
    except BaseException as error:
        write_json(output / "failure.json", dict(ok=False, error=str(error),
                   status="cancelled" if isinstance(error, KeyboardInterrupt) or getattr(error, "code", "") == "E_CANCELLED" else "failed"))
        raise
