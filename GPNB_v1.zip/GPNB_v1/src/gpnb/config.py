"""Versioned JSON contracts. No torch, data reads or implicit migrations.

Spec instances hold immutable canonical JSON. Editing uses to_dict() followed
by from_dict(); unknown fields are rejected except explicit JSON extensions.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import ClassVar

from .errors import GPNBError

SCHEMA_VERSION = 1
ACTIVATIONS = ("ReLU", "GELU", "Tanh", "Sigmoid")


def fail(code, path, detail):
    raise GPNBError(code, path, detail)


def object_fields(value, path, required, optional=()):
    if type(value) is not dict:
        fail("E_TYPE", path, "expected object")
    missing, extra = set(required) - value.keys(), value.keys() - set(required) - set(optional)
    if missing or extra:
        fail("E_FIELD", path, f"missing={sorted(missing)}, unknown={sorted(extra)}")


def text(value, path, *, empty=False):
    if type(value) is not str:
        fail("E_TYPE", path, "expected string; numeric IDs are not converted")
    if "\0" in value or (not empty and not value.strip()):
        fail("E_VALUE", path, "expected nonempty text without NUL")


def number(value, path, minimum=None, maximum=None, *, integer=False, positive=False):
    types = (int,) if integer else (int, float)
    if type(value) not in types:
        fail("E_TYPE", path, "expected integer" if integer else "expected finite number")
    if type(value) is float and not math.isfinite(value):
        fail("E_RANGE", path, "NaN/Infinity is not allowed")
    if ((minimum is not None and value < minimum) or
            (maximum is not None and value > maximum) or (positive and value <= 0)):
        fail("E_RANGE", path, f"min={minimum}, max={maximum}, positive={positive}")


def boolean(value, path):
    if type(value) is not bool:
        fail("E_TYPE", path, "expected boolean")


def choice(value, path, choices):
    # A literal tab is a valid delimiter; membership, not stripping, decides validity.
    text(value, path, empty=True)
    if value not in choices:
        fail("E_VALUE", path, f"expected one of {list(choices)}")


def sequence(value, path, *, nonempty=True):
    if type(value) is not list:
        fail("E_TYPE", path, "expected array")
    if nonempty and not value:
        fail("E_VALUE", path, "array must not be empty")


def optional_path(value, path):
    if value is not None:
        text(value, path)


def json_value(value, path="$"):
    """Reject non-JSON values, non-string keys and all nonfinite numbers."""
    if value is None or type(value) in (str, bool):
        return
    if type(value) in (int, float):
        number(value, path)
    elif type(value) is list:
        for index, item in enumerate(value):
            json_value(item, f"{path}[{index}]")
    elif type(value) is dict:
        for key, item in value.items():
            if type(key) is not str:
                fail("E_TYPE", path, "JSON object keys must be strings")
            json_value(item, f"{path}.{key}")
    else:
        fail("E_TYPE", path, "value is not JSON-serializable")


def header(value, path, kind, fields):
    object_fields(value, path, ("schema_version", "kind", *fields), ("extensions",))
    if type(value["schema_version"]) is not int or value["schema_version"] != SCHEMA_VERSION:
        fail("E_VERSION", path + ".schema_version", f"supported={SCHEMA_VERSION}")
    choice(value["kind"], path + ".kind", (kind,))
    if "extensions" in value and type(value["extensions"]) is not dict:
        fail("E_TYPE", path + ".extensions", "expected object")


def validate_layer(layer, path):
    object_fields(layer, path, ("id", "type", "params"))
    text(layer["id"], path + ".id")
    kind, params = layer["type"], layer["params"]
    choice(kind, path + ".type", ("Linear", "Dropout", *ACTIVATIONS))
    if kind == "Linear":
        object_fields(params, path + ".params", ("out_features", "bias"))
        number(params["out_features"], path + ".params.out_features", 1, 2**31 - 1, integer=True)
        boolean(params["bias"], path + ".params.bias")
    elif kind == "Dropout":
        object_fields(params, path + ".params", ("p",))
        number(params["p"], path + ".params.p", 0, 1)
    else:
        object_fields(params, path + ".params", ())


def validate_model(value, path="$"):
    if type(value) is dict and type(value.get("schema_version")) is int and value["schema_version"] == 2:
        from .models.registry import validate_v2
        return validate_v2(value, path)
    header(value, path, "model", ("name", "task", "input_layout", "layers"))
    text(value["name"], path + ".name")
    choice(value["task"], path + ".task", ("single_trait_regression",))
    choice(value["input_layout"], path + ".input_layout", ("batch_markers",))
    sequence(value["layers"], path + ".layers")
    ids = set()
    for i, layer in enumerate(value["layers"]):
        location = f"{path}.layers[{i}]"
        validate_layer(layer, location)
        if layer["id"] in ids:
            fail("E_VALUE", location + ".id", "duplicate layer ID")
        ids.add(layer["id"])
    last = value["layers"][-1]
    if last["type"] != "Linear" or last["params"]["out_features"] != 1:
        fail("E_VALUE", path + ".layers", "last layer must be Linear(out_features=1)")


def validate_run(value, path="$"):
    header(value, path, "run", ("split", "preprocessing", "training"))
    split = value["split"]
    p = path + ".split"
    object_fields(split, p, ("method", "ratios", "seed", "group_policy", "reuse_manifest"))
    choice(split["method"], p + ".method", ("fixed", "final_selection", "final_training"))
    choice(split["group_policy"], p + ".group_policy", ("genotype_equivalence", "individual_id"))
    optional_path(split["reuse_manifest"], p + ".reuse_manifest")
    number(split["seed"], p + ".seed", 0, 2**32 - 1, integer=True)
    sequence(split["ratios"], p + ".ratios")
    if len(split["ratios"]) != 3:
        fail("E_VALUE", p + ".ratios", "expected train/validation/test ratios")
    for i, ratio in enumerate(split["ratios"]):
        allow_zero = (i == 1 and split["reuse_manifest"]) or (i == 2 and split["method"] == "final_selection") or (i > 0 and split["method"] == "final_training")
        number(ratio, f"{p}.ratios[{i}]", minimum=0 if allow_zero else None, maximum=1, positive=not allow_zero)
    if not math.isclose(sum(split["ratios"]), 1.0, rel_tol=0, abs_tol=1e-10):
        fail("E_VALUE", p + ".ratios", "ratios must sum to one")
    if split["method"] == "final_selection" and split["ratios"][2] != 0:
        fail("E_SPLIT", p, "final selection has an internal holdout and no test set")
    if split["method"] == "final_training" and split["ratios"] != [1., 0., 0.]:
        fail("E_SPLIT", p, "final training uses all eligible rows; ratios must be [1,0,0]")
    pre = value["preprocessing"]
    p = path + ".preprocessing"
    object_fields(pre, p, ("fit_scope", "imputation", "standardize_genotypes", "standardize_target",
                           "maf_min", "marker_missing_max", "all_missing", "zero_variance"), ("enabled", "imputation_options"))
    boolean(pre.get("enabled", True), p + ".enabled")
    from .data.imputation import validate_options as validate_imputation
    validate_imputation(pre["imputation"], pre.get("imputation_options"))
    choice(pre["all_missing"], p + ".all_missing", ("zero_with_warning", "drop", "error"))
    for key, expected in (("fit_scope", "train"),
                          ("zero_variance", "scale_one")):
        choice(pre[key], p + "." + key, (expected,))
    for key in ("standardize_genotypes", "standardize_target"):
        boolean(pre[key], p + "." + key)
    for key, maximum in (("maf_min", .5), ("marker_missing_max", 1)):
        if pre[key] is not None:
            number(pre[key], p + "." + key, 0, maximum)
    if not pre.get("enabled", True) and (pre["imputation"] != "none" or
            pre["standardize_genotypes"] or pre["standardize_target"] or
            pre["maf_min"] is not None or pre["marker_missing_max"] is not None):
        fail("E_PREPROCESS", p, "disabled preprocessing requires no imputation, scaling or marker filters")
    training = value["training"]
    p = path + ".training"
    object_fields(training, p, ("optimizer", "learning_rate", "weight_decay", "batch_size", "epochs",
                               "seed", "patience", "min_delta", "device", "deterministic", "threads", "loss"), ("stages", "selection_mode", "adaptive_max_pool_strict", "momentum", "scheduler", "focal_beta", "focal_gamma", "gradient_clip_norm"))
    choice(training.get("selection_mode", "validation"), p+".selection_mode", ("validation", "fixed_epochs"))
    if split["method"] == "final_training" and training.get("selection_mode") != "fixed_epochs":
        fail("E_SPLIT", p, "all-data final training requires explicitly fixed selected epochs")
    boolean(training.get("adaptive_max_pool_strict", False), p+".adaptive_max_pool_strict")
    if "stages" in training:
        from .training.stages import validate_stages
        validate_stages(training["stages"])
    choice(training["optimizer"], p + ".optimizer", ("Adam", "SGD"))
    choice(training["device"], p + ".device", ("cpu", "cuda"))
    choice(training["loss"], p + ".loss", ("mse", "mae", "focal_mae"))
    number(training.get("momentum", 0.), p+".momentum", 0, 1)
    number(training.get("focal_beta", .5), p+".focal_beta", positive=True)
    number(training.get("focal_gamma", 1.), p+".focal_gamma", 1, 100)
    if training.get("gradient_clip_norm") is not None:
        number(training["gradient_clip_norm"], p+".gradient_clip_norm", positive=True)
    scheduler = training.get("scheduler")
    if scheduler is not None:
        object_fields(scheduler, p+".scheduler", ("type", "gamma"), ("step_size",))
        choice(scheduler["type"], p+".scheduler.type", ("ExponentialLR", "StepLR"))
        number(scheduler["gamma"], p+".scheduler.gamma", 0, 1, positive=True)
        if scheduler["type"] == "StepLR":
            number(scheduler.get("step_size"), p+".scheduler.step_size", 1, 2**31-1, integer=True)
        elif "step_size" in scheduler:
            fail("E_VALUE", p+".scheduler.step_size", "step_size is only used by StepLR")
    boolean(training["deterministic"], p + ".deterministic")
    number(training["learning_rate"], p + ".learning_rate", positive=True)
    for key in ("weight_decay", "min_delta"):
        number(training[key], p + "." + key, 0)
    for key in ("batch_size", "epochs", "patience", "threads"):
        number(training[key], p + "." + key, 1, 2**31 - 1, integer=True)
    number(training["seed"], p + ".seed", 0, 2**32 - 1, integer=True)
    if "search" in value.get("extensions", {}):
        from .training.search import validate_search
        validate_search(value["extensions"]["search"])
    if "cross_validation" in value.get("extensions", {}):
        validate_cv_options(value["extensions"]["cross_validation"], path + ".extensions.cross_validation")


def validate_cv_options(value, path="cross_validation"):
    object_fields(value, path, ("folds", "seed", "validation_fraction", "reuse_manifest"), ("method", "approved_folds", "training_policy"))
    choice(value.get("training_policy", "inner_holdout"), path+".training_policy", ("inner_holdout", "full_training"))
    method = value.get("method", "five_fold")
    choice(method, path + ".method", ("five_fold", "ten_fold", "leave_one_individual_out", "leave_one_genotype_group_out"))
    if method in ("five_fold", "ten_fold"):
        if value.get('training_policy') == 'full_training':
            fail('E_VALUE', path+'.training_policy', 'full_training is only a leave-out policy; K-fold uses inner validation')
        k = 5 if method == "five_fold" else 10
        number(value["folds"], path + ".folds", k, k, integer=True)
    elif value["folds"] is not None:
        fail("E_VALUE", path + ".folds", "leave-out fold count is data-derived; set folds to null")
    if value.get("approved_folds") is not None:
        number(value["approved_folds"], path + ".approved_folds", 2, 2**31-1, integer=True)
    number(value["seed"], path + ".seed", 0, 2**32 - 1, integer=True)
    number(value["validation_fraction"], path + ".validation_fraction", .01, .49)
    optional_path(value["reuse_manifest"], path + ".reuse_manifest")


def validate_project(value, path="$"):
    header(value, path, "project", ("project_id", "name", "language", "data", "output_dir", "model", "run"))
    for key in ("project_id", "name", "output_dir"):
        text(value[key], path + "." + key)
    choice(value["language"], path + ".language", ("zh_CN", "en_US"))
    data, p = value["data"], path + ".data"
    object_fields(data, p, ("dataset_id", "bed", "bim", "fam", "phenotype", "manifest",
                            "split_groups", "phenotype_options"), ("matrix",))
    if data.get("matrix") is not None:
        from .data.genotypes import validate_matrix
        validate_matrix(data["matrix"])
        if data["bed"] is not None or data["fam"] is not None:
            fail("E_VALUE", p, "matrix source uses its own IDs; bed/fam must be null")
        if data["manifest"] is not None:
            fail("E_MANIFEST", p, "legacy PLINK manifests cannot describe matrix inputs")
        if data["matrix"]["counted_allele"] == "DECLARED":
            if data["bim"] is not None:
                fail("E_VALUE", p + ".bim", "DECLARED matrix uses named columns without a BIM file")
        else:
            text(data["bim"], p + ".bim")
    else:
        for key in ("bed", "bim", "fam"):
            text(data[key], p + "." + key)
    for key in ("dataset_id", "phenotype"):
        text(data[key], p + "." + key)
    for key in ("manifest", "split_groups"):
        optional_path(data[key], p + "." + key)
    options, p = data["phenotype_options"], p + ".phenotype_options"
    object_fields(options, p, ("delimiter", "encoding", "id_mode", "id_columns", "trait", "missing_tokens"))
    choice(options["delimiter"], p + ".delimiter", (",", "\t", "whitespace"))
    choice(options["encoding"], p + ".encoding", ("utf-8", "utf-8-sig", "gb18030"))
    choice(options["id_mode"], p + ".id_mode", ("fid_iid", "iid"))
    sequence(options["id_columns"], p + ".id_columns")
    count = 2 if options["id_mode"] == "fid_iid" else 1
    if len(options["id_columns"]) != count:
        fail("E_VALUE", p + ".id_columns", f"expected {count} explicitly ordered ID columns")
    for i, column in enumerate(options["id_columns"]):
        text(column, f"{p}.id_columns[{i}]")
    if len(set(options["id_columns"])) != count:
        fail("E_VALUE", p + ".id_columns", "duplicate ID columns")
    if data.get("matrix") and len(data["matrix"]["id_columns"]) == 1 and options["id_mode"] != "iid":
        fail("E_VALUE", p + ".id_mode", "a single-ID genotype matrix requires IID phenotype matching")
    text(options["trait"], p + ".trait")
    if options["trait"] in options["id_columns"]:
        fail("E_VALUE", p + ".trait", "trait cannot be an ID column")
    sequence(options["missing_tokens"], p + ".missing_tokens", nonempty=False)
    for i, token in enumerate(options["missing_tokens"]):
        text(token, f"{p}.missing_tokens[{i}]", empty=True)
    from .training.trait_batch import validate_batch
    validate_batch(value)
    validate_model(value["model"], path + ".model")
    validate_run(value["run"], path + ".run")
    if "search" in value["run"].get("extensions", {}) and "stages" in value["run"]["training"]:
        fail("E_SEARCH", "stages", "parameter search currently requires single-stage regression; remove stages before searching")
    if value.get("extensions",{}).get("multitask") is not None or value["model"].get("task")=="multi_target_regression":
        from .data.multitask import validate_project_contract
        validate_project_contract(value)
    if "stages" in value["run"]["training"] or value["model"].get("reconstruction_output"):
        from .training.stages import validate_stage_model
        validate_stage_model(value["model"],value["run"]["training"].get("stages"))
    from .data.kernel_features import validate_project_kernel
    validate_project_kernel(value)
    if "input_tables" in value.get("extensions", {}) or value["model"].get("external_inputs"):
        from .data.additional import validate_tables, table_widths
        validate_tables(value.get("extensions", {}).get("input_tables", []), options["trait"])
        external = dict(value["model"].get("external_inputs", {}))
        if value["run"].get("extensions", {}).get("kernel_features", {}).get("mode") == "snp_kernel":
            external.pop("kernel", None)
        if table_widths(value) != external:
            fail("E_INPUT_TABLE", path, "model external input names/widths must exactly match selected input tables")


def _unique_pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            fail("E_JSON", "$", f"duplicate key: {key}")
        result[key] = value
    return result


@dataclass(frozen=True, init=False)
class Spec:
    _canonical: str
    kind: ClassVar[str]
    validator: ClassVar

    def __init__(self, document: dict):
        json_value(document)
        self.validator(document)
        object.__setattr__(self, "_canonical", json.dumps(document, ensure_ascii=False, sort_keys=True,
                                                        separators=(",", ":"), allow_nan=False))

    @classmethod
    def from_dict(cls, document: dict):
        return cls(document)

    def to_dict(self) -> dict:
        return json.loads(self._canonical)

    @property
    def sha256(self) -> str:
        return hashlib.sha256(self._canonical.encode("utf-8")).hexdigest()

    def save(self, path: Path, *, overwrite=False):
        """Atomic complete file. Existing project requires explicit overwrite."""
        path = Path(path)
        temporary = None
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent,
                                             prefix=".gpnb-", suffix=".partial", delete=False) as handle:
                temporary = Path(handle.name)
                handle.write(json.dumps(self.to_dict(), ensure_ascii=False, sort_keys=True, indent=2,
                                        allow_nan=False) + "\n")
                handle.flush()
                os.fsync(handle.fileno())
            if overwrite:
                os.replace(temporary, path)
            else:
                # Windows rename refuses an existing target, including on non-NTFS.
                if os.name == "nt":
                    os.rename(temporary, path)
                else:
                    os.link(temporary, path)
        except FileExistsError:
            fail("E_EXISTS", str(path), "use explicit overwrite for an existing project")
        except OSError as error:
            fail("E_IO", str(path), str(error))
        finally:
            if temporary is not None:
                temporary.unlink(missing_ok=True)


class ModelSpec(Spec):
    kind = "model"
    validator = staticmethod(validate_model)


class RunSpec(Spec):
    kind = "run"
    validator = staticmethod(validate_run)


class ProjectSpec(Spec):
    kind = "project"
    validator = staticmethod(validate_project)


SPEC_TYPES = {s.kind: s for s in (ModelSpec, RunSpec, ProjectSpec)}


def load_spec(path: Path) -> Spec:
    path = Path(path)
    try:
        document = json.loads(path.read_text(encoding="utf-8-sig"), object_pairs_hook=_unique_pairs,
                              parse_constant=lambda x: fail("E_JSON", "$", f"nonfinite token: {x}"))
    except (OSError, UnicodeError) as error:
        fail("E_IO", str(path), str(error))
    except json.JSONDecodeError as error:
        fail("E_JSON", f"{path}:{error.lineno}:{error.colno}", error.msg)
    if type(document) is not dict:
        fail("E_TYPE", "$", "expected object")
    if document.get("kind") == "graph":
        from .graphs.spec import GraphSpec
        return GraphSpec(document)
    if document.get("kind") == "individual_graph":
        from .graphs.individual import IndividualGraphSpec
        return IndividualGraphSpec(document)
    choice(document.get("kind"), "$.kind", SPEC_TYPES)
    return SPEC_TYPES[document["kind"]](document)


def resolve_project_path(project_file: Path, stored_path: str) -> Path:
    """Relative references are based on the project JSON, never the shell cwd."""
    candidate = Path(stored_path)
    return candidate.resolve() if candidate.is_absolute() else (Path(project_file).resolve().parent / candidate).resolve()


def default_model() -> ModelSpec:
    return ModelSpec({"schema_version": 1, "kind": "model", "name": "Basic MLP",
                      "task": "single_trait_regression", "input_layout": "batch_markers", "layers": [
                          {"id": "linear_1", "type": "Linear", "params": {"out_features": 64, "bias": True}},
                          {"id": "relu_1", "type": "ReLU", "params": {}},
                          {"id": "linear_2", "type": "Linear", "params": {"out_features": 16, "bias": True}},
                          {"id": "relu_2", "type": "ReLU", "params": {}},
                          {"id": "output", "type": "Linear", "params": {"out_features": 1, "bias": True}},
                      ]})


def default_run() -> RunSpec:
    return RunSpec({"schema_version": 1, "kind": "run",
                    "split": {"method": "fixed", "ratios": [.7, .15, .15], "seed": 5209,
                              "group_policy": "individual_id", "reuse_manifest": None},
                    "preprocessing": {"fit_scope": "train", "imputation": "mean", "standardize_genotypes": True,
                                      "standardize_target": False, "maf_min": None, "marker_missing_max": None,
                                      "all_missing": "drop", "zero_variance": "scale_one"},
                    "training": {"optimizer": "Adam", "learning_rate": .001, "weight_decay": 0,
                                 "batch_size": 64, "epochs": 100, "seed": 5209, "patience": 20,
                                 "min_delta": 0, "device": "cpu", "deterministic": True, "threads": 2, "loss": "mse"}})
