"""Short-lived health probes; native-library failures stay out of the parent."""
from __future__ import annotations

import argparse
import importlib
import importlib.metadata
import json
import math
import tempfile
from pathlib import Path

from .paths import configure_local_paths


def imports():
    versions = {}
    for module, distribution in [
        ("numpy", "numpy"), ("torch", "torch"), ("PySide6", "PySide6"),
        ("bed_reader", "bed-reader"), ("matplotlib", "matplotlib"), ("psutil", "psutil"),
    ]:
        importlib.import_module(module)
        versions[distribution] = importlib.metadata.version(distribution)
    return {"versions": versions}


def train(device):
    import torch

    if device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA is unavailable in this environment. Select the CPU profile or inspect the driver; no automatic fallback.")
    torch.set_num_threads(2)
    torch.manual_seed(5209)
    x = torch.randn(64, 8).to(device)
    y = (x[:, :1] * 2 - x[:, 1:2] + .5)
    model = torch.nn.Sequential(torch.nn.Linear(8, 16), torch.nn.Tanh(), torch.nn.Linear(16, 1)).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=.03)
    before = model[0].weight.detach().clone()
    initial = float(torch.nn.functional.mse_loss(model(x), y).detach().cpu())
    for _ in range(40):
        optimizer.zero_grad(set_to_none=True)
        loss = torch.nn.functional.mse_loss(model(x), y)
        loss.backward()
        if not all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters()):
            raise RuntimeError("Nonfinite/missing gradients")
        optimizer.step()
    if device == "cuda":
        torch.cuda.synchronize()
    final = float(torch.nn.functional.mse_loss(model(x), y).detach().cpu())
    if not math.isfinite(final) or final >= initial or torch.equal(before, model[0].weight):
        raise RuntimeError(f"Small model update failed: initial={initial}, final={final}")
    return {"device": device, "initial_mse": initial, "final_mse": final, "steps": 40,
            "weights_changed": True, "finite_gradients": True, "torch": torch.__version__,
            "cuda_build": torch.version.cuda,
            "device_name": torch.cuda.get_device_name(0) if device == "cuda" else "CPU",
            "purpose": "synthetic environment smoke check, not a genomic prediction result"}


def bed():
    import numpy as np
    from bed_reader import open_bed

    with tempfile.TemporaryDirectory(prefix="gpnb-doctor-", dir=configure_local_paths() / "tmp") as directory:
        root = Path(directory)
        (root / "tiny.bed").write_bytes(bytes([0x6c, 0x1b, 0x01, 0xE4, 0, 0x1B, 3]))
        (root / "tiny.fam").write_text("".join(f"00 00{i} 0 0 0 -9\n" for i in range(5)), encoding="utf-8")
        (root / "tiny.bim").write_text("scaffold_1\tm1\t0\t1\tA\ta\nscaffold_1\tm2\t0\t2\tC\tG\n", encoding="utf-8")
        reader = open_bed(root / "tiny.bed", count_A1=True, num_threads=2)
        np.testing.assert_array_equal(reader.read(dtype="int8"), [[2, 0], [-127, 1], [1, -127], [0, 2], [2, 0]])
        assert list(reader.iid) == [f"00{i}" for i in range(5)]
        assert list(reader.allele_2) == ["a", "G"]
    return {"golden_values": "passed", "leading_zero_ids": "passed", "allele_case": "passed"}


def qt(mode):
    from PySide6.QtCore import QTimer
    from PySide6.QtWidgets import QApplication, QLabel

    app = QApplication([])
    label = QLabel("GPNB_v1\n环境窗口自检 / Environment window check\nThis window closes automatically.")
    label.setWindowTitle("GPNB_v1 health check")
    label.resize(440, 150)
    label.show()
    result = {}

    def finish():
        result.update(platform=app.platformName(), visible=label.isVisible(),
                      exposed=bool(label.windowHandle() and label.windowHandle().isExposed()))
        label.close()
        app.quit()

    QTimer.singleShot(500, finish)
    app.exec()
    if not result.get("visible"):
        raise RuntimeError("Qt widget did not become visible")
    if mode == "window" and (result["platform"] != "windows" or not result["exposed"]):
        raise RuntimeError(f"Native Windows window was not exposed: {result}")
    result["mode"] = mode
    return result


def main():
    configure_local_paths()
    parser = argparse.ArgumentParser()
    parser.add_argument("probe", choices=["imports", "cpu", "cuda", "bed", "qt"])
    parser.add_argument("--qt-mode", choices=["window", "offscreen"], default="window")
    args = parser.parse_args()
    try:
        result = (imports() if args.probe == "imports" else
                  train(args.probe) if args.probe in {"cpu", "cuda"} else
                  bed() if args.probe == "bed" else qt(args.qt_mode))
        print(json.dumps({"ok": True, **result}, ensure_ascii=False))
        return 0
    except Exception as error:
        print(json.dumps({"ok": False, "error": f"{type(error).__name__}: {error}"}, ensure_ascii=False))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
