"""Independent descriptive GRM/kernel export, separate from training features."""
from __future__ import annotations

import csv
import shutil
import time
from pathlib import Path

import numpy as np

from ..config import ProjectSpec, fail, load_spec
from .audit import inspect_project
from .cache import load_cache
from .descriptor import load_descriptor
from .files import protect_inputs, snapshot, verify_snapshots, write_csv, write_json, sha256
from .genotypes import source_paths
from .kernels import KernelState, resource_estimate, validate_recipe
from .prepare import table
from .preprocessing import marker_identity


def export_matrices(project_file, output, recipe, *, cache_root=None, text=False,
                    progress=None, cancelled=None):
    """Export K(all, all) with explicit descriptive scope and fitted reference.

    This file is never imported by the training adapter. Training receives a
    recipe and fits its own reference state after each outer/inner split.
    """
    start = time.perf_counter()
    project_file, output = Path(project_file).resolve(), Path(output).resolve()
    recipe = validate_recipe(recipe)
    if type(text) is not bool:
        fail("E_TYPE", "matrix_export.text", "text export must be boolean")
    spec = load_spec(project_file)
    if not isinstance(spec, ProjectSpec):
        fail("E_TYPE", str(project_file), "matrix export requires ProjectSpec")
    project = spec.to_dict()
    inputs = source_paths(project["data"], project_file)
    protect_inputs(output, [project_file, *inputs.values()])
    if output.exists():
        fail("E_EXISTS", str(output), "choose a new relationship/kernel matrix directory")
    if cache_root is not None:
        cache_root = Path(cache_root).resolve()
        if output.is_relative_to(cache_root) or cache_root.is_relative_to(output):
            fail("E_IO", str(output), "matrix output and cache root must not overlap")
    else:
        # A self-contained cache is allowed beside (not inside) the audit.
        cache_root = output / "raw_cache"
    sources = {"project": snapshot(project_file), **{k: snapshot(p) for k, p in inputs.items()}}
    output.mkdir(parents=True)
    (output / "INCOMPLETE").write_text("Matrix export is not complete.\n", encoding="utf-8")
    write_json(output / "recipe.json", recipe)
    scope = ("Descriptive all-cohort matrix: all imported genotype individuals are reference rows. "
             "This export is not a train-only evaluation input. Formal training refits its own reference on each training partition.")
    write_json(output / "scope.json", dict(schema_version=1, reference_scope="all_imported_genotype_individuals",
               strict_training_boundary=False, scope=scope, source_files=sources))
    matrix = None
    estimate = None
    def stage(name, done=0, total=0):
        if cancelled and cancelled():
            fail("E_CANCELLED", str(output), "matrix export cancelled; partial matrix must not be used")
        if progress:
            progress({"event": "stage", "stage": name, "done": int(done), "total": int(total)})
    try:
        stage("matrix_import")
        inspect_project(project_file, output / "import", scan=True, cache_root=cache_root, progress=stage)
        descriptor = load_descriptor(output / "import")
        cache = load_cache(Path(descriptor["cache"]["path"]))
        n, m = cache.metadata["shape"]
        estimate = resource_estimate(n, m, recipe)
        estimate["text_export_requested"] = text
        estimate["text_bytes_exact"] = None
        estimate["text_note"] = "Text size depends on formatting and IDs; it is additional to binary/state storage."
        write_json(output / "resource_estimate.json", estimate)
        if progress:
            progress({"event": "matrix_estimate", **estimate})
        if estimate["matrix_bytes"] > recipe["max_matrix_bytes"]:
            fail("E_MODEL_LIMIT", str(output), f"Matrix requires {estimate['matrix_bytes']} bytes; max_matrix_bytes={recipe['max_matrix_bytes']}.")
        # Numeric NPZ state is intentionally uncompressed and has a predictable
        # minimum. No promise about Python/JSON/text/runtime overhead is made.
        minimum = estimate["matrix_bytes"] + estimate["state_numeric_bytes"] + 1024**2
        if shutil.disk_usage(output).free < minimum:
            fail("E_IO", str(output), f"At least {minimum} bytes of additional disk are needed for matrix/reference state; text needs extra space.")
        samples = table(output / "import" / "samples.csv")
        markers = marker_identity(table(output / "import" / "markers.csv"))
        ids = [[s["FID"], s["IID"]] for s in samples]
        rows, columns = np.arange(n), np.arange(m)
        state = KernelState.fit_cache(cache, rows, columns, recipe, reference_ids=ids, markers=markers,
                    provenance=dict(scope="descriptive_all_cohort", source_provenance=descriptor["provenance"],
                                    encoding=cache.metadata["identity"]["encoding"],
                                    source_files=descriptor["source_files"]), progress=stage, cancelled=cancelled)
        state.save(output / "reference")
        stage("matrix_calculate")
        matrix = state.transform_cache(cache, rows, columns, out=output / "matrix.npy", progress=stage, cancelled=cancelled)
        write_csv(output / "row_ids.csv", ["matrix_row", "FID", "IID"], ((i, *v) for i, v in enumerate(ids)))
        write_csv(output / "column_ids.csv", ["matrix_column", "FID", "IID"], ((i, *v) for i, v in enumerate(ids)))
        if text:
            with (output / "matrix.csv").open("w", encoding="utf-8-sig", newline="") as stream:
                writer = csv.writer(stream, lineterminator="\n")
                # Numeric column positions are unambiguous; full string IDs
                # live in column_ids.csv, including composite IDs and commas.
                writer.writerow(["matrix_row", "FID", "IID", *[f"reference_{i}" for i in range(n)]])
                for i in range(n):
                    stage("matrix_text_export", i, n)
                    writer.writerow([i, *ids[i], *[format(float(v), ".9g") for v in matrix[i]]])
        matrix.flush()
        matrix._mmap.close()
        matrix = None
        verify_snapshots(sources)
        stage("matrix_complete", n, n)
        report = dict(schema_version=1, kind="kernel_matrix_export", ok=True, output=str(output),
                      matrix="matrix.npy", text_matrix="matrix.csv" if text else None,
                      shape=[n, n], markers=m, recipe=recipe, resource_estimate=estimate,
                      reference_scope="all_imported_genotype_individuals", strict_training_boundary=False,
                      scope=scope, elapsed_seconds=time.perf_counter()-start,
                      row_ids="row_ids.csv", column_ids="column_ids.csv", reference="reference",
                      source_files=sources, encoding=cache.metadata["identity"]["encoding"])
        write_json(output / "report.json", report)
        inventory = {p.relative_to(output).as_posix(): sha256(p) for p in output.rglob("*")
                     if p.is_file() and p.name != "INCOMPLETE"}
        write_json(output / "complete.json", dict(schema_version=1, kind="kernel_matrix_bundle", files=inventory))
        (output / "INCOMPLETE").unlink()
        return report
    except BaseException as error:
        if matrix is not None:
            matrix.flush()
            matrix._mmap.close()
        write_json(output / "failure.json", dict(ok=False, error=str(error),
                   cancelled=getattr(error, "code", None) == "E_CANCELLED", scope=scope,
                   resource_estimate=estimate, elapsed_seconds=time.perf_counter()-start,
                   partial_outputs_must_not_be_used=True))
        raise
