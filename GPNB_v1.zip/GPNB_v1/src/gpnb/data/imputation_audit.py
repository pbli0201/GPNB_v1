"""Artificial masking audit confined to caller-supplied training genotypes.

This is a diagnostic, not an outer-test predictor assessment. Real missing calls
have no truth labels and never enter the metric denominator.
"""
from __future__ import annotations

import time
import numpy as np
from .imputation import ImputerState, statistics, _fail


def audit_imputation(training_raw, method, *, options=None, fraction=.1, seed=1729,
                     pattern="scattered", progress=None, cancelled=None):
    raw = np.asarray(training_raw)
    if raw.ndim != 2 or min(raw.shape) < 2 or not np.isin(raw, [-1,0,1,2]).all():
        _fail("Masking audit needs at least two training rows/markers of 0/1/2/-1 hard calls.")
    if raw.size > 2_000_000:
        _fail("Masking diagnostics are limited to 2,000,000 training cells. Select a representative training-only subset and record the sampling design.", "E_MODEL_LIMIT")
    if type(fraction) not in (int, float) or not 0 < fraction < 1:
        _fail("Masking fraction must be between zero and one.")
    if pattern not in ("scattered", "contiguous"):
        _fail("Masking pattern must be scattered or contiguous.")
    if method == "none":
        _fail("No-imputation cannot score deliberately hidden calls.")
    if np.any((raw >= 0).sum(0) == 0):
        _fail("Drop training-all-missing columns before the masking audit.")
    rng = np.random.default_rng(seed)
    if pattern == "scattered":
        mask = (rng.random(raw.shape) < fraction) & (raw >= 0)
    else:
        mask = np.zeros(raw.shape, dtype=bool)
        width = max(1, min(raw.shape[1]-1, round(raw.shape[1]*fraction)))
        for row in range(len(raw)):
            start = rng.integers(raw.shape[1]-width+1)
            mask[row, start:start+width] = raw[row, start:start+width] >= 0
    # Keep at least one observed reference value; explain this audit constraint.
    for col in range(raw.shape[1]):
        observed = np.flatnonzero(raw[:,col] >= 0)
        if np.all(mask[observed,col]):
            mask[observed[0],col] = False
    if not mask.any():
        _fail("No known calls selected for masking; use more data or a larger fraction.")
    masked = np.where(mask, -1, raw).astype(np.int8)
    counts = np.stack([(masked == code).sum(0) for code in range(3)])
    start = time.perf_counter()
    imputer = ImputerState.from_counts(counts, method, options, reference=masked)
    predictions = np.empty(raw.shape, dtype=np.float64)
    block = imputer.metadata["options"].get("block_rows", 64)
    for offset in range(0, len(raw), block):
        predictions[offset:offset+block] = imputer.transform(masked[offset:offset+block], progress=progress, cancelled=cancelled)
    observed, mean, _, _ = statistics(counts)
    maf = np.minimum(mean/2, 1-mean/2)
    missing = (masked == -1).mean(1)
    def scores(selected):
        truth, estimate = raw[selected], predictions[selected]
        if not len(truth):
            return {"n":0, "rmse":None, "mae":None, "hard_call_concordance":None}
        hard = method == "mode" or (method == "knn" and imputer.metadata["options"]["output"] == "mode")
        return dict(n=len(truth), rmse=float(np.sqrt(np.mean((truth-estimate)**2))),
                    mae=float(np.abs(truth-estimate).mean()),
                    hard_call_concordance=float((truth == estimate).mean()) if hard else None)
    return dict(schema_version=1, kind="training_masked_genotype_audit", method=method,
                parameters=imputer.metadata, seed=int(seed), pattern=pattern,
                requested_fraction=fraction, actual_masked_calls=int(mask.sum()),
                original_missing_calls=int((raw == -1).sum()), metrics=scores(mask),
                by_reference_maf={name:scores(mask & selected[None,:]) for name,selected in (
                    ("0_to_0.05", maf<.05), ("0.05_to_0.2", (maf>=.05)&(maf<.2)), ("0.2_to_0.5", maf>=.2))},
                by_query_missingness={name:scores(mask & selected[:,None]) for name,selected in (
                    ("below_0.25", missing<.25), ("0.25_or_more", missing>=.25))},
                elapsed_seconds=time.perf_counter()-start,
                scope="Artificially hidden known calls in supplied training data only; not accuracy on real missing calls or phenotype prediction.",
                constraints="At least one observed donor per marker is preserved; MAF uses masked reference observations; continuous estimates are not rounded for concordance.")
