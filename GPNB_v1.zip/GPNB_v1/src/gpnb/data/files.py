from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path

from ..config import _unique_pairs, fail


def sha256(path: Path) -> str:
    from .shared import current
    scope = current()
    return scope.digest(path, _sha256) if scope else _sha256(path)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            from .shared import current
            scope = current()
            if scope:
                scope.check()
            digest.update(block)
    return digest.hexdigest()


def snapshot(path: Path) -> dict:
    if not path.is_file():
        fail("E_IO", str(path), "required input file is missing")
    before = path.stat()
    digest = sha256(path)
    after = path.stat()
    if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
        fail("E_CHANGED", str(path), "file changed while hashing")
    return {"path": str(path), "sha256": digest, "bytes": after.st_size, "mtime_ns": after.st_mtime_ns}


def verify_snapshots(files: dict):
    for info in files.values():
        path = Path(info["path"])
        if not path.is_file() or sha256(path) != info["sha256"]:
            fail("E_CHANGED", str(path), "input hash differs from the initial snapshot; retry from stable inputs")


def read_json(path: Path):
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"), object_pairs_hook=_unique_pairs,
                          parse_constant=lambda x: fail("E_JSON", str(path), f"nonfinite token {x}"))
    except (ValueError, UnicodeError) as error:
        from ..errors import GPNBError
        if isinstance(error, GPNBError):
            raise
        fail("E_JSON", str(path), str(error))


def write_json(path: Path, value):
    # Callers own a fresh output directory; publish each complete JSON atomically.
    temporary = path.with_name(path.name + ".partial")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    temporary.replace(path)


def write_csv(path: Path, fields, rows):
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream, lineterminator="\n")
        writer.writerow(fields)
        writer.writerows(rows)


def order_hash(rows):
    digest = hashlib.sha256()
    for row in rows:
        digest.update((json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n").encode("utf-8"))
    return digest.hexdigest()


def protect_inputs(destination: Path, paths):
    """Protect the application's research data root and explicit input paths."""
    from ..paths import project_root
    readonly = project_root() / "data"
    if destination == readonly or destination.is_relative_to(readonly):
        fail("E_IO", str(destination), "application data/ is read-only; choose runs/ or cache/")
    for path in paths:
        if destination == path:
            fail("E_IO", str(destination), "output/cache conflicts with an input file")
