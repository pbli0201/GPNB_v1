"""One fold-local kernel recipe shared by training, preflight and prediction.

The project stores a recipe; resolved model widths and frozen references belong
to a particular training partition. External numeric tables remain independent.
"""
from __future__ import annotations

import copy
from pathlib import Path

import numpy as np

from ..config import ModelSpec, choice, fail, object_fields
from .files import order_hash, read_json, write_json


def options(project):
    return project['run'].get('extensions', {}).get('kernel_features')


def validate_project_kernel(project):
    config = options(project)
    if config is None:
        return
    from .kernels import validate_recipe
    object_fields(config, 'kernel_features', ('mode', 'kernel'))
    choice(config['mode'], 'kernel_features.mode', ('kernel', 'snp_kernel'))
    validate_recipe(config['kernel'])
    model = project['model']
    external = model.get('external_inputs', {})
    if any(t['id'] == 'kernel' for t in project.get('extensions', {}).get('input_tables', [])):
        fail('E_INPUT_TABLE', 'kernel', 'kernel is reserved for genotype-derived features; rename the numeric table')
    if config['mode'] == 'snp_kernel' and 'kernel' not in external:
        fail('E_MODEL', 'external_inputs.kernel', 'SNP + kernel mode requires an explicit kernel branch and connection')
    if config['mode'] == 'kernel':
        if 'kernel' in external:
            fail('E_MODEL', 'kernel', 'kernel-only mode uses the main input; remove the duplicate external kernel branch')
        if (model.get('input_representation') == 'genotype_categories' or
                model.get('graph_spec') or model.get('individual_graph_spec') or model.get('reconstruction_output')):
            fail('E_MODEL', 'kernel', 'reference-individual columns are not SNP positions/categories; use a compatible regression network or SNP + kernel mode')


def effective_recipe(project):
    from .kernels import validate_recipe
    recipe = dict(options(project)['kernel'])
    # A disabled or no-imputation pipeline must never gain a hidden imputer.
    recipe['imputation'] = project['run']['preprocessing']['imputation']
    recipe.pop('imputation_options', None)
    if project['run']['preprocessing'].get('imputation_options'):
        recipe['imputation_options'] = copy.deepcopy(project['run']['preprocessing']['imputation_options'])
    return validate_recipe(recipe)


def resolved_model(project, reference_count):
    model = copy.deepcopy(project['model'])
    config = options(project)
    if config and config['mode'] == 'snp_kernel':
        model['external_inputs']['kernel'] = int(reference_count)
    return ModelSpec(model)


def bind_kernel(project, data, *, output=None, progress=None, cancelled=None):
    """Fit solely from data.split.train; no validation/test genotypes or labels."""
    for name in ('kernel_state', 'kernel_mode', 'kernel_input_features'):
        if hasattr(data, name):
            delattr(data, name)
    config = options(project)
    if config is None:
        return ModelSpec(project['model'])
    validate_project_kernel(project)
    from .kernels import fit_cache
    rows = data.split.rows('train')
    columns = np.flatnonzero(data.state.arrays['keep'])
    markers = [data.state.metadata['input_markers'][i] for i in columns]
    identities = [[data.samples[i]['FID'], data.samples[i]['IID']] for i in rows]
    state = fit_cache(data.cache, rows, columns, effective_recipe(project),
                      reference_ids=identities, markers=markers,
                      provenance={'scope': 'current_training_partition',
                                  'upstream': data.state.metadata['provenance'],
                                  'encoding': data.state.metadata['encoding']},
                      progress=progress, cancelled=cancelled)
    data.kernel_state, data.kernel_mode = state, config['mode']
    if config['mode'] == 'kernel':
        data.kernel_input_features = state.reference_count
    if output is not None:
        output = Path(output)
        state.save(output)
        write_json(output / 'binding.json', {
            'schema_version': 1, 'mode': config['mode'], 'recipe': effective_recipe(project),
            'training_rows': list(map(int, rows)), 'reference_ids': identities,
            'selected_marker_order_sha256': order_hash(markers),
            'encoding': data.state.metadata['encoding'],
            'reference_columns': 'Saved training IDs, in reference_ids order; query features are K(Q,T).',
        })
    return resolved_model(project, state.reference_count)


def transform_inputs(data, raw, representation='standardized_dosage'):
    from .encoding import model_inputs
    state = getattr(data, 'kernel_state', None)
    if state is None:
        return model_inputs(data.state, raw, representation), None
    kernel = state.transform(np.asarray(raw)[:, data.state.arrays['keep']])
    if data.kernel_mode == 'kernel':
        return kernel, None
    return model_inputs(data.state, raw, representation), kernel


def load_kernel(project, preprocessor, directory, sample_ids):
    """Verify the frozen reference contract without reopening any original data."""
    config = options(project)
    if config is None:
        return None
    from .kernels import KernelState
    directory = Path(directory)
    state = KernelState.load(directory)
    binding = read_json(directory / 'binding.json')
    rows = preprocessor.metadata['train_rows']
    expected_ids = [sample_ids[i] for i in rows]
    expected = dict(schema_version=1, mode=config['mode'], recipe=effective_recipe(project),
        training_rows=rows, reference_ids=expected_ids,
        selected_marker_order_sha256=preprocessor.metadata['selected_marker_order_sha256'],
        encoding=preprocessor.metadata['encoding'])
    if (any(binding.get(k) != v for k, v in expected.items()) or
            state.reference_count != len(rows) or state.input_features != preprocessor.input_features):
        fail('E_BUNDLE', 'kernel/binding.json', 'kernel references differ from the saved training partition or marker encoding')
    metadata = state.metadata
    if (metadata.get('recipe') != expected['recipe'] or metadata.get('train_rows') != rows or
            metadata.get('reference_ids') != expected_ids or
            metadata.get('marker_order_sha256') != expected['selected_marker_order_sha256'] or
            metadata.get('provenance', {}).get('encoding') != expected['encoding']):
        fail('E_BUNDLE', 'kernel/state.json', 'frozen kernel state and binding disagree')
    if config['mode'] == 'snp_kernel' and project['model']['external_inputs']['kernel'] != len(rows):
        fail('E_BUNDLE', 'external_inputs.kernel', 'kernel width differs from the saved reference count')
    return state
