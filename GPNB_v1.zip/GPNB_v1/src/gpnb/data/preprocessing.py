"""Train-only fitted transforms. Raw caches and source data are never modified."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np

from ..config import default_run, fail, RunSpec
from .bed import ENCODING, MATRIX_ENCODING
from .files import order_hash, read_json, sha256, write_json
from .split import require
from .imputation import ImputerState


def marker_identity(rows):
    return [[r[key] for key in ("chromosome", "marker_id", "cm_position", "bp_position", "A1", "A2")]
            for r in rows]


def _options(options):
    run = default_run().to_dict()
    run["preprocessing"] = options
    RunSpec(run)


def _doses(raw, features):
    x = np.asarray(raw)
    if (x.ndim != 2 or x.shape[1] != features or x.dtype.kind not in "iuf" or
            not np.isin(x, [-1, 0, 1, 2]).all()):
        fail("E_PREPROCESS", "genotypes", "expected 2D raw BIM_A1 doses {-1,0,1,2} in the saved marker order")
    return x


@dataclass
class PreprocessorState:
    metadata: dict
    arrays: dict

    @property
    def input_features(self):
        return int(self.arrays["keep"].sum())

    @classmethod
    def fit(cls, cache, train_rows, targets, markers, options, *, block_markers=256, provenance=None, progress=None, cancelled=None):
        _options(options)
        n, m = cache.metadata["shape"]
        rows = np.asarray(train_rows)
        if (rows.ndim != 1 or rows.dtype.kind not in "iu" or not rows.size or
                len(np.unique(rows)) != rows.size or np.any(rows < 0) or np.any(rows >= n)):
            fail("E_PREPROCESS", "train_rows", "expected nonempty unique training row indices")
        if type(block_markers) is not int or block_markers < 1:
            fail("E_RANGE", "block_markers", "expected positive integer")
        if len(markers) != m:
            fail("E_PREPROCESS", "markers", "marker count differs from cache")
        y = np.asarray(targets, dtype=np.float64) if targets is not None else None
        if y is not None and (y.shape != (len(rows),) or not np.isfinite(y).all()):
            fail("E_PREPROCESS", "targets", "supply only finite training targets, in train_rows order")
        observed = np.zeros(m, dtype=np.int64)
        counts = np.zeros((3, m), dtype=np.int64)
        sums, squares = np.zeros(m), np.zeros(m)
        # Bounded row/column blocks: never request a validation or test row.
        for start in range(0, m, block_markers):
            if progress:
                progress("fit_preprocessing", start, m)
            stop = min(m, start + block_markers)
            cols = np.arange(start, stop)
            for offset in range(0, len(rows), 256):
                if progress:
                    progress("fit_preprocessing", start, m)
                x = _doses(cache.batch(rows[offset:offset + 256], cols), stop - start)
                if cancelled and cancelled():
                    fail("E_CANCELLED", "preprocessing", "Preprocessing cancelled")
                for dose in range(3):
                    counts[dose, start:stop] += (x == dose).sum(0)
                valid = x != -1
                x = np.where(valid, x, 0).astype(np.float64)
                observed[start:stop] += valid.sum(axis=0)
                sums[start:stop] += x.sum(axis=0)
                squares[start:stop] += np.square(x).sum(axis=0)
        if progress:
            progress("fit_preprocessing", m, m)
        all_missing = observed == 0
        mean = np.divide(sums, observed, out=np.zeros(m), where=~all_missing)
        missing_rate = (len(rows) - observed) / len(rows)
        # NaN in numeric NPZ explicitly represents undefined MAF; never in JSON.
        maf = np.where(all_missing, np.nan, np.minimum(mean / 2, 1 - mean / 2))
        variance = np.maximum(0, (squares - sums * mean) / len(rows))
        zero_variance = variance == 0
        scale = np.where(zero_variance, 1.0, np.sqrt(variance))
        keep = np.ones(m, dtype=bool)
        if options["maf_min"] is not None:
            keep &= (~all_missing) & (maf >= options["maf_min"])
        if options["marker_missing_max"] is not None:
            keep &= missing_rate <= options["marker_missing_max"]
        if options.get("enabled", True) and options["all_missing"] == "drop":
            keep &= ~all_missing
        elif options.get("enabled", True) and options["all_missing"] == "error" and np.any(all_missing & keep):
            bad = int(np.flatnonzero(all_missing & keep)[0])
            fail("E_PREPROCESS", f"markers[{bad}]", "Marker is entirely missing in training; choose all_missing=drop or a training-only filter")
        if not keep.any():
            fail("E_PREPROCESS", "filters", "training-only thresholds removed every marker")
        # Freeze one shared imputer on retained marker columns. The observed mean
        # remains separate (MAF/LD/VanRaden); centering uses the filled mean.
        reference = None
        columns = np.flatnonzero(keep)
        if options["imputation"] == "knn":
            from .imputation import validate_options
            knn = validate_options("knn", options.get("imputation_options"))
            ImputerState.check_budget(len(rows), len(columns), knn, query_rows=min(len(rows), knn["block_rows"]))
            reference = np.empty((len(rows), len(columns)), dtype=np.int8)
            for offset in range(0, len(rows), knn["block_rows"]):
                if progress:
                    progress("fit_imputation_reference", offset, len(rows))
                if cancelled and cancelled():
                    fail("E_CANCELLED", "preprocessing", "Preprocessing cancelled")
                for start in range(0, len(columns), block_markers):
                    reference[offset:offset+knn["block_rows"], start:start+block_markers] = cache.batch(rows[offset:offset+knn["block_rows"]], columns[start:start+block_markers])
        imputer = ImputerState.from_counts(counts[:, keep], options["imputation"], options.get("imputation_options"), reference=reference)
        if options["imputation"] in ("mode", "median") and np.any(all_missing & keep):
            fail("E_PREPROCESS", "all_missing", "Mode/median cannot be fitted for an entirely missing retained training marker; choose all_missing=drop")
        center = mean.copy()
        if options["imputation"] == "knn":
            filled_sums, filled_squares = np.zeros(len(columns)), np.zeros(len(columns))
            for offset in range(0, len(rows), knn["block_rows"]):
                filled = imputer.transform(reference[offset:offset+knn["block_rows"]], progress=progress, cancelled=cancelled)
                filled_sums += filled.sum(0)
                filled_squares += (filled*filled).sum(0)
            center[keep] = filled_sums / len(rows)
            variance[keep] = np.maximum(0, filled_squares / len(rows) - center[keep]**2)
        elif options["imputation"] in ("mode", "median"):
            fill = imputer.arrays["fill"]
            missing = len(rows) - observed[keep]
            center[keep] = (sums[keep] + missing*fill)/len(rows)
            variance[keep] = np.maximum(0, (squares[keep]+missing*fill**2)/len(rows)-center[keep]**2)
        zero_variance = variance == 0
        scale = np.where(zero_variance, 1., np.sqrt(variance))
        target_mean = float(y.mean()) if y is not None and options["standardize_target"] else 0.0
        target_std = float(y.std(ddof=0)) if y is not None and options["standardize_target"] else 1.0
        if not np.isfinite([target_mean, target_std]).all():
            fail("E_PREPROCESS", "targets", "target moments overflow float64")
        target_constant = bool(np.all(y == y[0])) if y is not None else False
        target_scale = target_std if target_std > 0 else 1.0
        warnings = []
        if all_missing.any() and options.get("enabled", True) and options["all_missing"] == "drop":
            warnings.append("All-missing training markers are removed before fitting imputation; no held-out data is used.")
        elif all_missing.any() and options["imputation"] == "mean":
            warnings.append("All-missing training markers map to zero in every set if retained; MAF is undefined.")
        elif all_missing.any():
            warnings.append("Some training markers are entirely missing; continuous input requires explicit handling, categorical input keeps its missing category.")
        if zero_variance.any() and options["standardize_genotypes"]:
            warnings.append("Zero training variance uses scale=1; constant markers are retained unless filtered.")
        if target_constant and options["standardize_target"]:
            warnings.append("Training target is constant; target scaling uses scale=1.")
        upstream = provenance or {"status": "unavailable", "genotype_preprocessing": None}
        if upstream.get("genotype_preprocessing") is None:
            warnings.append("Upstream genotype preprocessing is undocumented; absence of a record is not proof of fold-only provenance.")
        if (upstream.get("genotype_preprocessing") or {}).get("strict_training_fold_only") is False:
            warnings.append("Upstream whole-cohort preprocessing persists; this fit cannot restore strict fold-only provenance.")
        algorithm = "train_frozen_imputation_v3"
        metadata = {"schema_version": 1, "kind": "preprocessor_state", "algorithm": algorithm,
                    "options": options, "train_rows": rows.tolist(), "training_samples": len(rows),
                    "input_markers": markers, "marker_order_sha256": order_hash(markers),
                    "input_features": int(keep.sum()), "raw_features": m,
                    "selected_marker_order_sha256": order_hash([mark for mark, use in zip(markers, keep) if use]),
                    "target_mean": target_mean, "target_scale": target_scale,
                    "target_constant": target_constant, "provenance": upstream,
                    "encoding": cache.metadata.get("identity", {}).get("encoding", ENCODING), "this_fit_scope": "train", "warnings": warnings,
                    "imputer": imputer.metadata, "centering": "population_mean_after_imputation; observed mean separately retained for allele frequency"}
        if y is None:
            metadata["target_mode"]="separate_multi_target_state"
        return cls(metadata, {"observed": observed, "mean": mean, "scale": scale, "maf": maf,
                              "missing_rate": missing_rate, "all_missing": all_missing,
                              "zero_variance": zero_variance, "keep": keep, "center": center, **imputer.pack()})

    def transform(self, raw, markers, *, progress=None, cancelled=None):
        if markers != self.metadata["input_markers"]:
            fail("E_PREPROCESS", "markers", "marker identity/order or case-sensitive A1/A2 differs; automatic alignment is unavailable")
        values = np.asarray(raw)
        if values.ndim != 2 or values.shape[1] != self.metadata["raw_features"] or values.dtype.kind not in "iuf":
            fail("E_PREPROCESS", "genotypes", "expected 2D raw BIM_A1 doses {-1,0,1,2} in the saved marker order")
        if self.metadata.get("imputer", {}).get("method") == "knn":
            ImputerState.check_budget(*self.arrays["imputer_reference"].shape,
                                     self.metadata["imputer"]["options"], query_rows=len(values))
        x = _doses(values, self.metadata["raw_features"])[:, self.arrays["keep"]].astype(np.float64)
        mean = self.arrays["mean"][self.arrays["keep"]]
        if "imputer" in self.metadata:
            imputer = ImputerState(self.metadata["imputer"], {k[8:]: v for k,v in self.arrays.items() if k.startswith("imputer_")})
            x = imputer.transform(x, progress=progress, cancelled=cancelled)
            if self.metadata["options"]["all_missing"] == "zero_with_warning" and self.metadata["options"]["imputation"] == "mean":
                x[:, self.arrays["all_missing"][self.arrays["keep"]]] = 0
        elif self.metadata["options"]["imputation"] == "none":
            if (x == -1).any():
                fail("E_PREPROCESS", "missing_genotypes", "continuous input has missing calls while imputation is disabled; enable training-only imputation or use an explicit missing-category representation")
        else:
            x = np.where(x == -1, mean, x)
            x[:, self.arrays["all_missing"][self.arrays["keep"]]] = 0
        if self.metadata["options"]["standardize_genotypes"]:
            center = self.arrays.get("center", self.arrays["mean"])[self.arrays["keep"]]
            x = (x - center) / self.arrays["scale"][self.arrays["keep"]]
        return x.astype(np.float32)

    def transform_target(self, y):
        return self._target(y, inverse=False)

    def inverse_target(self, y):
        return self._target(y, inverse=True)

    def _target(self, y, inverse):
        if self.metadata.get("target_mode")=="separate_multi_target_state":
            fail("E_MULTITASK","target_transform","multi-target state must supply per-head transforms")
        values = np.asarray(y, dtype=np.float64)
        if not np.isfinite(values).all():
            fail("E_PREPROCESS", "targets", "target transform requires finite values")
        mean, scale = self.metadata["target_mean"], self.metadata["target_scale"]
        result = values * scale + mean if inverse else (values - mean) / scale
        if not np.isfinite(result).all():
            fail("E_PREPROCESS", "targets", "target transform overflow")
        return result

    def save(self, directory):
        directory = Path(directory)
        if directory.exists():
            fail("E_EXISTS", str(directory), "preprocessor directory exists")
        directory.mkdir(parents=True)
        np.savez(directory / "arrays.npz", **self.arrays)
        write_json(directory / "state.json", self.metadata)
        write_json(directory / "complete.json", {"schema_version": 1,
                   "files": {name: sha256(directory / name) for name in ("arrays.npz", "state.json")}})

    @classmethod
    def load(cls, directory):
        directory = Path(directory)
        try:
            complete = read_json(directory / "complete.json")
            require(complete["schema_version"] == 1)
            for name in ("arrays.npz", "state.json"):
                require(sha256(directory / name) == complete["files"][name], f"checksum mismatch: {name}")
            metadata = read_json(directory / "state.json")
            require(metadata["schema_version"] == 1 and metadata["kind"] == "preprocessor_state")
            require(metadata["algorithm"] in ("train_mean_population_sd_v1", "train_optional_preprocessing_v2", "train_frozen_imputation_v3"))
            from .genotypes import DECLARED_MATRIX_ENCODING
            require(metadata["encoding"] in (ENCODING, MATRIX_ENCODING, DECLARED_MATRIX_ENCODING) and metadata["this_fit_scope"] == "train")
            _options(metadata["options"])
            if metadata["algorithm"] == "train_mean_population_sd_v1":
                require(metadata["options"]["imputation"] == "mean" and "enabled" not in metadata["options"])
            if metadata["algorithm"] == "train_frozen_imputation_v3" and metadata["imputer"]["method"] == "knn":
                from .imputation import validate_options
                require(type(metadata["training_samples"]) is int and metadata["training_samples"] > 0)
                require(type(metadata["input_features"]) is int and metadata["input_features"] > 0)
                ImputerState.check_budget(metadata["training_samples"], metadata["input_features"],
                    validate_options("knn", metadata["imputer"]["options"]))
            with np.load(directory / "arrays.npz", allow_pickle=False) as bundle:
                arrays = {key: bundle[key].copy() for key in bundle.files}
            base = {"observed", "mean", "scale", "maf", "missing_rate", "all_missing", "zero_variance", "keep"}
            modern = metadata["algorithm"] == "train_frozen_imputation_v3"
            if modern:
                imputer = ImputerState.unpack(metadata["imputer"], arrays)
                from .imputation import validate_options
                require(imputer.metadata["options"] == validate_options(metadata["options"]["imputation"], metadata["options"].get("imputation_options")))
                require(metadata["imputer"]["method"] == metadata["options"]["imputation"])
                require(set(arrays) == base | {"center"} | set(imputer.pack()))
                require(metadata["imputer"]["features"] == metadata["input_features"])
                require(np.array_equal(imputer.arrays["observed"], arrays["observed"][arrays["keep"]]))
                if "reference" in imputer.arrays:
                    require(len(imputer.arrays["reference"]) == metadata["training_samples"])
            else:
                require(set(arrays) == base)
            m = metadata["raw_features"]
            require(type(m) is int and m > 0 and all(arrays[k].shape == (m,) for k in base))
            if modern:
                require(arrays["center"].shape == (m,) and np.isfinite(arrays["center"]).all())
            for key in ("all_missing", "zero_variance", "keep"):
                require(arrays[key].dtype == np.bool_)
            require(arrays["observed"].dtype == np.int64)
            require(type(metadata["training_samples"]) is int and metadata["training_samples"] > 0)
            require(type(metadata["train_rows"]) is list and
                    len(metadata["train_rows"]) == metadata["training_samples"] and
                    all(type(i) is int and i >= 0 for i in metadata["train_rows"]) and
                    len(set(metadata["train_rows"])) == metadata["training_samples"])
            for key in ("mean", "scale", "missing_rate"):
                require(arrays[key].dtype == np.float64 and np.isfinite(arrays[key]).all())
            require(np.all((arrays["mean"] >= 0) & (arrays["mean"] <= 2)) and np.all(arrays["scale"] > 0))
            require(np.all((arrays["observed"] >= 0) & (arrays["observed"] <= metadata["training_samples"])))
            require(np.array_equal(arrays["all_missing"], arrays["observed"] == 0))
            require(np.array_equal(arrays["missing_rate"],
                                   (metadata["training_samples"] - arrays["observed"]) / metadata["training_samples"]))
            require(np.all(arrays["mean"][arrays["all_missing"]] == 0))
            require(np.all(arrays["scale"][arrays["zero_variance"]] == 1))
            require(np.array_equal(np.isnan(arrays["maf"]), arrays["all_missing"]))
            require(np.all((arrays["maf"][~arrays["all_missing"]] >= 0) & (arrays["maf"][~arrays["all_missing"]] <= .5)))
            expected_keep = np.ones(m, dtype=bool)
            opts = metadata["options"]
            if opts["maf_min"] is not None:
                expected_keep &= ~arrays["all_missing"] & (arrays["maf"] >= opts["maf_min"])
            if opts["marker_missing_max"] is not None:
                expected_keep &= arrays["missing_rate"] <= opts["marker_missing_max"]
            if opts.get("enabled", True) and opts["all_missing"] == "drop":
                expected_keep &= ~arrays["all_missing"]
            require(np.array_equal(arrays["keep"], expected_keep))
            require(metadata["input_features"] == int(arrays["keep"].sum()) > 0)
            require(len(metadata["input_markers"]) == m)
            require(order_hash(metadata["input_markers"]) == metadata["marker_order_sha256"])
            require(order_hash([x for x, k in zip(metadata["input_markers"], arrays["keep"]) if k]) == metadata["selected_marker_order_sha256"])
            require(np.isfinite([metadata["target_mean"], metadata["target_scale"]]).all() and metadata["target_scale"] > 0)
            return cls(metadata, arrays)
        except (OSError, AssertionError, KeyError, TypeError, ValueError) as error:
            fail("E_PREPROCESS", str(directory), f"invalid or incomplete persisted state: {error}")
