from __future__ import annotations

import csv
import math
from collections import Counter
from dataclasses import dataclass
from pathlib import Path

from ..config import fail


def plink_table(path: Path, kind: str):
    from .shared import current
    from .files import sha256
    scope = current()
    if scope and str(Path(path).resolve()) in scope.paths:
        return scope.fact('plink_table', (sha256(path), kind), lambda: _plink_table(path, kind))
    return _plink_table(path, kind)


def _plink_table(path: Path, kind: str):
    """Parse legal whitespace ourselves; never rewrite user's BIM/FAM."""
    rows, seen = [], {}
    with path.open(encoding="utf-8-sig") as stream:
        for line_number, line in enumerate(stream, 1):
            fields = line.split()
            if len(fields) != 6:
                fail("E_FORMAT", f"{path}:{line_number}", f"{kind} needs exactly 6 whitespace-separated fields")
            key = tuple(fields[:2]) if kind == "FAM" else fields[1]
            if key in seen:
                fail("E_DUPLICATE", f"{path}:{line_number}", f"ID {key!r}; first occurrence at line {seen[key]}")
            seen[key] = line_number
            if kind == "BIM":
                try:
                    cm, bp = float(fields[2]), int(fields[3])
                    if not math.isfinite(cm) or bp < 0:
                        raise ValueError()
                except ValueError:
                    fail("E_FORMAT", f"{path}:{line_number}", "BIM needs finite genetic position and nonnegative integer bp position")
                if fields[4] == fields[5]:
                    fail("E_FORMAT", f"{path}:{line_number}", "A1 and A2 are identical; allele encoding is ambiguous")
            rows.append(tuple(fields))
    if not rows:
        fail("E_FORMAT", str(path), f"empty {kind}")
    return rows


def text_table(path: Path, delimiter=",", encoding="utf-8-sig"):
    """Yield (physical end-line, fields), respecting quoted CSV and TSV."""
    with path.open(encoding=encoding, newline="") as stream:
        if delimiter == "whitespace":
            for line, content in enumerate(stream, 1):
                yield line, content.split()
        else:
            reader = csv.reader(stream, delimiter=delimiter, strict=True)
            try:
                for row in reader:
                    yield reader.line_num, row
            except csv.Error as error:
                fail("E_FORMAT", f"{path}:{reader.line_num}", str(error))


@dataclass
class Phenotypes:
    columns: list
    rows: list
    lines: list
    keys: list
    lookup: dict
    traits: dict
    values: dict
    invalid: list


def read_phenotypes(path: Path, options: dict) -> Phenotypes:
    from .shared import current
    from .files import sha256
    import json
    scope = current()
    if scope and str(Path(path).resolve()) in scope.paths:
        interpretation = {k: v for k, v in options.items() if k != 'trait'}
        key = (sha256(path), json.dumps(interpretation, sort_keys=True))
        result = scope.fact('phenotype_parse', key, lambda: _read_phenotypes(path, options))
        if options['trait'] not in result.values:
            fail('E_FIELD', str(path), f"required trait {options['trait']!r} not found")
        return result
    return _read_phenotypes(path, options)


def _read_phenotypes(path: Path, options: dict) -> Phenotypes:
    iterator = iter(text_table(path, options["delimiter"], options["encoding"]))
    header_line, columns = next(iterator, (0, []))
    if not columns or any(not column.strip() for column in columns) or len(set(columns)) != len(columns):
        fail("E_FORMAT", f"{path}:{header_line}", "header must contain unique, nonempty column names")
    for column in [*options["id_columns"], options["trait"]]:
        if column not in columns:
            fail("E_FIELD", f"{path}:{header_line}", f"required column {column!r} not found; columns={columns}")
    id_indices = [columns.index(c) for c in options["id_columns"]]
    candidates = [c for c in columns if c not in options["id_columns"]]
    traits = {c: {"numeric": 0, "missing": 0, "invalid": 0, "invalid_examples": []} for c in candidates}
    values = {c: [] for c in candidates}
    rows, lines, keys, lookup, invalid = [], [], [], {}, []
    missing = set(options["missing_tokens"])
    for line, fields in iterator:
        if len(fields) != len(columns):
            fail("E_FORMAT", f"{path}:{line}", f"expected {len(columns)} columns, got {len(fields)}")
        key = tuple(fields[i] for i in id_indices)
        if any(not s.strip() or s != s.strip() for s in key):
            fail("E_FORMAT", f"{path}:{line}", "empty ID or surrounding whitespace; IDs are never silently trimmed")
        if key in lookup:
            fail("E_DUPLICATE", f"{path}:{line}", f"phenotype ID {key!r}; first occurrence at line {lines[lookup[key]]}")
        lookup[key] = len(rows)
        rows.append(fields)
        lines.append(line)
        keys.append(key)
        for column in candidates:
            token = fields[columns.index(column)]
            numeric = None
            if token in missing:
                traits[column]["missing"] += 1
            else:
                try:
                    numeric = float(token)
                    if not math.isfinite(numeric):
                        raise ValueError()
                    traits[column]["numeric"] += 1
                except ValueError:
                    numeric = None
                    traits[column]["invalid"] += 1
                    issue = {"line": line, "column": column, "value": token}
                    invalid.append(issue)
                    if len(traits[column]["invalid_examples"]) < 10:
                        traits[column]["invalid_examples"].append(issue)
            values[column].append(numeric)
    for stats in traits.values():
        stats["selectable"] = stats["invalid"] == 0 and stats["numeric"] > 0
    return Phenotypes(columns, rows, lines, keys, lookup, traits, values, invalid)


def match_samples(samples, phenotype: Phenotypes, options: dict, fam_path: Path):
    from .shared import current
    from .files import order_hash
    scope = current()
    if scope:
        return scope.fact('id_mapping', (order_hash([row[:2] for row in samples]), order_hash(phenotype.keys), options['id_mode']),
                          lambda: _match_samples(samples, phenotype, options, fam_path))
    return _match_samples(samples, phenotype, options, fam_path)


def _match_samples(samples, phenotype: Phenotypes, options: dict, fam_path: Path):
    keys = [tuple(row[:2]) if options["id_mode"] == "fid_iid" else (row[1],) for row in samples]
    seen = {}
    for i, key in enumerate(keys):
        if key in seen:
            fail("E_DUPLICATE", f"{fam_path}:{i + 1}", f"ID {key!r} is not unique in selected {options['id_mode']} mode; first row {seen[key] + 1}")
        seen[key] = i
    indices = [phenotype.lookup.get(key) for key in keys]
    extras = [i for i, key in enumerate(phenotype.keys) if key not in seen]
    return indices, extras


def read_groups(path: Path, samples):
    from .shared import current
    from .files import sha256, order_hash
    scope = current()
    if scope and str(Path(path).resolve()) in scope.paths:
        return scope.fact('provided_groups', (sha256(path), order_hash(samples)), lambda: _read_groups(path, samples))
    return _read_groups(path, samples)


def _read_groups(path: Path, samples):
    iterator = iter(text_table(path))
    _, header = next(iterator, (0, []))
    required = ["FID", "IID", "genotype_equivalence_group", "group_size", "basis"]
    if len(header) != len(set(header)) or not set(required).issubset(header):
        fail("E_GROUP", str(path), f"required unique columns: {required}")
    result, sizes = {}, {}
    for line, row in iterator:
        if len(row) != len(header):
            fail("E_GROUP", f"{path}:{line}", "wrong column count")
        item = dict(zip(header, row))
        key = (item["FID"], item["IID"])
        group = item["genotype_equivalence_group"]
        if key in result or not group.strip():
            fail("E_GROUP", f"{path}:{line}", "duplicate sample or empty group")
        try:
            size = int(item["group_size"])
            if size < 1:
                raise ValueError()
        except ValueError:
            fail("E_GROUP", f"{path}:{line}", "group_size must be a positive integer")
        if group in sizes and size != sizes[group]:
            fail("E_GROUP", f"{path}:{line}", "inconsistent group_size")
        result[key], sizes[group] = (group, item["basis"]), size
    expected = {tuple(s[:2]) for s in samples}
    if set(result) != expected:
        fail("E_GROUP", str(path), f"missing={len(expected - result.keys())}, extra={len(result.keys() - expected)}")
    actual = Counter(g for g, _ in result.values())
    if dict(actual) != sizes:
        fail("E_GROUP", str(path), "declared group_size disagrees with actual membership")
    return [result[tuple(s[:2])] for s in samples], {
        "groups": len(actual), "multi_sample_groups": sum(n > 1 for n in actual.values()),
        "samples_in_multi_sample_groups": sum(n for n in actual.values() if n > 1),
        "content_recomputed_from_genotypes": False, "interpretation": "genotype equivalence, not biological family",
    }
