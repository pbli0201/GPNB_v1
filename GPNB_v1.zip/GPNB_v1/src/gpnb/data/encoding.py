"""Model-facing input encoding after train-only marker selection."""
import numpy as np

from ..config import fail
from .preprocessing import _doses


def model_inputs(state, raw, representation="standardized_dosage"):
    if representation == "standardized_dosage":
        return state.transform(raw, state.metadata["input_markers"])
    if representation != "genotype_categories":
        fail("E_PREPROCESS", "input_representation", "unknown model input encoding")
    # Deliberately bypass dosage imputation/scaling, never cast transformed floats.
    selected = _doses(raw, state.metadata["raw_features"])[:, state.arrays["keep"]]
    return np.where(selected < 0, 3, selected).astype(np.int64)


def encoding_description(representation):
    return dict(representation=representation, marker_selection_fit_scope="inner_training",
                categories={"0": "A1 count 0", "1": "A1 count 1", "2": "A1 count 2", "3": "missing genotype"}
                if representation == "genotype_categories" else None,
                genotype_imputation_and_scaling_applied=False if representation == "genotype_categories" else None,
                preprocessing_policy="bypassed_for_categories" if representation == "genotype_categories" else "depends_on_saved_preprocessing_state",
                missing_category_is_sequence_padding=False,
                note="Category input bypasses fitted dosage imputation/scaling; marker selection and target scaling still use training-only state.")


def token_mapping(plan, state=None):
    """Local feature coordinates always; real marker identities only for direct genotype input."""
    markers = ([m for m, keep in zip(state.metadata["input_markers"], state.arrays["keep"]) if keep]
               if state is not None else None)
    mappings = []
    for row in plan["layers"]:
        if row["type"] not in ("Tokenize", "GenotypeEmbedding", "ToSequence"):
            continue
        width = row["input_shape"][1]
        if width > 1_000_000 or row["output_shape"][1] > 1_000_000:
            fail("E_MODEL_LIMIT", row["id"], "token mapping exceeds one million positions; use a smaller upstream representation")
        patch = row["kwargs"].get("patch_size", 1)
        valid = (width + patch - 1) // patch
        length = row["output_shape"][1]
        direct = row["inputs"] == {"x": "$input"}
        tokens = []
        for i in range(length):
            indices = list(range(i * patch, min((i + 1) * patch, width)))
            tokens.append(dict(token=i, feature_indices=indices, sequence_padding=i >= valid,
                               padded_feature_slots=patch - len(indices),
                               markers=[markers[j] for j in indices] if direct and markers is not None else None))
        mappings.append(dict(layer_id=row["id"], coordinate_system="retained_marker_file_order" if direct else "upstream_feature_order",
                             fit_scope="mapping of frozen retained features; no new cohort fit", tokens=tokens))
    return dict(schema_version=1, kind="token_mapping", model_sha256=plan["model_sha256"], mappings=mappings)


def grid_mapping(plan, state=None):
    markers = ([m for m,keep in zip(state.metadata["input_markers"],state.arrays["keep"]) if keep]
               if state is not None else None)
    layouts = []
    for row in plan["layers"]:
        if row["type"] != "ToGrid":
            continue
        c,h,w = row["output_shape"][1:]
        if c*h*w > 1_000_000:
            fail("E_MODEL_LIMIT",row["id"],"grid mapping exceeds one million cells")
        direct = row["inputs"] == {"x":"$input"}
        width = row["input_shape"][1]
        cells = [dict(channel=i//(h*w),row=(i//w)%h,column=i%w,
                      feature_index=i if i<width else None,
                      marker=markers[i] if direct and markers is not None and i<width else None,
                      zero_padding=i>=width) for i in range(c*h*w)]
        layouts.append(dict(layer_id=row["id"],layout="file_order_user_grid",
            coordinate_system="retained_marker_file_order" if direct else "upstream_feature_order",
            biological_adjacency_claimed=False,cells=cells))
    return dict(schema_version=1,kind="grid_mapping",model_sha256=plan["model_sha256"],layouts=layouts)
