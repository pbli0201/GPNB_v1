from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

from ..config import ProjectSpec, fail, load_spec, number, resolve_project_path
from ..errors import GPNBError
from .bed import ENCODING, READER, BedAdapter, validate_bed
from .cache import cache_identity, get_or_build_cache
from .files import (order_hash, protect_inputs, read_json, snapshot, verify_snapshots,
                    write_csv, write_json)
from .tables import match_samples, plink_table, read_groups, read_phenotypes


def _provenance(manifest, path, files, data, n, m):
    if manifest is None:
        return {"status": "unavailable", "genotype_preprocessing": None,
                "genotype_hash_binding_verified": False}, ["No source manifest; upstream preprocessing is unknown."], None
    if type(manifest) is not dict:
        fail("E_MANIFEST", str(path), "manifest must be a JSON object")
    if "master_file_sha256" in manifest:
        declared = manifest["master_file_sha256"]
        if type(declared) is not dict:
            fail("E_MANIFEST", str(path), "master_file_sha256 must be an object")
        counts = (manifest.get("n_master_individuals"), manifest.get("n_markers"))
        dataset = manifest.get("dataset")
        if dataset is not None and dataset != data["dataset_id"]:
            fail("E_MANIFEST", str(path), f"dataset name {dataset!r} differs from project")
        for key in ("bed", "bim", "fam"):
            name = Path(files[key]["path"]).name
            if declared.get(name) != files[key]["sha256"]:
                fail("E_MANIFEST", str(path), f"hash missing/mismatched for {name}")
        pheno_hash = manifest.get("phenotype_file_sha256")
        if pheno_hash is not None and pheno_hash != files["phenotype"]["sha256"]:
            fail("E_MANIFEST", str(path), "phenotype hash differs from manifest")
    elif manifest.get("kind") == "synthetic_manifest" and manifest.get("schema_version") == 1:
        counts = (manifest.get("samples"), manifest.get("markers"))
        if type(manifest.get("files")) is not dict:
            fail("E_MANIFEST", str(path), "files must be a hash object")
        for key in ("bed", "bim", "fam", "phenotype"):
            name = Path(files[key]["path"]).name
            if manifest.get("files", {}).get(name) != files[key]["sha256"]:
                fail("E_MANIFEST", str(path), f"synthetic file hash missing/mismatched for {name}")
    else:
        fail("E_MANIFEST", str(path), "unsupported manifest; use a supported manifest or explicitly set manifest=null")
    if any(type(c) is not int for c in counts) or counts != (n, m):
        fail("E_MANIFEST", str(path), f"declared sample/marker counts {counts} differ from {(n, m)}")
    qc = manifest.get("technical_qc", {})
    if not isinstance(qc, dict):
        fail("E_MANIFEST", str(path), "technical_qc must be an object")
    preprocessing = manifest.get("genotype_preprocessing")
    if preprocessing is not None and type(preprocessing) is not dict:
        fail("E_MANIFEST", str(path), "genotype_preprocessing must be an object or null")
    if type(qc.get("warnings", [])) is not list or any(type(w) is not str for w in qc.get("warnings", [])):
        fail("E_MANIFEST", str(path), "warnings must be an array of strings")
    warnings = list(qc.get("warnings", []))
    if preprocessing and preprocessing.get("strict_training_fold_only") is False:
        warnings.append("Input was preprocessed across the cohort; train-only fitting cannot undo that preprocessing.")
    if preprocessing is None:
        warnings.append("No explicit genotype_preprocessing record; absence does not certify never-imputed inputs.")
    return {
        "status": manifest.get("status", "synthetic"),
        "genotype_preprocessing": preprocessing,
        "genotype_hash_binding_verified": True,
        "upstream_provenance_verified": qc.get("upstream_provenance_verified", False),
        "technical_qc_run_id": qc.get("run_id"),
        "manifest_sha256": files["manifest"]["sha256"],
    }, warnings, qc.get("split_groups_file")


def inspect_project(project_file: Path, output: Path, *, scan=False, cache_root: Path | None = None,
                    block_markers=256, memory_mib=64, threads=2, progress=None, language=None) -> dict:
    """Inspect metadata or fully import raw doses. Original files remain read-only.

    Every output directory is new. descriptor.json is the completion marker;
    interrupted output retains INCOMPLETE and must never be consumed as complete.
    """
    project_file, output = Path(project_file).resolve(), Path(output).resolve()
    for name, value in (("block_markers", block_markers), ("memory_mib", memory_mib), ("threads", threads)):
        number(value, name, 1, 2**31 - 1, integer=True)
    cache_root = Path(cache_root).resolve() if cache_root is not None else None
    if output.exists():
        fail("E_EXISTS", str(output), "choose a new audit directory")
    if cache_root is not None and (cache_root == output or cache_root.is_relative_to(output) or output.is_relative_to(cache_root)):
        fail("E_IO", str(output), "audit and raw-cache roots must not overlap")
    project_file_snapshot = snapshot(project_file)
    spec = load_spec(project_file)
    if not isinstance(spec, ProjectSpec):
        fail("E_TYPE", str(project_file), "inspect/import requires a ProjectSpec")
    project, files = spec.to_dict(), {}
    language = language or project["language"]
    if language not in ("zh_CN", "en_US"):
        fail("E_VALUE", "language", "expected zh_CN or en_US")
    data = project["data"]
    from .genotypes import source_paths, open_source, matrix_identity
    paths = source_paths(data, project_file)
    protect_inputs(output, [project_file, *paths.values()])
    if cache_root is not None:
        protect_inputs(cache_root, [project_file, *paths.values()])
    files["project"] = project_file_snapshot
    for key, path in paths.items():
        if progress:
            progress("hash_" + key, 0, 1)
        files[key] = snapshot(path)
        if progress:
            progress("hash_" + key, 1, 1)
    samples, markers, source_adapter = open_source(data, paths, progress=progress,
                        block_markers=block_markers, memory_mib=memory_mib, threads=threads)
    n, m = len(samples), len(markers)
    manifest = read_json(paths["manifest"]) if "manifest" in paths else None
    provenance, warnings, declared_groups = _provenance(manifest, paths.get("manifest"), files, data, n, m)
    matrix_options = data.get("matrix")
    if matrix_options and matrix_options["counted_allele"] == "DECLARED":
        warnings.append("Matrix allele identities and physical positions are unknown. Only the supplied marker names and encoding declaration can be checked; allele direction is not independently verified.")
    if declared_groups is not None:
        if type(declared_groups) is not str or not declared_groups:
            fail("E_MANIFEST", str(paths["manifest"]), "split_groups_file must be a nonempty path string")
        declared_path = (paths["manifest"].parent / declared_groups).resolve()
        group_snapshot = snapshot(declared_path)
        if "split_groups" in paths and files["split_groups"]["sha256"] != group_snapshot["sha256"]:
            fail("E_GROUP", str(paths["split_groups"]), "explicit grouping conflicts with source manifest grouping")
        if "split_groups" not in paths:
            paths["split_groups"], files["split_groups"] = declared_path, group_snapshot
        protect_inputs(output, [declared_path])
        if cache_root is not None:
            protect_inputs(cache_root, [declared_path])
    group_rows, group_summary = None, {"status": "unavailable", "content_recomputed_from_genotypes": False}
    if "split_groups" in paths:
        group_rows, group_summary = read_groups(paths["split_groups"], samples)
        group_summary.update(status="provided_and_membership_validated",
                             sha256=files["split_groups"]["sha256"],
                             source_genotype_binding_verified=bool(declared_groups and provenance["genotype_hash_binding_verified"]))
        warnings.append("Provided genotype-equivalence groups preserved; genotype equivalence has not been recomputed by this import.")
    else:
        warnings.append("No genotype-equivalence groups supplied; A04 must establish groups before splitting.")
    options = data["phenotype_options"]
    phenotype = read_phenotypes(paths["phenotype"], options)
    mapping, extras = match_samples(samples, phenotype, options, paths.get("fam", paths.get("matrix")))
    from .statistics import trait_statistics
    descriptive = trait_statistics(phenotype, mapping)
    trait = options["trait"]
    eligible = [i for i, row in enumerate(mapping) if row is not None and phenotype.values[trait][row] is not None]
    from .multitask import contract,aligned_targets
    multitask=contract(project)
    if multitask:
        import numpy as np
        target_values=aligned_targets(phenotype,mapping,multitask,paths["phenotype"])
        eligible=np.flatnonzero(np.isfinite(target_values).any(1)).tolist()
    eligible_set=set(eligible)
    errors = []
    if phenotype.traits[trait]["invalid"]:
        for item in phenotype.traits[trait]["invalid_examples"]:
            errors.append(GPNBError("E_TRAIT", f"{paths['phenotype']}:{item['line']}:{trait}",
                                    f"invalid value {item['value']!r}").as_dict(language))
    if not any(row is not None for row in mapping):
        errors.append(GPNBError("E_VALUE", str(paths["phenotype"]), "no matching IDs; row order is never used").as_dict(language))
    if not eligible:
        warnings.append("No finite matched labels for the selected trait; supervised training is unavailable.")
    sample_order = order_hash([list(s[:2]) for s in samples])
    marker_order = order_hash([list(row) for row in markers])
    identity = (matrix_identity(files, sample_order, marker_order, data["matrix"]) if data.get("matrix")
                else cache_identity(files, sample_order, marker_order))
    output.mkdir(parents=True, exist_ok=False)
    (output / "INCOMPLETE").write_text("Audit is not complete.\n", encoding="utf-8")
    try:
        missing, cache, reused, adapter = None, None, False, None
        if (scan or cache_root is not None) and not errors:
            adapter = source_adapter
            if cache_root is not None:
                cache, reused = get_or_build_cache(cache_root, adapter, identity, files, progress)
                missing = cache.missing
            else:
                missing = adapter.scan(progress=progress)
        def sample_rows():
            for i, s in enumerate(samples):
                row = mapping[i]
                value = phenotype.values[trait][row] if row is not None else None
                status = ("genotype_only" if row is None else "matched_finite_label" if value is not None
                          else "matched_invalid_label" if phenotype.rows[row][phenotype.columns.index(trait)] not in options["missing_tokens"]
                          else "matched_missing_label")
                if multitask and i in eligible_set:
                    status="matched_finite_label"
                group = group_rows[i] if group_rows else ("", "")
                yield (i, *s, "" if row is None else row, "" if row is None else phenotype.lines[row],
                       status, trait, "" if value is None else value, *group,
                       "" if missing is None else int(missing.samples[i]))
        write_csv(output / "samples.csv",
                  ["fam_index", "FID", "IID", "father", "mother", "sex", "fam_phenotype",
                   "phenotype_row_index", "phenotype_line", "match_status", "trait", "value",
                   "genotype_equivalence_group", "group_basis", "missing_genotypes"], sample_rows())
        write_csv(output / "markers.csv", ["bim_index", "chromosome", "marker_id", "cm_position", "bp_position", "A1", "A2", "missing_genotypes"],
                  ((i, *row, "" if missing is None else int(missing.markers[i])) for i, row in enumerate(markers)))
        fam_for_pheno = {row: i for i, row in enumerate(mapping) if row is not None}
        write_csv(output / "phenotype_order.csv", ["phenotype_row_index", "source_line", *options["id_columns"], "fam_index"],
                  ((i, phenotype.lines[i], *key, fam_for_pheno.get(i, "")) for i, key in enumerate(phenotype.keys)))
        write_csv(output / "invalid_traits.csv", ["source_line", "column", "value"],
                  ((r["line"], r["column"], r["value"]) for r in phenotype.invalid))
        write_csv(output / "phenotype_only.csv", [*options["id_columns"], "source_line", "status"],
                  ((*phenotype.keys[i], phenotype.lines[i], "phenotype_only") for i in extras))
        write_csv(output / "trait_statistics.csv", ["trait", *next(iter(descriptive.values())).keys()],
                  ((name, *stats.values()) for name, stats in descriptive.items()))
        write_json(output / "project_snapshot.json", project)
        if matrix_options:
            write_json(output / "encoding.json", {
                "schema_version": 1, "kind": "genotype_encoding_manifest",
                "input_coding": matrix_options.get("coding", "012"),
                "canonical_encoding": identity["encoding"], "missing_tokens": matrix_options["missing_tokens"],
                "id_columns": matrix_options["id_columns"],
                "counted_allele": matrix_options["counted_allele"],
                "allele_declaration": matrix_options.get("allele_declaration"),
                "alleles_known": matrix_options["counted_allele"] == "BIM_A1",
                "marker_order_sha256": marker_order, "sample_order_sha256": sample_order,
                "markers": [list(row) for row in markers], "source_files": files,
                "allele_direction_independently_verified": False,
            })
        if manifest is not None:
            write_json(output / "source_manifest.json", manifest)
        verify_snapshots(files)
        data_files = {key: info for key, info in files.items() if key != "project"}
        report = {
            "schema_version": 1, "kind": "data_audit", "created_utc": datetime.now(timezone.utc).isoformat(),
            "ok": not errors, "errors": errors, "warnings": warnings,
            "dataset_id": data["dataset_id"], "trait": trait, "config_sha256": spec.sha256,
            "samples": n, "markers": m, "phenotype_rows": len(phenotype.rows),
            "matching": {"id_mode": options["id_mode"], "id_columns": options["id_columns"],
                         "matched": sum(r is not None for r in mapping), "genotype_only": sum(r is None for r in mapping),
                         "phenotype_only": len(extras), "eligible_labelled": len(eligible),
                         "matched_without_finite_label": sum(r is not None for r in mapping) - len(eligible)},
            "phenotype_options": options, "traits": phenotype.traits, "trait_statistics": descriptive,
            "chromosome_labels": dict(Counter(row[0] for row in markers)),
            "case_only_distinct_allele_markers": sum(r[4] != r[5] and r[4].upper() == r[5].upper() for r in markers),
            "encoding": identity["encoding"], "reader": identity["reader"], "source_files": data_files,
            "project_file_snapshot": project_file_snapshot,
            "sample_order_sha256": sample_order, "marker_order_sha256": marker_order,
            "provenance": provenance, "split_groups": group_summary,
            "genotype_missing": {**missing.summary(), "decoded_this_run": not reused,
                                 "statistics_source": "validated_cache" if reused else "current_scan"}
                                if missing else {"scanned": False, "decoded_this_run": False,
                                                 "statistics_source": "not_scanned", "missing_cells": None, "missing_rate": None},
            "input_format": "matrix" if data.get("matrix") else "plink",
            "matrix_options": matrix_options,
            "bed_checks": None if data.get("matrix") else {"header_and_size": True, "padding_checked": missing is not None},
            "cache": None if cache is None else {"path": str(cache.directory), "key": cache.metadata["key"], "reused": reused},
            "scan_options": None if adapter is None else {"effective_block_markers": getattr(adapter, "block_markers", None),
                                                         "memory_budget_mib": memory_mib, "threads": threads},
            "scope": "Read-only data import. No filtering, imputation, scaling, splitting or model training.",
        }
        write_json(output / "audit.json", report)
        artifacts = {p.name: snapshot(p)["sha256"] for p in output.iterdir() if p.is_file() and p.name != "INCOMPLETE"}
        write_json(output / "descriptor.json", {
            "schema_version": 1, "kind": "imported_dataset", "ok": not errors, "dataset_id": data["dataset_id"],
            "encoding": identity["encoding"], "reader": identity["reader"], "source_files": data_files,
            "project_file_snapshot": project_file_snapshot,
            "sample_order_sha256": sample_order, "marker_order_sha256": marker_order,
            "cache": report["cache"], "provenance": provenance, "split_groups": group_summary,
            "artifacts": artifacts, "artifact_base": "descriptor_directory",
        })
        (output / "INCOMPLETE").unlink()
        return report
    except Exception as error:
        write_json(output / "failure.json", {"ok": False, "error": str(error)})
        raise
