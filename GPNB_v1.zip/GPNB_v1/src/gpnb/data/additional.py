"""Explicit ID-matched numeric input tables with train-only fitted transforms."""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from ..config import boolean, choice, fail, number, object_fields, sequence, text
from .files import order_hash, snapshot, verify_snapshots
from .tables import text_table


def table_defaults(identifier="covariates", path="", columns=None):
    return dict(id=identifier, path=path, id_mode="fid_iid", id_columns=["FID", "IID"],
                columns=columns or ["covariate"], delimiter=",", missing_tokens=["", "NA", "NaN"],
                missing_rows="error", standardize=True, all_missing="error", max_cells=2_000_000)


def validate_tables(tables, target=None):
    sequence(tables, "input_tables", nonempty=False)
    if len(tables) > 16:
        fail("E_INPUT_TABLE", "input_tables", "at most 16 explicitly named input tables")
    names = set()
    for i, item in enumerate(tables):
        loc = f"input_tables[{i}]"
        object_fields(item, loc, ("id", "path", "id_mode", "id_columns", "columns", "delimiter", "missing_tokens",
                                 "missing_rows", "standardize", "all_missing", "max_cells"))
        if not isinstance(item["id"], str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,47}", item["id"]) or item["id"] in names:
            fail("E_INPUT_TABLE", loc+".id", "unique ASCII identifier required (letter then letters/digits/underscore)")
        names.add(item["id"])
        text(item["path"], loc+".path")
        choice(item["id_mode"], loc+".id_mode", ("fid_iid", "iid"))
        choice(item["delimiter"], loc+".delimiter", (",", "\t"))
        choice(item["missing_rows"], loc+".missing_rows", ("error", "fill"))
        choice(item["all_missing"], loc+".all_missing", ("error", "zero"))
        boolean(item["standardize"], loc+".standardize")
        number(item["max_cells"], loc+".max_cells", 1, 50_000_000, integer=True)
        for key in ("columns", "id_columns", "missing_tokens"):
            sequence(item[key], loc+"."+key, nonempty=key != "missing_tokens")
            for value in item[key]:
                text(value, loc+"."+key, empty=key == "missing_tokens")
            if len(set(item[key])) != len(item[key]):
                fail("E_INPUT_TABLE", loc+"."+key, "duplicate entries")
        if len(item["id_columns"]) != (2 if item["id_mode"] == "fid_iid" else 1):
            fail("E_INPUT_TABLE", loc+".id_columns", "FID+IID requires two columns; IID requires one")
        if set(item["columns"]) & set(item["id_columns"]) or (target is not None and target in item["columns"]):
            fail("E_INPUT_TABLE", loc+".columns", "IDs and the target trait cannot be input features")
        if len(item["columns"]) > 4096:
            fail("E_INPUT_TABLE", loc+".columns", "at most 4096 explicitly selected numeric columns per table")


def resolve_table_paths(project, project_path):
    """Mutates a fresh project dictionary, never the original on-disk document."""
    from ..config import resolve_project_path
    if project["data"].get("matrix"):
        project["data"]["matrix"]["path"] = str(resolve_project_path(project_path, project["data"]["matrix"]["path"]))
    for item in project.get("extensions", {}).get("input_tables", []):
        item["path"] = str(resolve_project_path(project_path, item["path"]))


def table_widths(project):
    return {item["id"]: len(item["columns"]) for item in project.get("extensions", {}).get("input_tables", [])}


def aligned_numeric(config, path, sample_ids):
    validate_tables([config])
    path = Path(path).resolve()
    key_for = lambda pair: tuple(pair) if config["id_mode"] == "fid_iid" else (pair[1],)
    keys = [key_for(pair) for pair in sample_ids]
    if len(set(keys)) != len(keys):
        fail("E_INPUT_TABLE", config["id"], "genotype sample IDs are not unique under this table's ID mode")
    features, rows = len(config["columns"]), len(keys)
    if rows*features > config["max_cells"]:
        fail("E_INPUT_TABLE", config["id"], "aligned table exceeds explicit max_cells budget")
    lookup = {key: i for i, key in enumerate(keys)}
    raw = np.full((rows, features), np.nan, dtype=np.float64)
    matched, seen, unused = set(), {}, 0
    before = snapshot(path)
    iterator = iter(text_table(path, config["delimiter"]))
    line, header = next(iterator, (0, []))
    required = [*config["id_columns"], *config["columns"]]
    if not header or len(set(header)) != len(header) or not set(required) <= set(header):
        fail("E_INPUT_TABLE", f"{path}:{line}", f"unique header must contain {required}")
    positions = {name: header.index(name) for name in required}
    for count, (line, fields) in enumerate(iterator, 1):
        if count*features > config["max_cells"]:
            fail("E_INPUT_TABLE", f"{path}:{line}", "source table exceeds explicit max_cells budget")
        if len(fields) != len(header):
            fail("E_INPUT_TABLE", f"{path}:{line}", "field count differs from header")
        key = tuple(fields[positions[name]] for name in config["id_columns"])
        if any(not v or v != v.strip() for v in key):
            fail("E_INPUT_TABLE", f"{path}:{line}", "nonempty exact string IDs required; no silent whitespace trimming")
        if key in seen:
            fail("E_INPUT_TABLE", f"{path}:{line}", f"duplicate ID {key}; first line {seen[key]}")
        seen[key] = line
        values = []
        for name in config["columns"]:
            value = fields[positions[name]]
            if value in config["missing_tokens"]:
                values.append(np.nan)
                continue
            try:
                parsed = float(value)
                if not np.isfinite(parsed):
                    raise ValueError()
            except ValueError:
                fail("E_INPUT_TABLE", f"{path}:{line}.{name}", f"expected finite numeric feature, got {value!r}")
            values.append(parsed)
        if key in lookup:
            row = lookup[key]
            raw[row] = values
            matched.add(row)
        else:
            unused += 1
    absent = [i for i in range(rows) if i not in matched]
    if absent and config["missing_rows"] == "error":
        fail("E_INPUT_TABLE", str(path), f"{len(absent)} genotype individuals lack input rows; examples={[keys[i] for i in absent[:10]]}")
    verify_snapshots({"input_table": before})
    return raw, dict(source=before, matched=len(matched), missing_rows=len(absent),
                     missing_row_examples=[list(keys[i]) for i in absent[:10]], unused_source_rows=unused,
                     missing_cells=int(np.isnan(raw).sum()), sample_order_sha256=order_hash(sample_ids))


@dataclass
class NumericTableState:
    value: dict

    @classmethod
    def fit(cls, config, raw, train_rows, sample_ids, report):
        train = [int(i) for i in train_rows]
        if not train or len(set(train)) != len(train) or min(train) < 0 or max(train) >= len(raw):
            fail("E_INPUT_TABLE", config["id"], "nonempty unique in-range training rows required")
        fitted = raw[train]
        observed = np.isfinite(fitted).sum(0)
        empty = observed == 0
        if empty.any() and config["all_missing"] == "error":
            fail("E_INPUT_TABLE", config["id"], f"all missing in training: {[c for c, e in zip(config['columns'], empty) if e]}")
        mean = np.divide(np.nansum(fitted, axis=0), observed, out=np.zeros(raw.shape[1]), where=~empty)
        filled = np.where(np.isnan(fitted), mean, fitted)
        scale = filled.std(0, ddof=0)
        constant = scale == 0
        scale[constant] = 1.
        if not np.isfinite(mean).all() or not np.isfinite(scale).all():
            fail("E_INPUT_TABLE", config["id"], "training numeric moments overflow")
        value = dict(schema_version=1, kind="numeric_input_state", config=config, train_rows=train,
                     sample_order_sha256=order_hash(sample_ids), mean=mean.tolist(), scale=scale.tolist(),
                     training_observed=observed.tolist(), all_missing=empty.tolist(), zero_variance=constant.tolist(),
                     report=report, scale_definition="population SD after training-mean imputation; zero SD -> 1")
        state = cls.load(value)
        state.transform(raw)
        return state

    @classmethod
    def load(cls, value):
        object_fields(value, "numeric_input_state", ("schema_version", "kind", "config", "train_rows",
            "sample_order_sha256", "mean", "scale", "training_observed", "all_missing", "zero_variance", "report", "scale_definition"))
        if value["schema_version"] != 1 or value["kind"] != "numeric_input_state":
            fail("E_INPUT_TABLE", "state", "unsupported input state version")
        validate_tables([value["config"]])
        width = len(value["config"]["columns"])
        report = value["report"]
        object_fields(report, "state.report", ("source", "matched", "missing_rows", "missing_row_examples",
                                              "unused_source_rows", "missing_cells", "sample_order_sha256"))
        for key in ("matched", "missing_rows", "unused_source_rows", "missing_cells"):
            number(report[key], "state.report."+key, 0, integer=True)
        samples = report["matched"] + report["missing_rows"]
        number(samples, "state.report.samples", 1, integer=True)
        for digest in (value["sample_order_sha256"], report["sample_order_sha256"]):
            if type(digest) is not str or len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest):
                fail("E_INPUT_TABLE", "state.sample_order_sha256", "invalid sample order digest")
        if value["sample_order_sha256"] != report["sample_order_sha256"]:
            fail("E_INPUT_TABLE", "state.report", "sample order differs from fitted state")
        source = report["source"]
        object_fields(source, "state.source", ("path", "sha256", "bytes", "mtime_ns"))
        if source["path"] != value["config"]["path"]:
            fail("E_INPUT_TABLE", "state.source", "source path differs from fitted configuration")
        if type(source["sha256"]) is not str or len(source["sha256"]) != 64 or any(c not in "0123456789abcdef" for c in source["sha256"]):
            fail("E_INPUT_TABLE", "state.source", "invalid source digest")
        for key in ("bytes", "mtime_ns"):
            number(source[key], "state.source."+key, 0, integer=True)
        rows = value["train_rows"]
        if not rows or len(set(rows)) != len(rows) or any(type(i) is not int or not 0 <= i < samples for i in rows):
            fail("E_INPUT_TABLE", "state.train_rows", "expected unique nonnegative training rows")
        for key in ("mean", "scale", "training_observed", "all_missing", "zero_variance"):
            if type(value[key]) is not list or len(value[key]) != width:
                fail("E_INPUT_TABLE", "state."+key, "state width differs from selected columns")
        for i in range(width):
            number(value["mean"][i], f"state.mean[{i}]")
            number(value["scale"][i], f"state.scale[{i}]", positive=True)
            number(value["training_observed"][i], f"state.training_observed[{i}]", 0, len(rows), integer=True)
            boolean(value["all_missing"][i], f"state.all_missing[{i}]")
            boolean(value["zero_variance"][i], f"state.zero_variance[{i}]")
            if value["all_missing"][i] != (value["training_observed"][i] == 0):
                fail("E_INPUT_TABLE", "state", "missing count and all-missing flag disagree")
            if value["zero_variance"][i] and value["scale"][i] != 1.:
                fail("E_INPUT_TABLE", "state", "zero-variance columns require unit scale")
            if value["all_missing"][i] and (value["mean"][i] != 0 or not value["zero_variance"][i]):
                fail("E_INPUT_TABLE", "state", "all-missing columns require zero mean and zero-variance fallback")
        return cls(value)

    def transform(self, raw):
        raw = np.asarray(raw, dtype=np.float64)
        config = self.value["config"]
        if raw.ndim != 2 or raw.shape[1] != len(config["columns"]) or np.isinf(raw).any():
            fail("E_INPUT_TABLE", config["id"], "raw array needs selected columns in saved order; only NaN denotes missing")
        x = np.where(np.isnan(raw), np.asarray(self.value["mean"]), raw)
        if config["standardize"]:
            x = (x - np.asarray(self.value["mean"])) / np.asarray(self.value["scale"])
        with np.errstate(over="ignore"):
            x = x.astype(np.float32)
        if not np.isfinite(x).all():
            fail("E_INPUT_TABLE", config["id"], "transformed features overflow float32")
        return x


def fit_tables(project, project_path, prepared):
    from ..config import resolve_project_path
    configs = project.get("extensions", {}).get("input_tables", [])
    validate_tables(configs, project["data"]["phenotype_options"]["trait"])
    sample_ids = [[s["FID"], s["IID"]] for s in prepared.samples]
    states, arrays, sources = {}, {}, {}
    for config in configs:
        path = resolve_project_path(project_path, config["path"])
        bound = {**config, "path": str(path)}
        raw, report = aligned_numeric(bound, path, sample_ids)
        state = NumericTableState.fit(bound, raw, prepared.split.rows("train"), sample_ids, report)
        states[config["id"]] = state.value
        arrays[config["id"]] = state.transform(raw)
        sources[config["id"]] = report["source"]
    return states, arrays, sources


def parse_table_arguments(items):
    mapping = {}
    for item in items or []:
        parts = item.split("=", 1)
        if len(parts) != 2 or not all(parts) or parts[0] in mapping:
            fail("E_INPUT_TABLE", "--input-table", "use unique name=path entries")
        mapping[parts[0]] = parts[1]
    return mapping


def copy_table_sources(states, project, output):
    """Portable retraining copies only when explicitly requested by caller."""
    import shutil
    from .files import sha256
    copies = {}
    for config in project.get("extensions", {}).get("input_tables", []):
        record = states[config["id"]]["report"]["source"]
        verify_snapshots({config["id"]: record})
        origin = Path(record["path"])
        relative = Path("inputs/additional") / config["id"] / origin.name
        target = output / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(origin, target)
        if sha256(target) != record["sha256"]:
            fail("E_CHANGED", str(origin), "additional table changed during export")
        config["path"] = relative.as_posix()
        copies[config["id"]] = dict(original=record, portable_path=relative.as_posix())
    return copies
