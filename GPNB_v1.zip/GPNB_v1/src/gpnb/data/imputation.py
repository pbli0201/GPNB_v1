"""Frozen genotype imputation, shared by SNP and kernel pipelines (NumPy only).

KNN distance is sqrt(P/common * sum((query-reference)**2)) over jointly
observed retained hard-call markers. Donors always come from the saved training
reference. No phenotype, query cohort, allele recoding or fitted query scale is used.
"""
from __future__ import annotations

from dataclasses import dataclass
import numpy as np

from ..errors import GPNBError

METHODS = ("mean", "none", "mode", "median", "knn")


def _fail(detail, code="E_PREPROCESS"):
    raise GPNBError(code, "imputation", detail)


def knn_defaults():
    return dict(k=5, weights="uniform", output="mean", min_common=1,
                block_rows=64, block_markers=256, max_reference_samples=20000,
                max_reference_bytes=256 * 1024**2, max_working_bytes=64 * 1024**2)


def validate_options(method, options=None):
    if method not in METHODS:
        _fail("Choose mean, mode, median, none or knn.")
    if options is None:
        options = {}
    if type(options) is not dict:
        _fail("imputation_options must be an object.")
    if method != "knn":
        if options:
            _fail("imputation_options only applies to knn; remove inactive parameters.")
        return {}
    result = knn_defaults()
    if set(options) - set(result):
        _fail("Unknown KNN parameters: " + ", ".join(sorted(set(options)-set(result))))
    result.update(options)
    for key in set(result) - {"weights", "output"}:
        if type(result[key]) is not int or result[key] < 1:
            _fail(f"KNN {key} must be a positive integer.")
    if result["weights"] not in ("uniform", "distance"):
        _fail("KNN weights must be uniform or distance.")
    if result["output"] not in ("mean", "mode"):
        _fail("KNN output must be mean (continuous) or mode (hard-call vote).")
    if result["block_rows"] > 4096 or result["block_markers"] > 65536:
        _fail("KNN block_rows <= 4096 and block_markers <= 65536 are required.")
    return result


def _check_cancel(cancelled):
    if cancelled and cancelled():
        _fail("Imputation cancelled; no completed state was produced.", "E_CANCELLED")


def statistics(counts):
    """Return observed count, mean, lower-code mode and interpolated median."""
    observed = counts.sum(0)
    sums = counts[1] + 2*counts[2]
    mean = np.divide(sums, observed, out=np.zeros(len(observed)), where=observed>0)
    mode = counts.argmax(0).astype(np.float64)
    cumulative = counts.cumsum(0)
    lower = (observed-1)//2
    upper = observed//2
    median = ((cumulative <= lower).sum(0) + (cumulative <= upper).sum(0))/2.
    median[observed == 0] = 0
    return observed, mean, mode, median


@dataclass
class ImputerState:
    metadata: dict
    arrays: dict

    @classmethod
    def from_counts(cls, counts, method, options=None, *, reference=None):
        opts = validate_options(method, options)
        observed, mean, mode, median = statistics(counts)
        fill = {"mean": mean, "mode": mode, "median": median, "none": mean,
                "knn": mode if opts.get("output") == "mode" else mean}[method]
        arrays = dict(fill=fill.copy(), observed=observed.astype(np.int64))
        if method == "knn":
            if reference is None:
                _fail("KNN requires frozen training reference genotypes.")
            cls.check_budget(reference.shape[0], reference.shape[1], opts)
            if np.any(observed == 0):
                _fail("KNN retained marker is entirely missing in training; remove it with all_missing=drop.")
            arrays["reference"] = np.asarray(reference, dtype=np.int8)
        return cls(dict(algorithm="frozen_genotype_imputer_v1", method=method,
                        options=opts, features=len(observed), fit_scope="training_reference_only",
                        distance="sqrt(P/common * squared_distance_on_jointly_observed_raw_012)",
                        tie_break="saved_reference_order; lower_genotype_code_for_mode",
                        fallback="training_mode" if method == "knn" and opts["output"] == "mode" else "training_mean",
                        no_reference_phenotypes=True), arrays)

    @staticmethod
    def check_budget(n, m, opts, query_rows=1):
        # Explicit array bounds; allocator/library/runtime overhead is excluded.
        if n > opts["max_reference_samples"] or n*m > opts["max_reference_bytes"]:
            _fail(f"KNN reference needs {n} samples / {n*m} bytes; exceeds configured reference budget. Reduce training rows/retained markers or explicitly raise the limit.", "E_MODEL_LIMIT")
        work = (query_rows*m*8 + n*48 + min(n, opts["block_rows"])*min(m, opts["block_markers"])*32)
        if work > opts["max_working_bytes"]:
            _fail(f"KNN numeric workspace estimate {work} bytes exceeds max_working_bytes={opts['max_working_bytes']}. Use smaller query batches/blocks or explicitly raise the budget. Runtime overhead is additional.", "E_MODEL_LIMIT")
        return work

    def transform(self, raw, *, progress=None, cancelled=None):
        raw = np.asarray(raw)
        if raw.ndim != 2 or raw.shape[1] != self.metadata["features"] or raw.dtype.kind not in "iuf":
            _fail("Expected raw 0/1/2/-1 calls in the frozen retained-marker order.")
        _check_cancel(cancelled)
        method = self.metadata["method"]
        opts = self.metadata["options"]
        if method == "knn":
            ref = self.arrays["reference"]
            self.check_budget(*ref.shape, opts, query_rows=len(raw))
        if not np.isin(raw, [-1,0,1,2]).all():
            _fail("Expected raw 0/1/2/-1 calls in the frozen retained-marker order.")
        if method == "none":
            if np.any(raw == -1):
                _fail("continuous input has missing calls while imputation is disabled; enable training-only imputation or use an explicit missing-category representation")
            return raw.astype(np.float64)
        result = np.where(raw == -1, self.arrays["fill"], raw).astype(np.float64)
        if method != "knn":
            return result
        n, m = ref.shape
        b, f = opts["block_rows"], opts["block_markers"]
        for qi, query in enumerate(raw):
            _check_cancel(cancelled)
            if progress:
                progress("imputation_knn", qi, len(raw))
            missing = np.flatnonzero(query == -1)
            if not len(missing):
                continue
            squared, common = np.zeros(n), np.zeros(n, dtype=np.int64)
            for start in range(0, n, b):
                for col in range(0, m, f):
                    _check_cancel(cancelled)
                    donor = ref[start:start+b, col:col+f]
                    q = query[col:col+f]
                    jointly = (donor >= 0) & (q >= 0)
                    common[start:start+b] += jointly.sum(1)
                    delta = donor.astype(np.float64) - q
                    squared[start:start+b] += np.where(jointly, delta*delta, 0).sum(1)
            distance = np.full(n, np.inf)
            available = common >= opts["min_common"]
            distance[available] = np.sqrt(m*squared[available]/common[available])
            ranked = np.argsort(distance, kind="stable")
            ranked = ranked[np.isfinite(distance[ranked])]
            for col in missing:
                _check_cancel(cancelled)
                donors = ranked[ref[ranked, col] >= 0][:opts["k"]]
                if not len(donors):
                    continue  # Frozen training mean/mode fallback, never a query mean.
                values = ref[donors, col]
                d = distance[donors]
                if opts["weights"] == "distance":
                    zero = d == 0
                    weights = zero.astype(float) if zero.any() else 1/d
                else:
                    weights = np.ones(len(donors))
                if opts["output"] == "mode":
                    result[qi, col] = np.bincount(values, weights=weights, minlength=3).argmax()
                else:
                    result[qi, col] = np.average(values, weights=weights)
        if progress:
            progress("imputation_knn", len(raw), len(raw))
        return result

    def pack(self):
        return {"imputer_"+k: v for k,v in self.arrays.items()}

    @classmethod
    def unpack(cls, metadata, arrays):
        method = metadata["method"]
        opts = validate_options(method, metadata["options"])
        if metadata.get("algorithm") != "frozen_genotype_imputer_v1" or metadata.get("fit_scope") != "training_reference_only":
            _fail("Unrecognized imputation state algorithm or fit scope.")
        members = {k[8:]: v for k,v in arrays.items() if k.startswith("imputer_")}
        expected = {"fill", "observed"} | ({"reference"} if method == "knn" else set())
        if set(members) != expected:
            _fail("Missing or unexpected imputation reference/state arrays.")
        m = metadata["features"]
        if any(members[k].shape != (m,) for k in ("fill", "observed")):
            _fail("Imputation state vector dimensions differ.")
        if not np.isfinite(members["fill"]).all() or np.any((members["fill"] < 0)|(members["fill"] > 2)) or np.any(members["observed"] < 0):
            _fail("Invalid imputation statistics.")
        if method == "knn":
            ref = members["reference"]
            if ref.ndim != 2 or ref.shape[1] != m or ref.dtype != np.int8:
                _fail("KNN reference dimensions or dtype differ.")
            cls.check_budget(*ref.shape, opts)
            for offset in range(0, len(ref), opts["block_rows"]):
                if not np.isin(ref[offset:offset+opts["block_rows"]], [-1,0,1,2]).all():
                    _fail("Invalid KNN reference hard calls.")
            if not np.array_equal((ref >= 0).sum(0), members["observed"]):
                _fail("KNN reference observed counts differ from saved statistics.")
        return cls(metadata, members)
