"""Job-local memoization of unfitted facts, with full content checks at both ends.

No fitted preprocessing, targets, models, or mutable output JSON is cached here.
Only explicitly registered input/cache files may reuse a digest. A final fresh
read detects even same-size/mtime edits; unfinished jobs never issue a receipt.
"""
from contextvars import ContextVar
from contextlib import contextmanager
from collections import Counter
from pathlib import Path
import copy
import time

_current = ContextVar('gpnb_shared_facts', default=None)


def current():
    return _current.get()


class SharedFacts:
    def __init__(self, paths=(), cancelled=None):
        self.paths = {str(Path(p).resolve()) for p in paths}
        self.hashes, self.facts = {}, {}
        self.counts = Counter()
        self.started = time.perf_counter()
        self.cancelled = cancelled
        self.verified = False
        self.peak_rss_bytes = 0
        self.last_sample = 0.

    def check(self):
        from ..training.core import check_cancel
        check_cancel(self.cancelled)
        if time.perf_counter() - self.last_sample >= .25:
            import psutil
            self.peak_rss_bytes = max(self.peak_rss_bytes, psutil.Process().memory_info().rss)
            self.last_sample = time.perf_counter()

    def register(self, paths):
        self.paths.update(str(Path(p).resolve()) for p in paths)

    def digest(self, path, read):
        name = str(Path(path).resolve())
        if name not in self.paths:
            return read(path)
        self.check()
        stat = Path(name).stat()
        signature = (stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns)
        if name in self.hashes:
            before, value = self.hashes[name]
            if before != signature:
                from ..config import fail
                fail('E_CHANGED', name, 'shared input changed during this job')
            self.counts['hash_hits'] += 1
            return value
        value = read(Path(name))
        after = Path(name).stat()
        if signature != (after.st_size, after.st_mtime_ns, after.st_ctime_ns):
            from ..config import fail
            fail('E_CHANGED', name, 'shared input changed while hashing')
        self.hashes[name] = (signature, value)
        self.counts['full_hash_reads_start'] += 1
        self.counts['hashed_bytes_start'] += stat.st_size
        return value

    def fact(self, kind, key, build):
        self.check()
        key = (kind, key)
        if key not in self.facts:
            self.facts[key] = build()
            self.counts[kind + '_builds'] += 1
        else:
            self.counts[kind + '_hits'] += 1
        # Callers cannot contaminate later traits by modifying a returned fact.
        return copy.deepcopy(self.facts[key])

    def verify(self):
        from .files import _sha256
        from ..config import fail
        for name, (_, expected) in self.hashes.items():
            self.check()
            if not Path(name).is_file() or _sha256(Path(name)) != expected:
                fail('E_CHANGED', name, 'shared input content changed; discard this job and retry')
            self.counts['full_hash_reads_end'] += 1
        self.verified = True

    def report(self):
        return dict(scope='job_local_unfitted_facts', counters=dict(self.counts),
                    final_content_verified=self.verified,
                    elapsed_seconds=time.perf_counter() - self.started,
                    sampled_peak_rss_bytes=self.peak_rss_bytes,
                    memory_measurement='process RSS sampled at checks, at most every 250 ms; not a total-allocation bound',
                    fitted_states_shared=False)


@contextmanager
def shared_facts(paths=(), cancelled=None):
    value = SharedFacts(paths, cancelled)
    token = _current.set(value)
    try:
        yield value
    finally:
        _current.reset(token)
