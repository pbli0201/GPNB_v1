from __future__ import annotations

from dataclasses import dataclass
from importlib.metadata import version
from pathlib import Path

import numpy as np
from bed_reader import open_bed

from ..config import fail, number

READER = {"name": "bed-reader", "version": version("bed-reader"), "adapter_version": 1}
ENCODING = {"counted_allele": "BIM_A1", "values": [0, 1, 2], "missing": -1,
            "bed_layout": "variant_major", "array_layout": "FAM_rows_BIM_columns",
            "allele_case_sensitive": True, "ploidy_inferred": False}
MATRIX_ENCODING = {**ENCODING, "bed_layout": None, "array_layout": "matrix_ID_rows_BIM_columns"}


def validate_bed(path: Path, samples: int, markers: int):
    with path.open("rb") as stream:
        header = stream.read(3)
    if header != b"\x6c\x1b\x01":
        fail("E_FORMAT", str(path), f"only variant-major BED supported; header={header.hex()}")
    expected = 3 + ((samples + 3) // 4) * markers
    if path.stat().st_size != expected:
        fail("E_FORMAT", str(path), f"BED byte count {path.stat().st_size}, expected {expected} from FAM/BIM")


@dataclass
class MissingCounts:
    samples: np.ndarray
    markers: np.ndarray

    @property
    def total(self):
        return int(self.samples.sum())

    def summary(self):
        cells = len(self.samples) * len(self.markers)
        return {"scanned": True, "cells": cells, "missing_cells": self.total,
                "missing_rate": self.total / cells, "samples_with_missing": int((self.samples > 0).sum()),
                "markers_with_missing": int((self.markers > 0).sum())}


class BedAdapter:
    def __init__(self, path: Path, samples: int, markers: int, *, block_markers=256, memory_mib=64, threads=2):
        for key, value in (("block_markers", block_markers), ("memory_mib", memory_mib), ("threads", threads)):
            number(value, key, 1, 2**31 - 1, integer=True)
        validate_bed(path, samples, markers)
        self.path, self.samples, self.markers, self.threads = path, samples, markers, threads
        # Conservative budget for int8 doses + bool mask + packed bytes + temporary work.
        maximum = (memory_mib * 1024**2) // (4 * samples)
        if maximum < 1:
            fail("E_RANGE", "memory_mib", "budget cannot hold one marker block")
        self.block_markers = min(block_markers, maximum, markers)

    def blocks(self):
        stride = (self.samples + 3) // 4
        # Counts prevent bed-reader from parsing sidecars with its own delimiter/ID rules.
        with open_bed(self.path, iid_count=self.samples, sid_count=self.markers,
                      count_A1=True, num_threads=self.threads) as reader, self.path.open("rb") as raw:
            raw.seek(3)
            for start in range(0, self.markers, self.block_markers):
                end = min(start + self.block_markers, self.markers)
                packed = raw.read(stride * (end - start))
                if len(packed) != stride * (end - start):
                    fail("E_CHANGED", str(self.path), "BED truncated while scanning")
                if self.samples % 4:
                    tails = np.frombuffer(packed, dtype=np.uint8)[stride - 1::stride]
                    bad = np.flatnonzero(tails >> (2 * (self.samples % 4)))
                    if len(bad):
                        fail("E_FORMAT", str(self.path), f"nonzero BED padding at marker index {start + int(bad[0])}")
                array = reader.read(np.s_[:, start:end], dtype="int8", order="F")
                array[array == -127] = -1
                if array.shape != (self.samples, end - start) or not np.isin(array, [-1, 0, 1, 2]).all():
                    fail("E_FORMAT", str(self.path), "unexpected decoded dosage/shape")
                yield start, end, array

    def scan(self, destination: Path | None = None, progress=None):
        missing = MissingCounts(np.zeros(self.samples, dtype=np.int64), np.zeros(self.markers, dtype=np.int64))
        mapped = None
        try:
            if destination is not None:
                mapped = np.lib.format.open_memmap(destination, mode="w+", dtype=np.int8,
                                                   shape=(self.samples, self.markers), fortran_order=False)
            for start, end, block in self.blocks():
                absent = block == -1
                missing.samples += absent.sum(axis=1, dtype=np.int64)
                missing.markers[start:end] = absent.sum(axis=0, dtype=np.int64)
                if mapped is not None:
                    mapped[:, start:end] = block
                if progress:
                    progress("genotype_scan", end, self.markers)
            if mapped is not None:
                mapped.flush()
            return missing
        finally:
            if mapped is not None:
                mapped._mmap.close()
