"""Versioned fixed splits; raw genotype equality remains a QC observation."""
from __future__ import annotations

import hashlib
from collections import Counter
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from ..config import RunSpec, default_run, fail
from .cache import identity_key
from .files import read_json, write_csv, write_json

PARTS = ("train", "validation", "test")
ALGORITHM = "pcg64_group_largest_deficit_v1"
INDIVIDUAL_ALGORITHM = "pcg64_individual_largest_deficit_v2"
BATCH_FIXED = "shared_individual_trait_projection_v1"
FINAL_ALGORITHMS = {"final_selection": "final_internal_holdout_v1", "final_training": "final_all_eligible_v1"}


def final_partitions(context, config):
    """An explicit deployment task, not a reusable independent evaluation."""
    members = {}
    for i, (unit, eligible) in enumerate(zip(unit_groups(context), context["eligible"])):
        if eligible:
            members.setdefault(unit, []).append(i)
    minimum = 2 if config["method"] == "final_selection" else 1
    if len(members) < minimum:
        fail("E_SPLIT", "eligible", f"final model needs at least {minimum} labelled splitting units")
    all_rows = sorted(i for rows in members.values() for i in rows)
    validation = []
    if config["method"] == "final_selection":
        names = sorted(members)
        names = [names[i] for i in np.random.Generator(np.random.PCG64(config["seed"])).permutation(len(names))]
        target = max(1, round(len(all_rows) * config["ratios"][1]))
        for name in names[:-1]:
            if len(validation) >= target:
                break
            validation.extend(members[name])
    return dict(train=sorted(set(all_rows) - set(validation)), validation=sorted(validation), test=[])


def context_for_policy(context, config):
    """Attach new policy only when requested; legacy contexts remain byte-identical."""
    policy = config.get("group_policy", "genotype_equivalence")
    expected = "individual_id" if policy == "individual_id" else None
    current = context.get("split_unit")
    if current is not None and current != expected:
        fail("E_SPLIT", "split_unit", "context and requested split policy differ; generate a new plan")
    if expected is not None:
        return {**context, "split_unit": expected}
    return context


def unit_groups(context):
    """Stable individual identities or the explicitly retained legacy equality groups."""
    if context.get("split_unit") == "individual_id":
        return ["individual_" + identity_key(ids) for ids in context["sample_ids"]]
    return context["groups"]


def write_genotype_qc(path, sample_ids, groups):
    """Report equality without concluding that distinct IDs are duplicate individuals."""
    counts = Counter(groups)
    write_csv(path, ["sample_index", "FID", "IID", "genotype_equivalence_group", "group_size"],
              ((i, *ids, group, counts[group]) for i, (ids, group) in enumerate(zip(sample_ids, groups))
               if counts[group] > 1))
    return {"identical_genotype_groups": sum(size > 1 for size in counts.values()),
            "individuals_in_identical_genotype_groups": sum(size for size in counts.values() if size > 1),
            "interpretation": "Genotype equality alone does not establish duplicate individual identity or pedigree."}


def require(condition, message="invalid manifest"):
    if not condition:
        raise ValueError(message)


def genotype_groups(cache, declared=None, progress=None):
    from .shared import current
    scope = current()
    if scope:
        return scope.fact('genotype_groups', (cache.metadata['key'], tuple(declared or ())),
                          lambda: _genotype_groups(cache, declared, progress))
    return _genotype_groups(cache, declared, progress)


def _genotype_groups(cache, declared=None, progress=None):
    """Hash full int8 rows (including missingness), then verify digest matches.

    Supplied groups must contain identical genotypes. Identical rows assigned
    different supplied names are joined. Group names never imply pedigree.
    """
    n, m = cache.metadata["shape"]
    representatives, groups = {}, []
    # At most ~8 MiB per row batch, except when one row alone exceeds that.
    step = max(1, min(256, 8 * 1024**2 // m))
    for start in range(0, n, step):
        matrix = cache.batch(np.arange(start, min(n, start + step)))
        for offset, row in enumerate(matrix):
            index = start + offset
            digest = hashlib.sha256(row.tobytes()).hexdigest()
            if digest in representatives:
                reference = cache.batch([representatives[digest]])[0]
                if not np.array_equal(reference, row):
                    fail("E_GROUP", f"sample[{index}]", "genotype digest collision")
            else:
                representatives[digest] = index
            groups.append("raw_" + digest)
        if progress:
            progress("genotype_groups", min(n, start + step), n)
    if declared is not None:
        if len(declared) != n:
            fail("E_GROUP", "groups", "provided group count differs from samples")
        known = {}
        for i, name in enumerate(declared):
            if not name:
                continue
            if name in known and known[name] != groups[i]:
                fail("E_GROUP", f"sample[{i}]", f"provided group {name!r} contains unequal raw genotypes")
            known[name] = groups[i]
    return groups


def _validate_context(context):
    try:
        ids, groups, eligible = context["sample_ids"], context["groups"], context["eligible"]
        n = len(ids)
        require(n and len(groups) == n and len(eligible) == n)
        require(all(type(x) is list and len(x) == 2 and all(type(s) is str for s in x) for x in ids))
        require(len({tuple(x) for x in ids}) == n)
        require(all(type(x) is str and x for x in groups))
        require(all(type(x) is bool for x in eligible))
        require(context.get("split_unit") in (None, "individual_id"))
    except (ValueError, KeyError, TypeError):
        fail("E_SPLIT", "context", "invalid ordered IDs, eligibility or genotype groups")


@dataclass(frozen=True)
class SplitManifest:
    value: dict

    @classmethod
    def create(cls, context, config):
        context = context_for_policy(context, config)
        _validate_context(context)
        run = default_run().to_dict()
        run["split"] = config
        if config["method"] == "final_training":
            run["training"]["selection_mode"] = "fixed_epochs"
        RunSpec(run)
        if config["method"] in FINAL_ALGORITHMS:
            value = dict(schema_version=1, kind="split_manifest", algorithm=FINAL_ALGORITHMS[config["method"]],
                context=context, context_sha256=identity_key(context), seed=config["seed"],
                requested_ratios=config["ratios"], partitions=final_partitions(context, config),
                excluded=[i for i, eligible in enumerate(context["eligible"]) if not eligible])
            result = cls(value)
            result.validate(context, config)
            return result
        if 'batch_union_eligible' in context:
            from .batch_split import union_context,project_partitions
            base=cls.create(union_context(context),config).value
            value={**base,'algorithm':BATCH_FIXED,'context':context,'context_sha256':identity_key(context),
                   'partitions':project_partitions(base['partitions'],context),
                   'excluded':[i for i,e in enumerate(context['eligible']) if not e]}
            result=cls(value);result.validate(context,config);return result
        group_members = {}
        for i, (group, eligible) in enumerate(zip(unit_groups(context), context["eligible"])):
            if eligible:
                group_members.setdefault(group, []).append(i)
        if len(group_members) < 3:
            fail("E_SPLIT", "eligible", "at least three labelled splitting units are required")
        names = sorted(group_members)
        rng = np.random.Generator(np.random.PCG64(config["seed"]))
        names = [names[i] for i in rng.permutation(len(names))]
        # Large groups first; seeded permutation breaks equal-size ties.
        names.sort(key=lambda key: -len(group_members[key]))
        total = sum(map(len, group_members.values()))
        targets = np.array(config["ratios"], dtype=np.float64) * total
        counts = np.zeros(3, dtype=np.int64)
        partitions = {part: [] for part in PARTS}
        for position, name in enumerate(names):
            empty = np.flatnonzero(counts == 0)
            candidates = empty if len(names) - position == len(empty) else np.arange(3)
            slot = int(candidates[np.argmax((targets - counts)[candidates])])
            partitions[PARTS[slot]].extend(group_members[name])
            counts[slot] += len(group_members[name])
        for rows in partitions.values():
            rows.sort()
        algorithm = INDIVIDUAL_ALGORITHM if context.get("split_unit") == "individual_id" else ALGORITHM
        value = {"schema_version": 1, "kind": "split_manifest", "algorithm": algorithm,
                 "context": context, "context_sha256": identity_key(context),
                 "seed": config["seed"], "requested_ratios": config["ratios"],
                 "partitions": partitions,
                 "excluded": [i for i, eligible in enumerate(context["eligible"]) if not eligible]}
        result = cls(value)
        result.validate(context, config)
        return result

    def validate(self, context, config=None):
        if config is not None:
            context = context_for_policy(context, config)
        elif self.value.get("context", {}).get("split_unit") == "individual_id" and "split_unit" not in context:
            context = context_for_policy(context, {"group_policy": "individual_id"})
        _validate_context(context)
        v = self.value
        try:
            require(type(v["schema_version"]) is int and v["schema_version"] == 1)
            from .folds import ALL_CV_ALGORITHMS, FULL_LOO_ALGORITHMS, fold_value, make_plan
            require(v["kind"] == "split_manifest" and v["algorithm"] in (ALGORITHM, INDIVIDUAL_ALGORITHM, BATCH_FIXED, *ALL_CV_ALGORITHMS, *FINAL_ALGORITHMS.values()))
            if v['algorithm']==BATCH_FIXED:
                from .batch_split import union_context,project_partitions
                config_base=dict(method='fixed',seed=v['seed'],ratios=v['requested_ratios'],group_policy='individual_id' if context.get('split_unit')=='individual_id' else 'genotype_equivalence',reuse_manifest=None)
                base=SplitManifest.create(union_context(context),config_base)
                require(v['partitions']==project_partitions(base.value['partitions'],context))
            if v["algorithm"] in FINAL_ALGORITHMS.values():
                method = next(k for k, a in FINAL_ALGORITHMS.items() if a == v["algorithm"])
                require(config is None or config["method"] == method)
                require(v["partitions"] == final_partitions(context, dict(method=method, seed=v["seed"], ratios=v["requested_ratios"])))
            if v["algorithm"] in (ALGORITHM, INDIVIDUAL_ALGORITHM):
                expected_algorithm = INDIVIDUAL_ALGORITHM if context.get("split_unit") == "individual_id" else ALGORITHM
                require(v["algorithm"] == expected_algorithm, "fixed split policy differs")
            if v["algorithm"] in ALL_CV_ALGORITHMS:
                cv = v["cross_validation"]
                expected = fold_value(make_plan(context, {**cv["config"], "reuse_manifest": None}), cv["fold"])
                require(v == expected, "invalid cross-validation fold or plan binding")
            require(v["context_sha256"] == identity_key(context) and v["context"] == context)
            if config is not None:
                require(v["seed"] == config["seed"] and v["requested_ratios"] == config["ratios"])
            require(set(v["partitions"]) == set(PARTS))
            observed, owners, units = [], {}, unit_groups(context)
            for part in PARTS:
                rows = v["partitions"][part]
                empty_allowed = (part == "validation" and v["algorithm"] in FULL_LOO_ALGORITHMS) or (part == "test" and v["algorithm"] in FINAL_ALGORITHMS.values()) or (part == "validation" and v["algorithm"] == FINAL_ALGORITHMS["final_training"])
                require(type(rows) is list and (rows or empty_allowed) and all(type(i) is int for i in rows))
                require(rows == sorted(set(rows)) and all(0 <= i < len(context["groups"]) for i in rows))
                observed.extend(rows)
                for i in rows:
                    require(context["eligible"][i])
                    group = units[i]
                    require(group not in owners or owners[group] == part)
                    owners[group] = part
            expected = [i for i, eligible in enumerate(context["eligible"]) if eligible]
            require(sorted(observed) == expected)
            require(v["excluded"] == [i for i, e in enumerate(context["eligible"]) if not e])
        except (ValueError, KeyError, TypeError, IndexError):
            fail("E_SPLIT", "split_manifest", "incompatible inputs/config, incomplete or overlapping sets, or a group crosses sets")

    @classmethod
    def load(cls, path, context, config=None):
        envelope = read_json(Path(path))
        try:
            if identity_key(envelope["manifest"]) != envelope["sha256"]:
                raise ValueError("split checksum mismatch")
            result = cls(envelope["manifest"])
            result.validate(context, config)
            return result
        except (KeyError, TypeError, ValueError) as error:
            from ..errors import GPNBError
            if isinstance(error, GPNBError):
                raise
            fail("E_SPLIT", str(path), str(error))

    def save(self, path):
        path = Path(path)
        if path.exists():
            fail("E_EXISTS", str(path), "split already exists")
        write_json(path, {"manifest": self.value, "sha256": identity_key(self.value)})

    def rows(self, part):
        if part not in PARTS:
            fail("E_SPLIT", "partition", f"expected one of {PARTS}")
        return np.array(self.value["partitions"][part], dtype=np.int64)

    def summary(self):
        counts = {part: len(self.value["partitions"][part]) for part in PARTS}
        total = sum(counts.values())
        groups = Counter(self.value["context"]["groups"])
        return {"counts": counts, "excluded": len(self.value["excluded"]),
                "split_unit": self.value["context"].get("split_unit", "genotype_equivalence"),
                "actual_ratios": {part: count / total for part, count in counts.items()},
                "requested_ratios": self.value["requested_ratios"],
                "genotype_groups": len(groups),
                "multi_sample_groups": sum(size > 1 for size in groups.values()),
                "samples_in_multi_sample_groups": sum(size for size in groups.values() if size > 1)}
