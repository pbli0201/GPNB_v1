"""Shared CLI/GUI preparation service and lazy transformed minibatches."""
from __future__ import annotations

import csv
import hashlib
import platform
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from ..config import ProjectSpec, fail, load_spec, resolve_project_path
from .cache import load_cache
from .descriptor import load_descriptor
from .files import (protect_inputs, read_json, sha256, snapshot,
                    verify_snapshots, write_csv, write_json)
from .preprocessing import PreprocessorState, marker_identity
from .split import PARTS, SplitManifest, genotype_groups, context_for_policy, write_genotype_qc


def table(path):
    with Path(path).open(encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream))


def prepare_project(project_file, import_directory, output, *, block_markers=256, progress=None):
    if progress:
        progress("prepare_start", 0, 1)
    project_file, import_directory, output = (Path(p).resolve() for p in (project_file, import_directory, output))
    if output.exists():
        fail("E_EXISTS", str(output), "choose a new preparation directory")
    project_before = snapshot(project_file)
    spec = load_spec(project_file)
    if not isinstance(spec, ProjectSpec):
        fail("E_TYPE", str(project_file), "prepare requires ProjectSpec")
    project = spec.to_dict()
    descriptor = load_descriptor(import_directory)
    if descriptor["cache"] is None:
        fail("E_CACHE", str(import_directory), "prepare requires an import with a complete raw cache; run gpnb import first")
    # Bind requested paths and interpretation, while permitting model/run changes.
    imported = read_json(import_directory / "project_snapshot.json")
    if (project["data"]["dataset_id"] != imported["data"]["dataset_id"] or
            project["data"]["phenotype_options"] != imported["data"]["phenotype_options"] or
            project.get("extensions",{}).get("multitask") != imported.get("extensions",{}).get("multitask")):
        fail("E_MANIFEST", "project.data", "dataset or phenotype interpretation changed; import the new configuration first")
    from .genotypes import verify_matrix_binding
    requested_files = verify_matrix_binding(project["data"], imported["data"], descriptor["source_files"], project_file)
    for name in ("bed", "bim", "fam", "phenotype", "manifest", "split_groups"):
        stored = project["data"][name]
        if stored is None:
            if imported["data"][name] is not None:
                fail("E_MANIFEST", name, "project removed an explicitly imported input")
            continue
        current = snapshot(resolve_project_path(project_file, stored))
        requested_files[name] = current
        if name not in descriptor["source_files"] or current["sha256"] != descriptor["source_files"][name]["sha256"]:
            fail("E_MANIFEST", name, "requested input differs from imported input")
    protect_inputs(output, [Path(v["path"]) for v in descriptor["source_files"].values()] + [project_file])
    for directory in (import_directory, Path(descriptor["cache"]["path"]).resolve()):
        if output.is_relative_to(directory) or directory.is_relative_to(output):
            fail("E_IO", str(output), "preparation must not overlap import/cache")
    cache = load_cache(Path(descriptor["cache"]["path"]))
    samples, marker_rows = table(import_directory / "samples.csv"), table(import_directory / "markers.csv")
    n, m = cache.metadata["shape"]
    if len(samples) != n or len(marker_rows) != m:
        fail("E_FORMAT", str(import_directory), "order tables differ from cache dimensions")
    markers = marker_identity(marker_rows)
    groups = genotype_groups(cache, [s["genotype_equivalence_group"] for s in samples], progress)
    eligible = [s["match_status"] == "matched_finite_label" for s in samples]
    context = {"dataset_id": descriptor["dataset_id"], "trait": project["data"]["phenotype_options"]["trait"],
               "cache_key": cache.metadata["key"], "phenotype_sha256": descriptor["source_files"]["phenotype"]["sha256"],
               "phenotype_options": project["data"]["phenotype_options"],
               "sample_ids": [[s["FID"], s["IID"]] for s in samples],
               "groups": groups, "eligible": eligible}
    from .multitask import contract,read_targets,fit_target_state
    multitask=contract(project)
    if multitask:
        context["multitask"]=multitask
    split_config = project["run"]["split"]
    context = context_for_policy(context, split_config)
    from .batch_split import bind_context
    context = bind_context(context, project, project_file)
    reuse = split_config["reuse_manifest"]
    split = (SplitManifest.load(resolve_project_path(project_file, reuse), context, split_config)
             if reuse else SplitManifest.create(context, split_config))
    train_rows = split.rows("train")
    target_state=None
    if multitask:
        target_values=read_targets(project,resolve_project_path(project_file,project["data"]["phenotype"]),context["sample_ids"])
        if np.isfinite(target_values).any(1).tolist()!=eligible:
            fail("E_MULTITASK","eligibility","target observations differ from import")
        target_state=fit_target_state(target_values,train_rows,split.rows("validation"),project,context["sample_ids"],
                                     descriptor["source_files"]["phenotype"]["sha256"])
    state = PreprocessorState.fit(cache, train_rows, None if multitask else [float(samples[i]["value"]) for i in train_rows],
                                 markers, project["run"]["preprocessing"], block_markers=block_markers,
                                 provenance=descriptor["provenance"], progress=progress)
    output.mkdir(parents=True)
    (output / "INCOMPLETE").write_text("Preparation not complete.\n", encoding="utf-8")
    try:
        split.save(output / "split.json")
        genotype_qc = write_genotype_qc(output / "identical_genotypes.csv", context["sample_ids"], groups)
        state.save(output / "preprocessor")
        if multitask:
            write_json(output/"target_state.json",target_state)
            np.save(output/"target_values.npy",target_values,allow_pickle=False)
        write_json(output / "project_snapshot.json", project)
        write_json(output / "input_descriptor.json", descriptor)
        assignment = {i: part for part in PARTS for i in split.rows(part)}
        write_csv(output / "samples.csv", ["fam_index", "FID", "IID", "group", "partition", "trait", "value", "transformed_value", "exclusion_reason"],
                  ((i, s["FID"], s["IID"], groups[i], assignment.get(i, "excluded"), s["trait"], s["value"],
                    float(state.transform_target(float(s["value"]))) if eligible[i] and not multitask else "",
                    "" if eligible[i] else s["match_status"]) for i, s in enumerate(samples)))
        write_csv(output / "exclusions.csv", ["fam_index", "FID", "IID", "reason"],
                  ((i, s["FID"], s["IID"], s["match_status"]) for i, s in enumerate(samples) if not eligible[i]))
        a = state.arrays
        def marker_records():
            selected_index = 0
            for i, row in enumerate(markers):
                reasons = []
                if project["run"]["preprocessing"].get("enabled", True) and project["run"]["preprocessing"]["all_missing"] == "drop" and a["all_missing"][i]:
                    reasons.append("all_missing_in_training")
                if project["run"]["preprocessing"]["maf_min"] is not None and (
                        a["all_missing"][i] or a["maf"][i] < project["run"]["preprocessing"]["maf_min"]):
                    reasons.append("undefined_or_low_training_MAF")
                if project["run"]["preprocessing"]["marker_missing_max"] is not None and (
                        a["missing_rate"][i] > project["run"]["preprocessing"]["marker_missing_max"]):
                    reasons.append("high_training_missing_rate")
                yield (i, selected_index if a["keep"][i] else "", *row, int(a["keep"][i]), ";".join(reasons),
                       int(a["observed"][i]), a["missing_rate"][i], "" if a["all_missing"][i] else a["maf"][i],
                       a["mean"][i], a["scale"][i], int(a["all_missing"][i]), int(a["zero_variance"][i]),
                       a.get("center", a["mean"])[i])
                selected_index += int(a["keep"][i])
        write_csv(output / "markers.csv", ["bim_index", "model_input_index", "chromosome", "marker_id", "cm_position",
                  "bp_position", "A1", "A2", "retained", "filter_reason", "training_observed", "training_missing_rate",
                  "training_MAF", "training_mean", "training_scale", "training_all_missing", "training_zero_variance", "training_imputed_center"], marker_records())
        # Actual model-facing inputs, including a missing category when explicitly selected.
        checks = {}
        from .encoding import model_inputs
        representation = project["model"].get("input_representation", "standardized_dosage")
        for part in PARTS:
            rows = split.rows(part)
            digest = hashlib.sha256()
            for start in range(0, len(rows), 64):
                if progress:
                    progress("check_" + part, start, len(rows))
                batch = model_inputs(state, cache.batch(rows[start:start + 64]), representation)
                if batch.shape[1] != state.input_features or not np.isfinite(batch).all():
                    fail("E_PREPROCESS", part, "transformed batch has invalid shape or nonfinite values")
                digest.update(batch.tobytes())
            checks[part] = {"shape": [len(rows), state.input_features], "finite": True,
                            "dtype": "int64" if representation == "genotype_categories" else "float32",
                            "input_sha256": digest.hexdigest()}
            if representation != "genotype_categories":
                checks[part]["float32_sha256"] = digest.hexdigest()
        # Recheck immutable input and import/cache artifacts before publication.
        if progress:
            progress("prepare_verify", 0, 1)
        load_descriptor(import_directory)
        verify_snapshots({"project": project_before})
        verify_snapshots(requested_files)
        report = {"schema_version": 1, "kind": "prepared_dataset", "ok": True,
                  "dataset_id": context["dataset_id"], "trait": context["trait"],
                  "import_directory": str(import_directory), "cache": descriptor["cache"],
                  "split_reused": reuse is not None, "split": split.summary(),
                  "group_verification": {"content_recomputed_from_genotypes": True,
                                         "basis": "exact_complete_raw_dosage_including_missingness",
                                         "provided_group_members_verified": any(s["genotype_equivalence_group"] for s in samples),
                                         "equal_rows_across_provided_groups_policy": "qc_only_keep_individual_ids" if context.get("split_unit") == "individual_id" else "merge",
                                         "split_unit": context.get("split_unit", "genotype_equivalence")},
                  "genotype_qc": genotype_qc,
                  "raw_features": m, "input_features": state.input_features,
                  "model_input": {"layout": "batch_markers", "features": state.input_features,
                                  "representation": representation,
                                  "marker_order_sha256": state.metadata["selected_marker_order_sha256"]},
                  "filters": project["run"]["preprocessing"],
                  "training_all_missing_markers": int(a["all_missing"].sum()),
                  "training_zero_variance_markers": int(a["zero_variance"].sum()),
                  "provenance": descriptor["provenance"], "warnings": state.metadata["warnings"],
                  "transforms": checks, "environment": {"python": platform.python_version(), "numpy": np.__version__},
                  "scope": "Fixed split and train-fitted preprocessing only; no model trained."}
        write_json(output / "report.json", report)
        if progress:
            progress("prepare_complete", 1, 1)
        artifacts = {p.relative_to(output).as_posix(): sha256(p) for p in output.rglob("*")
                     if p.is_file() and p.name != "INCOMPLETE"}
        write_json(output / "complete.json", {"schema_version": 1, "kind": "prepared_bundle", "files": artifacts})
        (output / "INCOMPLETE").unlink()
        return report
    except Exception as error:
        write_json(output / "failure.json", {"ok": False, "error": str(error)})
        raise


@dataclass
class PreparedDataset:
    """A05 consumes input_features; A06 consumes batches. Never refits on load."""
    cache: object
    state: PreprocessorState
    split: SplitManifest
    samples: list
    report: dict

    @property
    def input_features(self):
        # Genotype preprocessing remains separate from a fold-specific kernel input.
        return getattr(self, "kernel_input_features", self.state.input_features)

    @classmethod
    def load(cls, directory):
        directory = Path(directory).resolve()
        try:
            if (directory / "INCOMPLETE").exists():
                fail("E_PREPROCESS", str(directory), "preparation incomplete")
            complete = read_json(directory / "complete.json")
            if complete["schema_version"] != 1 or complete["kind"] != "prepared_bundle":
                fail("E_VERSION", str(directory), "unsupported prepared bundle")
            required = {"report.json", "input_descriptor.json", "project_snapshot.json", "split.json",
                        "samples.csv", "exclusions.csv", "markers.csv", "preprocessor/complete.json",
                        "preprocessor/state.json", "preprocessor/arrays.npz"}
            if not required.issubset(complete["files"]):
                fail("E_PREPROCESS", str(directory), "incomplete artifact inventory")
            for name, digest in complete["files"].items():
                path = (directory / name).resolve()
                if not path.is_relative_to(directory) or sha256(path) != digest:
                    fail("E_PREPROCESS", name, "invalid path or checksum")
            report = read_json(directory / "report.json")
            descriptor = read_json(directory / "input_descriptor.json")
            verify_snapshots(descriptor["source_files"])
            cache = load_cache(Path(report["cache"]["path"]))
            if cache.metadata["key"] != descriptor["cache"]["key"]:
                fail("E_PREPROCESS", "cache", "cache binding mismatch")
            state = PreprocessorState.load(directory / "preprocessor")
            envelope = read_json(directory / "split.json")
            project = load_spec(directory / "project_snapshot.json").to_dict()
            split = SplitManifest.load(directory / "split.json", envelope["manifest"]["context"], project["run"]["split"])
            if (split.value["context"]["cache_key"] != cache.metadata["key"] or
                    state.metadata["train_rows"] != split.rows("train").tolist() or
                    state.input_features != report["model_input"]["features"] or
                    state.metadata["options"] != project["run"]["preprocessing"] or
                    state.metadata["marker_order_sha256"] != cache.metadata["identity"]["marker_order_sha256"] or
                    state.metadata["selected_marker_order_sha256"] != report["model_input"]["marker_order_sha256"] or
                    state.metadata["provenance"] != descriptor["provenance"]):
                fail("E_PREPROCESS", str(directory), "split/state/model input binding mismatch")
            samples = table(directory / "samples.csv")
            if [[s["FID"], s["IID"]] for s in samples] != split.value["context"]["sample_ids"]:
                fail("E_PREPROCESS", "samples", "sample order differs from split")
            result=cls(cache,state,split,samples,report)
            from .multitask import contract,validate_state
            if contract(project):
                target_state=validate_state(read_json(directory/"target_state.json"))
                target_values=np.load(directory/"target_values.npy",allow_pickle=False)
                from .files import order_hash
                if (target_state["contract"]!=contract(project) or target_state["train_rows"]!=split.rows("train").tolist()
                        or target_state["sample_order_sha256"]!=order_hash(split.value["context"]["sample_ids"])
                        or target_state["phenotype_sha256"]!=descriptor["source_files"]["phenotype"]["sha256"]
                        or target_values.shape!=(len(samples),len(target_state["mean"])) or np.isinf(target_values).any()
                        or state.metadata.get("target_mode")!="separate_multi_target_state"
                        or target_state["standardized"]!=project["run"]["preprocessing"]["standardize_target"]):
                    fail("E_MULTITASK","prepared","target state/data/partition binding mismatch")
                result.target_state,result.target_values=target_state,target_values
            return result
        except (OSError, KeyError, TypeError) as error:
            fail("E_PREPROCESS", str(directory), f"invalid or incomplete prepared bundle: {error}")

    def batches(self, part, batch_size=64):
        if type(batch_size) is not int or batch_size < 1:
            fail("E_RANGE", "batch_size", "expected positive integer")
        rows = self.split.rows(part)
        for start in range(0, len(rows), batch_size):
            selected = rows[start:start + batch_size]
            from .encoding import model_inputs
            representation = self.report.get("model_input", {}).get("representation", "standardized_dosage")
            x = model_inputs(self.state, self.cache.batch(selected), representation)
            if hasattr(self,"target_state"):
                from .multitask import transform_targets
                y=transform_targets(self.target_values[selected],self.target_state)
            else:
                y = self.state.transform_target([float(self.samples[i]["value"]) for i in selected])
            yield selected.copy(), x, y
