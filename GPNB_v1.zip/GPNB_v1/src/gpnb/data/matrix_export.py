"""Export raw canonical hard calls with identities and an explicit encoding sidecar."""
from pathlib import Path
import csv

import numpy as np

from ..config import ProjectSpec, fail, load_spec
from .files import protect_inputs, snapshot, verify_snapshots, write_csv, write_json, order_hash
from .genotypes import source_paths, open_source, MatrixAdapter, decode_calls, matrix_encoding
from .bed import ENCODING


def export_genotypes(project_file, output, *, delimiter="\t", missing_token="NA", progress=None, cancelled=None):
    """Create a new export directory; never impute, filter or alter source files."""
    from ..training.core import check_cancel
    project_file, output = Path(project_file).resolve(), Path(output).resolve()
    if delimiter not in (",", "\t"):
        fail("E_FORMAT", "delimiter", "export delimiter must be comma or tab")
    if type(missing_token) is not str or not missing_token or missing_token in ("0", "1", "2") or any(c in missing_token for c in ("\0", "\n", "\r")):
        fail("E_FORMAT", "missing_token", "choose a nonempty explicit missing token other than 0/1/2")
    spec = load_spec(project_file)
    if not isinstance(spec, ProjectSpec):
        fail("E_TYPE", str(project_file), "genotype export requires ProjectSpec")
    project = spec.to_dict()
    paths = source_paths(project["data"], project_file)
    protect_inputs(output, [project_file, *paths.values()])
    if output.exists():
        fail("E_EXISTS", str(output), "choose a new genotype export directory")
    source = {key: snapshot(path) for key, path in paths.items() if key in ("bed", "bim", "fam", "matrix")}
    def stage(name, done=0, total=0):
        check_cancel(cancelled)
        if progress:
            progress({"event": "stage", "stage": name, "done": done, "total": total})
    stage("genotype_export_loading")
    samples, markers, adapter = open_source(project["data"], paths, progress=stage)
    options = project["data"].get("matrix")
    # PLINK and old matrix exports retain two IDs. No artificial FID is emitted for IID-only sources.
    single_id = bool(options and len(options["id_columns"]) == 1)
    id_columns = ["IID"] if single_id else ["FID", "IID"]
    names = [m[1] for m in markers]
    # Avoid output ambiguity when a marker uses one of the conventional ID names.
    if set(names).intersection(id_columns):
        id_columns = ["sample_iid"] if single_id else ["sample_fid", "sample_iid"]
        while set(names).intersection(id_columns):
            id_columns = ["_" + v for v in id_columns]
    output.mkdir(parents=True, exist_ok=False)
    (output / "INCOMPLETE").write_text("Genotype export is not complete.\n", encoding="utf-8")
    decoded = None
    try:
        if isinstance(adapter, MatrixAdapter):
            rows = ((i, decode_calls(values, options, adapter.path, line, names))
                    for i, (line, _, values) in enumerate(adapter.rows()))
        else:
            decoded = output / "decoded.npy"
            adapter.scan(decoded, progress=stage)
            mapped = np.load(decoded, mmap_mode="r", allow_pickle=False)
            rows = enumerate(mapped)
        filename = "calls.csv" if delimiter == "," else "calls.txt"
        missing = 0
        try:
            with (output / filename).open("w", encoding="utf-8", newline="") as stream:
                writer = csv.writer(stream, delimiter=delimiter, lineterminator="\n")
                writer.writerow([*id_columns, *names])
                for i, raw in rows:
                    if i % 64 == 0:
                        stage("genotype_export", i, len(samples))
                    missing += int((raw == -1).sum())
                    ids = [samples[i][1]] if single_id else samples[i][:2]
                    writer.writerow([*ids, *[missing_token if v == -1 else str(int(v)) for v in raw]])
        finally:
            if hasattr(rows, "close"):
                rows.close()
            if decoded is not None:
                mapped._mmap.close()
        if decoded is not None:
            decoded.unlink()
        encoding = matrix_encoding(options) if options else ENCODING
        write_csv(output / "markers.csv", ["chromosome", "marker_id", "cm_position", "bp_position", "A1", "A2"], markers)
        matrix = dict(path=filename, delimiter=delimiter, encoding="utf-8", id_columns=id_columns,
                      missing_tokens=[missing_token], counted_allele=encoding["counted_allele"], coding="012")
        if matrix["counted_allele"] == "DECLARED":
            matrix["allele_declaration"] = options["allele_declaration"]
        else:
            (output / "markers.bim").write_text("\n".join("\t".join(m) for m in markers) + "\n", encoding="utf-8")
        write_json(output / "matrix_config.json", matrix)
        write_json(output / "encoding.json", dict(schema_version=1, kind="genotype_encoding_manifest",
                   coding="012", counted_allele=encoding["counted_allele"],
                   allele_declaration=(options or {}).get("allele_declaration"),
                   missing_token=missing_token, id_columns=id_columns,
                   markers=markers, sample_order_sha256=order_hash([list(s[:2]) for s in samples]),
                   marker_order_sha256=order_hash([list(m) for m in markers]),
                   source_files=source, imputed=False, standardized=False, filtered=False))
        verify_snapshots(source)
        stage("genotype_export", len(samples), len(samples))
        report = dict(ok=True, kind="genotype_export", output=str(output), matrix=filename,
                      samples=len(samples), markers=len(markers), missing_genotypes=missing,
                      scope="Raw hard calls only; no imputation, filtering, standardization or phenotype fitting.")
        write_json(output / "report.json", report)
        (output / "INCOMPLETE").unlink()
        return report
    except BaseException as error:
        write_json(output / "failure.json", dict(ok=False, error=str(error)))
        raise
