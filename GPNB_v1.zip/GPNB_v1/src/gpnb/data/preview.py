"""Generate the same persisted split plans used by training, without fitting."""
from pathlib import Path
import numpy as np

from ..config import load_spec, resolve_project_path, fail
from .audit import inspect_project
from .descriptor import load_descriptor
from .cache import load_cache
from .prepare import table
from .split import genotype_groups, SplitManifest, PARTS, context_for_policy, unit_groups, write_genotype_qc
from .folds import make_plan, load_plan, save_plan, fold_value, fold_count
from .files import write_json, snapshot, verify_snapshots, protect_inputs


def preview_split(project_path, output, *, cache_root=None, progress=None, cancelled=None):
    from ..config import load_spec
    if load_spec(project_path).to_dict().get('extensions',{}).get('trait_batch'):
        from ..training.trait_batch import run_batch
        return run_batch(project_path,output,operation='preview',cache_root=cache_root,progress=progress,cancelled=cancelled)
    from ..paths import configure_local_paths
    from ..training.core import check_cancel
    from .multitask import contract,read_targets
    project_path,output=Path(project_path).resolve(),Path(output).resolve()
    if output.exists():fail("E_EXISTS",str(output),"choose a new preview directory")
    original=snapshot(project_path);project=load_spec(project_path).to_dict()
    from .genotypes import source_paths
    protect_inputs(output,[project_path,*source_paths(project["data"],project_path).values()])
    cache_root=Path(cache_root or configure_local_paths()/"cache/genotypes").resolve()
    if output.is_relative_to(cache_root) or cache_root.is_relative_to(output):fail("E_IO",str(output),"preview/cache overlap")
    output.mkdir(parents=True);(output/"INCOMPLETE").write_text("Split preview in progress")
    def stage(name,done=0,total=0):
        check_cancel(cancelled)
        if progress:progress(dict(event="stage",stage=name,done=done,total=total))
    try:
        a=inspect_project(project_path,output/"import",cache_root=cache_root,scan=True,progress=stage)
        if not a["ok"]:fail("E_FORMAT",str(output/"import"),"fix audit errors before splitting")
        d=load_descriptor(output/"import");cache=load_cache(Path(d["cache"]["path"]))
        samples=table(output/"import/samples.csv")
        groups=genotype_groups(cache,[s["genotype_equivalence_group"] for s in samples],progress=stage)
        context=dict(dataset_id=d["dataset_id"],trait=project["data"]["phenotype_options"]["trait"],cache_key=cache.metadata["key"],
            phenotype_sha256=d["source_files"]["phenotype"]["sha256"],phenotype_options=project["data"]["phenotype_options"],
            sample_ids=[[s["FID"],s["IID"]] for s in samples],groups=groups,
            eligible=[s["match_status"]=="matched_finite_label" for s in samples])
        multi=contract(project)
        if multi:context["multitask"]=multi
        context=context_for_policy(context,project["run"]["split"])
        from .batch_split import bind_context
        context = bind_context(context, project, project_path)
        genotype_qc=write_genotype_qc(output/"identical_genotypes.csv",context["sample_ids"],groups)
        cv=project["run"].get("extensions",{}).get("cross_validation")
        if cv:
            plan=load_plan(resolve_project_path(project_path,cv["reuse_manifest"]),context,cv) if cv["reuse_manifest"] else make_plan(context,cv)
            path=output/"cv_plan.json";save_plan(plan,path)
            splits=((i,SplitManifest(fold_value(plan,i))) for i in range(1,fold_count(plan)+1))
        else:
            config=project["run"]["split"]
            split=SplitManifest.load(resolve_project_path(project_path,config["reuse_manifest"]),context,config) if config["reuse_manifest"] else SplitManifest.create(context,config)
            path=output/"split.json";split.save(path);splits=[(0,split)]
        values=read_targets(project,resolve_project_path(project_path,project["data"]["phenotype"]),context["sample_ids"]) if multi else np.asarray([float(s["value"]) if s["match_status"]=="matched_finite_label" else np.nan for s in samples])[:,None]
        names=[t["id"] for t in multi["targets"]] if multi else [context["trait"]]
        rows=[];units=unit_groups(context)
        for fold,split in splits:
            stage("preview_fold",fold,fold_count(plan) if cv else 1)
            for partition in PARTS:
                indices=split.rows(partition);observed=np.isfinite(values[indices]).sum(0)
                rows.append(dict(fold=fold,partition=partition,individuals=len(indices),groups=len({groups[i] for i in indices}),
                                 splitting_units=len({units[i] for i in indices}),observed=dict(zip(names,map(int,observed)))))
                if partition in ("train","validation") and (partition == "train" or len(indices)) and np.any(observed==0):
                    fail("E_SPLIT",f"fold {fold}/{partition}","a selected target has no observations")
        verify_snapshots({"project":original,**d["source_files"]});stage("preview_complete")
        report=dict(kind="split_preview",ok=True,method=cv.get("method","five_fold") if cv else "fixed",plan=str(path),
            models=fold_count(plan) if cv else 1,
            rows=rows,eligible=sum(context["eligible"]),excluded=len(samples)-sum(context["eligible"]),
            split_unit=context.get("split_unit","genotype_equivalence"),
            genotype_qc=genotype_qc,
            fit_performed=False,project=project)
        write_json(output/"summary.json",report);(output/"INCOMPLETE").unlink();return report
    except BaseException as error:
        write_json(output/"failure.json",dict(ok=False,error=str(error)));raise
