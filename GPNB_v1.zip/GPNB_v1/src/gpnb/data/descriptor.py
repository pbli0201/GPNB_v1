from __future__ import annotations

from pathlib import Path

from ..config import fail
from .cache import load_cache
from .files import read_json, sha256, verify_snapshots


def load_descriptor(directory: Path, *, verify_sources=True):
    """Verify a completed audit before later stages consume its tables.

    This validates storage/integrity, not scientific eligibility for training.
    Metadata-only audits may have no dosage cache.
    """
    directory = Path(directory).resolve()
    if (directory / "INCOMPLETE").exists() or not (directory / "descriptor.json").is_file():
        fail("E_FORMAT", str(directory), "incomplete audit; descriptor cannot be consumed")
    descriptor = read_json(directory / "descriptor.json")
    if type(descriptor) is not dict:
        fail("E_FORMAT", str(directory), "descriptor must be an object")
    required = {"schema_version", "kind", "ok", "source_files", "artifacts", "cache",
                "sample_order_sha256", "marker_order_sha256"}
    if not required.issubset(descriptor) or type(descriptor["source_files"]) is not dict:
        fail("E_FORMAT", str(directory), "descriptor is missing required fields")
    if type(descriptor["schema_version"]) is not int or descriptor["schema_version"] != 1 or descriptor["kind"] != "imported_dataset":
        fail("E_VERSION", str(directory), "unsupported dataset descriptor")
    if descriptor.get("ok") is not True:
        fail("E_FORMAT", str(directory), "audit contains blocking errors; inspect audit.json")
    artifacts = descriptor.get("artifacts", {})
    if not isinstance(artifacts, dict) or not {"samples.csv", "markers.csv", "audit.json", "project_snapshot.json"}.issubset(artifacts):
        fail("E_FORMAT", str(directory), "missing artifact inventory")
    for name, digest in artifacts.items():
        path = directory / name
        if Path(name).name != name or not path.is_file() or sha256(path) != digest:
            fail("E_FORMAT", str(path), "invalid artifact name or checksum")
    if verify_sources:
        verify_snapshots(descriptor["source_files"])
    if descriptor["cache"] is not None:
        cache = load_cache(Path(descriptor["cache"]["path"]))
        identity = cache.metadata["identity"]
        if (cache.metadata["key"] != descriptor["cache"]["key"] or
                identity["sample_order_sha256"] != descriptor["sample_order_sha256"] or
                identity["marker_order_sha256"] != descriptor["marker_order_sha256"] or
                set(identity["source_sha256"]) != ({k for k in ("matrix", "bim") if k in descriptor["source_files"]} if "matrix" in descriptor["source_files"] else {"bed", "bim", "fam"}) or
                any(identity["source_sha256"][k] != descriptor["source_files"][k]["sha256"] for k in identity["source_sha256"])):
            fail("E_CACHE", str(cache.directory), "cache/descriptor identity mismatch")
    return descriptor
