"""Explicit wide-table target/environment contracts; no phenotype inputs."""
from ..config import choice,fail,number,object_fields,sequence,text


def contract(project):
    return project.get("extensions",{}).get("multitask")


def validate_contract(value):
    object_fields(value,"multitask",("protocol","auxiliary_visibility","targets"))
    choice(value["protocol"],"multitask.protocol",("new_individual_known_environments",))
    choice(value["auxiliary_visibility"],"multitask.auxiliary_visibility",("training_labels_only",))
    sequence(value["targets"],"multitask.targets")
    if not 2<=len(value["targets"])<=64:
        fail("E_MULTITASK","targets","select 2..64 target heads")
    import re
    for target in value["targets"]:
        object_fields(target,"target",("id","column","trait","environment","unit","correction","weight"))
        if not isinstance(target["id"],str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,47}",target["id"]):
            fail("E_MULTITASK","target.id","ASCII identifier required")
        for key in ("column","trait","environment","unit","correction"):
            text(target[key],"target."+key)
        number(target["weight"],"target.weight",1e-8,1e6)
    for key in ("id","column"):
        values=[t[key] for t in value["targets"]]
        if len(values)!=len(set(values)):
            fail("E_MULTITASK",key,"target identifiers and source columns must be unique")
    if len({(t["trait"],t["environment"]) for t in value["targets"]})!=len(value["targets"]):
        fail("E_MULTITASK","targets","each trait/environment pair must identify one head")


def validate_project_contract(project):
    value=contract(project)
    model=project["model"]
    if value is None:
        if model.get("task")=="multi_target_regression":
            fail("E_MULTITASK","project","multi-target model requires explicit observation contract")
        return
    validate_contract(value)
    columns=[t["column"] for t in value["targets"]]
    options=project["data"]["phenotype_options"]
    if options["trait"]!=columns[0] or set(columns)&set(options["id_columns"]):
        fail("E_MULTITASK","phenotype","primary display column must be first target; targets cannot be ID columns")
    if model.get("task")!="multi_target_regression" or model.get("output_targets")!=[t["id"] for t in value["targets"]]:
        fail("E_MULTITASK","model","model output order must exactly match target contract")
    if model.get("reconstruction_output") or "stages" in project["run"]["training"]:
        fail("E_MULTITASK","stages","multi-target staged/reconstruction objectives are not yet a validated combination")
    for table in project.get("extensions",{}).get("input_tables",[]):
        if set(table["columns"])&set(columns):
            fail("E_MULTITASK","input_tables","target columns may not be prediction input features")


def aligned_targets(phenotype,mapping,value,path):
    import numpy as np
    validate_contract(value)
    result=np.full((len(mapping),len(value["targets"])),np.nan,dtype=np.float64)
    if result.size>20_000_000:
        fail("E_MULTITASK","targets","target matrix exceeds 20 million cells")
    for j,target in enumerate(value["targets"]):
        column=target["column"]
        if column not in phenotype.values:
            fail("E_MULTITASK",str(path),f"missing target column {column}")
        if phenotype.traits[column]["invalid"]:
            item=phenotype.traits[column]["invalid_examples"][0]
            fail("E_TRAIT",f"{path}:{item['line']}:{column}",f"invalid target {item['value']!r}")
        for i,row in enumerate(mapping):
            if row is not None and phenotype.values[column][row] is not None:
                result[i,j]=phenotype.values[column][row]
    return result


def read_targets(project,path,sample_ids):
    from .tables import read_phenotypes,match_samples
    options=project["data"]["phenotype_options"]
    phenotype=read_phenotypes(path,options)
    mapping,_=match_samples(sample_ids,phenotype,options,path)
    return aligned_targets(phenotype,mapping,contract(project),path)


def fit_target_state(values,train_rows,validation_rows,project,sample_ids,source_sha256):
    import numpy as np
    from .files import order_hash
    means,scales,counts,constants=[],[],[],[]
    for j,target in enumerate(contract(project)["targets"]):
        observed=values[train_rows,j]
        observed=observed[np.isfinite(observed)]
        if not len(observed) or (len(validation_rows) > 0 and not np.isfinite(values[validation_rows,j]).any()):
            fail("E_MULTITASK",target["id"],"each head requires training and validation observations; change the declared split explicitly")
        standardized=project["run"]["preprocessing"]["standardize_target"]
        mean=float(observed.mean()) if standardized else 0.
        scale=float(observed.std(ddof=0)) if standardized else 1.
        if not np.isfinite([mean,scale]).all():
            fail("E_MULTITASK",target["id"],"training target moments overflow")
        means.append(mean);scales.append(scale if scale>0 else 1.)
        counts.append(len(observed));constants.append(bool(np.ptp(observed)==0))
    state=dict(schema_version=1,kind="multi_target_state",contract=contract(project),
        train_rows=[int(i) for i in train_rows],sample_order_sha256=order_hash(sample_ids),
        phenotype_sha256=source_sha256,mean=means,scale=scales,observed=counts,constant=constants,
        standardized=project["run"]["preprocessing"]["standardize_target"],
        label_inputs_at_prediction=False)
    validate_state(state)
    return state


def validate_state(state):
    import numpy as np
    object_fields(state,"multi_target_state",("schema_version","kind","contract","train_rows","sample_order_sha256",
        "phenotype_sha256","mean","scale","observed","constant","standardized","label_inputs_at_prediction"))
    validate_contract(state["contract"])
    if state["schema_version"]!=1 or state["kind"]!="multi_target_state" or state["label_inputs_at_prediction"] is not False:
        fail("E_MULTITASK","state","invalid target state contract/version")
    from ..config import boolean
    boolean(state["standardized"],"standardized")
    rows=state["train_rows"];sequence(rows,"train_rows")
    for i in rows:
        number(i,"train_row",0,integer=True)
    if len(set(rows))!=len(rows):
        fail("E_MULTITASK","state","duplicate training row")
    k=len(state["contract"]["targets"])
    for key in ("mean","scale","observed","constant"):
        if type(state[key]) is not list or len(state[key])!=k:
            fail("E_MULTITASK",key,"state dimensions differ from target inventory")
    for mean,scale,count,constant in zip(state["mean"],state["scale"],state["observed"],state["constant"]):
        number(mean,"mean");number(scale,"scale",positive=True)
        number(count,"observed",1,len(rows),integer=True);boolean(constant,"constant")
        if not state["standardized"] and (mean!=0 or scale!=1):
            fail("E_MULTITASK","state","unscaled targets require identity transform")
        if constant and scale!=1:
            fail("E_MULTITASK","state","constant target must use scale one")
    import re
    for key in ("sample_order_sha256","phenotype_sha256"):
        if not isinstance(state[key],str) or not re.fullmatch("[0-9a-f]{64}",state[key]):
            fail("E_MULTITASK",key,"invalid digest")
    return state


def transform_targets(values,state,inverse=False):
    import numpy as np
    values=np.asarray(values,dtype=np.float64)
    if values.ndim!=2 or values.shape[1]!=len(state["mean"]) or np.isinf(values).any():
        fail("E_MULTITASK","targets","expected aligned 2D values; NaN is reserved for missing labels")
    result=values*np.array(state["scale"])+np.array(state["mean"]) if inverse else (
        values-np.array(state["mean"]))/np.array(state["scale"])
    if np.isinf(result).any():
        fail("E_MULTITASK","targets","target scale overflow")
    return result


def masked_loss(prediction,target,weights,config=None):
    import torch
    if prediction.shape!=target.shape or prediction.ndim!=2 or not torch.isfinite(prediction).all() or torch.isinf(target).any():
        fail("E_MULTITASK","loss","aligned finite [batch,targets] prediction required")
    mask=torch.isfinite(target)
    counts=mask.sum(0)
    from ..training.objectives import elementwise_loss
    sums=elementwise_loss(prediction,torch.nan_to_num(target),config).masked_fill(~mask,0).sum(0)
    active=counts>0
    w=torch.as_tensor(weights,dtype=prediction.dtype,device=prediction.device)
    if not active.any():
        fail("E_MULTITASK","loss","no observed target in batch")
    loss=((sums/counts.clamp_min(1))*w*active).sum()/(w*active).sum()
    if not torch.isfinite(loss):
        fail("E_MULTITASK","loss","nonfinite masked objective")
    return loss,sums,counts


def aggregate_loss(sums,counts,weights):
    import numpy as np
    sums,counts,w=map(np.asarray,(sums,counts,weights))
    if np.any(counts<=0):
        fail("E_MULTITASK","validation","each head needs a validation observation")
    value=float(np.sum(sums/counts*w)/np.sum(w))
    if not np.isfinite(value):
        fail("E_MULTITASK","loss","objective overflow")
    return value
