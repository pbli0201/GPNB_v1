"""Descriptive audit statistics; never used to fit a training transform."""
import numpy as np


def trait_statistics(phenotype, mapping):
    output = {}
    matched = [r for r in mapping if r is not None]
    for name, values in phenotype.values.items():
        a = np.asarray([values[r] for r in matched if values[r] is not None], dtype=np.float64)
        output[name] = dict(scope="ID-matched individuals with finite observations",
            matched=len(matched), observed=len(a), unavailable=len(matched)-len(a),
            mean=float(a.mean()) if len(a) else None,
            sd=float(a.std(ddof=1)) if len(a)>1 else None,
            minimum=float(a.min()) if len(a) else None, maximum=float(a.max()) if len(a) else None,
            q25=float(np.quantile(a,.25,method="linear")) if len(a) else None,
            median=float(np.median(a)) if len(a) else None,
            q75=float(np.quantile(a,.75,method="linear")) if len(a) else None,
            sd_ddof=1, quantile_method="linear")
    return output
