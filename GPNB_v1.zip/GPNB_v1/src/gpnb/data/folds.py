"""Grouped outer folds with a distinct validation subset in each outer training set."""
from __future__ import annotations

import numpy as np

from ..config import fail, validate_cv_options
from .cache import identity_key
from .files import read_json, write_json
from .split import _validate_context, unit_groups

CV_ALGORITHM = "pcg64_grouped_outer5_inner_holdout_v1"
LOO_ALGORITHM = "pcg64_leave_unit_out_inner_holdout_v1"
FULL_LOO_ALGORITHM = "pcg64_leave_unit_out_full_training_v2"
GROUP_K_ALGORITHM = "pcg64_grouped_outerk_inner_holdout_v2"
INDIVIDUAL_CV_ALGORITHM = "pcg64_individual_outerk_inner_holdout_v2"
INDIVIDUAL_LOO_ALGORITHM = "pcg64_individual_leave_out_inner_holdout_v2"
INDIVIDUAL_FULL_LOO_ALGORITHM = "pcg64_individual_leave_out_full_training_v3"
FULL_LOO_ALGORITHMS = (FULL_LOO_ALGORITHM, INDIVIDUAL_FULL_LOO_ALGORITHM)
LOO_ALGORITHMS = (LOO_ALGORITHM, FULL_LOO_ALGORITHM, INDIVIDUAL_LOO_ALGORITHM, INDIVIDUAL_FULL_LOO_ALGORITHM)
ALL_CV_ALGORITHMS = (CV_ALGORITHM, GROUP_K_ALGORITHM, INDIVIDUAL_CV_ALGORITHM, *LOO_ALGORITHMS)


def fold_count(plan):
    return len(plan["outer_units"]) if plan["algorithm"] in LOO_ALGORITHMS else plan["config"]["folds"]


def _leave_partition(plan, fold):
    context, config = plan["context"], plan["config"]
    if 'batch_union_eligible' in context:
        from .batch_split import union_context,project_partitions
        base=make_plan(union_context(context),{**config,'reuse_manifest':None})
        base_fold=base['outer_units'].index(plan['outer_units'][fold-1])+1
        return project_partitions(_leave_partition(base,base_fold),context,
                                  allow_empty_validation=plan['algorithm'] in FULL_LOO_ALGORITHMS)
    members = {}
    for i, (group, eligible) in enumerate(zip(unit_groups(context), context["eligible"])):
        if eligible:
            members.setdefault(group, []).append(i)
    held = plan["outer_units"][fold - 1]
    available = [g for g in sorted(members) if g != held]
    if plan["algorithm"] in FULL_LOO_ALGORITHMS:
        return dict(train=sorted(i for g in available for i in members[g]), validation=[], test=members[held])
    rng = np.random.Generator(np.random.PCG64(np.random.SeedSequence([config["seed"], fold - 1, 1])))
    available = [available[i] for i in rng.permutation(len(available))]
    available.sort(key=lambda g: -len(members[g]))
    targets = np.array([1 - config["validation_fraction"], config["validation_fraction"]]) * sum(len(members[g]) for g in available)
    counts, inner = np.zeros(2, dtype=int), [[], []]
    for position, group in enumerate(available):
        empty = np.flatnonzero(counts == 0)
        candidates = empty if len(available) - position == len(empty) else np.arange(2)
        slot = int(candidates[np.argmax((targets - counts)[candidates])])
        inner[slot].extend(members[group]); counts[slot] += len(members[group])
    return dict(train=sorted(inner[0]), validation=sorted(inner[1]), test=members[held])


def make_plan(context, config):
    _validate_context(context)
    validate_cv_options(config)
    if 'batch_union_eligible' in context:
        from .batch_split import union_context,project_partitions
        import copy
        plan=copy.deepcopy(make_plan(union_context(context),config))
        plan.update(context=context,context_sha256=identity_key(context))
        if 'partitions' in plan:
            plan['partitions']=[project_partitions(p,context) for p in plan['partitions']]
        else:
            valid={g for g,e in zip(unit_groups(context),context['eligible']) if e}
            plan['outer_units']=[g for g in plan['outer_units'] if g in valid]
            for fold in range(1,len(plan['outer_units'])+1):_leave_partition(plan,fold)
        return plan
    method = config.get("method", "five_fold")
    individual = context.get("split_unit") == "individual_id"
    if individual and method == "leave_one_genotype_group_out":
        fail("E_SPLIT", "cross_validation", "legacy genotype-group leave-out requires its original genotype-equivalence policy")
    full = config.get("training_policy") == "full_training"
    config = {k: config[k] for k in ("folds", "seed", "validation_fraction")}
    if full:
        config["training_policy"] = "full_training"
    members = {}
    for i, (g, eligible) in enumerate(zip(unit_groups(context), context["eligible"])):
        if eligible:
            members.setdefault(g, []).append(i)
    if method not in ("five_fold", "ten_fold"):
        minimum = 2 if individual and full else 3
        if len(members) < minimum:
            label = "two" if minimum == 2 else "three"
            fail("E_SPLIT", "cross_validation", f"leave-out evaluation needs at least {label} labelled splitting units")
        if method == "leave_one_individual_out" and any(len(rows) != 1 for rows in members.values()):
            fail("E_SPLIT", "cross_validation", "identical genotypes would cross partitions in individual LOO; select leave_one_genotype_group_out (留一基因型组)")
        config["method"] = method
        # Compact O(N) plan; inner partitions are deterministic and generated on demand.
        algorithm = ((INDIVIDUAL_FULL_LOO_ALGORITHM if full else INDIVIDUAL_LOO_ALGORITHM) if individual
                     else (FULL_LOO_ALGORITHM if full else LOO_ALGORITHM))
        return dict(schema_version=1, kind="cross_validation_plan", algorithm=algorithm,
                    context=context, context_sha256=identity_key(context), config=config, outer_units=sorted(members))
    k, seed = config["folds"], config["seed"]
    if method == "ten_fold":
        config["method"] = method
    if len(members) < k:
        label = "five" if k == 5 else "ten"
        fail("E_SPLIT", "cross_validation", f"{label}-fold evaluation needs at least {k} labelled splitting units")
    rng = np.random.Generator(np.random.PCG64(seed))
    names = sorted(members)
    names = [names[i] for i in rng.permutation(len(names))]
    names.sort(key=lambda g: -len(members[g]))
    outer, counts = [[] for _ in range(k)], [0] * k
    for g in names:
        slot = int(np.argmin(counts))
        outer[slot].append(g)
        counts[slot] += len(members[g])
    partitions = []
    for f in range(k):
        available = [g for g in names if g not in set(outer[f])]
        if len(available) < 2:
            fail("E_SPLIT", "cross_validation", "outer training pool needs at least two units for training and validation")
        inner_rng = np.random.Generator(np.random.PCG64(np.random.SeedSequence([seed, f, 1])))
        available = [available[i] for i in inner_rng.permutation(len(available))]
        available.sort(key=lambda g: -len(members[g]))
        n = sum(len(members[g]) for g in available)
        targets = np.array([1 - config["validation_fraction"], config["validation_fraction"]]) * n
        occupied, inner = np.zeros(2, dtype=int), [[], []]
        for position, g in enumerate(available):
            empty = np.flatnonzero(occupied == 0)
            candidates = empty if len(available) - position == len(empty) else np.arange(2)
            slot = int(candidates[np.argmax((targets - occupied)[candidates])])
            inner[slot].extend(members[g])
            occupied[slot] += len(members[g])
        partitions.append(dict(train=sorted(inner[0]), validation=sorted(inner[1]),
                               test=sorted(i for g in outer[f] for i in members[g])))
    algorithm = INDIVIDUAL_CV_ALGORITHM if individual else CV_ALGORITHM if k == 5 else GROUP_K_ALGORITHM
    return dict(schema_version=1, kind="cross_validation_plan", algorithm=algorithm,
                context=context, context_sha256=identity_key(context), config=config, partitions=partitions)


def fold_value(plan, fold):
    config, context = plan["config"], plan["context"]
    if type(fold) is not int or not 1 <= fold <= fold_count(plan):
        fail("E_SPLIT", "fold", "invalid fold index")
    leave = plan["algorithm"] in LOO_ALGORITHMS
    partitions = _leave_partition(plan, fold) if leave else plan["partitions"][fold - 1]
    test = len(partitions["test"]) / sum(context["eligible"]) if leave else 1 / config["folds"]
    val = 0. if plan["algorithm"] in FULL_LOO_ALGORITHMS else (1 - test) * config["validation_fraction"]
    return dict(schema_version=1, kind="split_manifest", algorithm=plan["algorithm"],
                context=context, context_sha256=plan["context_sha256"],
                seed=config["seed"], requested_ratios=[1 - test - val, val, test],
                partitions=partitions,
                excluded=[i for i, eligible in enumerate(context["eligible"]) if not eligible],
                cross_validation={"fold": fold, "config": config, "plan_sha256": identity_key(plan)})


def save_plan(plan, path):
    if path.exists():
        fail("E_EXISTS", str(path), "choose a new cross-validation plan file")
    write_json(path, dict(manifest=plan, sha256=identity_key(plan)))


def load_plan(path, context, config):
    envelope = read_json(path)
    expected = make_plan(context, config)
    if envelope.get("sha256") != identity_key(envelope.get("manifest")) or envelope["manifest"] != expected:
        fail("E_SPLIT", str(path), "cross-validation plan differs from data, eligibility, seed or protocol")
    return envelope["manifest"]
