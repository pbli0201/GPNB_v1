"""Reference-fitted relationship/kernel features without an extra ML dependency.

All inputs are canonical 0/1/2 hard calls, with -1 (or NaN) denoting missing.
Only reference rows participate in fitting. Query columns always refer to the
saved reference IDs, never to other queries. Computation uses float64 blocks;
model-facing matrices use checked float32 storage.
"""
from __future__ import annotations

import copy
import math
import shutil
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from ..errors import GPNBError
from .files import order_hash, read_json, sha256, write_json
from .imputation import ImputerState, validate_options as validate_imputation

KINDS = ("vanraden", "linear", "cosine", "rbf", "exponential", "laplacian", "polynomial")
SOURCES = {
    "vanraden": "https://search.r-project.org/CRAN/refmans/rrBLUP/html/A.mat.html",
    "kernels": "https://scikit-learn.org/stable/modules/metrics.html#pairwise-metrics-affinities-and-kernels",
}


def _fail(path, detail, code="E_PREPROCESS"):
    raise GPNBError(code, "kernel." + str(path), detail)


def _step(progress, cancelled, stage, done, total):
    if cancelled and cancelled():
        _fail(stage, "Kernel calculation cancelled; partial output is not complete.", "E_CANCELLED")
    if progress:
        progress(stage, int(done), int(total))


def default_recipe(kind="vanraden"):
    return dict(kind=kind, imputation="mean", center=False, standardize=False,
                normalize_features=False, gamma=1.0, coef0=1.0, degree=2,
                block_rows=128, block_markers=1024,
                max_reference_bytes=512 * 1024**2, max_matrix_bytes=2 * 1024**3)


def validate_recipe(value):
    if type(value) is not dict:
        _fail("recipe", "Expected a kernel recipe object.", "E_TYPE")
    result = default_recipe()
    unknown = set(value) - set(result) - {"imputation_options"}
    if unknown:
        _fail("recipe", "Unknown fields: " + ", ".join(sorted(unknown)), "E_FIELD")
    result.update(value)
    if result["kind"] not in KINDS:
        _fail("kind", "Choose one of: " + ", ".join(KINDS), "E_VALUE")
    validate_imputation(result["imputation"], result.get("imputation_options"))
    for key in ("center", "standardize", "normalize_features"):
        if type(result[key]) is not bool:
            _fail(key, "Expected a boolean.", "E_TYPE")
    for key in ("gamma", "coef0"):
        val = result[key]
        if type(val) not in (int, float) or not math.isfinite(val) or val < 0 or (key == "gamma" and val == 0):
            _fail(key, "gamma must be finite and > 0; coef0 must be finite and >= 0.", "E_RANGE")
        result[key] = float(val)
    for key in ("degree", "block_rows", "block_markers", "max_reference_bytes", "max_matrix_bytes"):
        if type(result[key]) is not int or result[key] < 1:
            _fail(key, "Expected a positive integer.", "E_RANGE")
    # These are operational limits, not evidence that every budget fits RAM.
    if result["block_rows"] > 4096 or result["block_markers"] > 65536:
        _fail("blocks", "block_rows <= 4096 and block_markers <= 65536 are required.", "E_RANGE")
    if result["degree"] > 1024:
        _fail("degree", "Polynomial degree must be <= 1024; large powers are numerically unsafe for float32 model inputs.", "E_RANGE")
    if result["kind"] == "vanraden" and any(result[k] for k in ("center", "standardize", "normalize_features")):
        _fail("recipe", "VanRaden already uses frequency centering and its genetic denominator; extra scaling is not allowed.", "E_VALUE")
    if result["normalize_features"] and result["kind"] != "linear":
        _fail("normalize_features", "Feature-count normalization is available for the linear kernel only.", "E_VALUE")
    return result


def resource_estimate(reference_count, marker_count, recipe, queries=None):
    recipe = validate_recipe(recipe)
    for name, value in (("reference_count", reference_count), ("marker_count", marker_count)):
        if type(value) is not int or value < 1:
            _fail(name, "Expected a positive integer.", "E_RANGE")
    queries = reference_count if queries is None else queries
    if type(queries) is not int or queries < 0:
        _fail("queries", "Expected a nonnegative integer.", "E_RANGE")
    b = min(recipe["block_rows"], max(queries, reference_count))
    f = min(recipe["block_markers"], marker_count)
    return {
        "shape": [queries, reference_count], "dtype": "float32",
        "matrix_bytes": queries * reference_count * 4,
        "reference_bytes": reference_count * marker_count,
        "state_numeric_bytes": reference_count * marker_count * (2 if recipe["imputation"] == "knn" else 1) + marker_count * 64,
        "working_block_bytes_lower_bound": 2 * b * f * 8 + 3 * b * b * 8,
        "scope": "Array storage estimates only; excludes IDs, file headers, runtime, model and allocator overhead. Not a total RAM guarantee.",
    }


def _check_reference_budget(n, m, recipe):
    _check_knn_budget(n, m, recipe, min(n, recipe["block_rows"]))
    estimate = resource_estimate(n, m, recipe)
    if estimate["state_numeric_bytes"] > recipe["max_reference_bytes"]:
        _fail("reference", f"Reference state needs at least {estimate['state_numeric_bytes']} bytes, exceeding max_reference_bytes={recipe['max_reference_bytes']}; reduce reference size/markers or explicitly raise the budget.", "E_MODEL_LIMIT")
    return estimate


def _check_knn_budget(n, m, recipe, query_rows):
    if recipe["imputation"] == "knn":
        ImputerState.check_budget(n, m, validate_imputation("knn", recipe.get("imputation_options")), query_rows=query_rows)


def _canonical(raw, features=None, *, allow_empty=False):
    x = np.asarray(raw)
    if x.ndim != 2 or x.dtype.kind not in "iuf" or (not allow_empty and not x.shape[0]) or not x.shape[1]:
        _fail("genotypes", "Expected a nonempty 2D numeric hard-call matrix.")
    if features is not None and x.shape[1] != features:
        _fail("genotypes", f"Expected {features} markers in saved order; received {x.shape[1]}.")
    valid = np.isin(x, [-1, 0, 1, 2])
    missing_nan = np.isnan(x) if x.dtype.kind == "f" else np.zeros(x.shape, dtype=bool)
    if not (valid | missing_nan).all():
        row, col = np.argwhere(~(valid | missing_nan))[0]
        _fail(f"genotypes[{row},{col}]", "Expected 0/1/2 or -1/NaN missing; continuous dosages are not rounded.")
    return np.where(missing_nan, -1, x).astype(np.int8, copy=False)


def _identities(ids, n, name):
    if ids is None:
        return [[str(i)] for i in range(n)]
    if type(ids) is not list or len(ids) != n:
        _fail(name, "Identity count does not match matrix dimensions.")
    result = []
    for value in ids:
        value = [value] if isinstance(value, str) else value
        if type(value) is not list or not value or any(type(v) is not str for v in value):
            _fail(name, "Identities must be strings or arrays of strings; IDs retain leading zeros.")
        result.append(list(value))
    if len({tuple(v) for v in result}) != n:
        _fail(name, "Duplicate identities are not allowed.", "E_DUPLICATE")
    return result


@dataclass
class KernelState:
    metadata: dict
    arrays: dict

    @property
    def reference_count(self):
        return self.arrays["reference"].shape[0]

    @property
    def input_features(self):
        """Number of raw marker columns required by transform()."""
        return self.marker_count

    @property
    def marker_count(self):
        return self.arrays["reference"].shape[1]

    @property
    def recipe(self):
        return self.metadata["recipe"]

    @classmethod
    def fit(cls, reference_raw, recipe, *, reference_ids=None, markers=None,
            provenance=None, train_rows=None, progress=None, cancelled=None):
        recipe = validate_recipe(recipe)
        raw = np.asarray(reference_raw)
        if raw.ndim != 2 or not all(raw.shape):
            _fail("reference", "A nonempty 2D reference matrix is required.")
        _check_reference_budget(*raw.shape, recipe)
        # Validate/convert in small blocks, not via an N x P float64 expansion.
        reference = np.empty(raw.shape, dtype=np.int8)
        b, f = recipe["block_rows"], recipe["block_markers"]
        for i in range(0, len(raw), b):
            _step(progress, cancelled, "kernel_reference", i, len(raw))
            for j in range(0, raw.shape[1], f):
                reference[i:i+b, j:j+f] = _canonical(raw[i:i+b, j:j+f])
        return cls._fit(reference, recipe, reference_ids, markers, provenance, train_rows, progress, cancelled)

    @classmethod
    def fit_cache(cls, cache, train_rows, columns, recipe, *, reference_ids=None,
                  markers=None, provenance=None, progress=None, cancelled=None):
        recipe = validate_recipe(recipe)
        rows, cols = np.asarray(train_rows), np.asarray(columns)
        n, m = cache.metadata["shape"]
        for name, values, size in (("train_rows", rows, n), ("columns", cols, m)):
            if values.ndim != 1 or values.dtype.kind not in "iu" or not len(values) or len(np.unique(values)) != len(values) or np.any(values < 0) or np.any(values >= size):
                _fail(name, "Expected nonempty unique in-range integer indices.")
        _check_reference_budget(len(rows), len(cols), recipe)
        reference = np.empty((len(rows), len(cols)), dtype=np.int8)
        b, f = recipe["block_rows"], recipe["block_markers"]
        for i in range(0, len(rows), b):
            for j in range(0, len(cols), f):
                _step(progress, cancelled, "kernel_reference", i, len(rows))
                reference[i:i+b, j:j+f] = _canonical(cache.batch(rows[i:i+b], cols[j:j+f]))
        return cls._fit(reference, recipe, reference_ids, markers, provenance, rows.tolist(), progress, cancelled)

    @classmethod
    def _fit(cls, reference, recipe, ids, markers, provenance, rows, progress, cancelled):
        n, m = reference.shape
        ids = _identities(ids, n, "reference_ids")
        if markers is None:
            markers = [[str(i)] for i in range(m)]
        if type(markers) is not list or len(markers) != m:
            _fail("markers", "Supply selected marker identities in the reference column order.")
        if rows is not None and (len(rows) != n or any(type(i) is not int or i < 0 for i in rows) or len(set(rows)) != n):
            _fail("train_rows", "Training row indices must be unique, nonnegative and match reference rows.")
        mean, scale, observed = np.zeros(m), np.ones(m), np.zeros(m, dtype=np.int64)
        genotype_counts = np.zeros((3, m), dtype=np.int64)
        for j in range(0, m, recipe["block_markers"]):
            _step(progress, cancelled, "kernel_fit", j, m)
            stop = min(j + recipe["block_markers"], m)
            counts, sums, squares = np.zeros(stop-j, dtype=np.int64), np.zeros(stop-j), np.zeros(stop-j)
            for i in range(0, n, recipe["block_rows"]):
                _step(None, cancelled, "kernel_fit", j, m)
                block = reference[i:i+recipe["block_rows"], j:stop]
                for dose in range(3):
                    genotype_counts[dose, j:stop] += (block == dose).sum(0)
                valid = block != -1
                if recipe["imputation"] == "none" and not valid.all():
                    _fail("imputation", f"Missing reference calls at row {i + int(np.argwhere(~valid)[0,0])}, marker {j + int(np.argwhere(~valid)[0,1])}; enable training-reference mean imputation or provide complete calls.")
                values = np.where(valid, block, 0).astype(np.float64)
                counts += valid.sum(0)
                sums += values.sum(0)
                squares += (values * values).sum(0)
            if np.any(counts == 0):
                bad = j + int(np.flatnonzero(counts == 0)[0])
                _fail("markers", f"Reference marker {bad} {markers[bad]!r} is entirely missing. Its mean/frequency cannot be fitted; remove it with a training-only missingness filter.")
            mu = sums / counts
            mean[j:stop], observed[j:stop] = mu, counts
            # Population variance after reference-mean imputation; missing calls
            # contribute zero centered deviation, denominator is reference N.
            variance = np.maximum(0, (squares - sums * mu) / n)
            scale[j:stop] = np.where(variance > 0, np.sqrt(variance), 1.0)
        imputer = ImputerState.from_counts(genotype_counts, recipe["imputation"], recipe.get("imputation_options"), reference=reference)
        center = mean.copy()
        if recipe["imputation"] in ("mode", "median", "knn"):
            filled_sum, filled_square = np.zeros(m), np.zeros(m)
            for i in range(0, n, recipe["block_rows"]):
                _step(progress, cancelled, "kernel_imputation_fit", i, n)
                filled = imputer.transform(reference[i:i+recipe["block_rows"]], progress=progress, cancelled=cancelled)
                filled_sum += filled.sum(0)
                filled_square += (filled*filled).sum(0)
            center = filled_sum/n
            variance = np.maximum(0, filled_square/n-center**2)
            scale = np.where(variance > 0, np.sqrt(variance), 1.)
        frequency = mean / 2
        denominator = float(2 * np.sum(frequency * (1 - frequency)))
        if recipe["kind"] == "vanraden" and denominator <= 0:
            _fail("denominator", "VanRaden denominator is zero: all selected markers are monomorphic in the reference. Select polymorphic training markers; no epsilon substitute is used.")
        metadata = dict(schema_version=1, kind="kernel_reference_state", recipe=recipe,
                        reference_count=n, marker_count=m, reference_ids=ids,
                        reference_order_sha256=order_hash(ids), markers=copy.deepcopy(markers),
                        marker_order_sha256=order_hash(markers), train_rows=copy.deepcopy(rows),
                        provenance=copy.deepcopy(provenance), denominator=denominator,
                        reference_scope="explicit_reference_rows_only", variance_ddof=0,
                        missing_value=-1, encoding="canonical_012_counted_allele_from_provenance",
                        output_dtype="float32", sources=SOURCES, imputer=imputer.metadata,
                        meaning="additive_genetic_relationship_vanraden_method_1" if recipe["kind"] == "vanraden" else "generic_similarity_not_GBLUP")
        state = cls(metadata, dict(reference=reference, mean=mean, center=center, scale=scale, frequency=frequency, observed=observed, **imputer.pack()))
        if recipe["kind"] == "cosine":
            for i in range(0, n, recipe["block_rows"]):
                _step(None, cancelled, "kernel_fit", i, n)
                state._norms(reference[i:i+recipe["block_rows"]], "reference", i)
        _step(progress, cancelled, "kernel_fit", m, m)
        return state

    def _features(self, raw, start, stop):
        x = raw[:, start:stop].astype(np.float64)
        missing = x == -1
        if missing.any():
            if self.recipe["imputation"] == "none":
                _fail("query", "Query contains missing calls but saved imputation is none; query data never refits the state.")
            if "imputer" in self.metadata:
                x = self._impute(raw)[:, start:stop]
            else:
                x = np.where(missing, self.arrays["mean"][start:stop], x)
        if self.recipe["kind"] == "vanraden":
            x -= self.arrays["mean"][start:stop]
        elif self.recipe["center"]:
            x -= self.arrays.get("center", self.arrays["mean"])[start:stop]
        if self.recipe["standardize"]:
            x /= self.arrays["scale"][start:stop]
        return x

    def _impute(self, raw, progress=None, cancelled=None):
        if "imputer" not in self.metadata:
            return raw
        if self.recipe["imputation"] == "none" and np.any(raw == -1):
            _fail("query", "Query contains missing calls but saved imputation is none; query data never refits the state.")
        imputer = ImputerState(self.metadata["imputer"], {k[8:]: v for k,v in self.arrays.items() if k.startswith("imputer_")})
        return imputer.transform(raw, progress=progress, cancelled=cancelled)

    def _norms(self, raw, name, offset=0):
        if np.any(raw == -1) and "imputer" in self.metadata:
            raw = self._impute(raw)
        squared = np.zeros(len(raw))
        for j in range(0, self.marker_count, self.recipe["block_markers"]):
            x = self._features(raw, j, min(j+self.recipe["block_markers"], self.marker_count))
            squared += (x*x).sum(1)
        if np.any(squared == 0):
            row = offset + int(np.flatnonzero(squared == 0)[0])
            _fail("cosine", f"Zero norm in {name} row {row}; cosine similarity is undefined. Change the kernel or input centering settings.")
        return np.sqrt(squared)

    def _output(self, rows, out):
        estimate = resource_estimate(self.reference_count, self.marker_count, self.recipe, queries=rows)
        if estimate["matrix_bytes"] > self.recipe["max_matrix_bytes"]:
            _fail("matrix", f"Requested matrix needs {estimate['matrix_bytes']} bytes, exceeding max_matrix_bytes={self.recipe['max_matrix_bytes']}; use smaller query batches or explicitly raise the budget.", "E_MODEL_LIMIT")
        shape = (rows, self.reference_count)
        if out is None:
            return np.empty(shape, dtype=np.float32), False
        if isinstance(out, (str, Path)):
            path = Path(out)
            if path.exists():
                _fail(str(path), "Choose a new matrix output file.", "E_EXISTS")
            path.parent.mkdir(parents=True, exist_ok=True)
            if shutil.disk_usage(path.parent).free < estimate["matrix_bytes"] + 65536:
                _fail(str(path), "Insufficient free disk for matrix and file header.", "E_IO")
            return np.lib.format.open_memmap(path, mode="w+", dtype=np.float32, shape=shape), True
        if not isinstance(out, np.ndarray) or out.shape != shape or out.dtype != np.float32 or not out.flags.writeable:
            _fail("out", f"Output must be a writable float32 array of shape {shape}, or a new .npy path.")
        return out, False

    def transform(self, query_raw, *, out=None, progress=None, cancelled=None):
        query = np.asarray(query_raw)
        if query.ndim != 2 or query.shape[1] != self.marker_count or query.dtype.kind not in "iuf":
            _fail("query", f"Expected a 2D query with {self.marker_count} markers in saved order.")
        _check_knn_budget(self.reference_count, self.marker_count, self.recipe, min(len(query), self.recipe["block_rows"]))
        output, owns_map = self._output(len(query), out)
        try:
            b = self.recipe["block_rows"]
            for i in range(0, len(query), b):
                q = _canonical(query[i:i+b], self.marker_count)
                self._transform_rows(q, output[i:i+b], progress, cancelled, i, len(query))
            _step(progress, cancelled, "kernel_transform", len(query), len(query))
            if hasattr(output, "flush"):
                output.flush()
            return output
        except BaseException:
            if owns_map:
                output.flush()
                output._mmap.close()
            raise

    def transform_cache(self, cache, rows, columns, *, out=None, progress=None, cancelled=None):
        rows, cols = np.asarray(rows), np.asarray(columns)
        n, m = cache.metadata["shape"]
        for name, values, size in (("query_rows", rows, n), ("columns", cols, m)):
            if values.ndim != 1 or values.dtype.kind not in "iu" or np.any(values < 0) or np.any(values >= size):
                _fail(name, "Expected in-range integer indices.")
        if len(cols) != self.marker_count:
            _fail("columns", "Query marker count differs from saved state.")
        _check_knn_budget(self.reference_count, self.marker_count, self.recipe, min(len(rows), self.recipe["block_rows"]))
        output, owns_map = self._output(len(rows), out)
        try:
            b = self.recipe["block_rows"]
            for i in range(0, len(rows), b):
                q = _canonical(cache.batch(rows[i:i+b], cols), self.marker_count)
                self._transform_rows(q, output[i:i+b], progress, cancelled, i, len(rows))
            _step(progress, cancelled, "kernel_transform", len(rows), len(rows))
            if hasattr(output, "flush"):
                output.flush()
            return output
        except BaseException:
            if owns_map:
                output.flush()
                output._mmap.close()
            raise

    def _transform_rows(self, q, output, progress, cancelled, offset, total):
        b, f = self.recipe["block_rows"], self.recipe["block_markers"]
        kind = self.recipe["kind"]
        q = self._impute(q, progress, cancelled)
        qnorm = self._norms(q, "query", offset) if kind == "cosine" else None
        for r in range(0, self.reference_count, b):
            _step(progress, cancelled, "kernel_transform", offset, total)
            ref = self.arrays["reference"][r:r+b]
            ref = self._impute(ref, progress, cancelled)
            values = np.zeros((len(q), len(ref)), dtype=np.float64)
            qsq, rsq = np.zeros(len(q)), np.zeros(len(ref))
            for j in range(0, self.marker_count, f):
                _step(None, cancelled, "kernel_transform", offset, total)
                stop = min(j+f, self.marker_count)
                x, y = self._features(q, j, stop), self._features(ref, j, stop)
                if kind == "laplacian":
                    # Avoid an N_query x N_reference x N_marker temporary.
                    for row in range(len(q)):
                        values[row] += np.abs(y - x[row]).sum(1)
                else:
                    values += x @ y.T
                    if kind in ("rbf", "exponential"):
                        qsq += (x*x).sum(1)
                        rsq += (y*y).sum(1)
            with np.errstate(over="ignore", invalid="ignore", under="ignore"):
                if kind == "vanraden":
                    values /= self.metadata["denominator"]
                elif kind == "linear" and self.recipe["normalize_features"]:
                    values /= self.marker_count
                elif kind == "cosine":
                    values /= qnorm[:, None] * self._norms(ref, "reference", r)[None, :]
                elif kind in ("rbf", "exponential"):
                    distances = np.maximum(0, qsq[:, None] + rsq[None, :] - 2*values)
                    values = np.exp(-self.recipe["gamma"] * (np.sqrt(distances) if kind == "exponential" else distances))
                elif kind == "laplacian":
                    values = np.exp(-self.recipe["gamma"] * values)
                elif kind == "polynomial":
                    values = np.power(self.recipe["gamma"] * values + self.recipe["coef0"], self.recipe["degree"])
            if not np.isfinite(values).all() or np.any(np.abs(values) > np.finfo(np.float32).max):
                _fail("numerical", f"{kind} produced nonfinite or float32-overflow values; reduce polynomial degree/gamma or standardize the reference inputs.")
            output[:, r:r+len(ref)] = values.astype(np.float32)

    def save(self, directory):
        directory = Path(directory)
        if directory.exists():
            _fail(str(directory), "Choose a new kernel state directory.", "E_EXISTS")
        directory.mkdir(parents=True)
        (directory / "INCOMPLETE").write_text("Kernel reference state is incomplete.\n", encoding="utf-8")
        np.savez(directory / "arrays.npz", **self.arrays)
        write_json(directory / "state.json", self.metadata)
        write_json(directory / "complete.json", dict(schema_version=1, kind="kernel_reference_bundle",
                   files={name: sha256(directory / name) for name in ("arrays.npz", "state.json")}))
        (directory / "INCOMPLETE").unlink()

    @classmethod
    def load(cls, directory):
        directory = Path(directory)
        try:
            if (directory / "INCOMPLETE").exists():
                _fail(str(directory), "Kernel reference state is incomplete.")
            envelope = read_json(directory / "complete.json")
            if envelope["schema_version"] != 1 or envelope["kind"] != "kernel_reference_bundle" or set(envelope["files"]) != {"state.json", "arrays.npz"}:
                _fail(str(directory), "Unsupported kernel reference bundle.")
            for name, digest in envelope["files"].items():
                if sha256(directory / name) != digest:
                    _fail(name, "Kernel state checksum mismatch.")
            meta = read_json(directory / "state.json")
            if meta["schema_version"] != 1 or meta["kind"] != "kernel_reference_state":
                _fail(str(directory), "Unsupported kernel reference state.")
            recipe = validate_recipe(meta["recipe"])
            n, m = meta["reference_count"], meta["marker_count"]
            _check_reference_budget(n, m, recipe)
            with np.load(directory / "arrays.npz", allow_pickle=False) as stored:
                arrays = {k: stored[k].copy() for k in stored.files}
            expected_arrays = {"reference", "mean", "scale", "frequency", "observed"}
            if "imputer" in meta:
                imputer = ImputerState.unpack(meta["imputer"], arrays)
                expected_arrays |= {"center"} | set(imputer.pack())
                if imputer.metadata["method"] != recipe["imputation"] or imputer.metadata["features"] != m:
                    _fail("imputer", "Saved imputer differs from kernel recipe or dimensions.")
                if imputer.metadata["options"] != validate_imputation(recipe["imputation"], recipe.get("imputation_options")):
                    _fail("imputer", "Saved imputation parameters differ from kernel recipe.")
                if not np.array_equal(imputer.arrays["observed"], arrays["observed"]):
                    _fail("imputer", "Saved imputation observed counts differ from kernel.")
                if recipe["imputation"] == "knn" and not np.array_equal(imputer.arrays["reference"], arrays["reference"]):
                    _fail("imputer", "KNN reference differs from kernel training reference.")
                if arrays["center"].shape != (m,) or not np.isfinite(arrays["center"]).all():
                    _fail("center", "Invalid imputed center.")
            if set(arrays) != expected_arrays:
                _fail(str(directory), "Incomplete kernel arrays.")
            if arrays["reference"].shape != (n, m) or arrays["reference"].dtype != np.int8:
                _fail("reference", "Kernel reference dtype/shape mismatch.")
            for i in range(0, n, recipe["block_rows"]):
                _canonical(arrays["reference"][i:i+recipe["block_rows"]])
            for key in ("mean", "scale", "frequency", "observed"):
                if arrays[key].shape != (m,) or not np.isfinite(arrays[key]).all():
                    _fail(key, "Invalid fitted kernel vector.")
            if np.any(arrays["scale"] <= 0) or np.any(arrays["observed"] < 1) or np.any(arrays["observed"] > n) or np.any(arrays["mean"] < 0) or np.any(arrays["mean"] > 2):
                _fail("arrays", "Kernel fitted state is outside valid ranges.")
            if not np.array_equal(arrays["frequency"], arrays["mean"] / 2):
                _fail("frequency", "Frequency must equal reference mean dosage / 2.")
            if (len(meta["markers"]) != m or _identities(meta["reference_ids"], n, "reference_ids") != meta["reference_ids"]
                    or order_hash(meta["markers"]) != meta["marker_order_sha256"]
                    or order_hash(meta["reference_ids"]) != meta["reference_order_sha256"]):
                _fail("identity", "Kernel reference/marker order binding mismatch.")
            expected = float(2 * np.sum(arrays["frequency"] * (1-arrays["frequency"])))
            if meta["denominator"] != expected or (recipe["kind"] == "vanraden" and expected <= 0):
                _fail("denominator", "Invalid VanRaden denominator.")
            return cls(meta, arrays)
        except (OSError, KeyError, TypeError, ValueError) as error:
            if isinstance(error, GPNBError):
                raise
            _fail(str(directory), "Invalid or incomplete kernel state: " + str(error))


def fit_cache(cache, train_rows, columns, recipe, **kwargs):
    """Convenience alias for integrations that already hold an audited RawCache."""
    return KernelState.fit_cache(cache, train_rows, columns, recipe, **kwargs)
