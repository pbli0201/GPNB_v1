from __future__ import annotations

import hashlib
import json
import shutil
import uuid
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from ..config import fail
from .bed import ENCODING, MATRIX_ENCODING, READER, BedAdapter, MissingCounts
from .files import read_json, sha256, verify_snapshots, write_json


def cache_identity(files, sample_order, marker_order):
    return {"schema_version": 1, "reader": READER, "encoding": ENCODING,
            "source_sha256": {k: files[k]["sha256"] for k in ("bed", "bim", "fam")},
            "sample_order_sha256": sample_order, "marker_order_sha256": marker_order,
            "selection": "all_samples_all_markers"}


def identity_key(identity):
    return hashlib.sha256(json.dumps(identity, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()


@dataclass
class RawCache:
    directory: Path
    metadata: dict
    missing: MissingCounts

    def batch(self, rows, columns=None):
        """Read-only selected batch, preserving requested order; returns int8."""
        matrix = np.load(self.directory / "dosage.npy", mmap_mode="r", allow_pickle=False)
        try:
            def indices(value, size):
                result = np.asarray(value)
                if result.ndim != 1 or result.dtype.kind not in "iu" or np.any(result < 0) or np.any(result >= size):
                    fail("E_RANGE", "cache.batch", "indices must be a 1D integer array within shape")
                return result
            rows = indices(rows, matrix.shape[0])
            if columns is None:
                return np.array(matrix[rows, :], copy=True)
            columns = indices(columns, matrix.shape[1])
            return np.array(matrix[np.ix_(rows, columns)], copy=True)
        finally:
            matrix._mmap.close()


def load_cache(directory: Path, expected_identity=None) -> RawCache:
    """Verify completion, identity and content hashes before exposing a cache."""
    directory = Path(directory)
    from .shared import current
    scope = current()
    if scope:
        scope.register(directory / name for name in ('complete.json', 'dosage.npy', 'missing_counts.npz'))
        # Pin metadata too: otherwise a changed completion manifest could bind
        # a different matrix to a previously verified identity.
        sha256(directory / 'complete.json')
    try:
        metadata = read_json(directory / "complete.json")
        if type(metadata["schema_version"]) is not int or metadata["schema_version"] != 1 or metadata["key"] != identity_key(metadata["identity"]):
            raise ValueError("invalid cache schema or identity hash")
        if expected_identity is not None and metadata["identity"] != expected_identity:
            raise ValueError("cache belongs to different inputs/reader/order")
        from .genotypes import DECLARED_MATRIX_ENCODING
        if metadata["identity"]["encoding"] not in (ENCODING, MATRIX_ENCODING, DECLARED_MATRIX_ENCODING) or metadata["dtype"] != "int8":
            raise ValueError("unsupported dosage encoding")
        for name in ("dosage.npy", "missing_counts.npz"):
            if sha256(directory / name) != metadata["files"][name]:
                raise ValueError(f"checksum mismatch: {name}")
        matrix = np.load(directory / "dosage.npy", mmap_mode="r", allow_pickle=False)
        try:
            shape = tuple(metadata["shape"])
            if len(shape) != 2 or any(type(n) is not int or n < 1 for n in shape):
                raise ValueError("invalid cached shape")
            if matrix.dtype != np.int8 or matrix.shape != shape or not matrix.flags.c_contiguous:
                raise ValueError("incorrect cached array dtype/shape/order")
        finally:
            matrix._mmap.close()
        with np.load(directory / "missing_counts.npz", allow_pickle=False) as counts:
            missing = MissingCounts(counts["samples"].copy(), counts["markers"].copy())
        if (missing.samples.dtype != np.int64 or missing.markers.dtype != np.int64 or
                missing.samples.shape != (shape[0],) or missing.markers.shape != (shape[1],) or
                np.any(missing.samples < 0) or np.any(missing.samples > shape[1]) or
                np.any(missing.markers < 0) or np.any(missing.markers > shape[0]) or
                missing.total != int(missing.markers.sum()) or missing.total != metadata["missing_cells"]):
            raise ValueError("invalid cached missing counts")
        return RawCache(directory, metadata, missing)
    except (OSError, ValueError, KeyError, TypeError, IndexError) as error:
        fail("E_CACHE", str(directory), str(error))


def get_or_build_cache(root: Path, adapter: BedAdapter, identity: dict, files: dict, progress=None):
    key = identity_key(identity)
    destination = root / key
    if destination.exists():
        cache = load_cache(destination, identity)
        return cache, True
    root.mkdir(parents=True, exist_ok=True)
    if shutil.disk_usage(root).free < adapter.samples * adapter.markers + 64 * 1024**2:
        fail("E_IO", str(root), "not enough free disk for raw int8 cache and metadata")
    stage = root / (key + ".partial-" + uuid.uuid4().hex)
    stage.mkdir()
    try:
        missing = adapter.scan(stage / "dosage.npy", progress=progress)
        np.savez(stage / "missing_counts.npz", samples=missing.samples, markers=missing.markers)
        verify_snapshots(files)
        metadata = {"schema_version": 1, "key": key, "identity": identity, "dtype": "int8",
                    "shape": [adapter.samples, adapter.markers], "missing_cells": missing.total,
                    "files": {name: sha256(stage / name) for name in ("dosage.npy", "missing_counts.npz")}}
        write_json(stage / "complete.json", metadata)
        # Rename only a complete new directory. Never replace another completed cache.
        stage.rename(destination)
        return load_cache(destination, identity), False
    except Exception:
        # Failed partial directories are retained for diagnosis, never treated as complete.
        raise
