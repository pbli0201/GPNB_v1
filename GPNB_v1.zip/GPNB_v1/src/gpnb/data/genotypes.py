"""Explicit hard-call sources, sharing the same ordered int8 cache contract."""
from pathlib import Path

import numpy as np

from ..config import fail, object_fields, choice, sequence, text, resolve_project_path
from .bed import BedAdapter, MissingCounts, MATRIX_ENCODING
from .tables import text_table, plink_table

# Canonical cached calls are always 0/1/2, with -1 reserved for missing.
# This encoding deliberately makes no claim about biological allele identities.
DECLARED_MATRIX_ENCODING = {**MATRIX_ENCODING, "counted_allele": "DECLARED",
                           "array_layout": "matrix_ID_rows_named_columns",
                           "allele_case_sensitive": None}


def validate_matrix(value):
    object_fields(value, "data.matrix", ("path", "delimiter", "encoding", "id_columns", "missing_tokens", "counted_allele"),
                  ("coding", "allele_declaration"))
    text(value["path"], "data.matrix.path")
    choice(value["delimiter"], "data.matrix.delimiter", (",", "\t", "whitespace"))
    choice(value["encoding"], "data.matrix.encoding", ("utf-8", "utf-8-sig", "gb18030"))
    choice(value["counted_allele"], "data.matrix.counted_allele", ("BIM_A1", "DECLARED"))
    choice(value.get("coding", "012"), "data.matrix.coding", ("012", "-101"))
    if value["counted_allele"] == "DECLARED":
        text(value.get("allele_declaration"), "data.matrix.allele_declaration")
    elif "allele_declaration" in value:
        text(value["allele_declaration"], "data.matrix.allele_declaration", empty=True)
    for key in ("id_columns", "missing_tokens"):
        sequence(value[key], "data.matrix." + key, nonempty=key == "id_columns")
        for s in value[key]:
            text(s, "data.matrix." + key, empty=key == "missing_tokens")
    if len(value["id_columns"]) not in (1, 2) or len(set(value["id_columns"])) != len(value["id_columns"]):
        fail("E_FORMAT", "data.matrix.id_columns", "provide IID alone, or ordered FID and IID column names")
    calls = {"0", "1", "2"} if value.get("coding", "012") == "012" else {"-1", "0", "1"}
    if set(value["missing_tokens"]) & calls:
        fail("E_FORMAT", "data.matrix.missing_tokens", f"{sorted(calls)} are observed calls, not missing tokens")
    if value["delimiter"] == "whitespace" and "" in value["missing_tokens"]:
        fail("E_FORMAT", "data.matrix.missing_tokens", "whitespace tables require an explicit missing token such as NA; empty cells cannot be represented by spaces")


def matrix_encoding(options):
    return DECLARED_MATRIX_ENCODING if options["counted_allele"] == "DECLARED" else MATRIX_ENCODING


def matrix_header(path, options):
    stream = text_table(Path(path), options["delimiter"], options["encoding"])
    try:
        line, header = next(stream, (0, []))
    finally:
        stream.close()
    if not header or any(not name or name != name.strip() for name in header):
        fail("E_FORMAT", f"{path}:{line}", "matrix header needs nonempty column names without surrounding whitespace")
    if len(header) != len(set(header)):
        fail("E_DUPLICATE", f"{path}:{line}", "duplicate matrix column")
    if any(name not in header for name in options["id_columns"]):
        fail("E_FIELD", f"{path}:{line}", "configured ID columns not found")
    marker_names = [name for name in header if name not in options["id_columns"]]
    if not marker_names:
        fail("E_FORMAT", str(path), "matrix has no marker columns")
    return header, marker_names


def decode_calls(values, options, path, line, names):
    tokens = set(options["missing_tokens"])
    calls = {"0": 0, "1": 1, "2": 2} if options.get("coding", "012") == "012" else {"-1": 0, "0": 1, "1": 2}
    raw = np.empty(len(values), dtype=np.int8)
    for j, v in enumerate(values):
        if v in tokens:
            raw[j] = -1
        elif v in calls:
            raw[j] = calls[v]
        else:
            fail("E_FORMAT", f"{path}:{line}:{names[j]}",
                 f"expected exact {'/'.join(calls)} or missing token; got {v!r}. Continuous dosage is not rounded.")
    return raw


def preview_matrix(options, *, limit=8):
    """Bounded input preview only; not a replacement for full import validation."""
    validate_matrix(options)
    if type(limit) is not int or not 1 <= limit <= 100:
        fail("E_RANGE", "preview.limit", "expected 1..100 rows")
    path = Path(options["path"])
    import csv
    budget = 8 * 1024 * 1024
    def physical_lines():
        remaining = budget
        with path.open(encoding=options["encoding"], newline="") as f:
            while remaining > 0:
                line = f.readline(remaining + 1)
                if not line:
                    return
                if len(line) > remaining:
                    fail("E_FORMAT", "matrix.preview", "preview exceeds 8 million characters; use full data check")
                remaining -= len(line)
                yield line
            fail("E_FORMAT", "matrix.preview", "preview exceeds 8 million characters; use full data check")
    lines = physical_lines()
    reader = ((line.split()) for line in lines) if options["delimiter"] == "whitespace" else csv.reader(lines, delimiter=options["delimiter"], strict=True)
    stream = enumerate(reader, 1)
    rows = []
    try:
        _, header = next(stream, (0, []))
        if not header or any(not n or n != n.strip() for n in header) or len(set(header)) != len(header):
            fail("E_FORMAT", str(path), "matrix header must have unique nonempty column names")
        if not set(options["id_columns"]).issubset(header):
            fail("E_FIELD", str(path), "configured ID columns not found")
        names = [n for n in header if n not in options["id_columns"]]
        if not names:
            fail("E_FORMAT", str(path), "matrix has no marker columns")
        marker_indices = [i for i, k in enumerate(header) if k not in options["id_columns"]]
        id_indices = [header.index(k) for k in options["id_columns"]]
        for line, row in stream:
            if len(row) != len(header):
                fail("E_FORMAT", f"{path}:{line}", f"expected {len(header)} columns, got {len(row)}")
            if any(not row[i] or row[i] != row[i].strip() for i in id_indices):
                fail("E_FORMAT", f"{path}:{line}", "IDs must be nonempty strings without surrounding whitespace")
            decode_calls([row[i] for i in marker_indices], options, path, line, names)
            rows.append(row[:40])
            if len(rows) >= limit:
                break
    except csv.Error as error:
        fail("E_FORMAT", str(path), f"malformed matrix text: {error}")
    finally:
        lines.close()
    return dict(columns=header[:40], rows=rows, total_columns=len(header), coding=options.get("coding", "012"),
                scope="first rows only; run full data check before training")


def source_paths(data, project_path):
    result = {k: resolve_project_path(project_path, data[k]) for k in
              ("bed", "bim", "fam", "phenotype", "manifest", "split_groups") if data.get(k) is not None}
    if data.get("matrix"):
        result["matrix"] = resolve_project_path(project_path, data["matrix"]["path"])
    return result


def set_source_path(data, key, value):
    if key == "matrix":
        data["matrix"]["path"] = str(value)
    else:
        data[key] = str(value)


def verify_matrix_binding(data, imported, files, project_path):
    from .files import snapshot
    current, previous = data.get("matrix"), imported.get("matrix")
    options = lambda v: {k: x for k, x in (v or {}).items() if k != "path"}
    if options(current) != options(previous):
        fail("E_MANIFEST", "data.matrix", "matrix interpretation changed; import/prepare again")
    if current:
        record = snapshot(resolve_project_path(project_path, current["path"]))
        if record["sha256"] != files.get("matrix", {}).get("sha256"):
            fail("E_MANIFEST", "data.matrix", "matrix input changed")
        return {"matrix": record}
    return {}


def load_matrix_config(path):
    from .files import read_json
    value = read_json(Path(path))
    validate_matrix(value)
    value["path"] = str(resolve_project_path(path, value["path"]))
    return value


class MatrixAdapter:
    """Streaming sample-major text; named columns or exact explicit BIM order.

    No pandas inference, rounding, transposition, allele flipping or pickle.
    A row buffer plus O(samples + markers) metadata is held in memory.
    """
    def __init__(self, path, markers, options, *, progress=None):
        validate_matrix(options)
        _, names = matrix_header(path, options)
        if markers is None:
            if options["counted_allele"] != "DECLARED":
                fail("E_FORMAT", "data.bim", "BIM_A1 matrix requires BIM; no-BIM inputs require a declaration")
            markers = [("", name, "", "", "", "") for name in names]
        elif options["counted_allele"] != "BIM_A1":
            fail("E_FORMAT", "data.bim", "DECLARED mode does not use BIM; choose BIM_A1 to bind biological alleles")
        self.path, self.marker_rows, self.options = Path(path), markers, options
        self.markers = len(markers)
        self.sample_rows, self.lines = [], []
        seen = {}
        for line, ids, _ in self.rows():
            if ids in seen:
                fail("E_DUPLICATE", f"{path}:{line}", f"sample {ids}; first row {seen[ids]}")
            seen[ids] = line
            self.sample_rows.append((*ids, "0", "0", "0", "-9"))
            self.lines.append(line)
            if progress and len(self.lines) % 256 == 0:
                progress("matrix_metadata", len(self.lines), 0)
        self.samples = len(self.sample_rows)
        if not self.samples:
            fail("E_FORMAT", str(path), "empty genotype matrix")

    def rows(self):
        stream = text_table(self.path, self.options["delimiter"], self.options["encoding"])
        try:
            _, header = next(stream, (0, []))
            if len(header) != len(set(header)):
                fail("E_DUPLICATE", str(self.path), "duplicate matrix column")
            ids = self.options["id_columns"]
            if any(k not in header for k in ids):
                fail("E_FIELD", str(self.path), "FID/IID columns not found")
            id_idx = [header.index(k) for k in ids]
            marker_idx = [i for i, k in enumerate(header) if k not in ids]
            if [header[i] for i in marker_idx] != [r[1] for r in self.marker_rows]:
                fail("E_FORMAT", str(self.path), "matrix marker columns must match BIM IDs and order exactly")
            for line, row in stream:
                if len(row) != len(header):
                    fail("E_FORMAT", f"{self.path}:{line}", f"expected {len(header)} columns")
                key = tuple(row[i] for i in id_idx)
                if any(not k or k != k.strip() for k in key):
                    fail("E_FORMAT", f"{self.path}:{line}", "IDs must be nonempty strings without surrounding whitespace")
                if len(key) == 1:
                    key = ("", key[0])  # no inferred family; empty FID is only the internal ID slot
                yield line, key, [row[i] for i in marker_idx]
        finally:
            stream.close()

    def scan(self, destination=None, progress=None):
        missing = MissingCounts(np.zeros(self.samples, dtype=np.int64), np.zeros(self.markers, dtype=np.int64))
        mapped = None
        try:
            if destination is not None:
                mapped = np.lib.format.open_memmap(destination, mode="w+", dtype=np.int8, shape=(self.samples, self.markers))
            count = 0
            for i, (line, key, values) in enumerate(self.rows()):
                if i >= self.samples or key != self.sample_rows[i][:2]:
                    fail("E_CHANGED", str(self.path), "matrix sample order changed")
                raw = decode_calls(values, self.options, self.path, line, [m[1] for m in self.marker_rows])
                absent = raw == -1
                missing.samples[i] = int(absent.sum())
                missing.markers += absent
                if mapped is not None:
                    mapped[i] = raw
                count += 1
                if progress and (count % 256 == 0 or count == self.samples):
                    progress("genotype_scan", count, self.samples)
            if count != self.samples:
                fail("E_CHANGED", str(self.path), "matrix row count changed")
            if mapped is not None:
                mapped.flush()
            return missing
        finally:
            if mapped is not None:
                mapped._mmap.close()


def open_source(data, paths, *, progress=None, **bed_options):
    from .shared import current
    from .files import sha256
    import json
    scope = current()
    if scope:
        key = (tuple((name, str(path), sha256(path)) for name, path in sorted(paths.items()) if name in ('bed', 'bim', 'fam', 'matrix')),
               json.dumps(data.get('matrix'), sort_keys=True), tuple(sorted(bed_options.items())))
        return scope.fact('genotype_source', key, lambda: _open_source(data, paths, progress=progress, **bed_options))
    return _open_source(data, paths, progress=progress, **bed_options)


def _open_source(data, paths, *, progress=None, **bed_options):
    markers = plink_table(paths["bim"], "BIM") if paths.get("bim") else None
    if data.get("matrix"):
        adapter = MatrixAdapter(paths["matrix"], markers, data["matrix"], progress=progress)
        return adapter.sample_rows, adapter.marker_rows, adapter
    if markers is None:
        fail("E_FORMAT", "data.bim", "BED requires a BIM companion")
    samples = plink_table(paths["fam"], "FAM")
    return samples, markers, BedAdapter(paths["bed"], len(samples), len(markers), **bed_options)


def matrix_identity(files, samples_hash, markers_hash, options):
    legacy = options["counted_allele"] == "BIM_A1" and not {"coding", "allele_declaration"}.intersection(options)
    return {"schema_version": 1, "reader": {"name": "gpnb-hardcall-matrix", "adapter_version": 1 if legacy else 2},
            "encoding": matrix_encoding(options), "matrix_options": {k: v for k, v in options.items() if k != "path"},
            "source_sha256": {k: files[k]["sha256"] for k in ("matrix", "bim") if k in files},
            "sample_order_sha256": samples_hash, "marker_order_sha256": markers_hash,
            "selection": "all_samples_all_markers"}
