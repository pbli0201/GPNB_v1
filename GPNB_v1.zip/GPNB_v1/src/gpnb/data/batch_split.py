"""Shared individual assignments for separately fitted trait tasks."""
import copy
from ..config import fail,resolve_project_path
from .tables import read_phenotypes


def bind_context(context, project, path):
    traits=project.get('extensions',{}).get('batch_split_traits')
    if not traits:return context
    table=read_phenotypes(resolve_project_path(path,project['data']['phenotype']),project['data']['phenotype_options'])
    options=project['data']['phenotype_options']
    eligible=[]
    for ids in context['sample_ids']:
        row=table.lookup.get(tuple(ids) if options['id_mode']=='fid_iid' else (ids[1],))
        eligible.append(row is not None and any(table.values[t][row] is not None for t in traits))
    return {**context,'batch_union_eligible':eligible,'batch_traits':list(traits)}


def union_context(context):
    result=copy.deepcopy(context)
    result['eligible']=result.pop('batch_union_eligible')
    result.pop('batch_traits',None)
    return result


def project_partitions(partitions, context, allow_empty_validation=False, allow_empty_test=False):
    result={key:[i for i in rows if context['eligible'][i]] for key,rows in partitions.items()}
    for key,rows in result.items():
        if not rows and not (key=='validation' and allow_empty_validation or key=='test' and allow_empty_test):
            fail('E_SPLIT',context.get('trait','trait')+'.'+key,'shared individual plan has no valid labels in this partition; change the common protocol or exclude this trait (no automatic reshuffle)')
    return result
