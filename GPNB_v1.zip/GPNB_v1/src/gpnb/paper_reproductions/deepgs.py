"""DeepGS paper/author-code primitives, pending MXNet parity validation.

Source: cma2015/DeepGS commit 33ae2dc1ed7bda4e38b76460b18756649d4478a5,
DeepGS_1.2.tar.gz/R/DeepGS.R and author User Manual pp. 6-7.
The supplied Ma et al. 2018 PDF p. 3 specifies ReLU at the first FC layer,
whereas the author manual example uses sigmoid. Both are explicit profiles.
Other defaults combine paper p. 4 and pinned software defaults (see evidence).
This module does not claim the old adaptation
or a PyTorch model is the original R/MXNet software.
"""
from dataclasses import asdict, dataclass

import torch
from torch import nn

from ..models.core import build_model
from ..models.templates import sequential


@dataclass(frozen=True)
class DeepGSAuthorConfig:
    hidden_activation: str = "ReLU"
    rounds: int = 6000
    batch_size: int = 30
    learning_rate: float = 0.01
    momentum: float = 0.5
    weight_decay: float = 0.00001
    initializer_scale: float = 0.01
    seed: int = 0
    early_stop_bad_steps: int = 600
    evaluation_metric: str = "mae"
    prediction_state: str = "last_epoch_not_best_checkpoint"


def backbone_spec(config=None):
    """Complete native GPNB graph, including the published output dropout.

    Numerical inputs are supplied by the caller; no preprocessing is fitted here.
    """
    config = config or DeepGSAuthorConfig()
    if config.hidden_activation not in ("ReLU", "Sigmoid"):
        raise ValueError("hidden_activation must be ReLU (paper) or Sigmoid (author example)")
    return sequential([
        ("ToChannels", {}),
        ("Conv1d", dict(out_channels=8, kernel_size=18, stride=1, padding=0, bias=True)),
        ("ReLU", {}),
        ("MaxPool1d", dict(kernel_size=4, stride=4, padding=0, ceil_mode=False)),
        ("Dropout", dict(p=.2)),
        ("Flatten", {}),
        ("Linear", dict(out_features=32, bias=True)),
        (config.hidden_activation, {}),
        ("Dropout", dict(p=.1)),
        ("Linear", dict(out_features=1, bias=True)),
        ("Dropout", dict(p=.05)),
    ], "DeepGS paper ReLU / author example profile, complete native GPNB graph")


def build_deepgs(input_features, config=None, *, max_parameter_bytes=800_000_000):
    config = config or DeepGSAuthorConfig()
    if input_features < 21:
        raise ValueError("DeepGS requires at least 21 features for conv18/pool4")
    spec = backbone_spec(config)
    model = build_model(spec, input_features, seed=config.seed,
        max_parameter_bytes=max_parameter_bytes)
    model.reproduction_spec = spec
    model.reproduction_scope = "native_gpnb_author_topology_not_original_R_software"
    # mx.init.uniform initializes weights uniformly and biases to zero. RNG
    # implementations differ; mapping identical explicit arrays is required for
    # cross-framework numerical parity, not merely sharing a seed integer.
    with torch.random.fork_rng(devices=[]):
        torch.manual_seed(config.seed)
        for layer in model.modules():
            if isinstance(layer, (nn.Linear, nn.Conv1d)):
                nn.init.uniform_(layer.weight, -config.initializer_scale, config.initializer_scale)
                if layer.bias is not None:
                    nn.init.zeros_(layer.bias)
    model.author_config = asdict(config)
    return model


def regression_output_loss(prediction, target):
    """MXNet LinearRegressionOutput gradient with optimizer rescale_grad=1/B.

    For one output the backward is prediction-label; thus the corresponding
    PyTorch scalar is half mean squared error, not MAE nor the usual full MSE.
    MAE in the author call is an evaluation/early-stopping metric only.
    """
    if prediction.shape != target.shape or prediction.ndim != 2 or prediction.shape[1] != 1:
        raise ValueError("Expected matching [batch, 1] predictions and targets")
    return .5 * (prediction-target).square().mean()


def make_optimizer(model, config=None):
    config = config or DeepGSAuthorConfig()
    # The MXNet R SGD updater is applied to every trainable argument; no
    # separate bias wd multiplier is introduced by this reproduction.
    return torch.optim.SGD(model.parameters(), lr=config.learning_rate,
        momentum=config.momentum, weight_decay=config.weight_decay,
        dampening=0, nesterov=False, foreach=False)


class AuthorEarlyStop:
    """Match mx.callback.early.stop bad.steps semantics, including equal scores.

    This callback does not save or restore a best model; the author feedforward
    loop returns the last model extracted before its callback terminates.
    """
    def __init__(self, bad_steps=600):
        if bad_steps < 1:
            raise ValueError("bad_steps must be positive")
        self.best = float("inf")
        self.bad = 0
        self.bad_steps = bad_steps

    def update(self, value):
        value = float(value)
        if not torch.isfinite(torch.tensor(value)):
            raise ValueError("nonfinite validation metric")
        if value > self.best:
            self.bad += 1
        else:
            self.best, self.bad = value, 0
        return self.bad >= self.bad_steps


def load_matching_weights(model, conv_weight, conv_bias, hidden_weight, hidden_bias,
                          output_weight, output_bias):
    """Load explicit arrays in PyTorch [out,in,...] layout for parity fixtures.

    R/MXNet exporter must document its transposes. No guessing or silent reshape.
    """
    layers = [m for m in model.modules() if isinstance(m, (nn.Conv1d, nn.Linear))]
    assert len(layers) == 3
    with torch.no_grad():
        for layer, w, b in zip(layers, [conv_weight,hidden_weight,output_weight],
                               [conv_bias,hidden_bias,output_bias]):
            w=torch.as_tensor(w,dtype=layer.weight.dtype)
            b=torch.as_tensor(b,dtype=layer.bias.dtype)
            if w.shape != layer.weight.shape or b.shape != layer.bias.shape:
                raise ValueError("Explicit weight shape does not match the author topology")
            layer.weight.copy_(w);layer.bias.copy_(b)


def load_author_r_weights(model, folder):
    """Import a complete R/MXNet parameter export with explicit layout mapping."""
    import json
    from pathlib import Path
    import numpy as np
    folder = Path(folder)
    manifest = json.loads((folder / "weights_manifest.json").read_text())
    def read(name):
        item = manifest[name]
        shape = item["r_shape"]
        if isinstance(shape, int):
            shape = [shape]
        return np.fromfile(folder / item["file"], dtype="<f4").reshape(tuple(reversed(shape)))
    conv = read("convolution0_weight")
    # R reverses MXNet dimensions: C=[out,in,length,1], while PyTorch uses
    # [out,in,length]. The singleton axis must be explicit.
    if conv.ndim != 4 or conv.shape[-1] != 1:
        raise ValueError("Expected the documented DeepGS 1x18 convolution layout")
    load_matching_weights(model, conv[..., 0], read("convolution0_bias"),
        read("fullyconnected0_weight"), read("fullyconnected0_bias"),
        read("fullyconnected1_weight"), read("fullyconnected1_bias"))
    return model


def fit_author_ordered(model, x_train, y_train, x_valid, y_valid, *,
                       train_batches, validation_batches, config=None,
                       seed=0, device="cpu", progress_callback=None):
    """Match source batches, padded MAE, SGD and last-state early stopping.

    Batch indices must come from the original R iterator capture. Both sides
    use the same initial weights; Torch/MXNet dropout random streams still
    differ, so this is not a claim of identical stochastic training paths.
    This function never accepts external test data or external test labels.
    """
    import time
    import numpy as np
    config = config or DeepGSAuthorConfig()
    if config.rounds < 1:
        raise ValueError("Positive epoch budget required")
    x = torch.as_tensor(np.asarray(x_train), dtype=torch.float32, device=device)
    y = torch.as_tensor(np.asarray(y_train).reshape(-1, 1), dtype=torch.float32, device=device)
    vx = torch.as_tensor(np.asarray(x_valid), dtype=torch.float32, device=device)
    vy = torch.as_tensor(np.asarray(y_valid).reshape(-1, 1), dtype=torch.float32, device=device)
    if x.ndim != 2 or vx.ndim != 2 or x.shape[1] != vx.shape[1] or len(x) != len(y) or len(vx) != len(vy):
        raise ValueError("Aligned train and inner-validation matrices required")
    if not all(torch.isfinite(a).all() for a in (x, y, vx, vy)):
        raise ValueError("Finite numerical inputs required")
    effective_batch = min(config.batch_size, len(x))
    if len(vx) < effective_batch:
        raise ValueError("Original R FeedForward cannot validate fewer rows than its training batch")

    def validate_batches(records, n):
        validated, independent = [], []
        for record in records:
            index = np.asarray(record["indices"], dtype=np.int64)
            pad = int(record["pad"])
            if index.shape != (effective_batch,) or pad < 0 or pad >= effective_batch or np.any(index < 0) or np.any(index >= n):
                raise ValueError("Invalid author iterator batch")
            independent.extend(index[:effective_batch-pad].tolist())
            validated.append(torch.as_tensor(index, dtype=torch.long, device=device))
        if sorted(independent) != list(range(n)):
            raise ValueError("Unpadded original rows must cover this partition exactly once")
        return validated
    train_indices = validate_batches(train_batches, len(x))
    valid_indices = validate_batches(validation_batches, len(vx))
    model.to(device)
    optimizer = make_optimizer(model, config)
    stop = AuthorEarlyStop(config.early_stop_bad_steps)
    torch.manual_seed(int(seed))
    if str(device).startswith("cuda"):
        torch.cuda.manual_seed_all(int(seed)); torch.cuda.synchronize()
    started = time.perf_counter()
    history = []
    for epoch in range(1, config.rounds + 1):
        model.train()
        train_error, train_count = 0., 0
        for index in train_indices:
            optimizer.zero_grad(set_to_none=True)
            prediction = model(x[index])
            loss = regression_output_loss(prediction, y[index])
            if not torch.isfinite(loss):
                raise FloatingPointError("Nonfinite training loss")
            loss.backward()
            optimizer.step()
            train_error += float(np.abs(prediction.detach().cpu().numpy().astype(np.float64)
                                        -y[index].detach().cpu().numpy().astype(np.float64)).sum())
            train_count += len(index)
        model.eval()
        valid_error, valid_count = 0., 0
        with torch.no_grad():
            for index in valid_indices:
                prediction = model(vx[index]).cpu().numpy().astype(np.float64)
                labels = vy[index].cpu().numpy().astype(np.float64)
                valid_error += float(np.abs(prediction-labels).sum())
                valid_count += len(index)
        row = dict(epoch=epoch, train_mae=train_error/train_count,
                   validation_mae=valid_error/valid_count,
                   training_calculation_rows=train_count,
                   validation_calculation_rows=valid_count)
        history.append(row)
        if progress_callback is not None:
            progress_callback(row)
        if stop.update(row["validation_mae"]):
            break
    if str(device).startswith("cuda"):
        torch.cuda.synchronize()
    return dict(history=history, epochs_completed=len(history),
                fit_seconds=time.perf_counter()-started, config=asdict(config),
                checkpoint="last epoch, not best checkpoint",
                batch_order="captured original R batches, fixed across epochs",
                validation_metric="float32 model/labels, float64 CPU MAE over padded source calculation rows",
                outer_test_access=False,
                rng_limit="same dropout distributions; MXNet and Torch masks differ")

