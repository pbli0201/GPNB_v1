"""Native GPNB graph matched to the released DNNGP v1 TF1.15 runtime.
No TensorFlow network is used on the GPNB path. Original weights are imported
explicitly. Cross-framework random initialization/dropout are not bitwise equal.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
import json
from pathlib import Path
import time
import numpy as np
import torch
from ..config import ModelSpec
from ..models.core import build_model
from ..models.registry import component


@dataclass(frozen=True)
class DNNGPConfig:
    learning_rate: float = .1
    dropout1: float = .5
    dropout2: float = .5
    batch_size: int = 64
    epochs: int = 100
    lr_patience: int = 25

    def validate(self):
        if self.learning_rate <= 0 or min(self.batch_size, self.epochs, self.lr_patience) < 1:
            raise ValueError("Positive learning rate, batch size, epochs and patience required")
        if not (0 <= self.dropout1 < 1 and 0 <= self.dropout2 < 1):
            raise ValueError("Dropout must be in [0,1)")


def dnngp_spec(config=None):
    config = config or DNNGPConfig()
    config.validate()
    rows = []
    def add(name, kind, source, **params):
        rows.append(dict(id=name, type=kind, implementation_version=1,
                         params={**component(kind).defaults(), **params}, inputs={"x": source}))
        return name
    x = add("channels", "ToChannels", "$input")
    for i in range(3):
        x = add("pad"+str(i+1), "Pad1d", x, left=1, right=2)
        x = add("conv"+str(i+1), "Conv1d", x, out_channels=64, kernel_size=4, padding=0)
        x = add("relu"+str(i+1), "ReLU", x)
        if i < 2:
            x = add("drop"+str(i+1), "Dropout", x, p=config.dropout1 if i == 0 else config.dropout2)
        x = add("bn"+str(i+1), "KerasBatchNorm1d", x, eps=.001, momentum=.99, affine=True)
    x = add("channels_last", "Permute", x, axes=[1, 0], layout="Sequence")
    x = add("flatten", "Flatten", x)
    x = add("dense3", "Linear", x, out_features=3)
    x = add("drop3", "Dropout", x, p=.3)
    x = add("regression", "Linear", x, out_features=1)
    return ModelSpec(dict(schema_version=2, kind="model", name="DNNGP v1 author-runtime matched native GPNB",
        backend="pytorch", task="single_trait_regression", input_layout="batch_markers",
        input_representation="standardized_dosage", graph_mode="dag", layers=rows, output=x,
        extensions={"reproduction": {"source": "released 2022 Windows DNNGP v1 cp36 binary; TensorFlow1.15",
            "input_meaning": "floating PCA components; schema numeric-matrix label retained",
            "config": asdict(config), "batchnorm": "Keras population moving variance, retention .99",
            "initialization": "truncated normal std .05 for Conv; Glorot uniform Dense; explicit weight import for parity",
            "loss": "MSE plus separate Conv kernel/bias L2",
            "kernel_l2": [.01, .001, .001], "bias_l2": [.1, .00001, .0001],
            "optimizer": "KerasAdam epsilon_hat=1e-7; not torch Adam epsilon",
            "dropout_equivalence": "same distributions and locations; cross-framework masks not identical"}}))


def layers_by_id(model):
    return {r["id"]: model._modules[str(r.get("module_index", r["index"]))] for r in model.plan["layers"]}


def build_gpnb_dnngp(input_features, config=None, *, seed=123, device="cpu"):
    config = config or DNNGPConfig()
    spec = dnngp_spec(config)
    model = build_model(spec, int(input_features), seed=int(seed))
    layers = layers_by_id(model)
    with torch.random.fork_rng(devices=[]):
        torch.manual_seed(int(seed))
        for i in range(1, 4):
            torch.nn.init.trunc_normal_(layers["conv"+str(i)].weight, mean=0., std=.05, a=-.1, b=.1)
            torch.nn.init.zeros_(layers["conv"+str(i)].bias)
        for key in ("dense3", "regression"):
            torch.nn.init.xavier_uniform_(layers[key].weight)
            torch.nn.init.zeros_(layers[key].bias)
    model.reproduction_spec = spec
    return model.to(device)


def load_author_weights(model, npz_path):
    layers = layers_by_id(model)
    used = []
    with np.load(npz_path, allow_pickle=False) as weights, torch.no_grad():
        def put(parameter, key, axes=None):
            values = weights[key]
            if axes is not None:
                values = values.transpose(*axes)
            if tuple(values.shape) != tuple(parameter.shape):
                raise ValueError("Author weight shape mismatch for "+key)
            parameter.copy_(torch.as_tensor(np.ascontiguousarray(values), dtype=parameter.dtype, device=parameter.device))
            used.append(key)
        for i in range(3):
            suffix = "" if i == 0 else "_"+str(i)
            conv, bn = layers["conv"+str(i+1)], layers["bn"+str(i+1)]
            put(conv.weight, "conv1d"+suffix+"__0", (2, 1, 0))
            put(conv.bias, "conv1d"+suffix+"__1")
            for j, parameter in enumerate((bn.weight, bn.bias, bn.running_mean, bn.running_var)):
                put(parameter, "batch_normalization"+suffix+"__"+str(j))
        for original, target in (("dense", "dense3"), ("dense_1", "regression")):
            put(layers[target].weight, original+"__0", (1, 0))
            put(layers[target].bias, original+"__1")
        if set(used) != set(weights.files):
            raise ValueError("Unmapped author weights: "+str(set(weights.files)-set(used)))
    return model


def regularization_loss(model):
    layers = layers_by_id(model)
    terms = []
    for i, (kernel, bias) in enumerate(((.01, .1), (.001, .00001), (.001, .0001)), 1):
        layer = layers["conv"+str(i)]
        terms.extend((layer.weight.square().sum()*kernel, layer.bias.square().sum()*bias))
    return torch.stack(terms).sum()


def dnngp_loss(model, predictions, targets):
    return torch.nn.functional.mse_loss(predictions, targets.reshape(-1, 1)) + regularization_loss(model)


class KerasAdam(torch.optim.Optimizer):
    """TF1.15 dense Adam epsilon-hat denominator, no decoupled weight decay."""
    def __init__(self, params, lr=.1, betas=(.9, .999), eps=1e-7):
        if lr <= 0 or eps <= 0 or not all(0 <= b < 1 for b in betas):
            raise ValueError("Invalid KerasAdam parameters")
        super().__init__(params, dict(lr=lr, betas=betas, eps=eps))
        self._constant_cache = {}
    @torch.no_grad()
    def step(self, closure=None):
        loss = None
        if closure is not None:
            with torch.enable_grad():
                loss = closure()
        rates = {}  # Per-call: LR edits and skipped-gradient steps stay correct.
        for group in self.param_groups:
            for p in group["params"]:
                if p.grad is None:
                    continue
                if p.grad.is_sparse:
                    raise ValueError("DNNGP KerasAdam supports dense gradients only")
                state = self.state[p]
                if not state:
                    state.update(step=0, exp_avg=torch.zeros_like(p), exp_avg_sq=torch.zeros_like(p))
                state["step"] += 1
                key = (p.device, p.dtype, tuple(group["betas"]))
                constants = self._constant_cache.get(key)
                if constants is None:
                    b1 = torch.as_tensor(group["betas"][0], dtype=p.dtype, device=p.device)
                    b2 = torch.as_tensor(group["betas"][1], dtype=p.dtype, device=p.device)
                    constants = (b1, b2)
                    self._constant_cache[key] = constants
                b1, b2 = constants
                m, v = state["exp_avg"], state["exp_avg_sq"]
                m.add_((p.grad-m)*(1-b1))
                v.add_((p.grad.square()-v)*(1-b2))
                rate_key = (key, state["step"], group["lr"])
                rate = rates.get(rate_key)
                if rate is None:
                    rate = group["lr"] * torch.sqrt(1-b2.pow(state["step"])) / (1-b1.pow(state["step"]))
                    rates[rate_key] = rate
                p.add_(-rate*m/(v.sqrt()+group["eps"]))
        return loss


class KerasReduceLROnPlateau:
    """Observed author callback: monitor total train loss, abs delta, no stop."""
    def __init__(self, optimizer, patience=25):
        self.optimizer, self.patience = optimizer, patience
        self.best, self.wait = float("inf"), 0
    def step(self, value):
        if value < self.best - .0001:
            self.best, self.wait = value, 0
        else:
            self.wait += 1
            if self.wait >= self.patience:
                for group in self.optimizer.param_groups:
                    if group["lr"] > .00001:
                        group["lr"] = max(group["lr"]*.1, .00001)
                self.wait = 0


def predict_preprocessed(model, x, *, batch_size=64, device="cpu"):
    a = np.asarray(x)
    if a.ndim == 3 and a.shape[-1] == 1:
        a = a[:, :, 0]
    model.to(device).eval()
    out = []
    with torch.no_grad():
        for start in range(0, len(a), batch_size):
            out.append(model(torch.as_tensor(a[start:start+batch_size], dtype=torch.float32, device=device)).cpu().numpy())
    return np.concatenate(out).reshape(-1)


def fit_preprocessed(model, x_train, y_train_standardized, *, config=None, seed=123, device="cpu",
                     x_valid=None, y_valid=None, validation_target_units=None):
    """Training with optional inner-validation diagnostics; outer test stays outside.
    Validation never drives gradients, LR or model/epoch selection. Set explicit
    units: standardized, or raw_author_behavior to audit the author mixed-unit
    diagnostic (standardized prediction versus raw target; not valid trait RMSE).
    PCA/target scaling are fitted upstream. Cross-framework RNG masks differ.
    """
    config = config or DNNGPConfig()
    config.validate()
    x = np.asarray(x_train)
    if x.ndim == 3 and x.shape[-1] == 1:
        x = x[:, :, 0]
    if x.ndim != 2 or len(x) != len(y_train_standardized):
        raise ValueError("Aligned 2D PCA features and standardized target required")
    model.to(device)
    tx = torch.as_tensor(x, dtype=torch.float32, device=device)
    ty = torch.as_tensor(np.asarray(y_train_standardized).reshape(-1, 1), dtype=torch.float32, device=device)
    if not torch.isfinite(tx).all() or not torch.isfinite(ty).all():
        raise ValueError("Nonfinite training input")
    if (x_valid is None) != (y_valid is None):
        raise ValueError("Validation features and targets must both be supplied")
    vx = vy = None
    if x_valid is not None:
        if validation_target_units not in ("standardized", "raw_author_behavior"):
            raise ValueError("Explicit validation_target_units required: standardized or raw_author_behavior")
        valid = np.asarray(x_valid)
        target = np.asarray(y_valid).reshape(-1, 1)
        if valid.ndim == 3 and valid.shape[-1] == 1:
            valid = valid[:, :, 0]
        if valid.ndim != 2 or valid.shape[1] != x.shape[1] or len(valid) != len(target) or not len(valid):
            raise ValueError("Aligned nonempty inner-validation arrays with matching feature count required")
        vx = torch.as_tensor(np.ascontiguousarray(valid), dtype=torch.float32, device=device)
        vy = torch.as_tensor(np.ascontiguousarray(target), dtype=torch.float32, device=device)
        if not torch.isfinite(vx).all() or not torch.isfinite(vy).all():
            raise ValueError("Nonfinite validation input")
    elif validation_target_units is not None:
        raise ValueError("Validation units were supplied without validation data")
    loader = torch.utils.data.DataLoader(torch.utils.data.TensorDataset(tx, ty),
        batch_size=config.batch_size, shuffle=True, generator=torch.Generator().manual_seed(seed))
    torch.manual_seed(seed)
    if str(device).startswith("cuda"):
        torch.cuda.manual_seed_all(seed); torch.cuda.synchronize()
    optimizer = KerasAdam(model.parameters(), lr=config.learning_rate)
    scheduler = KerasReduceLROnPlateau(optimizer, config.lr_patience)
    started, history = time.perf_counter(), []
    for epoch in range(config.epochs):
        model.train()
        total = torch.zeros((), device=device)
        for bx, by in loader:
            optimizer.zero_grad()
            loss = dnngp_loss(model, model(bx), by)
            loss.backward()
            optimizer.step()
            total += loss.detach()*len(bx)
        value = float(total/len(tx))
        record = {"epoch": epoch+1, "loss": value, "lr": optimizer.param_groups[0]["lr"]}
        if vx is not None:
            model.eval()
            diagnostic_total = torch.zeros((), device=device)
            diagnostic_mse = torch.zeros((), device=device)
            diagnostic_mae = torch.zeros((), device=device)
            # Direct slices avoid a validation DataLoader consuming train RNG.
            # Eval disables dropout and BN updates; no test/validation gradients.
            with torch.no_grad():
                for start in range(0, len(vx), config.batch_size):
                    bx, by = vx[start:start+config.batch_size], vy[start:start+config.batch_size]
                    prediction = model(bx)
                    error = prediction-by
                    mse = error.square().mean()
                    diagnostic_total += (mse+regularization_loss(model))*len(bx)
                    diagnostic_mse += mse*len(bx)
                    diagnostic_mae += error.abs().mean()*len(bx)
            record["validation_diagnostics"] = {
                "loss_mse_plus_l2": float(diagnostic_total/len(vx)),
                "mse": float(diagnostic_mse/len(vx)),
                "mae": float(diagnostic_mae/len(vx)),
                "target_units": validation_target_units,
                "prediction_units": "standardized",
                "mixed_units": validation_target_units == "raw_author_behavior",
                "is_valid_original_trait_rmse": False}
        history.append(record)
        scheduler.step(value)  # training loss only, never validation diagnostics
    if str(device).startswith("cuda"):
        torch.cuda.synchronize()
    return {"history": history, "fit_seconds": time.perf_counter()-started,
            "config": asdict(config), "test_labels_accessed": False,
            "validation": {"enabled": vx is not None, "partition_contract": "inner_validation_only",
                           "target_units": validation_target_units, "prediction_units": "standardized",
                           "used_for_gradient": False, "used_for_lr": False, "used_for_selection": False,
                           "included_in_fit_seconds": vx is not None,
                           "source_note": "author used raw test labels with standardized outputs; mixed-unit diagnostics are not trait-scale RMSE"},
            "optimizer": "TF1.15 Adam epsilon-hat", "loss": "standardized-target MSE + per-Conv L2",
            "rng_limit": "Torch and TF dropout/shuffle sequences differ"}
