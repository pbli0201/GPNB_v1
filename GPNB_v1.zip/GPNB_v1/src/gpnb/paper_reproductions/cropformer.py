"""Auditable Cropformer author-core / GPNB graph comparison.

The GPNB model is built by its existing ModelSpec/registry/runtime path.  The
author model is imported from a separately preserved, pinned source file with
one documented missing-import repair. No author training runs at import time.
This module does NOT equate the published multi-head description with the
repository's single-token attention, or reproduce its test-label selection.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import importlib.util
import json
from pathlib import Path
import time
from itertools import product

import numpy as np
import torch

from ..config import ModelSpec
from ..models.core import build_model
from ..models.paper_templates import paper_template

AUTHOR_COMMIT = "e0a77cf699b034d956b249f41b2e1f357f486f06"
AUTHOR_URL = "https://github.com/jiekesen/Cropformer"
ENCODING = "cropformer_nucleotide_0_9"
ANONYMOUS_DOSAGE = "anonymous_dosage"
SUPPORTED_ENCODINGS = (ENCODING, ANONYMOUS_DOSAGE)

def validate_encoded_matrix(x, encoding):
    """Validate declared values; never infer nucleotide identity from dosage."""
    if encoding not in SUPPORTED_ENCODINGS:
        raise ValueError("Explicit supported input encoding required")
    a = np.asarray(x)
    allowed = (0, 1, 2) if encoding == ANONYMOUS_DOSAGE else tuple(range(10))
    if a.ndim != 2 or not np.isin(a, allowed).all():
        raise ValueError("Input must contain complete integer codes " + str(allowed) + " for " + encoding)
    return a

NUCLEOTIDE_CODES = {"AA": 0, "AT": 1, "TA": 1, "AC": 2, "CA": 2,
                    "AG": 3, "GA": 3, "TT": 4, "TC": 5, "CT": 5,
                    "TG": 6, "GT": 6, "CC": 7, "CG": 8, "GC": 8, "GG": 9}


@dataclass(frozen=True)
class CropformerConfig:
    """Actual model.py main-call defaults; not all values are paper-reported."""
    hidden_size: int = 64
    num_attention_heads: int = 8
    kernel_size: int = 3
    hidden_dropout_prob: float = .5
    attention_probs_dropout_prob: float = .5
    learning_rate: float = .001
    batch_size: int = 32
    target_features: int = 10000

    def validate(self):
        if self.hidden_size < 1 or self.num_attention_heads not in (4, 8):
            raise ValueError("Author search uses 4 or 8 heads and positive hidden size")
        if self.hidden_size // self.num_attention_heads < 1 or self.kernel_size != 3:
            raise ValueError("This source-compatible graph requires kernel=3 and head_size>=1")
        if not all(0 <= p < 1 for p in (self.hidden_dropout_prob, self.attention_probs_dropout_prob)):
            raise ValueError("dropout must be in [0,1)")
        if min(self.learning_rate, self.batch_size, self.target_features) <= 0:
            raise ValueError("learning rate, batch size and feature count must be positive")


def paper_search_configs():
    """24 settings in supplemental Tables S2-S6; dropout filled from code.

    The paper reports no dropout grid. Fixed .5 for both dropouts is explicitly
    a repository-derived completion, not a recovered unpublished paper value.
    """
    return [CropformerConfig(batch_size=batch, num_attention_heads=heads,
                              learning_rate=lr, hidden_size=hidden)
            for batch, heads, lr, hidden in product((64, 128), (4, 8),
                                                    (.01, .001, .0001), (64, 128))]


def repository_search_configs():
    """Distinct source objective settings (Optuna samples these 20 times)."""
    return [CropformerConfig(num_attention_heads=heads, attention_probs_dropout_prob=p)
            for heads, p in product((4, 8), (.2, .5))]


def training_configuration(config=None, *, search_protocol="paper_grid_24", seed=42, encoding=ENCODING):
    """Serializable complete protocol; source-completed values are labeled."""
    config = config or CropformerConfig(batch_size=64 if search_protocol == "paper_grid_24" else 32)
    config.validate()
    if encoding not in SUPPORTED_ENCODINGS:
        raise ValueError("Unknown input encoding protocol")
    if search_protocol not in ("paper_grid_24", "repository_optuna_20"):
        raise ValueError("Unknown search protocol")
    return {"schema_version": 1, "model": "Cropformer", "author_commit": AUTHOR_COMMIT,
        "model_config": asdict(config), "model_config_role": "candidate template, not an inferred best configuration", "encoding": encoding,
        "preprocessing": {"selection": "sklearn.mutual_info_regression", "n_neighbors": 3,
            "discrete_features": "auto (continuous for dense arrays)", "copy": True,
            "sort": "numpy.argsort default; selected scores ascending", "padding": "right zero",
            "scaler": "StandardScaler(with_mean=True,with_std=True)", "maf_filter": None,
            "target_transform": "none", "fit_scope": "each inner training partition"},
        "loss": {"name": "MSELoss", "reduction": "mean"},
        "optimizer": {"name": "Adam", "betas": [.9, .999], "eps": 1e-8,
                      "weight_decay": 0, "amsgrad": False, "lr": config.learning_rate},
        "training": {"inner_epochs": 20, "final_max_epochs": 100,
            "early_stopping_metric": "inner_validation_pearson", "early_stopping_patience": 5,
            "early_stopping_delta": 0, "equal_score_resets_patience": True,
            "scheduler": {"name": "ReduceLROnPlateau", "mode": "min", "metric": "negative inner_validation_pearson",
                          "factor": .1, "patience": 10, "threshold": .0001, "threshold_mode": "rel",
                          "cooldown": 0, "min_lr": 0, "eps": 1e-8},
            "amp": False, "gradient_clip": None, "dataloader_workers": 0, "shuffle": True,
            "shuffle_generator": "private torch.Generator", "drop_last": False,
            "initialization": "author PyTorch defaults copied layerwise to GPNB", "seed": int(seed)},
        "evaluation": {"outer_folds": 5, "inner_folds": 3, "shuffle": True, "split_seed": 42,
            "paper_external_test_fraction": .2, "inner_objective": "unweighted mean of validation batch MSE, then mean folds",
            "outer_test_access": "prediction only after hyperparameters and epochs frozen",
            "test_labels_in_selection": False, "paired_splits": True},
        "search": {"protocol": search_protocol,
            "candidates": [asdict(c) for c in (paper_search_configs() if search_protocol == "paper_grid_24" else repository_search_configs())],
            "n_trials": 24 if search_protocol == "paper_grid_24" else 20,
            "sampler": "exhaustive deterministic grid" if search_protocol == "paper_grid_24" else "Optuna TPESampler default; seeded by paired driver"},
        "provenance": {"paper_reported": (["SNP encoding"] if encoding == ENCODING else []) + ["10000 input", "kernel/stride/padding", "outer5 inner3", "24 grid range", "MSE"],
            "source_completed": ["dropout", "Adam settings", "epochs", "patience", "target unscaled", "StandardScaler", "initialization"],
            "conflicts": ["paper MIC versus source mutual_info_regression", "paper multi-head versus source single-token", "paper grid versus source Optuna space"],
            "evaluation_changes": ["feature selection only inner training", "never use outer test to select epoch", "explicit seeded shuffle and MI jitter"] + (["anonymous 0/1/2 dosage adaptation authorized for both implementations; not authentic nucleotide 0-9"] if encoding == ANONYMOUS_DOSAGE else [])}}


def save_training_configuration(path, config=None, *, search_protocol="paper_grid_24", seed=42, encoding=ENCODING):
    value = training_configuration(config, search_protocol=search_protocol, seed=seed, encoding=encoding)
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding="utf-8")
    return value


def load_training_configuration(path):
    value = json.loads(Path(path).read_text(encoding="utf-8"))
    config = CropformerConfig(**value["model_config"])
    config.validate()
    expected = training_configuration(config, search_protocol=value["search"]["protocol"], seed=value["training"]["seed"], encoding=value["encoding"])
    if value != expected:
        raise ValueError("Configuration differs from supported explicit protocol; audit edits before running")
    return config, value


def build_gpnb_cropformer(input_features, config=None, *, seed=42, device="cpu", encoding=ENCODING):
    """Build the platform's existing editable DAG, with source-matched settings."""
    config = config or CropformerConfig()
    config.validate()
    if encoding not in SUPPORTED_ENCODINGS:
        raise ValueError("Unknown input encoding protocol")
    value = paper_template("Cropformer").to_dict()
    value["name"] = "Cropformer author-core aligned GPNB graph"
    for row in value["layers"]:
        if row["id"] == "attention":
            row["params"].update(hidden_size=config.hidden_size,
                                 scale_dim=config.hidden_size // config.num_attention_heads,
                                 dropout=config.attention_probs_dropout_prob)
        elif row["id"] == "out_drop":
            row["params"]["p"] = config.hidden_dropout_prob
    value["extensions"]["reproduction"] = {
        "author_commit": AUTHOR_COMMIT, "source": AUTHOR_URL,
        "input_encoding": encoding, "target_scaling": "none",
        "input_adaptation": "explicit anonymous 0/1/2 dosage; no nucleotide recovery claimed" if encoding == ANONYMOUS_DOSAGE else "authentic nucleotide codes",
        "scope": "repository regression SelfAttention core; leakage-free evaluation external",
        "config": asdict(config), "initialization": "copy author state for paired runs",
        "warning": "repository attention is one token with no head splitting"}
    # The schema name standardized_dosage is retained for runtime compatibility;
    # it means floating matrix here, with actual encoding recorded above.
    spec = ModelSpec(value)
    model = build_model(spec, int(input_features), seed=int(seed))
    model.reproduction_spec = spec
    return model.to(device)


def prepare_author_compat(source_path, destination):
    """Preserve full original module; add precisely its missing nn import."""
    source_path, destination = Path(source_path), Path(destination)
    raw = source_path.read_bytes()
    text = raw.decode("utf-8-sig").replace("\r\n", "\n")
    if "class SelfAttention(LightningModule):" not in text or "if __name__ == '__main__':" not in text:
        raise ValueError("Unexpected author source structure")
    if "from torch import nn" in text:
        raise ValueError("Source already imports nn; inspect revision rather than patch blindly")
    repaired = text.replace("import torch\n", "import torch\nfrom torch import nn  # compatibility: missing import in pinned author source\n", 1)
    # Normalize only line endings for a small, reviewable compatibility file.
    if repaired == text:
        repaired = text.replace("import torch\r\n", "import torch\r\nfrom torch import nn  # compatibility: missing import in pinned author source\r\n", 1)
    if repaired == text:
        raise ValueError("Cannot locate torch import")
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(repaired, encoding="utf-8", newline="\n")
    manifest = {"source": str(source_path), "compat": str(destination),
                "commit": AUTHOR_COMMIT, "source_sha256": hashlib.sha256(raw).hexdigest(),
                "compat_sha256": hashlib.sha256(destination.read_bytes()).hexdigest(),
                "patch": "add from torch import nn; normalize line endings only",
                "unchanged": "SelfAttention class, LightningModule base, forward and optimizer"}
    destination.with_suffix(".patch.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest


def load_author_cropformer(input_features, config=None, *, source_path, seed=42, device="cpu"):
    """Import full compatibility module, keeping the genuine Lightning base."""
    config = config or CropformerConfig()
    config.validate()
    path = Path(source_path)
    spec = importlib.util.spec_from_file_location("cropformer_author_" + hashlib.sha256(path.read_bytes()).hexdigest()[:12], path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    with torch.random.fork_rng(devices=[]):
        torch.manual_seed(int(seed))
        model = module.SelfAttention(config.num_attention_heads, int(input_features),
            config.hidden_size, output_dim=1, kernel_size=config.kernel_size,
            hidden_dropout_prob=config.hidden_dropout_prob,
            attention_probs_dropout_prob=config.attention_probs_dropout_prob,
            learning_rate=config.learning_rate)
    return model.to(device)


def paired_modules(author, gpnb):
    lookup = {r["id"]: gpnb._modules[str(r.get("module_index", r["index"]))]
              for r in gpnb.plan["layers"]}
    attention = lookup["attention"]
    return {"cnn": (author.cnn, lookup["conv"]),
            "query": (author.query, attention.query),
            "key": (author.key, attention.key),
            "value": (author.value, attention.value),
            "dense": (author.dense, attention.projection),
            "LayerNorm": (author.LayerNorm, lookup["normalize"]),
            "out": (author.out, lookup["regression"])}


def copy_author_to_gpnb(author, gpnb):
    """Copy weights rather than assuming constructor-order RNG equivalence."""
    for origin, target in paired_modules(author, gpnb).values():
        target.load_state_dict(origin.state_dict(), strict=True)
    return gpnb


def paired_parameters(author, gpnb):
    for layer, (origin, target) in paired_modules(author, gpnb).items():
        right = dict(target.named_parameters())
        for name, parameter in origin.named_parameters():
            yield f"{layer}.{name}", parameter, right[name]


def make_optimizer(model, config=None):
    """Explicit PyTorch Adam defaults used by the source, with raw-target MSE."""
    config = config or CropformerConfig()
    return torch.optim.Adam(model.parameters(), lr=config.learning_rate,
                            betas=(.9, .999), eps=1e-8, weight_decay=0, amsgrad=False)


def encode_a1_dosages(dosages, allele1, allele2):
    """Translate BIM A1 dosage only when authentic uppercase A/C/G/T exist.

    Deliberately does not uppercase A/a placeholders or infer unknown alleles.
    Missing/imputed/continuous dosages are not supported by the source codec.
    """
    x = np.asarray(dosages)
    a1, a2 = np.asarray(allele1).astype(str), np.asarray(allele2).astype(str)
    if x.ndim != 2 or a1.shape != (x.shape[1],) or a2.shape != a1.shape:
        raise ValueError("Expected aligned dosage [samples,markers] and two allele arrays")
    if not np.isin(a1, ["A", "C", "G", "T"]).all() or not np.isin(a2, ["A", "C", "G", "T"]).all():
        raise ValueError("Authentic uppercase A/C/G/T alleles required; A/a placeholders cannot be recovered")
    if not np.isin(x, [0, 1, 2]).all():
        raise ValueError("Author encoding requires complete diploid hard calls 0,1,2")
    lookup = np.array([[NUCLEOTIDE_CODES[b+b], NUCLEOTIDE_CODES[a+b], NUCLEOTIDE_CODES[a+a]]
                       for a, b in zip(a1, a2)], dtype=np.uint8)
    return lookup[np.arange(x.shape[1])[None, :], x.astype(np.int64)]


class FoldPreprocessor:
    """Source MI selector + zero padding + StandardScaler, fit on train only.

    Despite author class name MICSelector, the actual estimator is sklearn
    mutual_info_regression (continuous default), NOT maximal information
    coefficient. Selection order deliberately matches source np.argsort.
    """
    def __init__(self, target_features=10000, seed=42, *, encoding=ENCODING, n_jobs=1):
        self.target_features, self.seed = int(target_features), int(seed)
        if encoding not in SUPPORTED_ENCODINGS:
            raise ValueError("Unknown input encoding protocol")
        if not isinstance(n_jobs, int) or n_jobs < 1:
            raise ValueError("Explicit positive n_jobs required; default1 matches author serial execution")
        self.encoding, self.n_jobs = encoding, n_jobs
        if self.target_features < 1:
            raise ValueError("target_features must be positive")

    def fit(self, x, y):
        from sklearn.feature_selection import mutual_info_regression
        from sklearn.preprocessing import StandardScaler
        x, y = np.asarray(x), np.asarray(y).reshape(-1)
        if x.ndim != 2 or len(x) != len(y) or len(y) < 4 or not np.isfinite(x).all() or not np.isfinite(y).all():
            raise ValueError("Finite aligned training arrays with >=4 samples required")
        validate_encoded_matrix(x, self.encoding)
        self.n_input_features_ = x.shape[1]
        # Original estimator consumes numpy global RNG for jitter. Seed and
        # restore it to make the author/GPNB pair use identical selection.
        state = np.random.get_state()
        try:
            np.random.seed(self.seed)
            from joblib.parallel import get_active_backend
            self.mi_backend_ = type(get_active_backend()[0]).__name__
            self.scores_ = mutual_info_regression(x, y, n_jobs=self.n_jobs)
        finally:
            np.random.set_state(state)
        self.indices_ = np.argsort(self.scores_)[-self.target_features:]
        self.scaler_ = StandardScaler().fit(self._selected_padded(x))
        return self

    def _selected_padded(self, x):
        x = np.asarray(x)
        if x.ndim != 2 or x.shape[1] != self.n_input_features_ or not np.isfinite(x).all():
            raise ValueError("Prediction features differ from finite training features")
        validate_encoded_matrix(x, self.encoding)
        chosen = x[:, self.indices_]
        return np.pad(chosen, ((0, 0), (0, max(0, self.target_features-chosen.shape[1]))))

    def transform(self, x):
        return self.scaler_.transform(self._selected_padded(x)).astype(np.float32)

    def metadata(self):
        return {"estimator": "sklearn.mutual_info_regression(default continuous)",
                "fit_partition": "training only", "seed": self.seed,
                "target_features": self.target_features, "input_features": self.n_input_features_,
                "selected_indices": self.indices_.tolist(),
                "scaler_mean": self.scaler_.mean_.tolist(), "scaler_scale": self.scaler_.scale_.tolist(),
                "target_transform": "none", "encoding": self.encoding,
                "allowed_input_values": [0,1,2] if self.encoding == ANONYMOUS_DOSAGE else list(range(10)),
                "encoding_role": "new-study anonymous dosage adaptation" if self.encoding == ANONYMOUS_DOSAGE else "original nucleotide protocol",
                "mi_n_jobs": self.n_jobs, "mi_backend": self.mi_backend_,
                "extra_maf_filter": False, "padding": "right zero"}


def fit_preprocessed(model, x_train, y_train, *, config=None, epochs=20,
                     x_valid=None, y_valid=None, patience=5, seed=42, device="cpu"):
    """Shared source-style loop. Validation is explicitly NOT outer test data.

    With no validation this is the fixed-20-epoch inner objective. With
    validation, source correlation scheduler/early-stop are routed to an
    independent inner validation set; best state is returned. The caller may
    instead use its selected epoch count to refit all outer training samples.
    """
    config = config or CropformerConfig()
    config.validate()
    if epochs < 1 or (x_valid is None) != (y_valid is None):
        raise ValueError("Positive epoch budget and paired validation arrays required")
    model.to(device)
    x = torch.as_tensor(np.asarray(x_train), dtype=torch.float32, device=device)
    y = torch.as_tensor(np.asarray(y_train).reshape(-1, 1), dtype=torch.float32, device=device)
    if x.shape[0] != y.shape[0] or not torch.isfinite(x).all() or not torch.isfinite(y).all():
        raise ValueError("Invalid training arrays")
    # A private generator keeps shuffles paired independently of model RNG.
    generator = torch.Generator().manual_seed(int(seed))
    loader = torch.utils.data.DataLoader(torch.utils.data.TensorDataset(x, y),
        batch_size=config.batch_size, shuffle=True, generator=generator, num_workers=0)
    optimizer = make_optimizer(model, config)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode="min", factor=.1, patience=10)
    loss_fn = torch.nn.MSELoss()
    vx = None if x_valid is None else torch.as_tensor(np.asarray(x_valid), dtype=torch.float32, device=device)
    vy = None if y_valid is None else np.asarray(y_valid).reshape(-1)
    torch.manual_seed(int(seed))
    if str(device).startswith("cuda"):
        torch.cuda.manual_seed_all(int(seed)); torch.cuda.synchronize()
    started = time.perf_counter()
    history, best_state, best_score, best_epoch, stale = [], None, -float("inf"), 0, 0
    for epoch in range(1, int(epochs)+1):
        model.train()
        loss_sum = torch.zeros((), device=device)
        for bx, by in loader:
            optimizer.zero_grad()
            loss = loss_fn(model(bx), by)
            loss.backward()
            optimizer.step()
            loss_sum += loss.detach() * len(bx)
        record = {"epoch": epoch, "train_mse": float(loss_sum/len(x)), "lr": optimizer.param_groups[0]["lr"]}
        if vx is not None:
            prediction = predict_preprocessed(model, vx, batch_size=config.batch_size, device=device)
            score = float(np.corrcoef(prediction, vy)[0, 1])
            if not np.isfinite(score):
                raise ValueError("Undefined validation correlation; do not select on test labels")
            scheduler.step(-score)
            record["validation_pearson"] = score
            if score > best_score:
                best_score, best_epoch = score, epoch
                best_state = {k: v.detach().clone() for k, v in model.state_dict().items()}
            # Author EarlyStopping treats equality as improvement.
            previous = max((h["validation_pearson"] for h in history), default=-float("inf"))
            stale = stale+1 if score < previous else 0
        history.append(record)
        if vx is not None and stale >= patience:
            break
    if best_state is not None:
        model.load_state_dict(best_state)
    if str(device).startswith("cuda"):
        torch.cuda.synchronize()
    return {"history": history, "selected_epoch": best_epoch or len(history),
            "fit_seconds": time.perf_counter()-started, "epochs_completed": len(history),
            "selection_partition": "inner validation" if vx is not None else "fixed epochs",
            "target_scaling": "none", "optimizer": {"name": "Adam", "lr": config.learning_rate,
            "betas": [.9, .999], "eps": 1e-8, "weight_decay": 0},
            "shuffle_rng": "private seeded torch generator (paired protocol addition)"}


def predict_preprocessed(model, x, *, batch_size=32, device="cpu"):
    model.eval()
    tensor = x if isinstance(x, torch.Tensor) else torch.as_tensor(np.asarray(x), dtype=torch.float32)
    predictions = []
    with torch.no_grad():
        for start in range(0, len(tensor), batch_size):
            predictions.append(model(tensor[start:start+batch_size].to(device)).reshape(-1).cpu().numpy())
    return np.concatenate(predictions)


def score_inner_fold(x_train_encoded, y_train, x_valid_encoded, y_valid, *,
                     encoding, config=None, implementation="gpnb", author_source,
                     seed=42, device="cpu"):
    """Inner-search API deliberately has no outer-test or outer-test-label input.

    Feature selection and scaling use x_train_encoded/y_train exclusively.
    Validation only scores the fixed 20-epoch fit. The caller aggregates three
    fold scores and chooses candidates before final fitting/test prediction.
    """
    validate_encoded_matrix(x_train_encoded, encoding)
    validate_encoded_matrix(x_valid_encoded, encoding)
    if implementation not in ("gpnb", "author"):
        raise ValueError("implementation must be gpnb or author")
    config = config or CropformerConfig()
    started = time.perf_counter()
    preprocess = FoldPreprocessor(config.target_features, seed, encoding=encoding).fit(x_train_encoded, y_train)
    train, valid = preprocess.transform(x_train_encoded), preprocess.transform(x_valid_encoded)
    preprocessing_seconds = time.perf_counter()-started
    author = load_author_cropformer(train.shape[1], config, source_path=author_source, seed=seed, device=device)
    model = author if implementation == "author" else copy_author_to_gpnb(author, build_gpnb_cropformer(train.shape[1], config, seed=seed, device=device, encoding=encoding))
    training = fit_preprocessed(model, train, y_train, config=config, epochs=20, seed=seed, device=device)
    model.eval()
    losses = []
    with torch.no_grad():
        for start in range(0, len(valid), config.batch_size):
            x = torch.as_tensor(valid[start:start+config.batch_size], device=device)
            y = torch.as_tensor(np.asarray(y_valid).reshape(-1, 1)[start:start+config.batch_size], dtype=torch.float32, device=device)
            losses.append(float(torch.nn.functional.mse_loss(model(x), y)))
    return {"inner_validation_mean_batch_mse": float(np.mean(losses)),
            "training": training, "preprocessing_seconds": preprocessing_seconds,
            "preprocessor": preprocess.metadata(), "implementation": implementation,
            "outer_test_accessed": False, "model_config": asdict(config)}
