"""Fresh destination checks at task launch, without numerical probes."""
import shutil,tempfile
from pathlib import Path
from .config import fail

def validate_destination(output):
    output=Path(output).resolve()
    if output.exists():fail('E_EXISTS',str(output),'choose a new output directory')
    parent=output.parent
    parent.mkdir(parents=True,exist_ok=True)
    if shutil.disk_usage(parent).free<32*2**20:fail('E_DISK',str(parent),'less than 32 MiB available; free disk space before training')
    try:
        with tempfile.TemporaryFile(dir=parent) as stream:stream.write(b'GPNB output permission probe')
    except OSError as error:fail('E_IO',str(parent),str(error))
