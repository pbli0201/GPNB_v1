"""Export the internal selection evidence and the final refitted predictor together."""
from pathlib import Path
import copy
import shutil

from .bundle import safe_member, seal, verify_bundle
from .config import ProjectSpec
from .data.files import read_json, write_json
from .training.core import check_cancel


def export_final_refit(bundle, output, *, include_data=False, max_parameter_bytes=256*2**20,
                       progress=None, cancelled=None):
    from .exporting import export_run
    bundle, output = Path(bundle).resolve(), Path(output).resolve()
    verify_bundle(bundle, 'final_refit', ('summary.json', 'project_original.json'))
    summary = read_json(bundle/'summary.json')
    report = export_run(safe_member(bundle, summary['model_directory']), output,
        include_data=include_data, max_parameter_bytes=max_parameter_bytes, progress=progress, cancelled=cancelled)
    (output/'INCOMPLETE').write_text('Final model evidence export in progress\n', encoding='utf-8')
    try:
        selection = safe_member(bundle, summary['internal_selection_directory'])
        manifest = verify_bundle(selection, 'training_run')
        for name in [*manifest['files'], 'complete.json']:
            check_cancel(cancelled)
            target = safe_member(output/'selection', name)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(safe_member(selection, name), target)
        write_json(output/'final_refit_summary.json', summary)
        if include_data:
            portable = read_json(output/'project.json')
            original = read_json(bundle/'project_original.json')
            # Use original architecture/search request, but the exported copies of
            # every genotype, observation and numeric-table source for fresh selection.
            original['data'] = copy.deepcopy(portable['data'])
            original['output_dir'] = 'results'
            original['run']['split']['reuse_manifest'] = None
            if portable.get('extensions', {}).get('input_tables'):
                original.setdefault('extensions', {})['input_tables'] = portable['extensions']['input_tables']
            ProjectSpec(original).save(output/'project.json', overwrite=True)
        report['final_refit'] = dict(protocol=summary['provenance']['protocol'],
            selection_evidence='selection', final_model='run',
            retraining='Fresh internal selection then all eligible data; original outer CV is not rerun',
            independent_test_metrics=None)
        write_json(output/'export.json', report)
        verify_bundle(bundle, 'final_refit')
        check_cancel(cancelled)
        seal(output, 'exported_run')
        (output/'INCOMPLETE').unlink()
        return report
    except BaseException as error:
        write_json(output/'failure.json', dict(ok=False, error=str(error)))
        raise
