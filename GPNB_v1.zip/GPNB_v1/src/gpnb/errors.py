"""Stable error codes shared by CLI and the future GUI."""
from __future__ import annotations

MESSAGES = {
    "E_JSON": ("JSON 格式无效或存在重复键", "Invalid JSON or duplicate key"),
    "E_VERSION": ("不支持此配置版本", "Unsupported schema version"),
    "E_FIELD": ("字段缺失或未知", "Missing or unknown field"),
    "E_TYPE": ("字段类型错误", "Incorrect field type"),
    "E_RANGE": ("数值超出允许范围", "Value outside the allowed range"),
    "E_VALUE": ("字段值或组合不合法", "Invalid value or combination"),
    "E_IO": ("无法读取或写入文件", "Cannot read or write file"),
    "E_EXISTS": ("目标已存在，拒绝覆盖", "Destination exists; refusing to overwrite"),
    "E_LIMIT": ("超出小型夹具生成器的范围", "Outside the small fixture generator limits"),
    "E_FORMAT": ("数据格式或配套文件不合法", "Invalid data format or companion files"),
    "E_DUPLICATE": ("发现重复标识", "Duplicate identifier"),
    "E_TRAIT": ("所选性状含非数值或无效数值", "Selected trait contains invalid numeric values"),
    "E_MANIFEST": ("数据与来源清单不一致", "Data does not match its source manifest"),
    "E_GROUP": ("分组文件不完整或不一致", "Incomplete or inconsistent grouping file"),
    "E_CHANGED": ("读取过程中输入文件发生变化", "Input changed during reading"),
    "E_CACHE": ("缓存不完整或校验失败", "Incomplete or corrupt cache"),
    "E_SPLIT": ("划分不兼容或违反分组约束", "Incompatible split or violated group constraint"),
    "E_PREPROCESS": ("预处理状态、输入或筛选结果不合法", "Invalid preprocessing state, input or filter result"),
    "E_MODEL": ("模型结构或输入形状不合法", "Invalid model structure or input shape"),
    "E_PORT": ("部件端口、轴或张量类型不兼容", "Incompatible component port, axis or tensor type"),
    "E_GRAPH": ("图定义、节点映射或边策略不合法", "Invalid graph definition, node mapping or edge policy"),
    "E_INPUT_TABLE": ("额外输入表、个体匹配或拟合状态不合法", "Invalid additional input table, sample mapping or fitted state"),
    "E_REFERENCE": ("个体参考图协议、身份或资源预算不合法", "Invalid individual reference graph protocol, identity or resource budget"),
    "E_MODEL_LIMIT": ("模型存储或中间计算超过显式预算", "Model storage or intermediate computation exceeds explicit budget"),
    "E_TRAIN": ("训练或评估数据、数值不合法", "Invalid training/evaluation data or numerical result"),
    "E_DEVICE": ("请求的计算设备不可用", "Requested compute device unavailable"),
    "E_PREFLIGHT": ("运行前检查未通过或已失效，请重新检查", "Preflight failed or expired; run checks again"),
    "E_SEARCH": ("参数搜索配置或候选训练不合法", "Invalid search configuration or candidate training"),
    "E_CANCELLED": ("任务已取消，未标记为成功", "Task cancelled; not marked successful"),
    "E_BUNDLE": ("模型归档不完整、损坏或内容不一致", "Incomplete, corrupt or inconsistent model archive"),
    "E_MARKER": ("预测数据标记或等位基因编码不兼容", "Incompatible prediction markers or allele encoding"),
}


class GPNBError(ValueError):
    def __init__(self, code: str, path: str, detail: str):
        self.code, self.path, self.detail = code, path, detail
        super().__init__(f"{code} {path}: {detail}")

    def as_dict(self, language="zh_CN"):
        zh, en = MESSAGES[self.code]
        return {"code": self.code, "path": self.path,
                "message": zh if language == "zh_CN" else en, "detail": self.detail}
