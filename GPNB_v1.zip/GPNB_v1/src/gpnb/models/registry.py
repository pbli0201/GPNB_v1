"""Closed, versioned component contracts. Static checks never allocate torch tensors."""
from __future__ import annotations

from dataclasses import dataclass

from ..config import boolean, choice, fail, number, object_fields, sequence, text


@dataclass(frozen=True)
class TensorType:
    kind: str
    dimensions: tuple[int, ...]  # batch is implicit and cannot be edited

    def __post_init__(self):
        ranks = {"Vector": 1, "Channels": 2, "Sequence": 2, "Graph": 2, "Grid": 3, "Mask": 1, "Categorical": 1}
        if self.kind not in ranks or len(self.dimensions) != ranks[self.kind]:
            fail("E_PORT", "shape", "unsupported tensor kind or rank")
        for d in self.dimensions:
            number(d, "shape.dimension", 1, 2**31 - 1, integer=True)

    @property
    def shape(self):
        return ["batch", *self.dimensions]

    def to_dict(self):
        return {"kind": self.kind, "shape": self.shape}


@dataclass(frozen=True)
class Parameter:
    type: str
    default: object
    minimum: float | None = None
    maximum: float | None = None
    choices: tuple = ()

    def validate(self, value, path):
        if self.type == "bool":
            boolean(value, path)
        elif self.type in ("int", "float"):
            number(value, path, self.minimum, self.maximum, integer=self.type == "int")
        elif self.type == "choice":
            choice(value, path, self.choices)
        elif self.type == "integers":
            sequence(value, path)
            for i, v in enumerate(value):
                number(v, f"{path}[{i}]", self.minimum, self.maximum, integer=True)
        else:
            fail("E_TYPE", path, "unknown registered parameter type")

    def to_dict(self):
        return dict(type=self.type, default=self.default, minimum=self.minimum,
                    maximum=self.maximum, choices=list(self.choices))


@dataclass(frozen=True)
class Component:
    name: str
    parameters: dict[str, Parameter]
    input_kinds: tuple[str, ...] = ("Vector",)
    implementation_version: int = 1
    ports: tuple[str, ...] = ("x",)

    def validate(self, params, path):
        object_fields(params, path, tuple(self.parameters))
        for key, definition in self.parameters.items():
            definition.validate(params[key], f"{path}.{key}")
        if self.name == "BatchNorm1d" and not params["track_running_stats"]:
            fail("E_MODEL", path, "BatchNorm1d requires saved running statistics for batch-independent prediction")

    def defaults(self):
        return {k: p.default for k, p in self.parameters.items()}

    def describe(self):
        return dict(type=self.name, implementation_version=self.implementation_version,
                    backend="pytorch", parameters={k: v.to_dict() for k, v in self.parameters.items()},
                    inputs={p: ["Mask"] if p.endswith("mask") else ["Vector"] if p in ("gate", "weight")
                            else list(self.input_kinds) for p in self.ports}, output="inferred",
                    devices=["cpu", "cuda"], dtype="float32", exporter="resolved_pytorch",
                    status="implemented", semantics="batch axis is preserved",
                    numerical_implementation=("exact adaptive bins using native slice/mean/stack"
                                              if self.name == "AdaptiveAvgPool1d" else "native module or registered formula"),
                    restrictions=(["CUDA strict determinism is disabled by default for models using this pool; explicit strict mode is rejected"] if self.name == "AdaptiveMaxPool1d" else []))

    def resolve(self, incoming, params, path):
        if incoming.kind not in self.input_kinds:
            fail("E_PORT", path, f"{self.name} requires {self.input_kinds}, received {incoming.kind}")
        kwargs, output, count = dict(params), incoming, 0
        if self.name == "Linear":
            width = incoming.dimensions[-1]
            kwargs = dict(in_features=width, **params)
            output = TensorType(incoming.kind, (*incoming.dimensions[:-1], params["out_features"]))
            count = width * params["out_features"] + params["out_features"] * params["bias"]
        elif self.name not in ("Dropout", "ReLU", "GELU", "Tanh", "Sigmoid"):
            from .shapes import resolve_component
            return resolve_component(self.name, incoming, params, path)
        return kwargs, output, count, 0


COMPONENTS = {
    c.name: c for c in (
        Component("Linear", {"out_features": Parameter("int", 32, 1, 2**31 - 1),
                             "bias": Parameter("bool", True)}),
        Component("Dropout", {"p": Parameter("float", .2, 0, 1)}),
        *(Component(name, {}) for name in ("ReLU", "GELU", "Tanh", "Sigmoid")),
    )
}

FLOAT_LAYOUTS = ("Vector", "Channels", "Sequence")
for _name in ("Linear", "Dropout", "ReLU", "GELU", "Tanh", "Sigmoid"):
    old = COMPONENTS[_name]
    # Linear acts on the last dimension; restrict Channels to an explicit layout conversion.
    layouts = ("Vector", "Sequence") if _name == "Linear" else FLOAT_LAYOUTS
    COMPONENTS[_name] = Component(_name, old.parameters, layouts)


def _register(name, params, kinds=FLOAT_LAYOUTS):
    COMPONENTS[name] = Component(name, params, kinds)


_positive = lambda default: Parameter("int", default, 1, 2**31 - 1)
_eps = Parameter("float", 1e-5, 1e-12, 1.)
for _name in ("Identity", "SiLU", "ELU", "SELU", "Softplus", "Softsign"):
    _register(_name, {})
_register("LeakyReLU", {"negative_slope": Parameter("float", .01, 0, 1)})
_register("PReLU", {"init": Parameter("float", .25, 0, 1)})
_register("AlphaDropout", {"p": Parameter("float", .2, 0, 1)})
_register("Dropout1d", {"p": Parameter("float", .2, 0, 1)}, ("Channels",))
_register("ToChannels", {}, ("Vector",))
_register("SingleToken", {}, ("Vector",))
_register("MarkerChunk", {"parts": _positive(5), "index": Parameter("int", 0, 0, 2**31-1)}, ("Vector",))
_register("Pad1d", {"left": Parameter("int", 0, 0, 2**31-1), "right": Parameter("int", 0, 0, 2**31-1)}, ("Channels",))
_register("Flatten", {})
_register("Reshape", {"shape": Parameter("integers", [1, 12], 1, 2**31 - 1),
                      "layout": Parameter("choice", "Channels", choices=FLOAT_LAYOUTS)})
_register("Permute", {"axes": Parameter("integers", [1, 0], 0, 1),
                      "layout": Parameter("choice", "Sequence", choices=("Channels", "Sequence"))},
          ("Channels", "Sequence"))
for _name in ("Conv1d", "DepthwiseSeparableConv1d", "CausalConv1d", "LocallyConnected1d"):
    _params = dict(out_channels=_positive(8), kernel_size=_positive(3), stride=_positive(1),
                   dilation=_positive(1), bias=Parameter("bool", True))
    if _name not in ("CausalConv1d", "LocallyConnected1d"):
        _params["padding"] = Parameter("int", 0, 0, 2**31 - 1)
    if _name == "LocallyConnected1d":
        _params.update(padding_left=Parameter("int", 0, 0, 2**31 - 1),
                       padding_right=Parameter("int", 0, 0, 2**31 - 1),
                       boundary=Parameter("choice", "file_order", choices=("file_order",)))
    if _name == "Conv1d":
        _params["groups"] = _positive(1)
    _register(_name, _params, ("Channels",))
for _name in ("MaxPool1d", "AvgPool1d"):
    _params = dict(kernel_size=_positive(2), stride=_positive(2),
                   padding=Parameter("int", 0, 0, 2**31 - 1), ceil_mode=Parameter("bool", False))
    if _name == "MaxPool1d":
        _params["dilation"] = _positive(1)
    else:
        _params["count_include_pad"] = Parameter("bool", True)
    _register(_name, _params, ("Channels",))
for _name in ("AdaptiveAvgPool1d", "AdaptiveMaxPool1d"):
    _register(_name, {"output_size": _positive(1)}, ("Channels",))
_register("GlobalPool1d", {"mode": Parameter("choice", "mean", choices=("mean", "sum", "max"))},
          ("Channels",))
_register("BatchNorm1d", dict(eps=_eps, momentum=Parameter("float", .1, 0, 1),
                            affine=Parameter("bool", True), track_running_stats=Parameter("bool", True)),
          ("Vector", "Channels"))
_register("KerasBatchNorm1d", dict(eps=Parameter("float", .001, 1e-12, 1.),
                                 momentum=Parameter("float", .99, 0, 1),
                                 affine=Parameter("bool", True)), ("Vector", "Channels"))
_register("InstanceNorm1d", dict(eps=_eps, momentum=Parameter("float", .1, 0, 1),
                               affine=Parameter("bool", True), track_running_stats=Parameter("bool", False)),
          ("Channels",))
_register("GroupNorm", dict(num_groups=_positive(1), eps=_eps, affine=Parameter("bool", True)), ("Channels",))
for _name in ("LayerNorm", "RMSNorm"):
    _register(_name, dict(eps=_eps, elementwise_affine=Parameter("bool", True)))

for _name in ("Add", "Multiply", "Concat"):
    COMPONENTS[_name] = Component(_name, {"axis": _positive(1)} if _name == "Concat" else {},
                                  FLOAT_LAYOUTS, ports=("a", "b"))

_register("ToSequence", {}, ("Vector",))
_register("SequenceReadout", {"mode": Parameter("choice", "mean", choices=("mean", "sum", "max", "first", "last"))},
          ("Sequence",))
for _name in ("RNN", "LSTM", "GRU"):
    _params = dict(hidden_size=_positive(16), num_layers=_positive(1), bias=Parameter("bool", True),
                   bidirectional=Parameter("bool", False), dropout=Parameter("float", 0., 0, 1),
                   readout=Parameter("choice", "sequence", choices=("sequence", "final_state")))
    if _name == "RNN":
        _params["nonlinearity"] = Parameter("choice", "tanh", choices=("tanh", "relu"))
    _register(_name, _params, ("Sequence",))

_register("GenotypeEmbedding", {"embedding_dim": _positive(8)}, ("Categorical",))
_token_params = dict(patch_size=_positive(4), pad_tokens=Parameter("int", 0, 0, 2**31 - 1))
_register("Tokenize", {**_token_params, "embedding_dim": _positive(16), "bias": Parameter("bool", True)}, ("Vector",))
_register("TokenMask", _token_params, ("Vector",))
_register("SequenceMask", {"valid_length": Parameter("int", -1, -1, 2**31 - 1)}, ("Sequence",))
_register("PositionEncoding", {"mode": Parameter("choice", "sinusoidal", choices=("sinusoidal", "learned")),
                               "max_length": _positive(4096)}, ("Sequence",))
_register("ClassToken", {}, ("Sequence",))
_register("PrependMask", {}, ("Mask",))
COMPONENTS["MaskedReadout"] = Component("MaskedReadout",
    {"mode": Parameter("choice", "mean", choices=("mean", "sum", "max"))}, ("Sequence",), ports=("x", "mask"))

_attention = dict(num_heads=_positive(4), dropout=Parameter("float", 0., 0, 1),
                  bias=Parameter("bool", True), causal=Parameter("bool", False),
                  max_score_elements=_positive(8_000_000))
COMPONENTS["SelfAttention"] = Component("SelfAttention", _attention, ("Sequence",), ports=("x", "mask"))
COMPONENTS["ProjectedAttention"] = Component("ProjectedAttention", {
    "hidden_size": _positive(64), "scale_dim": _positive(8), "dropout": Parameter("float", .5, 0, 1),
    "max_score_elements": _positive(8_000_000)}, ("Sequence",), ports=("x", "mask"))
COMPONENTS["TransformerEncoder"] = Component("TransformerEncoder",
    {**_attention, "num_layers": _positive(1), "dim_feedforward": _positive(64),
     "norm_first": Parameter("bool", True), "eps": _eps,
     "activation": Parameter("choice", "gelu", choices=("gelu", "relu"))}, ("Sequence",), ports=("x", "mask"))

COMPONENTS["CrossAttention"] = Component("CrossAttention", {k: v for k, v in _attention.items() if k != "causal"},
    ("Sequence",), ports=("query", "context", "query_mask", "context_mask"))
COMPONENTS["GatedAdd"] = Component("GatedAdd", {"bias": Parameter("bool", True)}, ("Vector", "Sequence"), ports=("a", "b"))
_register("SqueezeExcite1d", {"hidden_size": _positive(4)}, ("Channels",))
_register("GatedMLP", {"hidden_size": _positive(32), "bias": Parameter("bool", True),
                      "dropout": Parameter("float", 0., 0, 1)}, ("Vector", "Sequence"))
_register("TCNBlock", {"hidden_size": _positive(8), "kernel_size": _positive(3), "dilation": _positive(1),
                      "bias": Parameter("bool", True), "dropout": Parameter("float", 0., 0, 1)}, ("Channels",))
_register("DenseMoE", {"num_experts": Parameter("int", 3, 1, 128), "hidden_size": _positive(16),
                      "out_features": _positive(8), "dropout": Parameter("float", 0., 0, 1)}, ("Vector",))
COMPONENTS["AttentionPooling"] = Component("AttentionPooling", {"bias": Parameter("bool", True)}, ("Sequence",), ports=("x", "mask"))
COMPONENTS["MLPMixer"] = Component("MLPMixer", {"token_hidden": _positive(16), "channel_hidden": _positive(32),
    "dropout": Parameter("float", 0., 0, 1), "eps": _eps}, ("Sequence",), ports=("x", "mask"))
COMPONENTS["ApplyMask"] = Component("ApplyMask", {}, ("Sequence",), ports=("x", "mask"))
COMPONENTS["ChannelScale"] = Component("ChannelScale", {}, ("Channels",), ports=("x", "gate"))
COMPONENTS["ScaleByWeight"] = Component("ScaleByWeight", {}, ("Vector",), ports=("x", "weight"))
_register("Slice", {"axis": _positive(1), "start": Parameter("int", 0, 0, 2**31-1), "stop": _positive(1)})
_register("Softmax", {})
_register("OneMinus", {})

_message_limit = Parameter("int", 8_000_000, 1, 2**31-1)
_register("GraphInput", {}, ("Vector",))
_register("GCN", dict(out_features=_positive(16), bias=Parameter("bool", True),
                     max_message_elements=_message_limit), ("Graph",))
_register("GraphSAGE", dict(out_features=_positive(16), bias=Parameter("bool", True),
                           normalize=Parameter("bool", False), max_message_elements=_message_limit), ("Graph",))
_register("GIN", dict(out_features=_positive(16), eps=Parameter("float", 0., -10., 10.),
                     train_eps=Parameter("bool", True), max_message_elements=_message_limit), ("Graph",))
_register("GAT", dict(out_features=_positive(8), heads=Parameter("int", 2, 1, 128),
                     concat=Parameter("bool", True), bias=Parameter("bool", True),
                     negative_slope=Parameter("float", .2, 0., 1.),
                     dropout=Parameter("float", 0., 0., 1.), max_message_elements=_message_limit), ("Graph",))
_register("GraphReadout", {"mode": Parameter("choice", "mean", choices=("mean", "sum", "max", "attention"))}, ("Graph",))
_register("ReferenceGraphSAGE", dict(hidden_size=_positive(16), num_layers=Parameter("int", 2, 1, 8),
                                   bias=Parameter("bool", True), max_message_elements=_message_limit), ("Vector",))
for _name in ("Linear", "Identity", "Dropout", "ReLU", "GELU", "Tanh", "Sigmoid"):
    _old = COMPONENTS[_name]
    COMPONENTS[_name] = Component(_name, _old.parameters, (*_old.input_kinds, "Graph"))


from .experimental import register as _register_experimental
_register_experimental(Component, Parameter, COMPONENTS)
for _retired in ("DiagonalSSM", "LinearSplineKAN"):
    COMPONENTS.pop(_retired, None)
_register("AutoCorrelation", dict(num_heads=_positive(4), factor=Parameter("float", 2., .1, 16.),
    bias=Parameter("bool", True), max_elements=_positive(8_000_000)), ("Sequence",))
_register("SeriesDecomposition", dict(kernel_size=Parameter("int",25,1,1025),
    output=Parameter("choice","residual",choices=("residual","trend"))), ("Sequence",))
_register("ReconstructMarkers", {"bias": Parameter("bool", True)}, ("Vector",))


def component(name, path="type"):
    text(name, path)
    if name not in COMPONENTS:
        fail("E_MODEL", path, f"unregistered component: {name}")
    return COMPONENTS[name]


def regression_head(value):
    """Find the Linear head, allowing one explicit output Dropout in v2.

    Dropout preserves the regression width and is disabled for prediction.
    Other post-head operations are not implicitly accepted by this contract.
    This also supports incomplete GUI drafts by returning None.
    """
    layers = value.get("layers", [])
    if not layers:
        return None
    rows = {row["id"]: row for row in layers}
    last = rows.get(value.get("output", layers[-1]["id"]))
    if last is not None and last["type"] == "Dropout" and value.get("schema_version") == 2:
        last = rows.get(last.get("inputs", {}).get("x"))
    return last if last is not None and last["type"] == "Linear" else None


def validate_v2(value, path):
    object_fields(value, path, ("schema_version", "kind", "name", "task", "backend",
                               "input_layout", "layers"), ("extensions", "graph_mode", "output", "input_representation", "graph_spec",
                                                          "external_inputs", "individual_graph_spec", "reconstruction_output", "output_targets"))
    choice(value["kind"], path + ".kind", ("model",))
    choice(value["backend"], path + ".backend", ("pytorch",))
    choice(value["task"], path + ".task", ("single_trait_regression", "multi_target_regression"))
    output_width=1
    if value["task"]=="multi_target_regression":
        targets=value.get("output_targets")
        sequence(targets,path+".output_targets")
        for target in targets:
            text(target,path+".output_targets")
        if not 2<=len(targets)<=64 or len(set(targets))!=len(targets):
            fail("E_MULTITASK",path,"2..64 unique target identifiers required")
        if value.get("reconstruction_output"):
            fail("E_MULTITASK",path,"multi-target reconstruction training is not supported")
        output_width=len(targets)
    elif "output_targets" in value:
        fail("E_MULTITASK",path,"output_targets only applies to multi-target regression")
    choice(value["input_layout"], path + ".input_layout", ("batch_markers",))
    choice(value.get("input_representation", "standardized_dosage"), path + ".input_representation",
           ("standardized_dosage", "genotype_categories"))
    text(value["name"], path + ".name")
    if "reconstruction_output" in value:
        text(value["reconstruction_output"],path+".reconstruction_output")
        if value.get("graph_mode") != "dag" or value.get("input_representation","standardized_dosage") != "standardized_dosage":
            fail("E_AUXILIARY",path,"reconstruction requires explicit DAG and continuous dosage input")
    external = value.get("external_inputs", {})
    if type(external) is not dict:
        fail("E_INPUT_TABLE", path+".external_inputs", "expected input name -> numeric width mapping")
    import re
    for name, width in external.items():
        if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,47}", name):
            fail("E_INPUT_TABLE", path+".external_inputs", "invalid input identifier")
        number(width, path+".external_inputs."+name, 1, 4096, integer=True)
    if external and value.get("graph_mode") != "dag":
        fail("E_INPUT_TABLE", path, "multiple input branches require explicit DAG mode")
    if "graph_spec" in value:
        from ..graphs.spec import GraphSpec
        GraphSpec(value["graph_spec"])
    if "individual_graph_spec" in value:
        from ..graphs.individual import IndividualGraphSpec
        IndividualGraphSpec(value["individual_graph_spec"])
        if value.get("input_representation", "standardized_dosage") != "standardized_dosage":
            fail("E_REFERENCE", path, "individual reference graph requires continuous genotype input")
    if "extensions" in value and type(value["extensions"]) is not dict:
        fail("E_TYPE", path + ".extensions", "expected object")
    sequence(value["layers"], path + ".layers")
    mode = value.get("graph_mode", "sequential")
    choice(mode, path + ".graph_mode", ("sequential", "dag"))
    previous, ids = "$input", set()
    for i, layer in enumerate(value["layers"]):
        loc = f"{path}.layers[{i}]"
        object_fields(layer, loc, ("id", "type", "implementation_version", "inputs", "params"), ("share_with",))
        text(layer["id"], loc + ".id")
        if layer["id"] in ids or layer["id"] in {"$input", *("$input:"+name for name in external)}:
            fail("E_MODEL", loc + ".id", "duplicate or reserved layer ID")
        definition = component(layer["type"], loc + ".type")
        if type(layer["implementation_version"]) is not int or layer["implementation_version"] != definition.implementation_version:
            fail("E_VERSION", loc, "unsupported component implementation version")
        object_fields(layer["inputs"], loc + ".inputs", definition.ports)
        for port, source in layer["inputs"].items():
            text(source, loc + ".inputs." + port)
        if mode == "sequential" and (definition.ports != ("x",) or layer["inputs"]["x"] != previous):
            fail("E_PORT", loc + ".inputs.x", "sequential v2 requires the immediately preceding output")
        if "share_with" in layer:
            text(layer["share_with"], loc + ".share_with")
            if mode != "dag":
                fail("E_MODEL", loc, "shared calls require explicit dag mode")
        definition.validate(layer["params"], loc + ".params")
        ids.add(layer["id"])
        previous = layer["id"]
    from .dag import execution_order
    execution_order(value)
    head = regression_head(value)
    if head is None or head["params"]["out_features"] != output_width:
        fail("E_MODEL", path + ".layers", f"regression head must be Linear(out_features={output_width}), optionally followed by one Dropout")


def resolve_v2(spec, input_features, graph_state=None, reference_state=None):
    from .dag import execution_order, resolve_merge
    from .blocks import BLOCK_NAMES, resolve_block
    from .graph import GRAPH_COMPONENTS, resolve_graph_layer
    from .experimental import NAMES as EXPERIMENTAL_NAMES, resolve as resolve_experimental
    value = spec.to_dict()
    reference_options = value.get("individual_graph_spec")
    if reference_state is not None:
        if reference_options is None:
            fail("E_REFERENCE", "reference_state", "state supplied without individual graph protocol")
        from ..graphs.individual import validate_reference_state
        validate_reference_state(reference_options, reference_state, input_features)
    topology = None
    if "graph_spec" in value:
        from ..graphs.state import resolve_graph, validate_state
        topology = validate_state(value["graph_spec"], graph_state or resolve_graph(value["graph_spec"]), input_features)
    elif graph_state is not None:
        fail("E_GRAPH", "graph_state", "frozen graph provided without model GraphSpec")
    representation = value.get("input_representation", "standardized_dosage")
    input_type = TensorType("Categorical" if representation == "genotype_categories" else "Vector", (input_features,))
    types = {"$input": input_type, **{"$input:"+name: TensorType("Vector", (width,))
                                    for name, width in value.get("external_inputs", {}).items()}}
    order = execution_order(value)
    by_id = {row["id"]: row for row in value["layers"]}
    indices = {row["id"]: i for i, row in enumerate(value["layers"])}
    resolved, total, buffers = {}, 0, 0
    for identifier in order:
        layer, i = by_id[identifier], indices[identifier]
        definition = component(layer["type"])
        ports = {port: types[source] for port, source in layer["inputs"].items()}
        incoming = ports.get("x", ports.get("query", next(iter(ports.values()))))
        if definition.name == "ReconstructMarkers":
            if incoming.kind != "Vector":
                fail("E_PORT",identifier,"ReconstructMarkers requires an encoded Vector")
            kwargs = dict(in_features=incoming.dimensions[0],out_features=input_features,**layer["params"])
            output,count,buffer_bytes = TensorType("Vector",(input_features,)), input_features*(incoming.dimensions[0]+layer["params"]["bias"]),0
        elif definition.name in EXPERIMENTAL_NAMES:
            if incoming.kind not in definition.input_kinds:
                fail("E_PORT", identifier, f"{definition.name} requires {definition.input_kinds}")
            kwargs, output, count, buffer_bytes = resolve_experimental(definition.name, ports, layer["params"], identifier)
        elif definition.name == "ReferenceGraphSAGE":
            if reference_options is None or incoming.kind != "Vector" or layer["inputs"]["x"] != "$input":
                fail("E_REFERENCE", identifier, "reference block requires explicit individual graph protocol and direct genotype input")
            p = layer["params"]
            h, depth = p["hidden_size"], p["num_layers"]
            count = 2*input_features*h + h*p["bias"] + (depth-1)*(2*h*h+h*p["bias"])
            kwargs, output, buffer_bytes = dict(in_features=input_features, **p), TensorType("Vector", (h,)), 0
        elif definition.name in GRAPH_COMPONENTS:
            if definition.name == "GraphInput" and layer["inputs"]["x"] != "$input":
                fail("E_GRAPH", identifier, "GraphInput must map the original retained-marker input")
            kwargs, output, count, buffer_bytes = resolve_graph_layer(definition.name, incoming, layer["params"], topology, identifier)
        elif definition.name in BLOCK_NAMES:
            kwargs, output, count, buffer_bytes = resolve_block(definition.name, ports, layer["params"], identifier)
        elif definition.name in ("MaskedReadout", "SelfAttention", "ProjectedAttention", "TransformerEncoder"):
            if ports["x"].kind != "Sequence" or ports["mask"] != TensorType("Mask", (ports["x"].dimensions[0],)):
                fail("E_PORT", identifier, "component needs Sequence and aligned Mask (True means padding)")
            if definition.name == "MaskedReadout":
                kwargs, output, count, buffer_bytes = dict(layer["params"]), TensorType("Vector", (ports["x"].dimensions[1],)), 0, 0
            else:
                from .attention import resolve_attention
                kwargs, output, count, buffer_bytes = resolve_attention(definition.name, ports["x"], layer["params"], identifier)
        elif definition.name in ("Add", "Multiply", "Concat"):
            kwargs, output, count, buffer_bytes = resolve_merge(definition.name, ports, layer["params"], f"layers[{i}]")
        else:
            kwargs, output, count, buffer_bytes = definition.resolve(incoming, layer["params"], f"layers[{i}]")
        resolved[identifier] = dict(index=i, id=layer["id"], type=layer["type"], constructor=definition.name,
                         implementation_version=definition.implementation_version, inputs=layer["inputs"],
                         kwargs=kwargs, input_type=incoming.to_dict(), output_type=output.to_dict(),
                         input_types={p: t.to_dict() for p, t in ports.items()},
                         input_shape=incoming.shape, output_shape=output.shape, parameters=count,
                         trainable_parameters=count, buffer_bytes=buffer_bytes, module_index=i)
        if definition.name in ("SelfAttention", "ProjectedAttention", "TransformerEncoder"):
            heads, length = layer["params"].get("num_heads", 1), ports["x"].dimensions[0]
            resolved[identifier]["attention_cost"] = {
                "score_elements_per_sample": heads * length * length,
                "one_float32_score_bytes_per_sample": 4 * heads * length * length,
                "stack_layers": layer["params"].get("num_layers", 1),
                "scope": "One materialized attention score tensor, not total memory or elapsed time.",
                "limit_elements_per_call": layer["params"]["max_score_elements"]}
        elif definition.name == "CrossAttention":
            size = layer["params"]["num_heads"] * ports["query"].dimensions[0] * ports["context"].dimensions[0]
            resolved[identifier]["attention_cost"] = dict(
                score_elements_per_sample=size, one_float32_score_bytes_per_sample=4*size, stack_layers=1,
                scope="One rectangular cross-attention score tensor, not total memory.",
                limit_elements_per_call=layer["params"]["max_score_elements"])
        types[identifier] = output
        if "max_elements" in layer["params"]:
            from math import prod
            size = prod(output.dimensions)
            resolved[identifier]["element_cost"] = dict(elements_per_sample=size,
                limit_elements_per_call=layer["params"]["max_elements"],
                scope="One output/basis/sequence tensor; excludes other activations, gradients and workspaces.")
        if "max_message_elements" in layer["params"] and definition.name != "ReferenceGraphSAGE":
            width = kwargs["out_features"] if definition.name in ("GCN", "GAT") else incoming.dimensions[-1]
            heads = kwargs.get("heads", 1)
            resolved[identifier]["graph_cost"] = dict(message_elements_per_sample=len(topology["edges"])*width*heads,
                limit_elements_per_call=kwargs["max_message_elements"],
                scope="One edge message tensor; not total memory. Topology shared across individuals.")
        if definition.name == "ReferenceGraphSAGE" and reference_state is not None:
            n, k = reference_state["feature_shape"][0], reference_state["neighbors"]
            resolved[identifier]["reference_cost"] = dict(reference_message_elements=n*k*layer["params"]["hidden_size"],
                query_message_elements_per_sample=k*layer["params"]["hidden_size"],
                limit_elements_per_call=layer["params"]["max_message_elements"])
    rows = [resolved[row["id"]] for row in value["layers"]]
    for row, layer in zip(rows, value["layers"]):
        if "share_with" in layer:
            owner = resolved[layer["share_with"]]
            if row["kwargs"] != owner["kwargs"]:
                fail("E_MODEL", row["id"], "shared calls require identical resolved dimensions and constructor")
            row.update(share_with=owner["id"], module_index=owner["index"], referenced_parameters=owner["parameters"],
                       parameters=0, trainable_parameters=0, buffer_bytes=0)
        total += row["parameters"]
        buffers += row["buffer_bytes"]
    if topology is not None:
        from ..graphs.state import topology_bytes
        buffers += topology_bytes(topology)
    output_id = value.get("output", value["layers"][-1]["id"])
    incoming = types[output_id]
    width=len(value.get("output_targets",[None]))
    if incoming != TensorType("Vector", (width,)):
        fail("E_MODEL", "output", f"regression requires Vector[batch,{width}], got {incoming.to_dict()}")
    auxiliary = value.get("reconstruction_output")
    if auxiliary and types[auxiliary] != TensorType("Vector",(input_features,)):
        fail("E_AUXILIARY","reconstruction_output","reconstruction must equal retained-marker input width")
    plan = dict(schema_version=2, kind="resolved_model", model_sha256=spec.sha256,
                name=value["name"], backend="pytorch", input_shape=["batch", input_features],
                input_type=input_type.to_dict(), input_representation=representation,
                graph_mode=value.get("graph_mode", "sequential"), execution_order=order, output=output_id,
                output_shape=incoming.shape, layers=rows, parameters=total, trainable_parameters=total,
                parameter_dtype="float32", parameter_bytes=4 * total, buffer_bytes=buffers,
                storage_scope="Parameter and buffer storage only; excludes activations, gradients and optimizer.")
    if topology is not None:
        plan["graph_state"] = topology
        if value["graph_spec"]["source"]["kind"] == "training_ld" and topology["ld_fit"] is None:
            # Preview uses a conservative storage upper bound, never a fabricated fitted edge count.
            bound = 20 * (2*value["graph_spec"]["max_edges"] + len(topology["nodes"])) + 16*len(topology["nodes"])
            plan["buffer_bytes"] += bound - topology_bytes(topology)
            plan["graph_unfitted"] = True
            plan["buffer_storage_scope"] = "Upper bound from edge budget; LD edges not fitted in architecture preview."
    if value.get("external_inputs"):
        plan["external_inputs"] = dict(value["external_inputs"])
    if auxiliary:
        plan["reconstruction_output"] = auxiliary
    if value.get("output_targets"):
        plan["output_targets"]=list(value["output_targets"])
    if reference_options is not None:
        if not any(row["type"] == "ReferenceGraphSAGE" for row in rows):
            fail("E_REFERENCE", "individual_graph_spec", "individual graph protocol requires a reference graph component")
        plan["reference_state"] = reference_state
        if reference_state is None:
            plan["reference_unfitted"] = True
            plan["buffer_bytes"] += 4*reference_options["max_reference_cells"] + 12*reference_options["max_reference_individuals"]*reference_options["neighbors"]
            plan["buffer_storage_scope"] = "Upper bound from reference limits; reference population not yet fitted."
        else:
            n, m = reference_state["feature_shape"]
            plan["buffer_bytes"] += 4*n*m + 12*n*reference_state["neighbors"]
    return plan
