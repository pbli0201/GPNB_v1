"""Evidence-bearing settings for editable paper architecture adaptations.

Never represents author-code or accuracy reproduction. No runtime dependency
on the research downloads; source coordinates travel in the saved project.
"""
import copy
from ..config import RunSpec, fail
from .paper_templates import paper_catalog, paper_template


def parameter_profile(name):
    record = next((r for r in paper_catalog() if r["id"] == name and r["available"]), None)
    if record is None:
        fail("E_MODEL", "paper_profile", "unknown available architecture")
    rows = []
    repo = f'https://github.com/{record["repository"]}/blob/{record["commit"]}/' if record.get("repository") else record["paper_url"]

    def add(key, original, applied, status, location, reason="", url=None):
        rows.append(dict(parameter=key, original=original, applied=applied, status=status,
                         source_url=url or repo+location.split(":")[0], location=location,
                         reason=reason, applies_to="GPNB single-input continuous single-target adaptation"))

    def code(values, location):
        for key, val in values.items():
            add(key, val, val, "author_code_version", location,
                "Native PyTorch implementation; optimizer/initialization equivalence across frameworks is not claimed.")

    if name == "DeepGS":
        code(dict(epochs=6000,batch_size=30,learning_rate=.01,momentum=.5,weight_decay=.00001,seed=0), "README.md:Training DeepGS model")
        add("optimizer", "MXNet FeedForward default SGD", "SGD", "gpnb_adaptation", "DeepGS_1.2.tar.gz:R/DeepGS.R:188-194", "Explicit PyTorch SGD; source omits optimizer argument.")
        add("loss", "LinearRegressionOutput", "mse", "gpnb_adaptation", "DeepGS_1.2.tar.gz:R/DeepGS.R:186", "Squared regression objective; eval_metric=mae is a reported metric, not the training objective.")
        add("patience", 600, None, "unsupported", "DeepGS_1.2.tar.gz:R/DeepGS.R:194", "MXNet callback metric/state differs; keep project validation-loss patience.")
    elif name == "GPformer":
        for key,val in dict(optimizer="Adam",learning_rate=.0001,weight_decay=.00001,batch_size=32,loss="focal_mae",focal_beta=.5,focal_gamma=1.).items():
            add(key,val,val,"paper_reported","Materials and methods / GPformer method, focal MAE equation and following paragraph",url=record["paper_url"])
        add("scheduler", "ExponentialLR; decay factor not reported", None, "unreported", "Methods / GPformer method", "Supported engine, but no factor can be inferred; preserve current schedule and flag partial application.",record["paper_url"])
    elif name == "WheatGP":
        code(dict(optimizer="Adam",learning_rate=.005,weight_decay=.0001,batch_size=64,epochs=300,loss="mse",gradient_clip_norm=1.,scheduler=dict(type="StepLR",step_size=90,gamma=.1)), "train.py:main / train_and_validate")
        add("patience",50,None,"unsupported","train.py:main / train_and_validate","Source selects validation Pearson; GPNB selects the configured validation loss. Keep project patience.")
    elif name == "DLGWAS":
        code(dict(optimizer="Adam",learning_rate=.001,loss="mse",batch_size=250,epochs=1000),"HEIGHT/height.py:86,146-152")
        add("patience",5,None,"unsupported","HEIGHT/height.py:147-152","Source monitors validation MAE; GPNB monitors its training objective. Keep project patience.")
        add("regularization", "per-layer kernel/bias penalties",None,"unsupported","HEIGHT/height.py:resnet","Not equivalent to one global weight decay.")
    elif name == "Cropformer":
        code(dict(optimizer="Adam",learning_rate=.001,weight_decay=0.,loss="mse",batch_size=32,epochs=100),"model.py:191-212,288-298")
        add("scheduler",dict(type="ReduceLROnPlateau",factor=.1,patience=10),None,"unsupported","model.py:193,230","Source passes outer-test correlation; excluded to preserve independent evaluation.")
    elif name == "DeepGP":
        code(dict(loss="mse"),"GP/MLP/mlp.py:65-75")
        add("optimizer_search",["Adam","Nadam","sgd"],None,"unsupported","GP/MLP/mlp.py:58-66","Talos normalizes learning rates. No single published best setting can be inferred.")
    elif name == "DNNGP":
        add("learning_rate",1,None,"unsupported","README.md:38-50","Post-publication README relies on a hidden internal schedule. Do not transplant lr=1 into native PyTorch.")
        add("preprocessing", "PCA / multi-omics",None,"unsupported","Paper Figure 1A","No PCA or multi-omics concatenation is applied automatically.",record["paper_url"])
    elif name == "deepGBLUP":
        add("joint_estimation","GBLUP / variance / heritability",None,"unsupported","README.md:main.py configuration","Only the neural subgraph is implemented; full training protocol is not applied.")

    covered = {r["parameter"] for r in rows}
    for key in ("optimizer","learning_rate","weight_decay","batch_size","epochs","loss","momentum","patience","seed","scheduler","gradient_clip_norm"):
        if key not in covered:
            add(key,None,None,"unreported","Audited sources / no transferable scalar", "Not established for this adaptation; retain current project setting.",record["paper_url"])
    # Inventory *all* effective structure parameters, distinguishing audited
    # topology from defaults that are not established in the publication.
    spec=paper_template(name).to_dict()
    for layer in spec["layers"]:
        for key,value in layer["params"].items():
            add("layers."+layer["id"]+"."+key,None,value,"gpnb_adaptation","GPNB architecture mapping v1", "Explicit editable mapping value; not asserted to be an author-reported scalar.",record["paper_url"])
    if name == "DNNGP":
        for row in rows:
            if row["parameter"].startswith("layers.") and (row["parameter"].endswith(".out_channels") or row["parameter"].endswith(".kernel_size")):
                row.update(status="paper_reported", original=row["applied"],location="Paper Figure 1A",reason="Three convolution layers: 64 channels, kernel 4.")
    return dict(name=name,profile_id=name+"-audited-partial-v1",version=1,review_date="2026-10-23",
                source_commit=record.get("commit"),paper_doi=record.get("doi"),parameters=rows,
                status="verified_partial",experiment_status="not_reproduced",
                scope="base architecture without KGM" if name=="GPformer" else "neural subgraph only" if name=="deepGBLUP" else "editable architecture adaptation")


def preview_preset(project,name,mode="verified",*,clear_stages=False):
    if mode not in ("verified","architecture"):
        fail("E_MODEL","paper_profile.mode","choose verified or architecture")
    if project.get("extensions",{}).get("input_tables") or project.get("extensions",{}).get("multitask"):
        fail("E_MODEL","paper_profile","Use a single-input, single-target project first; then explicitly adapt the architecture.")
    profile=parameter_profile(name)
    value=copy.deepcopy(project)
    original=value["run"]["training"]
    changes=[dict(parameter="model",before=value["model"]["name"],after=name)]
    blockers=[]
    if "stages" in original:
        if clear_stages:
            changes.append(dict(parameter="stages",before=original.pop("stages"),after=None))
        else:
            blockers.append("Existing stages may reference the previous architecture. Explicitly acknowledge their removal or cancel.")
    value["model"]=paper_template(name).to_dict()
    applied=[]
    if mode=="verified":
        for row in profile["parameters"]:
            key=row["parameter"]
            if key.startswith("layers.") or row["applied"] is None:
                continue
            changes.append(dict(parameter=key,before=original.get(key),after=row["applied"]))
            original[key]=copy.deepcopy(row["applied"])
            applied.append(key)
    preserved={k:copy.deepcopy(v) for k,v in original.items() if k not in applied}
    unsupported=[r for r in profile["parameters"] if r["status"] in ("unsupported","unreported")]
    audit=dict(profile=profile,mode=mode,status="verified_partial" if mode=="verified" else "architecture_only",
               applied_training_keys=applied,baseline_training=copy.deepcopy(original))
    value["model"].setdefault("extensions",{})["paper_preset"]=audit
    # Refresh only the GPNB baseline; never call it author implementation.
    baseline=copy.deepcopy(value["model"])
    baseline["extensions"].pop("template",None)
    from ..config import ModelSpec
    value["model"]["extensions"]["template"]["baseline"]=baseline
    value["model"]["extensions"]["template"]["baseline_sha256"]=ModelSpec(baseline).sha256
    if not blockers:
        RunSpec(value["run"])
    return dict(project=value,changes=changes,preserved=preserved,unsupported=unsupported,blockers=blockers,status=audit["status"])


def apply_preset(project,name,mode="verified",*,clear_stages=False):
    preview=preview_preset(project,name,mode,clear_stages=clear_stages)
    if preview["blockers"]:
        fail("E_MODEL","paper_profile"," ".join(preview["blockers"]))
    return preview["project"]
