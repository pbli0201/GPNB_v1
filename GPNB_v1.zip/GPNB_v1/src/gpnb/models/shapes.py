"""Exact non-batch dimensions and state storage; no torch import or allocation."""
from math import prod

from ..config import fail
from .registry import TensorType


def resolve_component(name, incoming, p, path):
    dims = incoming.dimensions
    kwargs, output, count, buffers = dict(p), incoming, 0, 0
    if name == "AutoCorrelation":
        if dims[-1] % p["num_heads"]:
            fail("E_PORT", path, "AutoCorrelation width must be divisible by heads")
        kwargs = dict(width=dims[-1], **p)
        count = 4 * (dims[-1] ** 2 + dims[-1] * p["bias"])
    elif name == "SeriesDecomposition":
        if p["kernel_size"] % 2 != 1:
            fail("E_PORT", path, "SeriesDecomposition requires an odd kernel")
    elif name == "ToChannels":
        output = TensorType("Channels", (1, dims[0]))
    elif name == "SingleToken":
        output = TensorType("Sequence", (1, dims[0]))
    elif name == "MarkerChunk":
        if p["index"] >= p["parts"] or p["parts"] > dims[0]:
            fail("E_PORT", path, "MarkerChunk requires index < parts <= retained marker count")
        width, extra = divmod(dims[0], p["parts"])
        start = width * p["index"] + min(p["index"], extra)
        size = width + int(p["index"] < extra)
        kwargs = dict(start=start, stop=start + size)
        output = TensorType("Vector", (size,))
    elif name == "Pad1d":
        output = TensorType("Channels", (dims[0], dims[1] + p["left"] + p["right"]))
    elif name == "ToSequence":
        output = TensorType("Sequence", (dims[0], 1))
    elif name == "SequenceReadout":
        output = TensorType("Vector", (dims[-1],))
    elif name == "GenotypeEmbedding":
        count = 4 * p["embedding_dim"]
        output = TensorType("Sequence", (dims[0], p["embedding_dim"]))
    elif name in ("Tokenize", "TokenMask"):
        valid = (dims[0] + p["patch_size"] - 1) // p["patch_size"]
        length = valid + p["pad_tokens"]
        kwargs = dict(input_features=dims[0], **p)
        if name == "Tokenize":
            count = p["patch_size"] * p["embedding_dim"] + p["embedding_dim"] * p["bias"]
            output = TensorType("Sequence", (length, p["embedding_dim"]))
        else:
            output = TensorType("Mask", (length,))
    elif name == "SequenceMask":
        if p["valid_length"] > dims[0]:
            fail("E_PORT", path, "valid_length exceeds sequence length")
        output = TensorType("Mask", (dims[0],))
    elif name == "PositionEncoding":
        if dims[0] > p["max_length"]:
            fail("E_PORT", path, "sequence exceeds explicit position capacity")
        kwargs = dict(embedding_dim=dims[1], **p)
        count = p["max_length"] * dims[1] if p["mode"] == "learned" else 0
        buffers = 4 * p["max_length"] * dims[1] if p["mode"] == "sinusoidal" else 0
    elif name == "ClassToken":
        kwargs = dict(embedding_dim=dims[1])
        output = TensorType("Sequence", (dims[0] + 1, dims[1]))
        count = dims[1]
    elif name == "PrependMask":
        output = TensorType("Mask", (dims[0] + 1,))
    elif name in ("RNN", "LSTM", "GRU"):
        length, width = dims
        hidden, directions = p["hidden_size"], 2 if p["bidirectional"] else 1
        if p["num_layers"] == 1 and p["dropout"] != 0:
            fail("E_MODEL", path, "recurrent dropout acts between layers; one layer requires dropout=0")
        gates = {"RNN": 1, "LSTM": 4, "GRU": 3}[name]
        count = directions * gates * hidden * (width + hidden + 2 * p["bias"])
        count += (p["num_layers"] - 1) * directions * gates * hidden * (directions * hidden + hidden + 2 * p["bias"])
        output = TensorType("Sequence", (length, directions * hidden)) if p["readout"] == "sequence" else TensorType("Vector", (directions * hidden,))
        kwargs = dict(input_size=width, **p)
    elif name == "Flatten":
        output = TensorType("Vector", (prod(dims),))
        kwargs = dict(start_dim=1, end_dim=-1)
    elif name == "Reshape":
        if prod(p["shape"]) != prod(dims):
            fail("E_PORT", path, "Reshape must preserve elements per individual")
        output = TensorType(p["layout"], tuple(p["shape"]))
        kwargs = dict(shape=list(p["shape"]))
    elif name == "Permute":
        if sorted(p["axes"]) != list(range(len(dims))):
            fail("E_PORT", path, "axes must permute only non-batch axes exactly once")
        output = TensorType(p["layout"], tuple(dims[i] for i in p["axes"]))
        kwargs = dict(axes=[0, *[i + 1 for i in p["axes"]]])
    elif name in ("Conv1d", "CausalConv1d", "DepthwiseSeparableConv1d", "LocallyConnected1d"):
        channels, length = dims
        kernel, dilation, stride = p["kernel_size"], p["dilation"], p["stride"]
        effective = dilation * (kernel - 1) + 1
        padding = p.get("padding", 0)
        total_padding = p.get("padding_left", padding) + p.get("padding_right", padding)
        after = (length - 1) // stride + 1 if name == "CausalConv1d" else (length + total_padding - effective) // stride + 1
        groups = p.get("groups", 1)
        out = p["out_channels"]
        if channels % groups or out % groups:
            fail("E_PORT", path, "Conv1d groups must divide both inferred input and output channels")
        if after < 1:
            fail("E_PORT", path, f"convolution sequence length is {after}; reduce kernel/dilation or add padding")
        output = TensorType("Channels", (out, after))
        kwargs = dict(in_channels=channels, **p)
        count = (channels // groups) * out * kernel + out * p["bias"]
        if name == "DepthwiseSeparableConv1d":
            count = channels * kernel + channels * p["bias"] + channels * out + out * p["bias"]
        if name == "LocallyConnected1d":
            count *= after
            kwargs["input_length"] = length
            kwargs.pop("boundary")  # interpretation is preserved in ModelSpec, not a tensor operation
    elif name in ("MaxPool1d", "AvgPool1d"):
        channels, length = dims
        k, s, pad = p["kernel_size"], p["stride"], p["padding"]
        if pad > k // 2:
            fail("E_PORT", path, "pooling padding cannot exceed half the kernel")
        effective = p.get("dilation", 1) * (k - 1) + 1
        after = (length + 2 * pad - effective + ((s - 1) if p["ceil_mode"] else 0)) // s + 1
        if p["ceil_mode"] and (after - 1) * s >= length + pad:
            after -= 1
        if after < 1:
            fail("E_PORT", path, "pooling leaves no output positions")
        output = TensorType("Channels", (channels, after))
    elif name in ("AdaptiveAvgPool1d", "AdaptiveMaxPool1d"):
        output = TensorType("Channels", (dims[0], p["output_size"]))
    elif name == "GlobalPool1d":
        output = TensorType("Vector", (dims[0],))
    elif name == "KerasBatchNorm1d":
        n = dims[0]
        kwargs = dict(num_features=n, **p)
        count = 2 * n if p["affine"] else 0
        buffers = 8 * n
    elif name in ("BatchNorm1d", "InstanceNorm1d"):
        n = dims[0]
        kwargs = dict(num_features=n, **p)
        if name == "InstanceNorm1d" and dims[1] < 2:
            fail("E_PORT", path, "InstanceNorm1d training requires at least two spatial positions")
        count = 2 * n if p["affine"] else 0
        buffers = 8 * n + 8 if p["track_running_stats"] else 0  # 2 float32 stats, int64 counter
    elif name == "GroupNorm":
        if dims[0] % p["num_groups"]:
            fail("E_PORT", path, "GroupNorm groups must divide channels")
        if prod(dims) // p["num_groups"] < 2:
            fail("E_PORT", path, "GroupNorm must have at least two elements per group per individual")
        kwargs = dict(num_channels=dims[0], **p)
        count = 2 * dims[0] if p["affine"] else 0
    elif name in ("LayerNorm", "RMSNorm"):
        kwargs = dict(normalized_shape=dims[-1], **p)
        count = dims[-1] * (2 if name == "LayerNorm" else 1) if p["elementwise_affine"] else 0
    elif name == "PReLU":
        kwargs["num_parameters"] = 1
        count = 1
    elif name not in ("Identity", "SiLU", "ELU", "SELU", "Softplus", "Softsign", "LeakyReLU",
                       "AlphaDropout", "Dropout1d"):
        fail("E_MODEL", path, f"no shape implementation for {name}")
    return kwargs, output, count, buffers
