from ..config import fail
from .registry import TensorType

GRAPH_COMPONENTS = ("GraphInput", "GCN", "GraphSAGE", "GIN", "GAT", "GraphReadout")


def resolve_graph_layer(name, incoming, params, state, path):
    if state is None:
        fail("E_GRAPH", path, "attach an explicit GraphSpec before using graph layers")
    n = len(state["nodes"])
    kwargs, count = dict(params), 0
    if name == "GraphInput":
        if incoming.kind != "Vector" or incoming.dimensions != (sum(state["keep"]),):
            fail("E_PORT", path, "GraphInput requires unaltered retained-marker Vector")
        return kwargs, TensorType("Graph", (n, 1)), 0, 0
    if incoming.kind != "Graph" or incoming.dimensions[0] != n:
        fail("E_PORT", path, "requires Graph with the frozen locus topology")
    width = incoming.dimensions[1]
    if name == "GraphReadout":
        count = width + 1 if params["mode"] == "attention" else 0
        return dict(in_features=width, **params), TensorType("Vector", (width,)), count, 0
    out = params["out_features"]
    kwargs["in_features"] = width
    if name == "GCN":
        if state["direction"] != "undirected":
            fail("E_GRAPH", path, "symmetric-degree GCN requires explicit undirected topology")
        count = width * out + out * params["bias"]
    elif name == "GraphSAGE":
        count = 2 * width * out + out * params["bias"]
    elif name == "GIN":
        count = width*out + out + out*out + out + int(params["train_eps"])
    elif name == "GAT":
        heads = params["heads"]
        count = width*out*heads + 2*out*heads + (out*heads if params["concat"] else out)*params["bias"]
        out *= heads if params["concat"] else 1
    return kwargs, TensorType("Graph", (n, out)), count, 4 if name == "GIN" and not params["train_eps"] else 0
