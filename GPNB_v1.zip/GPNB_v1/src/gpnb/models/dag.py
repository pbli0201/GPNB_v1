"""Deterministic graph validation; no tensor allocation or hidden broadcasting."""
from ..config import fail


def execution_order(value):
    rows = {row["id"]: row for row in value["layers"]}
    roots = {"$input", *("$input:"+name for name in value.get("external_inputs", {}))}
    output = value.get("output", value["layers"][-1]["id"])
    if output not in rows:
        fail("E_PORT", "model.output", "output must reference an existing layer")
    auxiliary = value.get("reconstruction_output")
    if auxiliary is not None and (auxiliary not in rows or auxiliary == output):
        fail("E_AUXILIARY","model.reconstruction_output","auxiliary must reference a distinct existing layer")
    if value.get("graph_mode", "sequential") == "sequential" and output != value["layers"][-1]["id"]:
        fail("E_PORT", "model.output", "sequential output must be the last layer")
    for identifier, row in rows.items():
        for port, source in row["inputs"].items():
            if source not in roots and source not in rows:
                fail("E_PORT", identifier + ".inputs." + port, f"missing source {source}")
        if "share_with" in row:
            owner = rows.get(row["share_with"])
            if owner is None or owner is row or "share_with" in owner:
                fail("E_MODEL", identifier, "share_with must reference a distinct unshared owner")
            if any(row[key] != owner[key] for key in ("type", "params", "implementation_version")):
                fail("E_MODEL", identifier, "shared calls must use the owner's type, version and parameters")
    remaining, done, order = list(rows), set(roots), []
    while remaining:
        ready = [key for key in remaining if set(rows[key]["inputs"].values()) <= done]
        if not ready:
            fail("E_PORT", "model.layers", f"cycle among {remaining}")
        for key in ready:
            remaining.remove(key)
            done.add(key)
            order.append(key)
    used, used_roots, pending = set(), set(), [output, *([auxiliary] if auxiliary else [])]
    while pending:
        key = pending.pop()
        if key in roots:
            used_roots.add(key)
            continue
        if key in used:
            continue
        used.add(key)
        pending.extend(rows[key]["inputs"].values())
    if used != set(rows):
        fail("E_PORT", "model.layers", f"layers disconnected from output: {sorted(set(rows) - used)}")
    if used_roots != roots:
        fail("E_PORT", "model.external_inputs", f"input branches disconnected from output: {sorted(roots-used_roots)}")
    return order


def resolve_merge(name, ports, params, path):
    from .registry import TensorType
    a, b = ports["a"], ports["b"]
    if a.kind != b.kind:
        fail("E_PORT", path, "merge inputs must have the same tensor layout")
    if name in ("Add", "Multiply"):
        if a != b:
            fail("E_PORT", path, "Add/Multiply require identical shapes; implicit broadcasting is forbidden")
        return {}, a, 0, 0
    axis = params["axis"] - 1
    if not 0 <= axis < len(a.dimensions):
        fail("E_PORT", path + ".axis", "Concat axis excludes batch: use 1..rank-1")
    dims = list(a.dimensions)
    for i, (left, right) in enumerate(zip(a.dimensions, b.dimensions)):
        if i != axis and left != right:
            fail("E_PORT", path, "non-concatenated dimensions must match")
    dims[axis] += b.dimensions[axis]
    return dict(axis=axis + 1), TensorType(a.kind, tuple(dims)), 0, 0
