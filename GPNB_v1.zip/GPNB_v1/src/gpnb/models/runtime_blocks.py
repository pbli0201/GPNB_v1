"""Explicit composite formulas, using only native torch; embedded in exports."""
import math
import torch
from torch import nn
from torch.nn import functional as F


def linear(a, b, bias=True):
    return nn.Linear(a, b, bias=bias, device="cpu", dtype=torch.float32)


class CrossAttention(nn.Module):
    def __init__(self, query_dim, context_dim, num_heads, dropout, bias, max_score_elements):
        super().__init__()
        self.heads, self.dropout, self.limit = num_heads, dropout, max_score_elements
        self.query = linear(query_dim, query_dim, bias)
        self.key_value = linear(context_dim, 2 * query_dim, bias)
        self.output = linear(query_dim, query_dim, bias)

    def forward(self, query, context, query_mask, context_mask):
        b, ql, d = query.shape
        kl = context.shape[1]
        if b * self.heads * ql * kl > self.limit:
            raise ValueError("CrossAttention score budget exceeded")
        q = self.query(query.masked_fill(query_mask.unsqueeze(-1), 0))
        kv = self.key_value(context.masked_fill(context_mask.unsqueeze(-1), 0))
        q = q.reshape(b, ql, self.heads, d // self.heads).transpose(1, 2)
        k, v = kv.reshape(b, kl, 2, self.heads, d // self.heads).permute(2, 0, 3, 1, 4).unbind(0)
        scores = q @ k.transpose(-2, -1) / math.sqrt(d // self.heads)
        blocked = context_mask[:, None, None, :]
        weights = scores.masked_fill(blocked, torch.finfo(scores.dtype).min).softmax(-1).masked_fill(blocked, 0)
        weights = F.dropout(weights, self.dropout, self.training)
        mixed = (weights @ v).transpose(1, 2).reshape(b, ql, d)
        absent = query_mask | context_mask.all(1, keepdim=True)
        return self.output(mixed).masked_fill(absent.unsqueeze(-1), 0)


class GatedAdd(nn.Module):
    def __init__(self, features, bias):
        super().__init__()
        self.gate = linear(2 * features, features, bias)

    def forward(self, a, b):
        gate = torch.sigmoid(self.gate(torch.cat((a, b), -1)))
        return gate * a + (1 - gate) * b


class SqueezeExcite1d(nn.Module):
    def __init__(self, channels, hidden_size):
        super().__init__()
        self.reduce, self.expand = linear(channels, hidden_size), linear(hidden_size, channels)

    def forward(self, x):
        gates = self.expand(F.relu(self.reduce(x.mean(-1)))).sigmoid()
        return x * gates.unsqueeze(-1)


class AttentionPooling(nn.Module):
    def __init__(self, features, bias):
        super().__init__()
        self.score = linear(features, 1, bias)

    def forward(self, x, mask):
        x = x.masked_fill(mask.unsqueeze(-1), 0)
        scores = self.score(x).squeeze(-1)
        weights = scores.masked_fill(mask, torch.finfo(scores.dtype).min).softmax(-1).masked_fill(mask, 0)
        return (x * weights.unsqueeze(-1)).sum(1)


class GatedMLP(nn.Module):
    def __init__(self, features, hidden_size, bias, dropout):
        super().__init__()
        self.projection, self.output = linear(features, 2 * hidden_size, bias), linear(hidden_size, features, bias)
        self.dropout = dropout

    def forward(self, x):
        value, gate = self.projection(x).chunk(2, -1)
        return self.output(F.dropout(value * F.gelu(gate), self.dropout, self.training))


class TCNBlock(nn.Module):
    """Two causal convolutions, same length, visible residual; no weight normalization."""
    def __init__(self, channels, hidden_size, kernel_size, dilation, dropout, bias):
        super().__init__()
        self.left, self.dropout = dilation * (kernel_size - 1), dropout
        self.first = nn.Conv1d(channels, hidden_size, kernel_size, dilation=dilation, bias=bias, device="cpu", dtype=torch.float32)
        self.second = nn.Conv1d(hidden_size, channels, kernel_size, dilation=dilation, bias=bias, device="cpu", dtype=torch.float32)

    def forward(self, x):
        y = F.dropout(F.relu(self.first(F.pad(x, (self.left, 0)))), self.dropout, self.training)
        y = F.dropout(self.second(F.pad(y, (self.left, 0))), self.dropout, self.training)
        return F.relu(x + y)


class MLPMixer(nn.Module):
    """One fixed-length token/channel mixing block; masked positions zeroed at each residual."""
    def __init__(self, length, features, token_hidden, channel_hidden, dropout, eps):
        super().__init__()
        self.norm1 = nn.LayerNorm(features, eps=eps, device="cpu", dtype=torch.float32)
        self.norm2 = nn.LayerNorm(features, eps=eps, device="cpu", dtype=torch.float32)
        self.token1, self.token2 = linear(length, token_hidden), linear(token_hidden, length)
        self.channel1, self.channel2 = linear(features, channel_hidden), linear(channel_hidden, features)
        self.dropout = dropout

    def forward(self, x, mask):
        x = x.masked_fill(mask.unsqueeze(-1), 0)
        tokens = self.norm1(x).transpose(1, 2)
        tokens = self.token2(F.dropout(F.gelu(self.token1(tokens)), self.dropout, self.training)).transpose(1, 2)
        x = (x + F.dropout(tokens, self.dropout, self.training)).masked_fill(mask.unsqueeze(-1), 0)
        channels = self.channel2(F.dropout(F.gelu(self.channel1(self.norm2(x))), self.dropout, self.training))
        return (x + F.dropout(channels, self.dropout, self.training)).masked_fill(mask.unsqueeze(-1), 0)


class DenseMoE(nn.Module):
    """All independent experts are evaluated. No sparse routing or acceleration claim."""
    def __init__(self, features, num_experts, hidden_size, out_features, dropout):
        super().__init__()
        self.gate = linear(features, num_experts)
        self.experts = nn.ModuleList([
            nn.Sequential(linear(features, hidden_size), nn.GELU(), nn.Dropout(dropout), linear(hidden_size, out_features))
            for _ in range(num_experts)])

    def forward(self, x):
        gates = self.gate(x).softmax(-1)
        predictions = torch.stack([expert(x) for expert in self.experts], dim=1)
        return (gates.unsqueeze(-1) * predictions).sum(1)


class ApplyMask(nn.Module):
    def forward(self, x, mask):
        return x.masked_fill(mask.unsqueeze(-1), 0)


class ChannelScale(nn.Module):
    def forward(self, x, gate):
        return x * gate.unsqueeze(-1)


class ScaleByWeight(nn.Module):
    def forward(self, x, weight):
        return x * weight


class Slice(nn.Module):
    def __init__(self, axis, start, stop):
        super().__init__()
        self.axis, self.start, self.stop = axis, start, stop

    def forward(self, x):
        return x.narrow(self.axis, self.start, self.stop - self.start)


class Softmax(nn.Module):
    def forward(self, x):
        return x.softmax(-1)


class OneMinus(nn.Module):
    def forward(self, x):
        return 1 - x


CUSTOM_BLOCKS = {cls.__name__: cls for cls in (
    CrossAttention, GatedAdd, SqueezeExcite1d, AttentionPooling, GatedMLP, TCNBlock, MLPMixer, DenseMoE,
    ApplyMask, ChannelScale, ScaleByWeight, Slice, Softmax, OneMinus)}
