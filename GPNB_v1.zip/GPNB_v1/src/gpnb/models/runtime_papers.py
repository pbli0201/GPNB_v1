"""Native PyTorch paper building blocks; no author software or extra backend."""
import math
import torch
from torch import nn


class AutoCorrelation(nn.Module):
    """FFT circular Q/K correlation, top lag softmax, rolled V aggregation.

    Lags are selected independently for every individual, in train and eval.
    Positive correlation lag d weights V[t-d]; ties retain ascending lag order.
    No padding mask: each position must represent a real marker/token.
    """
    def __init__(self, width, num_heads=4, factor=2., bias=True, max_elements=8_000_000):
        super().__init__()
        self.heads, self.factor, self.limit = num_heads, factor, max_elements
        self.query = nn.Linear(width, width, bias=bias, device='cpu', dtype=torch.float32)
        self.key = nn.Linear(width, width, bias=bias, device='cpu', dtype=torch.float32)
        self.value = nn.Linear(width, width, bias=bias, device='cpu', dtype=torch.float32)
        self.output = nn.Linear(width, width, bias=bias, device='cpu', dtype=torch.float32)

    def forward(self, x):
        b, length, width = x.shape
        if x.numel() > self.limit:
            raise ValueError('AutoCorrelation input exceeds explicit element budget')
        def heads(z):
            return z.reshape(b, length, self.heads, width // self.heads).permute(0, 2, 3, 1)
        q, k, v = (heads(layer(x)) for layer in (self.query, self.key, self.value))
        correlation = torch.fft.irfft(torch.fft.rfft(q, dim=-1) *
                                     torch.conj(torch.fft.rfft(k, dim=-1)), n=length, dim=-1)
        scores = correlation.mean(dim=(1, 2))
        count = min(length, max(1, int(self.factor * math.log(max(length, 2)))))
        lags = torch.argsort(scores, dim=-1, descending=True, stable=True)[:, :count]
        weights = torch.softmax(scores.gather(1, lags), dim=-1)
        # Read the discrete shifts together; preserve roll and reduction order.
        host_lags = lags.detach().cpu().tolist()
        individuals = []
        for i in range(b):
            terms = [torch.roll(v[i], host_lags[i][j], dims=-1) * weights[i, j]
                     for j in range(count)]
            individuals.append(torch.stack(terms).sum(0))
        result = torch.stack(individuals).permute(0, 3, 1, 2).reshape(b, length, width)
        return self.output(result)


class SeriesDecomposition(nn.Module):
    """Length-preserving odd moving mean with repeated endpoint padding."""
    def __init__(self, kernel_size=25, output='residual'):
        super().__init__()
        self.kernel_size, self.output = kernel_size, output

    def forward(self, x):
        y = x.transpose(1, 2)
        p = self.kernel_size // 2
        # Concatenation avoids CUDA replicate-pad backward nondeterminism.
        padded = torch.cat((y[..., :1].expand(*y.shape[:-1], p), y,
                            y[..., -1:].expand(*y.shape[:-1], p)), dim=-1)
        trend = torch.nn.functional.avg_pool1d(padded, self.kernel_size, stride=1).transpose(1, 2)
        return trend if self.output == 'trend' else x - trend


class KerasBatchNorm1d(nn.Module):
    """TF1 non-fused BN: retention momentum and population moving variance."""
    def __init__(self, num_features, eps=.001, momentum=.99, affine=True):
        super().__init__()
        self.num_features, self.eps, self.momentum = num_features, eps, momentum
        self.affine = affine
        if affine:
            self.weight = nn.Parameter(torch.ones(num_features, device='cpu', dtype=torch.float32))
            self.bias = nn.Parameter(torch.zeros(num_features, device='cpu', dtype=torch.float32))
        else:
            self.register_parameter('weight', None)
            self.register_parameter('bias', None)
        self.register_buffer('running_mean', torch.zeros(num_features, device='cpu', dtype=torch.float32))
        self.register_buffer('running_var', torch.ones(num_features, device='cpu', dtype=torch.float32))

    def forward(self, x):
        if x.ndim not in (2, 3) or x.shape[1] != self.num_features:
            raise ValueError('KerasBatchNorm1d expects [N,C] or [N,C,L]')
        shape = (1, self.num_features) + (1,) * (x.ndim - 2)
        if self.training:
            axes = (0,) if x.ndim == 2 else (0, 2)
            mean = x.mean(dim=axes)
            variance = (x - mean.detach().reshape(shape)).square().mean(dim=axes)
            with torch.no_grad():
                self.running_mean.sub_((self.running_mean-mean.detach()) * (1-self.momentum))
                self.running_var.sub_((self.running_var-variance.detach()) * (1-self.momentum))
        else:
            mean, variance = self.running_mean, self.running_var
        inverse = torch.rsqrt(variance + self.eps)
        if self.affine:
            inverse = inverse * self.weight
            offset = self.bias - mean * inverse
        else:
            offset = -mean * inverse
        return x * inverse.reshape(shape) + offset.reshape(shape)


PAPER_RUNTIME = {'AutoCorrelation': AutoCorrelation, 'SeriesDecomposition': SeriesDecomposition, 'KerasBatchNorm1d': KerasBatchNorm1d}
