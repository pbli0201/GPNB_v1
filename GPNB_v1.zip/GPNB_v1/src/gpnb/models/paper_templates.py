"""Editable, independently authored mappings of audited architecture features.

No author software is imported. A mapping is not an experimental reproduction.
"""
import copy

from ..config import ModelSpec, fail
from .registry import component
from .templates import sequential
from .paper_catalog import CANDIDATES

AVAILABLE = ("DeepGS", "DeepGP", "DLGWAS", "deepGBLUP", "WheatGP", "Cropformer", "DNNGP", "GPformer")
NOTES = {
    "DNNGP": "原论文 Figure 1A：Conv/ReLU→Dropout→BN→Conv/ReLU→Dropout→Conv/ReLU→Flatten→Dense 1。三层卷积均 64 通道、核 4；至少 10 个保留位点。",
    "GPformer": "基础 GPformer：卷积 SNP 嵌入+位置编码、自相关注意力、两次序列分解、卷积、LayerNorm、两次 GELU/Dropout、Flatten→Linear。默认维度 16、4 头、分解核 25；不含独立 KGM 分支。",
    "DeepGS": "参考 1.2 示例 CNN：8×18 卷积、ReLU、4/4 最大池化、Dropout .2、Dense 32、Sigmoid、Dropout .1、Dense 1。至少 21 个保留位点。",
    "DeepGP": "参考可调 MLP 回归分支；本配置选择 64→32→1、ReLU、Dropout .2，属于明确的配置实例，非论文统一最优参数。",
    "DLGWAS": "参考 HEIGHT 残差卷积：10 通道、核 4/20/4、捷径、Dropout .75。显式非对称 SAME padding；将原 isru 输出替换为线性回归输出。",
    "deepGBLUP": "仅参考神经网络子图：右侧填充局部连接核 5/3、LayerNorm、GELU、输入残差、线性头。目标均值/尺度由训练内预处理恢复；不包含 GBLUP 联合估计。",
    "WheatGP": "五段复用 CNN 权重（1→2→4→8，核 1/3/9），拼接为单 token，再 LSTM 128、Dropout .3、回归。序列长度为 1，不宣称跨五段递归。至少 25 个保留位点。",
    "Cropformer": "参考已审代码的 Conv1d→单 token 投影注意力→残差 LayerNorm→ReLU→回归。hidden=64、scale_dim=8 为示例选择；无多头拆分，注意力矩阵为 1×1。",
}
CHANGES = {
    "DNNGP": ["按论文结构图独立实现；Conv stride=1/valid、Dropout=.2、BN eps=1e-5/momentum=.1 为显式默认值；不宣称与闭源核心逐参数一致。", "不自动执行论文 PCA 或多组学拼接；使用当前项目输入。"],
    "GPformer": ["按论文方法描述实现基础架构，未取得可核验作者源码；分解残差连接、卷积 kernel=1、维度16、4头、factor=2、Dropout=.1 为明确的映射选择，不能宣称逐算子忠实复现。", "FFT 循环相关后按个体选滞后；相关正滞后 d 对齐 V[t-d]，同分保留小滞后；使用端点重复填充移动均值。", "位置使用输入顺序；不含 GWAS 知识引导 KGM；已核实参数档可应用 focal MAE 与 Adam，原指数衰减因子未报告，不擅自启用。"],
    "DeepGS": ["R/MXNet→原生 PyTorch；不含集成与原初始化器；去掉源示例末端 Dropout .05，遵守 GPNB 线性回归输出合同。"],
    "DeepGP": ["选定可编辑宽度与 dropout；不含 Talos 搜索、Keras 初始化或逐层 L2 正则。"],
    "DLGWAS": ["输出 isru 改线性；不含逐层权重/偏置正则与 saliency 工作流。"],
    "deepGBLUP": ["仅神经子图，未实现 GBLUP 方差/联合优化；采用 GPNB 初始化和训练内目标标准化。"],
    "WheatGP": ["保留位点按文件顺序均衡分五段，余数优先分给前段；段边界不代表染色体或 LD；冻结阶段由用户另外配置。"],
    "Cropformer": ["从候选超参数选 hidden=64、scale_dim=8、kernel=3；保留代码单 token 语义；移除按测试相关选模型流程，统一独立验证集早停。"],
}
COMMON_CHANGES = ["输入为 BIM A1 计数剂量，填补/筛选/标准化仅在训练分区拟合；不保证与作者编码一致。",
                  "沿用项目的优化器、种子、训练轮数与内层验证；训练参数可由独立的已核实参数档显式应用；未复现论文准确率。"]


def paper_catalog():
    records = copy.deepcopy(CANDIDATES)
    for record in records:
        name = record["id"]
        record.update(available=name in AVAILABLE, implementation="native_pytorch_adaptation" if name in AVAILABLE else "not_implemented",
                      structure_status="audited_code_mapping" if name in AVAILABLE else "candidate_audit_only",
                      experiment_status="not_reproduced",
                      engineering_status="see GPNB release validation report; not an author-code execution claim")
        if name in AVAILABLE:
            record.update(mapping=NOTES[name], changes=CHANGES[name]+COMMON_CHANGES,
                          input_requirements="single diploid hard-call dosage input; continuous single-target regression")
        if name in ("DNNGP", "GPformer"):
            record.update(structure_status="paper_based_architecture_mapping", mapping_review_date="2026-10-22",
                          limitation="Usable independent architecture mapping; exact author-operator equivalence and paper results are not established.")
    return records


class _Graph:
    def __init__(self):
        self.rows = []

    def add(self, name, kind, source="$input", *, inputs=None, share=None, **params):
        row = dict(id=name, type=kind, implementation_version=1,
                   params={**component(kind).defaults(), **params}, inputs=inputs or {"x": source})
        if share:
            row["share_with"] = share
        self.rows.append(row)
        return name

    def spec(self, name, output):
        return ModelSpec(dict(schema_version=2,kind="model",name=name,backend="pytorch",task="single_trait_regression",
            input_layout="batch_markers",input_representation="standardized_dosage",graph_mode="dag",layers=self.rows,output=output))


def paper_template(name):
    record = next((r for r in paper_catalog() if r["id"] == name), None)
    if record is None or not record["available"]:
        fail("E_MODEL", "paper_template", (record or {}).get("limitation", "unknown paper architecture"))
    label = f"{name} — GPNB architecture adaptation v1"
    if name == "DeepGS":
        spec = sequential([("ToChannels",{}),("Conv1d",dict(out_channels=8,kernel_size=18)),("ReLU",{}),
            ("MaxPool1d",dict(kernel_size=4,stride=4)),("Dropout",dict(p=.2)),("Flatten",{}),
            ("Linear",dict(out_features=32)),("Sigmoid",{}),("Dropout",dict(p=.1)),
            ("Linear",dict(out_features=1))],label)
    elif name == "DNNGP":
        spec = sequential([("ToChannels",{}), ("Conv1d",dict(out_channels=64,kernel_size=4)), ("ReLU",{}),
            ("Dropout",dict(p=.2)), ("BatchNorm1d",{}), ("Conv1d",dict(out_channels=64,kernel_size=4)),
            ("ReLU",{}), ("Dropout",dict(p=.2)), ("Conv1d",dict(out_channels=64,kernel_size=4)),
            ("ReLU",{}), ("Flatten",{}), ("Linear",dict(out_features=1))],label)
    elif name == "DeepGP":
        spec = sequential([("Linear",dict(out_features=64)),("ReLU",{}),("Dropout",dict(p=.2)),
            ("Linear",dict(out_features=32)),("ReLU",{}),("Dropout",dict(p=.2)),("Linear",dict(out_features=1))],label)
    else:
        g = _Graph()
        if name == "GPformer":
            a=g.add("channels","ToChannels")
            a=g.add("snp_embedding","Conv1d",a,out_channels=16,kernel_size=3,padding=1)
            a=g.add("sequence","Permute",a,axes=[1,0],layout="Sequence")
            x=g.add("position","PositionEncoding",a)
            a=g.add("autocorrelation","AutoCorrelation",x)
            a=g.add("gelu1","GELU",a);a=g.add("drop1","Dropout",a,p=.1)
            a=g.add("residual1","Add",inputs=dict(a=x,b=a))
            x=g.add("decompose1","SeriesDecomposition",a)
            a=g.add("cnn_channels","Permute",x,axes=[1,0],layout="Channels")
            a=g.add("cnn","Conv1d",a,out_channels=16,kernel_size=1)
            a=g.add("cnn_sequence","Permute",a,axes=[1,0],layout="Sequence")
            a=g.add("gelu2","GELU",a);a=g.add("drop2","Dropout",a,p=.1)
            a=g.add("residual2","Add",inputs=dict(a=x,b=a))
            a=g.add("decompose2","SeriesDecomposition",a)
            a=g.add("norm","LayerNorm",a);a=g.add("flatten","Flatten",a)
        elif name == "DLGWAS":
            x=g.add("channels","ToChannels")
            def same(tag, source, kernel):
                p=g.add(tag+"_pad","Pad1d",source,left=(kernel-1)//2,right=kernel//2)
                return g.add(tag,"Conv1d",p,out_channels=10,kernel_size=kernel)
            a=same("conv1",x,4);a=same("conv2",a,20);a=g.add("drop1","Dropout",a,p=.75)
            b=same("shortcut",x,4);a=g.add("residual","Add",inputs=dict(a=a,b=b))
            a=same("conv3",a,4);a=g.add("drop2","Dropout",a,p=.75)
            a=g.add("flatten","Flatten",a);a=g.add("drop3","Dropout",a,p=.75)
        elif name == "deepGBLUP":
            a=g.add("channels","ToChannels")
            a=g.add("local5","LocallyConnected1d",a,out_channels=1,kernel_size=5,padding_right=4)
            a=g.add("normalize","LayerNorm",a);a=g.add("activation","GELU",a)
            a=g.add("local3","LocallyConnected1d",a,out_channels=1,kernel_size=3,padding_right=2)
            a=g.add("flatten","Flatten",a);a=g.add("residual","Add",inputs=dict(a=a,b="$input"))
        elif name == "WheatGP":
            branches=[]
            for i in range(5):
                a=g.add(f"chunk{i}","MarkerChunk",parts=5,index=i)
                a=g.add(f"channels{i}","ToChannels",a)
                for j,(width,kernel) in enumerate(((2,1),(4,3),(8,9))):
                    a=g.add(f"conv{i}_{j}","Conv1d",a,out_channels=width,kernel_size=kernel,padding=1,
                            share=f"conv0_{j}" if i else None)
                    a=g.add(f"relu{i}_{j}","ReLU",a)
                a=g.add(f"drop{i}","Dropout",a,p=.5);a=g.add(f"flat{i}","Flatten",a);branches.append(a)
            a=branches[0]
            for i,b in enumerate(branches[1:],1):a=g.add(f"concat{i}","Concat",inputs=dict(a=a,b=b),axis=1)
            a=g.add("single_token","SingleToken",a);a=g.add("lstm","LSTM",a,hidden_size=128)
            a=g.add("lstm_dropout","Dropout",a,p=.3);a=g.add("readout","SequenceReadout",a,mode="last")
        elif name == "Cropformer":
            a=g.add("channels","ToChannels");a=g.add("conv","Conv1d",a,out_channels=1,kernel_size=3,padding=1)
            a=g.add("flat","Flatten",a);x=g.add("single_token","SingleToken",a)
            mask=g.add("mask","SequenceMask",x)
            a=g.add("attention","ProjectedAttention",inputs=dict(x=x,mask=mask),hidden_size=64,scale_dim=8,dropout=.5)
            a=g.add("out_drop","Dropout",a,p=.5);a=g.add("residual","Add",inputs=dict(a=a,b=x))
            a=g.add("normalize","LayerNorm",a,eps=1e-12);a=g.add("flatten","Flatten",a);a=g.add("relu","ReLU",a)
        output=g.add("regression","Linear",a,out_features=1)
        spec=g.spec(label,output)
    value=spec.to_dict()
    value.setdefault("extensions",{})["paper_reference"]={**record,"mapping_version":1}
    baseline=ModelSpec(value)
    value["extensions"]["template"]={"name":f"paper:{name}","baseline":baseline.to_dict(),"baseline_sha256":baseline.sha256}
    return ModelSpec(value)
