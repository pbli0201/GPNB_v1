"""Native, sparse edge-list locus graph modules; embedded in independent exports."""
import torch
from torch import nn
from torch.nn import functional as F


class GraphBuffers(nn.Module):
    def __init__(self, state):
        super().__init__()
        self.n = len(state["nodes"])
        self.aggregation = state["aggregation"]
        edge = state["edges"]
        self.register_buffer("src", torch.tensor([r[0] for r in edge], dtype=torch.int64, device="cpu"))
        self.register_buffer("dst", torch.tensor([r[1] for r in edge], dtype=torch.int64, device="cpu"))
        self.register_buffer("weight", torch.tensor([r[2] for r in edge], dtype=torch.float32, device="cpu"))
        degrees = [0.] * self.n
        for _, dst, weight in edge:
            degrees[dst] += weight
        self.register_buffer("degree", torch.tensor(degrees, dtype=torch.float32, device="cpu"))
        mapping = [0] * sum(map(len, state["groups"]))
        for i, group in enumerate(state["groups"]):
            for marker in group:
                mapping[marker] = i
        self.register_buffer("mapping", torch.tensor(mapping, dtype=torch.int64, device="cpu"))
        self.register_buffer("counts", torch.tensor(list(map(len, state["groups"])), dtype=torch.float32, device="cpu"))


class GraphLayer(nn.Module):
    def bind_graph(self, graph):
        # Root is the sole registered owner; .to(), state_dict and storage count once.
        object.__setattr__(self, "_graph", graph)

    def budget(self, x, width, heads=1):
        elements = x.shape[0] * self._graph.src.numel() * width * heads
        if elements > self.max_message_elements:
            raise ValueError("Graph message budget exceeded; reduce batch/edges/width or raise explicit limit")

    def aggregate(self, x, normalized=False, exclude_self=False, mean=False):
        g = self._graph
        src, dst, weight = g.src, g.dst, g.weight
        if exclude_self:
            keep = src != dst
            src, dst, weight = src[keep], dst[keep], weight[keep]
        if normalized:
            weight = weight * g.degree[src].clamp_min(1e-30).rsqrt() * g.degree[dst].clamp_min(1e-30).rsqrt()
        result = x.new_zeros(x.shape[0], g.n, x.shape[-1])
        result.index_add_(1, dst, x[:, src] * weight[None, :, None])
        if mean:
            degree = weight.new_zeros(g.n).index_add(0, dst, weight)
            result = result / degree.clamp_min(1e-30)[None, :, None]
        return result


class GraphInput(GraphLayer):
    def forward(self, x):
        g = self._graph
        y = x.new_zeros(x.shape[0], g.n).index_add(1, g.mapping, x)
        if g.aggregation == "mean":
            y = y / g.counts
        return y.unsqueeze(-1)


class GCN(GraphLayer):
    def __init__(self, in_features, out_features, bias, max_message_elements):
        super().__init__()
        self.projection = nn.Linear(in_features, out_features, bias=False, dtype=torch.float32, device="cpu")
        self.bias = nn.Parameter(torch.zeros(out_features, dtype=torch.float32, device="cpu")) if bias else None
        self.max_message_elements = max_message_elements

    def forward(self, x):
        self.budget(x, self.projection.out_features)
        y = self.aggregate(self.projection(x), normalized=True)
        return y if self.bias is None else y + self.bias


class GraphSAGE(GraphLayer):
    def __init__(self, in_features, out_features, bias, normalize, max_message_elements):
        super().__init__()
        self.own = nn.Linear(in_features, out_features, bias=bias, dtype=torch.float32, device="cpu")
        self.neighbor = nn.Linear(in_features, out_features, bias=False, dtype=torch.float32, device="cpu")
        self.normalize, self.max_message_elements = normalize, max_message_elements

    def forward(self, x):
        self.budget(x, x.shape[-1])
        y = self.own(x) + self.neighbor(self.aggregate(x, exclude_self=True, mean=True))
        return F.normalize(y, p=2, dim=-1) if self.normalize else y


class GIN(GraphLayer):
    def __init__(self, in_features, out_features, eps, train_eps, max_message_elements):
        super().__init__()
        value = torch.tensor(float(eps), dtype=torch.float32, device="cpu")
        if train_eps:
            self.epsilon = nn.Parameter(value)
        else:
            self.register_buffer("epsilon", value)
        self.mlp = nn.Sequential(nn.Linear(in_features, out_features, dtype=torch.float32, device="cpu"), nn.ReLU(),
                                 nn.Linear(out_features, out_features, dtype=torch.float32, device="cpu"))
        self.max_message_elements = max_message_elements

    def forward(self, x):
        self.budget(x, x.shape[-1])
        return self.mlp((1 + self.epsilon)*x + self.aggregate(x, exclude_self=True))


class GAT(GraphLayer):
    def __init__(self, in_features, out_features, heads, concat, bias, negative_slope, dropout,
                 max_message_elements):
        super().__init__()
        self.projection = nn.Linear(in_features, out_features*heads, bias=False, dtype=torch.float32, device="cpu")
        self.attention_source = nn.Parameter(torch.empty(heads, out_features, dtype=torch.float32, device="cpu"))
        self.attention_target = nn.Parameter(torch.empty(heads, out_features, dtype=torch.float32, device="cpu"))
        nn.init.xavier_uniform_(self.attention_source)
        nn.init.xavier_uniform_(self.attention_target)
        self.bias = nn.Parameter(torch.zeros(out_features*heads if concat else out_features, dtype=torch.float32, device="cpu")) if bias else None
        self.width, self.heads, self.concat = out_features, heads, concat
        self.negative_slope, self.dropout, self.max_message_elements = negative_slope, dropout, max_message_elements

    def forward(self, x):
        self.budget(x, self.width, self.heads)
        g, b = self._graph, x.shape[0]
        z = self.projection(x).reshape(b, g.n, self.heads, self.width)
        scores = F.leaky_relu((z[:, g.src]*self.attention_source).sum(-1) +
                             (z[:, g.dst]*self.attention_target).sum(-1), self.negative_slope)
        # Positive external weight is an explicit multiplicative attention prior.
        scores = scores + g.weight.log()[None, :, None]
        indices = g.dst[None, :, None].expand(b, -1, self.heads)
        maximum = scores.new_full((b, g.n, self.heads), -torch.inf)
        maximum.scatter_reduce_(1, indices, scores.detach(), reduce="amax", include_self=True)
        exp = (scores - maximum[:, g.dst]).exp()
        total = exp.new_zeros(b, g.n, self.heads).scatter_add(1, indices, exp)
        alpha = F.dropout(exp / total[:, g.dst].clamp_min(1e-30), self.dropout, self.training)
        y = z.new_zeros(b, g.n, self.heads, self.width)
        y.index_add_(1, g.dst, z[:, g.src] * alpha[..., None])
        y = y.flatten(2) if self.concat else y.mean(2)
        return y if self.bias is None else y + self.bias


class GraphReadout(GraphLayer):
    def __init__(self, in_features, mode):
        super().__init__()
        self.mode = mode
        if mode == "attention":
            self.score = nn.Linear(in_features, 1, dtype=torch.float32, device="cpu")

    def forward(self, x):
        if self.mode == "attention":
            return (x * self.score(x).softmax(1)).sum(1)
        return x.amax(1) if self.mode == "max" else x.sum(1) if self.mode == "sum" else x.mean(1)


GRAPH_RUNTIME = {cls.__name__: cls for cls in (GraphInput, GCN, GraphSAGE, GIN, GAT, GraphReadout)}
