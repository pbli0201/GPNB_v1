"""Readable network summaries derived from the same specification/resolved plan."""
from __future__ import annotations

import json


def _cell(value):
    return str(value).replace("|", "\\|").replace("\n", " ").replace("\r", " ")


def _shape(value):
    return "[" + ", ".join("B" if x == "batch" else str(x) for x in value) + "]"


def markdown_summary(spec_or_value, plan=None, *, language="en_US", pending_reason=None, input_context=None):
    """Render without fitting or allocation; unresolved widths never invent counts.

    A resolved plan must belong to this exact ModelSpec. Shared calls have zero
    new parameters in the resolver and are explicitly linked to their owner.
    """
    from ..config import ModelSpec
    spec = spec_or_value if isinstance(spec_or_value, ModelSpec) else ModelSpec(spec_or_value)
    value = spec.to_dict()
    if plan is not None and plan.get("model_sha256") != spec.sha256:
        raise ValueError("Network summary plan belongs to a different model definition")
    zh = language == "zh_CN"
    choose = lambda cn, en: cn if zh else en
    lines = ["# " + choose("网络摘要", "Network summary"), "", _cell(value["name"]), "",
             "Model SHA256: `" + spec.sha256 + "`", ""]
    context = input_context or {}
    if context.get("mode") in ("kernel", "snp_kernel"):
        port = "$input" if context["mode"] == "kernel" else "$input:kernel"
        lines += [choose("核输入端口", "Kernel input port") + ": `" + port + "`", "",
                  choose("核列按保存的训练参考个体顺序排列，不是 SNP 位点或染色体坐标。对新个体使用 K(Q,T)，不重新建立 K(Q,Q)。",
                         "Kernel columns follow the saved training reference order, not SNP positions or chromosome coordinates. New individuals use K(Q,T), never a new K(Q,Q)."), ""]
        if context.get("reference_ids") is not None:
            lines += [choose("保存的参考个体数 T", "Saved reference count T") + f": {len(context['reference_ids']):,}", ""]
    if pending_reason or plan is None:
        lines += [choose("状态：尺寸及参数量待训练分区确定。", "Status: dimensions and parameter counts await the training partition."), ""]
        if pending_reason:
            lines += [_cell(pending_reason), ""]
        lines += [choose("P = 训练内保留位点数；T = 当前训练参考个体数。", "P = retained training markers; T = current training reference individuals."), ""]
        resolved = {}
    else:
        resolved = {r["id"]: r for r in plan["layers"]}
        lines += [choose("实际输入", "Actual input") + ": " + _shape(plan["input_shape"]), ""]
    headers = (["层", "输入来自", "配置", "输入 → 输出", "新增可训练参数", "缓冲区（字节）"] if zh else
               ["Layer", "Inputs from", "Configuration", "Input → output", "New trainable parameters", "Buffers (bytes)"])
    lines += ["| " + " | ".join(headers) + " |", "| " + " | ".join(["---"] * len(headers)) + " |"]
    previous = "$input"
    for layer in value["layers"]:
        row = resolved.get(layer["id"])
        sources = layer.get("inputs", {"x": previous})
        ports = "; ".join(f"{k}: {v}" for k, v in sources.items())
        config = json.dumps(layer["params"], ensure_ascii=False, sort_keys=True)
        name = layer["id"] + " · " + layer["type"]
        if layer.get("share_with"):
            config += choose("；共享：", "; shared with: ") + layer["share_with"]
        if row:
            before = "; ".join(f"{p}: {_shape(t['shape'])}" for p, t in row.get("input_types", {}).items())
            shape = (before or _shape(row["input_shape"])) + " → " + _shape(row["output_shape"])
            count, buffers = f"{row['trainable_parameters']:,}", f"{row.get('buffer_bytes', 0):,}"
        else:
            shape = choose("待确定", "Pending")
            count = "0" if layer.get("share_with") else "—"
            buffers = "—"
        lines.append("| " + " | ".join(_cell(x) for x in (name, ports, config, shape, count, buffers)) + " |")
        previous = layer["id"]
    lines += [""]
    if resolved:
        lines += [choose("合计可训练参数", "Total trainable parameters") + f": **{plan['trainable_parameters']:,}**",
                  "", choose("参数存储", "Parameter storage") + f": {plan['parameter_bytes']:,} bytes; " +
                  choose("缓冲区", "buffers") + f": {plan.get('buffer_bytes', 0):,} bytes", ""]
    lines += [choose("共享参数只计一次；缓冲区不是可训练参数。以上存储量不包含梯度、优化器、激活与运行时开销。",
                     "Shared parameters are counted once; buffers are not trainable parameters. Storage excludes gradients, optimizer state, activations and runtime overhead."), ""]
    if value.get("external_inputs"):
        lines += [choose("其他输入端口", "Other input ports") + ": " + ", ".join("`$input:" + _cell(k) + "`" for k in value["external_inputs"]), ""]
    return "\n".join(lines)
