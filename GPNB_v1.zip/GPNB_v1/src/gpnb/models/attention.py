"""Static attention contracts; execution uses allowlisted native torch operations."""
from ..config import fail


def resolve_attention(name, incoming, p, path):
    length, width = incoming.dimensions
    if name == "ProjectedAttention":
        if length * length > p["max_score_elements"]:
            fail("E_MODEL_LIMIT", path, "one sample exceeds attention score budget")
        hidden = p["hidden_size"]
        return dict(input_size=width, **p), incoming, 4 * width * hidden + 3 * hidden + width, 0
    if width % p["num_heads"]:
        fail("E_PORT", path, "embedding width must be divisible by num_heads")
    if p["num_heads"] * length * length > p["max_score_elements"]:
        fail("E_MODEL_LIMIT", path, "one sample exceeds attention score budget; increase patch size/reduce tokens or explicitly raise the limit")
    count = 4 * width * width + 4 * width * p["bias"]
    if name == "TransformerEncoder":
        ff = p["dim_feedforward"]
        count = p["num_layers"] * (count + 2 * width * ff + (ff + width) * p["bias"] + 4 * width)
    return dict(embedding_dim=width, **p), incoming, count, 0
