"""Dependency-free diagrams with explicit semantic edges and embedded evidence."""
import json
import textwrap
from collections import defaultdict
from xml.etree import ElementTree as ET

NS="http://www.w3.org/2000/svg"
ET.register_namespace("",NS)
EDGE_ZH = {"shared state":"共享状态", "reference":"参考", "output":"输出", "auxiliary":"辅助", "eligible":"符合条件", "fit":"拟合", "labels / mask":"标签及掩码", "transform X":"变换输入", "predictions":"预测", "gradients":"梯度", "frozen transform":"固定变换", "X, labels":"输入及标签", "candidate weights":"候选权重", "best weights":"最佳权重", "state":"状态", "frozen predict":"固定模型预测", "next stage":"下一阶段", "stage schedule":"阶段设置", "target column":"目标列"}


def draw_graph(nodes, edges, title, metadata, compact=False, language="en_US"):
    """Layered left-to-right DAG. Non-data edges do not change dependency depth."""
    incoming=defaultdict(list)
    for source,target,port,kind in edges:
        if kind!="shared":incoming[target].append(source)
    depth={}
    def level(n, visiting=None):
        if n in depth:return depth[n]
        visiting=set() if visiting is None else visiting
        if n in visiting:raise ValueError("diagram dependency cycle")
        visiting=visiting|{n}
        depth[n]=max([level(p,visiting)+1 for p in incoming[n]] or [0]);return depth[n]
    for n in nodes:level(n)
    ranks=defaultdict(list)
    for n in nodes:ranks[depth[n]].append(n)
    bw,bh,gap,vgap=(230,98,92,72) if compact else (300,160,105,80)
    width=max(950,(max(depth.values())+1)*(bw+gap)+80)
    height=max(380,max(map(len,ranks.values()))*(bh+vgap)+165)
    root=ET.Element(f"{{{NS}}}svg",width=str(width),height=str(height),viewBox=f"0 0 {width} {height}",role="img")
    def element(tag,attrs=None,parent=root):return ET.SubElement(parent,f"{{{NS}}}{tag}",attrs or {})
    element("title").text=title;element("metadata").text=json.dumps(metadata,ensure_ascii=False)
    element("rect",dict(width=str(width),height=str(height),fill="#f8fafc"))
    def txt(x,y,value,size=15,color="#20374b",parent=root):
        element("text",dict(x=str(x),y=str(y),fill=color,**{"font-size":str(size),"font-family":"Microsoft YaHei, Segoe UI, sans-serif"}),parent).text=value
    txt(30,34,title,23)
    txt(30,61,"实线：张量或数据流 · 虚线：共享参数（不是数据流）" if language == "zh_CN" else "Solid arrows: tensor/data flow · Dashed: shared parameters (not data)",13)
    positions={}
    for rank,ids in ranks.items():
        for i,n in enumerate(ids):positions[n]=(35+rank*(bw+gap),110+i*(bh+vgap))
    for source,target,port,kind in edges:
        sx,sy=positions[source];tx,ty=positions[target]
        x1,y1,x2,y2=sx+bw,sy+bh/2,tx,ty+bh/2
        color="#8b5cf6" if kind=="shared" else "#475569"
        if kind=="shared":
            x1,y1,x2,y2=sx+bw/2,sy,tx+bw/2,ty
            d=f"M{x1} {y1} C{x1} {min(y1,y2)-40}, {x2} {min(y1,y2)-40}, {x2} {y2}"
        else:
            mid=(x1+x2)/2;d=f"M{x1} {y1} C{mid} {y1}, {mid} {y2}, {x2-9} {y2}"
            if depth[target]-depth[source]>1:
                # Route skip connections above intervening nodes, not through them.
                rail=80+(len(source)+len(target))%5*4
                d=f"M{x1} {y1} L{x1+18} {y1} L{x1+18} {rail} L{x2-18} {rail} L{x2-18} {y2} L{x2-9} {y2}"
        attrs={"d":d,"fill":"none","stroke":color,"stroke-width":"2","data-source":source,"data-target":target,"data-port":port,"data-kind":kind}
        if kind=="shared":attrs["stroke-dasharray"]="7 5"
        element("path",attrs)
        if kind!="shared":element("polygon",dict(points=f"{x2-9},{y2-5} {x2},{y2} {x2-9},{y2+5}",fill=color))
        txt((x1+x2)/2,y2-9,(EDGE_ZH.get(port,port) if language == "zh_CN" else port)[:28],11,color)
    colors={"input":"#dbeafe","layer":"#ede9fe","output":"#dcfce7","state":"#fef3c7","stage":"#ffedd5"}
    for n,node in nodes.items():
        x,y=positions[n];group=element("g",{"data-node":n})
        element("title",parent=group).text=node["title"]+"\n"+node.get("detail","")
        element("rect",dict(x=str(x),y=str(y),width=str(bw),height=str(bh),rx="12",fill=colors.get(node.get("kind"),"#fff"),stroke="#64748b"),group)
        lines=textwrap.wrap(node["title"],25 if compact else 33)
        details=textwrap.wrap(node.get("detail",""),29 if compact else 39)
        for j,line in enumerate((lines+details)[:4 if compact else 7]):txt(x+14,y+25+j*19,line,14 if j==0 else 12,parent=group)
    return ET.tostring(root,encoding="unicode",xml_declaration=True)


def topology_svg(plan, compact=False, language="en_US"):
    t = lambda zh,en: zh if language == "zh_CN" else en
    nodes={"$input":dict(title=t("基因型", "Genotypes"),detail=str(plan["input_shape"]),kind="input")};edges=[]
    for name,width in plan.get("external_inputs",{}).items():nodes["$input:"+name]=dict(title=name,detail=t(f"[批量, {width}] · 按 ID 匹配的数值", f"[batch, {width}] · ID-aligned numeric"),kind="input")
    if "reference_state" in plan:nodes["$reference"]=dict(title=t("冻结的参考基因型", "Frozen reference genotypes"),detail=t("不含待预测标签", "No query labels"),kind="state")
    previous="$input"
    for row in plan["layers"]:
        identifier=row["id"]
        nodes[identifier]=dict(title=f"{identifier} {row['type']}",detail=t(f"{row['output_shape']} | 参数 {row['parameters']:,}\n", f"{row['output_shape']} | params {row['parameters']:,}\n")+json.dumps(row.get("kwargs",{}),ensure_ascii=False),kind="layer")
        for port,source in row.get("inputs",{"x":previous}).items():edges.append((source,identifier,port,"data"))
        if row.get("share_with"):edges.append((row["share_with"],identifier,"shared state","shared"))
        if row["type"]=="ReferenceGraphSAGE":edges.append(("$reference",identifier,"reference","data"))
        previous=identifier
    nodes["$output"]=dict(title=t("回归输出", "Regression outputs"),detail=str(plan["output_shape"])+" "+", ".join(plan.get("output_targets",[])),kind="output")
    edges.append((plan.get("output",previous),"$output","output","data"))
    if plan.get("reconstruction_output"):
        nodes["$reconstruction"]=dict(title=t("重建输出", "Reconstruction"),detail=t("仅观测到的基因型", "Observed genotypes only"),kind="output")
        edges.append((plan["reconstruction_output"],"$reconstruction","auxiliary","data"))
    return draw_graph(nodes,edges,plan["name"],plan,compact,language)


def workflow_svg(project, preview=None, language="en_US"):
    t = lambda zh,en: zh if language == "zh_CN" else en
    cv=project["run"].get("extensions",{}).get("cross_validation")
    stages=project["run"]["training"].get("stages",[])
    nodes={}
    def node(n,title,detail="",kind="stage"):nodes[n]=dict(title=title,detail=detail,kind=kind)
    node("source",t("基因型与表型", "Genotype + phenotype"),t("明确的个体 ID", "Explicit IDs"), "input")
    node("match",t("匹配个体并检查标签", "Match & valid labels"),t("缺失标签保持缺失", "Missing labels remain missing"))
    node("split",t("交叉验证外层划分", "Cross-validation outer folds") if cv else t("固定划分", "Fixed split"),t("计划已保存", "Plan saved") if preview else t("划分待生成", "Plan pending"))
    rows=(preview or {}).get("rows",[])
    for key in ("train","validation","test"):
        counts="; ".join(t(f"折 {r['fold']}: 个体={r['individuals']}, 观测={r['observed']}", f"fold {r['fold']}: n={r['individuals']}, observed={r['observed']}") for r in rows if r["partition"]==key)
        node(key,t({"train":"训练集", "validation":"验证集", "test":"测试集"}[key],key),counts or (t("内层划分", "Inner partition") if cv and key!="test" else t("外层测试", "Outer test") if cv else t("人数待生成", "Counts pending")))
    node("preprocess",t("拟合预处理", "Fit preprocessing"),t("仅内层训练：筛选、填补、标准化", "Inner TRAIN only: filtering, imputation, scaling"), "state")
    node("fit",t("训练前向计算", "TRAIN forward pass"),t("当前网络定义和训练阶段", "Configured ModelSpec; current training stage"))
    node("loss",t("训练目标", "Training objective"),t("观测标签 MSE；按目标使用缺失掩码", "Observed-label MSE; per-target mask") if project.get("extensions",{}).get("multitask") else t("MSE；仅显式配置时加入重建损失", "MSE; reconstruction only if explicitly configured"))
    node("update",t("反向传播与优化器", "Backward & optimizer"),project["run"]["training"]["optimizer"]+t(" · 按批量更新未冻结参数", " · update unfrozen parameters; repeat per batch"))
    node("select",t("验证集选择权重", "Validation selects weights"),t("早停不使用测试标签", "Early stopping; no TEST labels"))
    node("model",t("固定的模型包", "Frozen model bundle"),t("权重、预处理和位点", "Weights + transforms + markers"), "state")
    node("evaluate",t("测试集或 OOF 评估", "TEST / OOF evaluation"),"Pearson, RMSE, MAE", "output")
    node("query",t("新个体", "New individuals"),t("相同编码；无需标签", "Same encoding; no labels"), "input")
    node("predict",t("固定模型预测", "Frozen prediction"),t("原始目标量纲；不自动等于育种值", "Input target scale; not automatically GEBV"), "output")
    tuples=[("source","match","IDs"),("match","split","eligible"),("split","train",""),("split","validation",""),("split","test",""),
        ("train","preprocess","fit"),("train","loss","labels / mask"),("preprocess","fit","transform X"),
        ("fit","loss","predictions"),("loss","update","gradients"),
        ("preprocess","select","frozen transform"),("validation","select","X, labels"),("update","select","candidate weights"),
        ("select","model","best weights"),("preprocess","model","state"),("model","evaluate","frozen predict"),("test","evaluate","X, labels"),
        ("model","predict","frozen predict"),("query","predict","X")]
    previous=None
    for i,stage in enumerate(stages):
        key=f"stage_{i+1}"
        node(key,t(f"阶段 {i+1}: {stage['mode']}", f"Stage {i+1}: {stage['mode']}"),t(f"轮数≤{stage['epochs']} · 回归权重={stage['regression_weight']} · 重建权重={stage['reconstruction_weight']} · 冻结层={stage['freeze']}",f"epochs≤{stage['epochs']} · regression={stage['regression_weight']} · reconstruction={stage['reconstruction_weight']} · frozen={stage['freeze']}"),"state")
        if previous:tuples.append((previous,key,"next stage"))
        previous=key
    if previous:tuples.append((previous,"fit","stage schedule"))
    targets=project.get("extensions",{}).get("multitask",{}).get("targets",[])
    for target in targets:
        key="head_"+target["id"]
        node(key,target["id"],f"{target['trait']} / {target['environment']} / {target['unit']}","output")
        tuples.append(("predict",key,"target column"))
    return draw_graph(nodes,[(a,b,p,"data") for a,b,p in tuples],t("GPNB · 训练与预测流程", "GPNB · Training & prediction flow"),dict(project=project,preview=preview),True,language)
