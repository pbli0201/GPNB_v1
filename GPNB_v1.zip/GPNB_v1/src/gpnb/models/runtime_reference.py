"""Individual reference graph; no labels and no query-to-reference messages."""
import torch
from torch import nn


class ReferenceBuffers(nn.Module):
    def __init__(self, state):
        super().__init__()
        self.register_buffer("features", torch.zeros(*state["feature_shape"], dtype=torch.float32, device="cpu"))
        self.register_buffer("indices", torch.tensor(state["indices"], dtype=torch.int64, device="cpu"))
        self.register_buffer("weights", torch.tensor(state["weights"], dtype=torch.float32, device="cpu"))


class ReferenceGraphSAGE(nn.Module):
    def __init__(self, in_features, hidden_size, num_layers, bias, max_message_elements):
        super().__init__()
        self.layers = nn.ModuleList([
            nn.ModuleDict(dict(own=nn.Linear(in_features if i == 0 else hidden_size, hidden_size, bias=bias, device="cpu", dtype=torch.float32),
                               neighbor=nn.Linear(in_features if i == 0 else hidden_size, hidden_size, bias=False, device="cpu", dtype=torch.float32)))
            for i in range(num_layers)])
        self.max_message_elements = max_message_elements
        self.hidden_size = hidden_size

    def bind_reference(self, buffers):
        object.__setattr__(self, "_reference", buffers)

    def forward(self, x, context):
        g = self._reference
        indices, weights = context["indices"], context["weights"]
        n, k = g.indices.shape
        if (n + x.shape[0])*k*self.hidden_size > self.max_message_elements:
            raise ValueError("Reference graph message budget exceeded; reduce reference/query size or hidden width")
        reference = g.features
        query = x
        for layer in self.layers:
            projected = layer["neighbor"](reference)
            query = (layer["own"](query) + (projected[indices]*weights[..., None]).sum(1)).relu()
            reference = (layer["own"](reference) + (projected[g.indices]*g.weights[..., None]).sum(1)).relu()
        return query


def check_reference_context(context, state, batch, device):
    if type(context) is not dict or set(context) != {"indices", "weights"}:
        raise ValueError("Reference component requires explicit query neighbor indices/weights from its data adapter")
    indices, weights = context["indices"], context["weights"]
    shape = [batch, state["neighbors"]]
    if (not isinstance(indices, torch.Tensor) or list(indices.shape) != shape or indices.dtype != torch.int64
            or indices.device != device or torch.any((indices < 0) | (indices >= state["feature_shape"][0]))):
        raise ValueError("Invalid reference query neighbor indices")
    if shape[1] > 1 and torch.any(indices.sort(1).values[:, 1:] == indices.sort(1).values[:, :-1]):
        raise ValueError("Reference query neighbors must be distinct")
    if (not isinstance(weights, torch.Tensor) or list(weights.shape) != shape or not weights.is_floating_point()
            or weights.device != device or weights.requires_grad or not torch.isfinite(weights).all()
            or torch.any(weights < 0)):
        raise ValueError("Reference query weights must be frozen finite nonnegative floats")
    totals = weights.sum(1)
    if not torch.all((totals == 0) | ((totals-1).abs() <= 1e-6)):
        raise ValueError("Reference query weights must sum to one or zero")
