"""ModelSpec -> resolved sequential plan -> PyTorch, diagram and source."""
from .core import build_model, inspect_model, template_diff

__all__ = ["build_model", "inspect_model", "template_diff"]
