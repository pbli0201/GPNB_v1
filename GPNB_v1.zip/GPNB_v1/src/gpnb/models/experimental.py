"""Bounded experimental components; exact contracts, no optional backend."""
from math import prod

from ..config import fail

NAMES = {"ToGrid", "Conv2d", "MaxPool2d", "AvgPool2d", "AdaptiveAvgPool2d",
         "BatchNorm2d", "GridReadout", "FeatureAffine"}


def register(Component, Parameter, components):
    integer = lambda value, low=1, high=2**31-1: Parameter("int", value, low, high)
    boolean = lambda value: Parameter("bool", value)
    choice = lambda value, options: Parameter("choice", value, choices=options)
    limit = integer(8_000_000)
    def add(name, params, kinds, ports=("x",)):
        components[name] = Component(name, params, kinds, ports=ports)
    add("ToGrid", dict(channels=integer(1), rows=integer(0, 0), columns=integer(8),
        layout=choice("file_order_user_grid", ("file_order_user_grid",)),
        padding=choice("zero_end", ("error", "zero_end")), max_elements=limit), ("Vector",))
    axes = dict(kernel_h=integer(3), kernel_w=integer(3), stride_h=integer(1), stride_w=integer(1),
                padding_h=integer(0, 0), padding_w=integer(0, 0))
    add("Conv2d", dict(**axes, out_channels=integer(8), dilation_h=integer(1), dilation_w=integer(1),
                      groups=integer(1), bias=boolean(True), max_elements=limit), ("Grid",))
    for name in ("MaxPool2d", "AvgPool2d"):
        add(name, dict(**axes, ceil_mode=boolean(False), max_elements=limit,
                       **({"count_include_pad": boolean(True)} if name == "AvgPool2d" else {})), ("Grid",))
    add("AdaptiveAvgPool2d", dict(rows=integer(2), columns=integer(2), max_elements=limit), ("Grid",))
    add("BatchNorm2d", dict(eps=Parameter("float", 1e-5, 1e-12, 1.),
        momentum=Parameter("float", .1, 0., 1.), affine=boolean(True)), ("Grid",))
    add("GridReadout", {"mode": choice("mean", ("mean", "sum", "max"))}, ("Grid",))
    add("FeatureAffine", {"bias": boolean(True)}, ("Vector", "Sequence"), ("x", "condition"))
    for name in ("Flatten", "Identity", "Dropout", "ReLU", "GELU", "Tanh", "Sigmoid",
                 "SiLU", "ELU", "SELU", "Softplus", "Softsign", "LeakyReLU"):
        old = components[name]
        components[name] = Component(name, old.parameters, (*old.input_kinds, "Grid"))


def resolve(name, ports, p, path):
    from .registry import TensorType
    x = ports["x"]
    dims = x.dimensions
    kwargs, shape, count, buffers = dict(p), x, 0, 0
    if name == "ToGrid":
        c, w = p["channels"], p["columns"]
        h = p["rows"] or (dims[0]+c*w-1)//(c*w)
        if c*h*w < dims[0] or (p["padding"] == "error" and c*h*w != dims[0]):
            fail("E_GRID", path, "grid cannot truncate features; select exact dimensions or explicit zero_end padding")
        kwargs = dict(input_features=dims[0], channels=c, rows=h, columns=w, max_elements=p["max_elements"])
        shape = TensorType("Grid", (c,h,w))
    elif name in ("Conv2d", "MaxPool2d", "AvgPool2d"):
        c,h,w = dims
        sizes = []
        for axis, length in zip(("h", "w"), (h,w)):
            k,s,pad,d = p["kernel_"+axis],p["stride_"+axis],p["padding_"+axis],p.get("dilation_"+axis, 1)
            if name != "Conv2d" and pad > k//2:
                fail("E_GRID", path, "pool padding cannot exceed half kernel on either axis")
            n = (length+2*pad-d*(k-1)-1+(s-1 if p.get("ceil_mode") else 0))//s+1
            if p.get("ceil_mode") and (n-1)*s >= length+pad:
                n -= 1
            if n < 1:
                fail("E_GRID", path, "grid spatial dimension is zero or negative")
            sizes.append(n)
        kwargs = dict(kernel_size=[p["kernel_h"],p["kernel_w"]],
            stride=[p["stride_h"],p["stride_w"]], padding=[p["padding_h"],p["padding_w"]],
            max_elements=p["max_elements"], output_elements=(p.get("out_channels",c)*prod(sizes)))
        if name == "Conv2d":
            out,g = p["out_channels"],p["groups"]
            if c%g or out%g:
                fail("E_GRID", path, "groups must divide input and output channels")
            kwargs.update(in_channels=c,out_channels=out,dilation=[p["dilation_h"],p["dilation_w"]],
                          groups=g,bias=p["bias"])
            count = out*(c//g)*p["kernel_h"]*p["kernel_w"]+out*p["bias"]
            c = out
        else:
            kwargs["ceil_mode"] = p["ceil_mode"]
            if name == "AvgPool2d":
                kwargs["count_include_pad"] = p["count_include_pad"]
        shape = TensorType("Grid",(c,*sizes))
    elif name == "AdaptiveAvgPool2d":
        shape = TensorType("Grid",(dims[0],p["rows"],p["columns"]))
    elif name == "BatchNorm2d":
        kwargs = dict(num_features=dims[0],track_running_stats=True,**p)
        count, buffers = 2*dims[0]*p["affine"],8*dims[0]+8
    elif name == "GridReadout":
        shape = TensorType("Vector",(dims[0],))
    elif name == "FeatureAffine":
        if ports["condition"].kind != "Vector":
            fail("E_PORT",path,"FeatureAffine condition must be a per-individual Vector")
        kwargs.update(width=dims[-1],condition_width=ports["condition"].dimensions[0])
        count = 2*dims[-1]*(ports["condition"].dimensions[0]+p["bias"])
    if "max_elements" in p:
        elements = prod(shape.dimensions)
        if elements > p["max_elements"]:
            fail("E_RESOURCE",path,"component element budget cannot support even one individual")
    return kwargs,shape,count,buffers
