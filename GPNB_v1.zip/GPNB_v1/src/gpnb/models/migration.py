"""Explicit v1 -> v2 copies; never rewrites a historical experiment."""
from __future__ import annotations

from pathlib import Path

from ..config import ModelSpec, fail, load_spec
from ..data.files import sha256, write_json


def migrate_model(spec):
    if not isinstance(spec, ModelSpec) or spec.to_dict()["schema_version"] != 1:
        fail("E_VERSION", "migration", "expected a v1 ModelSpec")
    value = spec.to_dict()
    value.update(schema_version=2, backend="pytorch")
    previous = "$input"
    for layer in value["layers"]:
        layer.update(implementation_version=1, inputs={"x": previous})
        previous = layer["id"]
    return ModelSpec(value)


def migrate_file(source, output):
    source, output = Path(source).resolve(), Path(output).resolve()
    spec = load_spec(source)
    migrated = migrate_model(spec)
    if output.exists():
        fail("E_EXISTS", str(output), "migration needs a new directory")
    if source.is_relative_to(output):
        fail("E_IO", str(output), "migration must not contain the source")
    original = source.read_bytes()
    original_sha = sha256(source)
    output.mkdir(parents=True)
    (output / "INCOMPLETE").write_text("Migration in progress", encoding="utf-8")
    (output / "original.json").write_bytes(original)
    migrated.save(output / "model.json")
    if sha256(source) != original_sha:
        fail("E_MANIFEST", str(source), "source changed while migrating")
    report = dict(ok=True, from_version=1, to_version=2, original_file_sha256=original_sha,
                  original_model_sha256=spec.sha256, model_sha256=migrated.sha256,
                  source=str(source), output=str(output),
                  semantics="Explicit sequential inputs; identical mathematics and state_dict keys.")
    write_json(output / "migration.json", report)
    (output / "INCOMPLETE").unlink()
    return report
