"""Turn supported composite cards into ordinary editable DAG nodes."""
import copy
import uuid

from ..config import ModelSpec, fail
from .core import inspect_model
from .registry import component

EXPANDABLE = {"TransformerEncoder", "TCNBlock", "SqueezeExcite1d", "GatedMLP", "GatedAdd", "MLPMixer", "DenseMoE"}


def expand_model(spec, index, features):
    value = spec.to_dict()
    plan = inspect_model(spec, features)
    old = value["layers"][index]
    if old["type"] not in EXPANDABLE:
        fail("E_MODEL", old["id"], "this component is a primitive, not an expandable block")
    if "share_with" in old or any(r.get("share_with") == old["id"] for r in value["layers"]):
        fail("E_MODEL", old["id"], "detach shared calls before expanding a composite")
    p, shape = old["params"], plan["layers"][index]
    rows = []
    prefix = old["id"] + "_expanded_" + uuid.uuid4().hex[:6]
    previous = old["inputs"].get("x")

    def add(kind, params=None, inputs=None):
        nonlocal previous
        identifier = prefix + "_" + str(len(rows) + 1)
        rows.append(dict(id=identifier, type=kind, implementation_version=1,
                         inputs=inputs if inputs is not None else {"x": previous},
                         params={**copy.deepcopy(component(kind).defaults()), **(params or {})}))
        previous = identifier
        return identifier

    def linear(width, bias=True, source=None):
        return add("Linear", dict(out_features=width, bias=bias), {"x": source} if source else None)

    def drop(probability):
        return add("Dropout", {"p": probability})

    def mask(source=None):
        return add("ApplyMask", inputs={"x": source or previous, "mask": old["inputs"]["mask"]})

    kind, width = old["type"], shape["input_shape"][-1]
    if kind == "TCNBlock":
        start = previous
        for out, activation in ((p["hidden_size"], True), (shape["input_shape"][1], False)):
            add("CausalConv1d", dict(out_channels=out, kernel_size=p["kernel_size"], dilation=p["dilation"],
                                     stride=1, bias=p["bias"]))
            if activation:
                add("ReLU")
            drop(p["dropout"])
        add("Add", inputs={"a": start, "b": previous})
        add("ReLU")
    elif kind == "SqueezeExcite1d":
        start = previous
        add("GlobalPool1d", {"mode": "mean"})
        linear(p["hidden_size"])
        add("ReLU")
        linear(shape["input_shape"][1])
        add("Sigmoid")
        add("ChannelScale", inputs={"x": start, "gate": previous})
    elif kind == "GatedMLP":
        projected = linear(2 * p["hidden_size"], p["bias"])
        axis = len(shape["input_shape"]) - 1
        left = add("Slice", dict(axis=axis, start=0, stop=p["hidden_size"]), {"x": projected})
        add("Slice", dict(axis=axis, start=p["hidden_size"], stop=2*p["hidden_size"]), {"x": projected})
        add("GELU")
        add("Multiply", inputs={"a": left, "b": previous})
        drop(p["dropout"])
        linear(width, p["bias"])
    elif kind == "GatedAdd":
        a, b = old["inputs"]["a"], old["inputs"]["b"]
        add("Concat", {"axis": len(shape["input_shape"]) - 1}, {"a": a, "b": b})
        linear(width, p["bias"])
        gate = add("Sigmoid")
        inverse = add("OneMinus")
        left = add("Multiply", inputs={"a": a, "b": gate})
        right = add("Multiply", inputs={"a": b, "b": inverse})
        add("Add", inputs={"a": left, "b": right})
    elif kind == "DenseMoE":
        start, accumulator = previous, None
        linear(p["num_experts"])
        gate = add("Softmax")
        for i in range(p["num_experts"]):
            linear(p["hidden_size"], source=start)
            add("GELU")
            drop(p["dropout"])
            expert = linear(p["out_features"])
            weight = add("Slice", dict(axis=1, start=i, stop=i+1), {"x": gate})
            weighted = add("ScaleByWeight", inputs={"x": expert, "weight": weight})
            accumulator = weighted if accumulator is None else add("Add", inputs={"a": accumulator, "b": weighted})
        previous = accumulator
    elif kind == "MLPMixer":
        start = mask()
        add("LayerNorm", {"eps": p["eps"]})
        add("Permute", {"axes": [1, 0], "layout": "Sequence"})
        linear(p["token_hidden"])
        add("GELU")
        drop(p["dropout"])
        linear(shape["input_shape"][1])
        add("Permute", {"axes": [1, 0], "layout": "Sequence"})
        drop(p["dropout"])
        add("Add", inputs={"a": start, "b": previous})
        start = mask()
        add("LayerNorm", {"eps": p["eps"]})
        linear(p["channel_hidden"])
        add("GELU")
        drop(p["dropout"])
        linear(width)
        drop(p["dropout"])
        add("Add", inputs={"a": start, "b": previous})
        mask()
    else:  # TransformerEncoder
        mask()
        for _ in range(p["num_layers"]):
            start = previous
            if p["norm_first"]:
                add("LayerNorm", {"eps": p["eps"]})
            add("SelfAttention", {k: p[k] for k in ("num_heads", "dropout", "bias", "causal", "max_score_elements")},
                {"x": previous, "mask": old["inputs"]["mask"]})
            drop(p["dropout"])
            add("Add", inputs={"a": start, "b": previous})
            if not p["norm_first"]:
                add("LayerNorm", {"eps": p["eps"]})
            start = previous
            if p["norm_first"]:
                add("LayerNorm", {"eps": p["eps"]})
            linear(p["dim_feedforward"], p["bias"])
            add("GELU" if p["activation"] == "gelu" else "ReLU")
            drop(p["dropout"])
            linear(width, p["bias"])
            drop(p["dropout"])
            add("Add", inputs={"a": start, "b": previous})
            if not p["norm_first"]:
                add("LayerNorm", {"eps": p["eps"]})
            mask()
    rows.append(dict(id=old["id"], type="Identity", implementation_version=1, inputs={"x": previous}, params={}))
    value["layers"][index:index+1] = rows
    value["graph_mode"] = "dag"
    value["output"] = plan["output"]
    extensions = value.setdefault("extensions", {})
    extensions.setdefault("expansions", []).append(dict(original_model_sha256=spec.sha256,
        original_layer=old, replacement_ids=[r["id"] for r in rows],
        semantics="Editable untrained architecture expansion; no trained weights copied or silently migrated."))
    extensions.setdefault("blocks", []).append(dict(name=old["id"] + " expanded", layers=[r["id"] for r in rows]))
    result = ModelSpec(value)
    expanded = inspect_model(result, features)
    if expanded["parameters"] != plan["parameters"] or expanded["output_shape"] != plan["output_shape"]:
        fail("E_MODEL", old["id"], "expansion changed parameter count or output shape")
    return result
