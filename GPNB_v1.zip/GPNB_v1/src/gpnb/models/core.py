from __future__ import annotations

from ..config import ModelSpec, default_model, fail, number

# Closed registry: user-supplied names are never evaluated or dynamically imported.
REGISTRY = {name: name for name in ("Linear", "Dropout", "ReLU", "GELU", "Tanh", "Sigmoid")}
TEMPLATE_ID = "basic_mlp_v1"
DEFAULT_PARAMETER_BYTES = 256 * 1024**2


def inspect_model(spec: ModelSpec, input_features: int, *, graph_state=None, reference_state=None):
    """Resolve shapes and exact float32 parameter storage without allocation."""
    if not isinstance(spec, ModelSpec):
        fail("E_TYPE", "model", "expected a validated ModelSpec")
    number(input_features, "input_features", 1, 2**31 - 1, integer=True)
    labels = [spec.to_dict()["name"], *[layer["id"] for layer in spec.to_dict()["layers"]]]
    for label in labels:
        if any(not (c in "\t\n\r" or 0x20 <= ord(c) <= 0xD7FF or
                    0xE000 <= ord(c) <= 0xFFFD or 0x10000 <= ord(c) <= 0x10FFFF) for c in label):
            fail("E_MODEL", "name/id", "control characters incompatible with XML diagrams are not allowed")
    if spec.to_dict()["schema_version"] == 2:
        from .registry import resolve_v2
        return resolve_v2(spec, input_features, graph_state, reference_state)
    width, rows, total = input_features, [], 0
    for i, layer in enumerate(spec.to_dict()["layers"]):
        kind, params = layer["type"], layer["params"]
        if kind not in REGISTRY:
            fail("E_MODEL", f"layers[{i}]", f"unsupported layer {kind}")
        kwargs = dict(params)
        before, count = width, 0
        if kind == "Linear":
            kwargs = {"in_features": width, **params}
            width = params["out_features"]
            count = before * width + (width if params["bias"] else 0)
        rows.append({"index": i, "id": layer["id"], "type": kind, "constructor": REGISTRY[kind],
                     "kwargs": kwargs, "input_shape": ["batch", before], "output_shape": ["batch", width],
                     "parameters": count, "trainable_parameters": count})
        total += count
    # Regression always remains [batch, 1], including a batch of one.
    if width != 1:
        fail("E_MODEL", "output", "single-trait regression requires [batch, 1]")
    return {"schema_version": 1, "kind": "resolved_model", "model_sha256": spec.sha256,
            "name": spec.to_dict()["name"], "input_shape": ["batch", input_features],
            "output_shape": ["batch", 1], "layers": rows, "parameters": total,
            "trainable_parameters": total, "parameter_dtype": "float32",
            "parameter_bytes": total * 4,
            "storage_scope": "Parameters only; excludes gradients, optimizer, activations and framework memory."}


def check_budget(plan, max_parameter_bytes):
    number(max_parameter_bytes, "max_parameter_bytes", 1, integer=True)
    if plan["parameter_bytes"] + plan.get("buffer_bytes", 0) > max_parameter_bytes:
        fail("E_MODEL_LIMIT", "parameters",
             f"float32 parameter storage {plan['parameter_bytes']} bytes exceeds allocation budget {max_parameter_bytes}; inspect without allocating or raise the explicit budget")


def check_execution(plan, device, deterministic, batch_size, train_count):
    """Reject unsupported training combinations before allocating/fitting."""
    for row in plan["layers"]:
        if "element_cost" in row:
            c = row["element_cost"]
            if min(batch_size, train_count)*c["elements_per_sample"] > c["limit_elements_per_call"]:
                fail("E_MODEL_LIMIT",row["id"],"training batch exceeds experimental component element budget")
        if "reference_cost" in row:
            c = row["reference_cost"]
            if c["reference_message_elements"] + min(batch_size, train_count)*c["query_message_elements_per_sample"] > c["limit_elements_per_call"]:
                fail("E_MODEL_LIMIT", row["id"], "reference graph message budget exceeded")
        if "graph_cost" in row:
            cost = row["graph_cost"]
            if min(batch_size, train_count) * cost["message_elements_per_sample"] > cost["limit_elements_per_call"]:
                fail("E_MODEL_LIMIT", row["id"], "training batch exceeds graph message budget")
        if "attention_cost" in row:
            cost = row["attention_cost"]
            if min(batch_size, train_count) * cost["score_elements_per_sample"] > cost["limit_elements_per_call"]:
                fail("E_MODEL_LIMIT", row["id"], "training batch exceeds attention score budget; reduce batch size/tokens or raise explicit limit")
        if row["type"] == "AdaptiveMaxPool1d" and device == "cuda" and deterministic:
            fail("E_DEVICE", row["id"], "AdaptiveMaxPool1d CUDA deterministic backward is unsupported; select CPU")
        if row["type"] in ("BatchNorm1d", "BatchNorm2d"):
            from math import prod
            spatial = prod(row["input_shape"][2:])
            smallest = min(batch_size, train_count)
            if train_count % batch_size:
                smallest = min(smallest, train_count % batch_size)
            if smallest * spatial < 2:
                fail("E_MODEL", row["id"], "BatchNorm would receive one training observation; change batch size or normalization")


def _check_input(x, input_features):
    # This function is also copied verbatim into standalone generated source.
    import torch
    if not isinstance(x, torch.Tensor):
        raise ValueError("expected a torch.Tensor")
    if x.ndim != 2 or x.shape[1] != input_features or x.shape[0] < 1:
        raise ValueError(f"expected nonempty [batch, {input_features}], got {tuple(x.shape)}")
    if not x.is_floating_point():
        raise ValueError("expected floating point preprocessed genotypes, not raw integer doses")


# Lazy torch import keeps schema/static inspection free from torch allocation.
def build_model(spec, input_features, *, seed=5209, max_parameter_bytes=DEFAULT_PARAMETER_BYTES,
                graph_state=None, reference_state=None, reference_data=None):
    plan = inspect_model(spec, input_features, graph_state=graph_state, reference_state=reference_state)
    check_budget(plan, max_parameter_bytes)
    number(seed, "seed", 0, 2**32 - 1, integer=True)
    if spec.to_dict()["schema_version"] == 2:
        from .runtime import build_resolved
        model = build_resolved(plan, seed, max_parameter_bytes)
        if reference_data is not None:
            from ..graphs.individual import feature_digest
            if reference_state is None or feature_digest(reference_data) != reference_state["feature_sha256"]:
                fail("E_REFERENCE", "reference_data", "reference features differ from frozen data digest")
            import torch
            model.reference_buffers.features.copy_(torch.as_tensor(reference_data, dtype=torch.float32, device="cpu"))
        return model
    import torch

    class SequentialRegressor(torch.nn.Sequential):
        def forward(self, x):
            _check_input(x, input_features)
            return super().forward(x)

    # Only initialize the CPU RNG; do not change caller CPU/CUDA RNG streams.
    with torch.random.fork_rng(devices=[]):
        torch.random.default_generator.manual_seed(seed)
        modules = []
        for row in plan["layers"]:
            kwargs = dict(row["kwargs"])
            if row["type"] == "Linear":
                kwargs.update(device="cpu", dtype=torch.float32)
            modules.append(getattr(torch.nn, row["constructor"])(**kwargs))
        model = SequentialRegressor(*modules)
    model.input_features = input_features
    model.model_sha256 = spec.sha256
    return model


def template_diff(spec, baseline=None):
    """ID-based diff; records positions as well as changes to layer parameters."""
    recorded = spec.to_dict().get("extensions", {}).get("template", {})
    baseline = baseline or (ModelSpec(recorded["baseline"]) if "baseline" in recorded else default_model())
    before, after = baseline.to_dict(), spec.to_dict()
    old = {row["id"]: (i, row) for i, row in enumerate(before["layers"])}
    new = {row["id"]: (i, row) for i, row in enumerate(after["layers"])}
    changes = []
    for name in old.keys() | new.keys():
        if name not in old:
            changes.append({"id": name, "change": "added", "after": new[name][1], "index": new[name][0]})
        elif name not in new:
            changes.append({"id": name, "change": "removed", "before": old[name][1], "index": old[name][0]})
        else:
            oi, ol = old[name]
            ni, nl = new[name]
            if ol != nl or oi != ni:
                changes.append({"id": name, "change": "modified_or_moved", "before": ol, "after": nl,
                                "old_index": oi, "new_index": ni})
    changes.sort(key=lambda change: change["id"])
    metadata = {key: {"before": before.get(key), "after": after.get(key)}
                for key in sorted(before.keys() | after.keys()) if key != "layers" and before.get(key) != after.get(key)}
    return {"template_id": TEMPLATE_ID if baseline.sha256 == default_model().sha256 else "custom_baseline",
            "baseline_sha256": baseline.sha256, "model_sha256": spec.sha256,
            "baseline": before, "identical": before == after, "layer_changes": changes, "metadata_changes": metadata}
