"""Native experimental formulas, embedded in portable source exports."""
import math
import torch
from torch import nn
from torch.nn import functional as F


def check_elements(size, limit):
    if size > limit:
        raise ValueError("Experimental component element budget exceeded; reduce batch/width or explicitly raise limit")


class ToGrid(nn.Module):
    def __init__(self, input_features, channels, rows, columns, max_elements):
        super().__init__()
        self.shape, self.width, self.limit = (channels,rows,columns), input_features, max_elements

    def forward(self,x):
        size = math.prod(self.shape)
        check_elements(x.shape[0]*size,self.limit)
        return F.pad(x,(0,size-self.width)).reshape(x.shape[0],*self.shape)


class GridOperation(nn.Module):
    native = None
    def __init__(self,max_elements,output_elements,**kwargs):
        super().__init__()
        self.limit,self.size = max_elements,output_elements
        if self.native == nn.Conv2d:
            kwargs.update(device="cpu",dtype=torch.float32)
        self.operation = self.native(**kwargs)

    def forward(self,x):
        check_elements(x.shape[0]*self.size,self.limit)
        return self.operation(x)


class Conv2d(GridOperation):
    native = nn.Conv2d


class MaxPool2d(GridOperation):
    native = nn.MaxPool2d


class AvgPool2d(GridOperation):
    native = nn.AvgPool2d


class AdaptiveAvgPool2d(nn.Module):
    def __init__(self,rows,columns,max_elements):
        super().__init__()
        self.rows,self.columns,self.limit = rows,columns,max_elements

    def forward(self,x):
        b,c,h,w = x.shape
        check_elements(b*c*self.rows*self.columns,self.limit)
        return torch.stack([torch.stack([
            x[...,i*h//self.rows:((i+1)*h+self.rows-1)//self.rows,
              j*w//self.columns:((j+1)*w+self.columns-1)//self.columns].mean((-2,-1))
            for j in range(self.columns)],dim=-1) for i in range(self.rows)],dim=-2)


class GridReadout(nn.Module):
    def __init__(self,mode):
        super().__init__()
        self.mode = mode

    def forward(self,x):
        return x.mean((-2,-1)) if self.mode == "mean" else x.sum((-2,-1)) if self.mode == "sum" else x.amax((-2,-1))


class FeatureAffine(nn.Module):
    def __init__(self,width,condition_width,bias):
        super().__init__()
        self.affine = nn.Linear(condition_width,2*width,bias=bias,device="cpu",dtype=torch.float32)

    def forward(self,x,condition):
        if x.shape[0] != condition.shape[0]:
            raise ValueError("FeatureAffine requires aligned individual batches")
        gamma,beta = self.affine(condition).chunk(2,-1)
        if x.ndim == 3:
            gamma,beta = gamma[:,None,:],beta[:,None,:]
        return (1+gamma)*x+beta


EXPERIMENTAL_RUNTIME = {c.__name__:c for c in (ToGrid,Conv2d,MaxPool2d,AvgPool2d,AdaptiveAvgPool2d,
    GridReadout,FeatureAffine)}
