"""Small, generic editable examples. No named paper models."""
from ..config import ModelSpec, default_model
from .migration import migrate_model
from .registry import component, regression_head


def with_targets(spec,targets):
    from .migration import migrate_model
    value=(migrate_model(spec) if spec.to_dict()["schema_version"]==1 else spec).to_dict()
    if value.get("reconstruction_output"):
        from ..config import fail
        fail("E_MULTITASK","model","remove the reconstruction training configuration before enabling multi-target heads")
    value["task"]="multi_target_regression"
    value["output_targets"]=[t["id"] for t in targets]
    regression_head(value)["params"]["out_features"]=len(targets)
    return ModelSpec(value)


def numeric_fusion_template(widths):
    """Independent numeric branches with explicit concatenation."""
    if not widths:
        from ..config import fail
        fail("E_INPUT_TABLE", "template", "select at least one numeric input table")
    rows = []
    def add(identifier, kind, inputs, **params):
        rows.append(dict(id=identifier, type=kind, implementation_version=1, inputs=inputs,
                         params={**component(kind).defaults(), **params}))
        return identifier
    source = add("genotype_hidden", "Linear", {"x": "$input"}, out_features=32)
    source = add("genotype_activation", "ReLU", {"x": source})
    for i, name in enumerate(widths):
        branch = add(f"table_{i}_hidden", "Linear", {"x": "$input:"+name}, out_features=16)
        branch = add(f"table_{i}_activation", "ReLU", {"x": branch})
        source = add(f"fusion_{i}", "Concat", {"a": source, "b": branch}, axis=1)
    add("output", "Linear", {"x": source}, out_features=1)
    return ModelSpec(dict(schema_version=2, kind="model", name="Numeric multi-input regression",
                         task="single_trait_regression", backend="pytorch", input_layout="batch_markers",
                         graph_mode="dag", external_inputs=widths, layers=rows))


def reference_template(protocol, widths=None):
    if widths:
        value = numeric_fusion_template(widths).to_dict()
        value["layers"][0].update(type="ReferenceGraphSAGE", params=component("ReferenceGraphSAGE").defaults())
    else:
        value = sequential([("ReferenceGraphSAGE", {}), ("Linear", {"out_features": 1})],
                           "Individual reference graph regression").to_dict()
    value["name"] = "Individual reference graph regression"
    value["individual_graph_spec"] = protocol
    return ModelSpec(value)


def sequential(layers, name="Custom network", representation="standardized_dosage"):
    rows, previous = [], "$input"
    for i, (kind, overrides) in enumerate(layers):
        row = dict(id=f"layer_{i+1}", type=kind, implementation_version=1, inputs={"x": previous},
                   params={**component(kind).defaults(), **overrides})
        rows.append(row)
        previous = row["id"]
    return ModelSpec(dict(schema_version=2, kind="model", backend="pytorch",
                          name=name, task="single_trait_regression", input_layout="batch_markers", layers=rows,
                          input_representation=representation))


def basic_template(name, graph_spec=None):
    if name == "Autoencoder":
        value=sequential([("Tokenize",{"patch_size":8,"embedding_dim":8,"pad_tokens":0}),
            ("GELU",{}),("Flatten",{}),("Linear",{"out_features":16}),("ReLU",{}),
            ("Linear",{"out_features":1})],"Block encoder with reconstruction auxiliary").to_dict()
        value.update(graph_mode="dag",output="layer_6",reconstruction_output="reconstruction")
        value["layers"].append(dict(id="reconstruction",type="ReconstructMarkers",implementation_version=1,
            inputs={"x":"layer_5"},params={"bias":True}))
        return ModelSpec(value)
    if name == "GridCNN":
        return sequential([("ToGrid", {"columns":8}),("Conv2d",{"padding_h":1,"padding_w":1}),
            ("BatchNorm2d",{}),("ReLU",{}),("AdaptiveAvgPool2d",{}),("Flatten",{}),
            ("Linear",{"out_features":1})],"Experimental user-grid CNN")
    if name == "FeatureAffine":
        value = sequential([("Linear",{"out_features":8}),("ReLU",{}),
            ("Linear",{"out_features":1})],"Feature affine conditioning").to_dict()
        value["graph_mode"] = "dag"
        value["layers"].insert(2,dict(id="conditioned",type="FeatureAffine",implementation_version=1,
            inputs={"x":"layer_2","condition":"$input"},params=component("FeatureAffine").defaults()))
        value["layers"][-1]["inputs"]["x"] = "conditioned"
        return ModelSpec(value)
    if name in ("GCN", "GraphSAGE", "GIN", "GAT"):
        from ..config import fail
        if graph_spec is None:
            fail("E_GRAPH", "template", "import/attach a locus GraphSpec before applying a graph template")
        value = sequential([("GraphInput", {}), (name, {}), ("ReLU", {}),
                            ("GraphReadout", {}), ("Linear", {"out_features": 1})], name + " locus regression").to_dict()
        value["graph_spec"] = graph_spec
        return ModelSpec(value)
    if name in ("Mixer", "AttentionPool"):
        value = basic_template("Tokens").to_dict()
        value["name"] = name + " token regression"
        if name == "AttentionPool":
            value["layers"][3].update(type="AttentionPooling", params=component("AttentionPooling").defaults())
        else:
            value["layers"].insert(3, dict(id="mixer", type="MLPMixer", implementation_version=1,
                                          inputs={"x": "layer_2", "mask": "token_mask"}, params=component("MLPMixer").defaults()))
            value["layers"][4]["inputs"]["x"] = "mixer"
        return ModelSpec(value)
    if name == "CrossAttention":
        value = basic_template("Tokens").to_dict()
        value["name"] = "Two-resolution cross attention"
        rows = [dict(id="context", type="Tokenize", implementation_version=1, inputs={"x": "$input"},
                     params={**component("Tokenize").defaults(), "patch_size": 2, "embedding_dim": 12}),
                dict(id="context_mask", type="TokenMask", implementation_version=1, inputs={"x": "$input"},
                     params={"patch_size": 2, "pad_tokens": 0}),
                dict(id="cross", type="CrossAttention", implementation_version=1,
                     inputs=dict(query="layer_2", context="context", query_mask="token_mask", context_mask="context_mask"),
                     params=component("CrossAttention").defaults())]
        value["layers"][3]["inputs"]["x"] = "cross"
        value["layers"][3:3] = rows
        return ModelSpec(value)
    if name == "GatedAdd":
        value = basic_template("Residual").to_dict()
        value["name"] = "Gated branches"
        value["layers"][3].update(type="GatedAdd", params=component("GatedAdd").defaults())
        return ModelSpec(value)
    if name in ("DenseMoE", "GatedMLP"):
        return sequential([("Linear", {"out_features": 16}), (name, {}),
                           ("Linear", {"out_features": 1})], name + " regression")
    if name in ("TCN", "SE"):
        block = [("TCNBlock", {})] if name == "TCN" else [
            ("Conv1d", {"out_channels": 8, "padding": 1}), ("SqueezeExcite1d", {}), ("ReLU", {})]
        return sequential([("ToChannels", {}), *block, ("AdaptiveAvgPool1d", {"output_size": 4}),
                           ("Flatten", {}), ("Linear", {"out_features": 1})], name + " regression")
    if name in ("SelfAttention", "Transformer"):
        value = basic_template("Tokens").to_dict()
        kind = "TransformerEncoder" if name == "Transformer" else "SelfAttention"
        value["name"] = name + " token regression"
        value["layers"].insert(3, dict(id="attention", type=kind, implementation_version=1,
                                      inputs={"x": "layer_2", "mask": "token_mask"}, params=component(kind).defaults()))
        value["layers"][4]["inputs"]["x"] = "attention"
        return ModelSpec(value)
    if name == "Categorical":
        return sequential([("GenotypeEmbedding", {"embedding_dim": 8}), ("Flatten", {}),
                           ("Linear", {"out_features": 16}), ("GELU", {}),
                           ("Linear", {"out_features": 1})], "Categorical genotype MLP", "genotype_categories")
    if name == "Tokens":
        value = sequential([("Tokenize", {"embedding_dim": 8, "patch_size": 4, "pad_tokens": 2}),
                            ("PositionEncoding", {"max_length": 4096}), ("SequenceReadout", {"mode": "mean"}),
                            ("Linear", {"out_features": 1})], "Masked token regression").to_dict()
        value["graph_mode"] = "dag"
        value["layers"][2].update(type="MaskedReadout", inputs={"x": "layer_2", "mask": "token_mask"})
        value["layers"].insert(2, dict(id="token_mask", type="TokenMask", implementation_version=1,
                                       inputs={"x": "$input"}, params={"patch_size": 4, "pad_tokens": 2}))
        return ModelSpec(value)
    if name in ("RNN", "LSTM", "GRU"):
        return sequential([("ToChannels", {}), ("AvgPool1d", {"kernel_size": 4, "stride": 4}),
                           ("Permute", {"axes": [1, 0], "layout": "Sequence"}),
                           (name, {"hidden_size": 8, "bidirectional": True, "readout": "final_state"}),
                           ("Linear", {"out_features": 1})], "Pooled " + name)
    if name == "Residual":
        spec = sequential([("Linear", {"out_features": 16}), ("ReLU", {}),
                           ("Linear", {"out_features": 16}), ("ReLU", {}),
                           ("Linear", {"out_features": 1})], "Residual MLP").to_dict()
        spec["graph_mode"] = "dag"
        spec["layers"].insert(3, dict(id="residual_add", type="Add", implementation_version=1,
                                     inputs={"a": "layer_1", "b": "layer_3"}, params={}))
        spec["layers"][4]["inputs"]["x"] = "residual_add"
        spec["extensions"] = {"blocks": [{"name": "Residual", "layers": ["layer_2", "layer_3", "residual_add"]}]}
        return ModelSpec(spec)
    if name == "MLP":
        return migrate_model(default_model())
    if name == "CNN":
        return sequential([("ToChannels", {}), ("Conv1d", {"out_channels": 8, "padding": 1}),
                           ("ReLU", {}), ("AdaptiveAvgPool1d", {"output_size": 4}), ("Flatten", {}),
                           ("Linear", {"out_features": 16}), ("ReLU", {}), ("Linear", {"out_features": 1})],
                          "Basic CNN")
    if name == "Local":
        return sequential([("ToChannels", {}), ("LocallyConnected1d", {"out_channels": 4,
                           "padding_left": 1, "padding_right": 1}), ("GELU", {}),
                           ("AdaptiveAvgPool1d", {"output_size": 4}), ("Flatten", {}),
                           ("Linear", {"out_features": 1})], "Local connections")
    raise ValueError(f"Unknown generic template {name}")
