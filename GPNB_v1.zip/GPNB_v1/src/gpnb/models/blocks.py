"""Static contracts for native composites and their expansion primitives."""
from ..config import fail
from .registry import TensorType

BLOCK_NAMES = {"CrossAttention", "GatedAdd", "SqueezeExcite1d", "AttentionPooling", "GatedMLP", "TCNBlock",
               "MLPMixer", "DenseMoE", "ApplyMask", "ChannelScale", "ScaleByWeight", "Slice", "Softmax", "OneMinus"}


def resolve_block(name, ports, p, path):
    x = ports.get("x", ports.get("query", ports.get("a")))
    dims, out, count = x.dimensions, x, 0
    kwargs = dict(p)
    if name == "CrossAttention":
        context = ports["context"]
        if x.kind != "Sequence" or context.kind != "Sequence":
            fail("E_PORT", path, "cross attention requires query and context sequences")
        for key, sequence in (("query_mask", x), ("context_mask", context)):
            if ports[key] != TensorType("Mask", (sequence.dimensions[0],)):
                fail("E_PORT", path, f"{key} does not match its sequence")
        if dims[1] % p["num_heads"]:
            fail("E_PORT", path, "query width must be divisible by heads")
        if dims[0] * context.dimensions[0] * p["num_heads"] > p["max_score_elements"]:
            fail("E_MODEL_LIMIT", path, "one sample exceeds cross attention score budget")
        kwargs.update(query_dim=dims[1], context_dim=context.dimensions[1])
        count = 2 * dims[1] ** 2 + 2 * dims[1] * context.dimensions[1] + 4 * dims[1] * p["bias"]
    elif name == "GatedAdd":
        if x.kind not in ("Vector", "Sequence") or x != ports["b"]:
            fail("E_PORT", path, "gated addition requires identical Vector or Sequence inputs")
        kwargs["features"] = dims[-1]
        count = 2 * dims[-1] ** 2 + dims[-1] * p["bias"]
    elif name in ("ApplyMask", "AttentionPooling", "MLPMixer"):
        if x.kind != "Sequence" or ports["mask"] != TensorType("Mask", (dims[0],)):
            fail("E_PORT", path, "aligned Sequence and Mask required")
        if name == "AttentionPooling":
            kwargs["features"] = dims[1]
            count, out = dims[1] + int(p["bias"]), TensorType("Vector", (dims[1],))
        elif name == "MLPMixer":
            length, width = dims
            t, c = p["token_hidden"], p["channel_hidden"]
            kwargs.update(length=length, features=width)
            count = 4 * width + 2 * length * t + t + length + 2 * width * c + c + width
    elif name in ("TCNBlock", "SqueezeExcite1d"):
        if x.kind != "Channels":
            fail("E_PORT", path, "Channels layout required")
        kwargs["channels"] = dims[0]
        hidden = p["hidden_size"]
        count = 2 * dims[0] * hidden + hidden + dims[0]
        if name == "TCNBlock":
            count = 2 * dims[0] * hidden * p["kernel_size"] + (hidden + dims[0]) * p["bias"]
    elif name == "GatedMLP":
        if x.kind not in ("Vector", "Sequence"):
            fail("E_PORT", path, "Vector or Sequence required")
        kwargs["features"] = dims[-1]
        count = 3 * dims[-1] * p["hidden_size"] + (2 * p["hidden_size"] + dims[-1]) * p["bias"]
    elif name == "DenseMoE":
        if x.kind != "Vector":
            fail("E_PORT", path, "DenseMoE requires Vector; pool or flatten explicitly")
        kwargs["features"] = dims[0]
        e, h, o = p["num_experts"], p["hidden_size"], p["out_features"]
        count = e * (dims[0] + 1) + e * (dims[0] * h + h + h * o + o)
        out = TensorType("Vector", (o,))
    elif name == "ChannelScale":
        if x.kind != "Channels" or ports["gate"] != TensorType("Vector", (dims[0],)):
            fail("E_PORT", path, "channel scaling needs Channels and one gate per channel")
    elif name == "ScaleByWeight":
        if x.kind != "Vector" or ports["weight"] != TensorType("Vector", (1,)):
            fail("E_PORT", path, "scaling needs Vector and explicit scalar Vector[batch,1]")
    elif name == "Slice":
        if x.kind not in ("Vector", "Sequence", "Channels"):
            fail("E_PORT", path, "Slice requires a floating feature layout")
        axis = p["axis"] - 1
        if not 0 <= axis < len(dims) or not 0 <= p["start"] < p["stop"] <= dims[axis]:
            fail("E_PORT", path, "Slice must select a nonempty range on a non-batch axis")
        shape = list(dims)
        shape[axis] = p["stop"] - p["start"]
        out = TensorType(x.kind, tuple(shape))
    elif name in ("Softmax", "OneMinus"):
        if x.kind not in ("Vector", "Channels", "Sequence"):
            fail("E_PORT", path, "floating layout required")
    else:
        fail("E_MODEL", path, "unregistered composite")
    return kwargs, out, count, 0
