"""Native PyTorch runtime, also embedded verbatim in independent model exports.

This module deliberately has no GPNB imports. Configuration resolution lives
in the registry; this runtime accepts only already-resolved, allowlisted plans.
"""
import math
import torch
from torch import nn
from torch.nn import functional as F
from .runtime_blocks import CUSTOM_BLOCKS
from .runtime_graph import GRAPH_RUNTIME, GraphBuffers, GraphLayer
from .runtime_reference import ReferenceBuffers, ReferenceGraphSAGE, check_reference_context
from .runtime_experimental import EXPERIMENTAL_RUNTIME
from .runtime_papers import PAPER_RUNTIME


class ToChannels(nn.Module):
    def forward(self, x):
        return x.unsqueeze(1)


class ToSequence(nn.Module):
    def forward(self, x):
        return x.unsqueeze(-1)


class SingleToken(nn.Module):
    def forward(self, x):
        return x.unsqueeze(1)


class MarkerChunk(nn.Module):
    def __init__(self, start, stop):
        super().__init__()
        self.start, self.stop = start, stop

    def forward(self, x):
        return x[:, self.start:self.stop]


class Pad1d(nn.Module):
    def __init__(self, left, right):
        super().__init__()
        self.padding = (left, right)

    def forward(self, x):
        return F.pad(x, self.padding)


class ProjectedAttention(nn.Module):
    """Single score matrix with explicit Q/K/V width and scale; no head splitting."""
    def __init__(self, input_size, hidden_size, scale_dim, dropout, max_score_elements):
        super().__init__()
        self.query = nn.Linear(input_size, hidden_size, device="cpu", dtype=torch.float32)
        self.key = nn.Linear(input_size, hidden_size, device="cpu", dtype=torch.float32)
        self.value = nn.Linear(input_size, hidden_size, device="cpu", dtype=torch.float32)
        self.projection = nn.Linear(hidden_size, input_size, device="cpu", dtype=torch.float32)
        self.dropout = nn.Dropout(dropout)
        self.scale, self.limit = scale_dim ** -.5, max_score_elements

    def forward(self, x, mask):
        if mask.dtype != torch.bool or mask.shape != x.shape[:2]:
            raise ValueError("ProjectedAttention requires aligned bool padding mask")
        if x.shape[0] * x.shape[1] ** 2 > self.limit:
            raise ValueError("Attention score budget exceeded")
        x = x.masked_fill(mask.unsqueeze(-1), 0)
        scores = (self.query(x) @ self.key(x).transpose(-1, -2)) * self.scale
        scores = scores.masked_fill(mask.unsqueeze(1), float("-inf"))
        scores = scores.masked_fill(mask.all(1)[:, None, None], 0)
        weights = self.dropout(scores.softmax(-1)).masked_fill(mask.unsqueeze(1), 0)
        return self.projection(weights @ self.value(x)).masked_fill(mask.unsqueeze(-1), 0)


class SequenceReadout(nn.Module):
    def __init__(self, mode):
        super().__init__()
        self.mode = mode

    def forward(self, x):
        if self.mode in ("first", "last"):
            return x[:, 0 if self.mode == "first" else -1]
        return x.amax(1) if self.mode == "max" else x.sum(1) if self.mode == "sum" else x.mean(1)


class Recurrent(nn.Module):
    cell_type = None

    def __init__(self, input_size, hidden_size, num_layers, bias, bidirectional, dropout, readout, **options):
        super().__init__()
        self.readout = readout
        self.directions = 2 if bidirectional else 1
        self.cell = self.cell_type(input_size, hidden_size, num_layers, bias=bias, batch_first=True,
                                  dropout=dropout, bidirectional=bidirectional,
                                  device="cpu", dtype=torch.float32, **options)

    def forward(self, x):
        # No incoming/cached hidden state: every individual starts at zero on each call.
        output, state = self.cell(x.contiguous())
        if self.readout == "sequence":
            return output
        hidden = state[0] if isinstance(state, tuple) else state
        return hidden[-self.directions:].transpose(0, 1).reshape(x.shape[0], -1)


class RNN(Recurrent):
    cell_type = nn.RNN


class LSTM(Recurrent):
    cell_type = nn.LSTM


class GRU(Recurrent):
    cell_type = nn.GRU


class GenotypeEmbedding(nn.Module):
    def __init__(self, embedding_dim):
        super().__init__()
        # Raw A1 count 0/1/2, missing=3; missing is trainable, not sequence padding.
        self.embedding = nn.Embedding(4, embedding_dim, device="cpu", dtype=torch.float32)

    def forward(self, x):
        if x.dtype != torch.int64 or torch.any((x < 0) | (x > 3)):
            raise ValueError("GenotypeEmbedding requires int64 A1 categories 0/1/2 and missing=3")
        return self.embedding(x)


class Tokenize(nn.Module):
    def __init__(self, input_features, patch_size, pad_tokens, embedding_dim, bias):
        super().__init__()
        self.patch_size = patch_size
        self.valid = (input_features + patch_size - 1) // patch_size
        self.length = self.valid + pad_tokens
        self.projection = nn.Linear(patch_size, embedding_dim, bias=bias, device="cpu", dtype=torch.float32)

    def forward(self, x):
        chunks = F.pad(x, (0, self.valid * self.patch_size - x.shape[1])).reshape(x.shape[0], self.valid, self.patch_size)
        result = self.projection(chunks)
        return F.pad(result, (0, 0, 0, self.length - self.valid))


class TokenMask(nn.Module):
    def __init__(self, input_features, patch_size, pad_tokens):
        super().__init__()
        self.valid = (input_features + patch_size - 1) // patch_size
        self.length = self.valid + pad_tokens

    def forward(self, x):
        return (torch.arange(self.length, device=x.device) >= self.valid).unsqueeze(0).expand(x.shape[0], -1)


class SequenceMask(nn.Module):
    def __init__(self, valid_length):
        super().__init__()
        self.valid_length = valid_length

    def forward(self, x):
        valid = x.shape[1] if self.valid_length == -1 else self.valid_length
        return (torch.arange(x.shape[1], device=x.device) >= valid).unsqueeze(0).expand(x.shape[0], -1)


class PositionEncoding(nn.Module):
    def __init__(self, embedding_dim, mode, max_length):
        super().__init__()
        if mode == "learned":
            self.positions = nn.Parameter(torch.empty(max_length, embedding_dim, dtype=torch.float32, device="cpu"))
            nn.init.normal_(self.positions, std=.02)
        else:
            indices = torch.arange(max_length, dtype=torch.float32, device="cpu").unsqueeze(1)
            rates = torch.exp(torch.arange(0, embedding_dim, 2, dtype=torch.float32, device="cpu") *
                              (-math.log(10000.) / embedding_dim))
            values = torch.zeros(max_length, embedding_dim, dtype=torch.float32, device="cpu")
            values[:, 0::2] = torch.sin(indices * rates)
            values[:, 1::2] = torch.cos(indices * rates[:embedding_dim // 2])
            self.register_buffer("positions", values)

    def forward(self, x):
        return x + self.positions[:x.shape[1]].unsqueeze(0)


class ClassToken(nn.Module):
    def __init__(self, embedding_dim):
        super().__init__()
        self.token = nn.Parameter(torch.zeros(1, 1, embedding_dim, device="cpu", dtype=torch.float32))

    def forward(self, x):
        return torch.cat((self.token.expand(x.shape[0], -1, -1), x), dim=1)


class PrependMask(nn.Module):
    def forward(self, x):
        return F.pad(x, (1, 0), value=False)


class MaskedReadout(nn.Module):
    def __init__(self, mode):
        super().__init__()
        self.mode = mode

    def forward(self, x, mask):
        valid = ~mask
        if self.mode == "max":
            result = x.masked_fill(mask.unsqueeze(-1), -torch.inf).amax(1)
            return torch.where(valid.any(1).unsqueeze(-1), result, torch.zeros_like(result))
        result = x.masked_fill(mask.unsqueeze(-1), 0).sum(1)
        return result if self.mode == "sum" else result / valid.sum(1).clamp_min(1).unsqueeze(-1)


class SelfAttention(nn.Module):
    """Explicit scaled dot-product multihead attention, no device-specific kernels.

    True mask means padding. Padded query outputs and fully masked rows are zero.
    The score budget applies before constructing the quadratic tensor.
    """
    def __init__(self, embedding_dim, num_heads, dropout, bias, causal, max_score_elements):
        super().__init__()
        self.num_heads, self.dropout, self.causal = num_heads, dropout, causal
        self.max_score_elements = max_score_elements
        self.qkv = nn.Linear(embedding_dim, 3 * embedding_dim, bias=bias, device="cpu", dtype=torch.float32)
        self.output = nn.Linear(embedding_dim, embedding_dim, bias=bias, device="cpu", dtype=torch.float32)

    def forward(self, x, mask):
        batch, length, width = x.shape
        if mask.dtype != torch.bool or mask.shape != x.shape[:2]:
            raise ValueError("Attention requires aligned bool padding mask")
        if batch * self.num_heads * length * length > self.max_score_elements:
            raise ValueError("Attention score budget exceeded; reduce batch size/tokens or explicitly raise the limit")
        # Mask before projections so even extreme padded feature values do not enter products.
        clean = x.masked_fill(mask.unsqueeze(-1), 0)
        qkv = self.qkv(clean).reshape(batch, length, 3, self.num_heads, width // self.num_heads)
        q, k, v = qkv.permute(2, 0, 3, 1, 4).unbind(0)
        scores = (q @ k.transpose(-2, -1)) / math.sqrt(width // self.num_heads)
        excluded = mask[:, None, None, :]
        if self.causal:
            excluded = excluded | torch.ones(length, length, dtype=torch.bool, device=x.device).triu(1)[None, None]
        scores = scores.masked_fill(excluded, torch.finfo(scores.dtype).min)
        weights = scores.softmax(-1).masked_fill(excluded, 0)
        weights = F.dropout(weights, p=self.dropout, training=self.training)
        combined = (weights @ v).transpose(1, 2).reshape(batch, length, width)
        return self.output(combined).masked_fill(mask.unsqueeze(-1), 0)


class EncoderBlock(nn.Module):
    def __init__(self, embedding_dim, dim_feedforward, norm_first, activation, eps, **attention):
        super().__init__()
        self.attention = SelfAttention(embedding_dim, **attention)
        self.norm1 = nn.LayerNorm(embedding_dim, eps=eps, device="cpu", dtype=torch.float32)
        self.norm2 = nn.LayerNorm(embedding_dim, eps=eps, device="cpu", dtype=torch.float32)
        self.linear1 = nn.Linear(embedding_dim, dim_feedforward, bias=attention["bias"], device="cpu", dtype=torch.float32)
        self.linear2 = nn.Linear(dim_feedforward, embedding_dim, bias=attention["bias"], device="cpu", dtype=torch.float32)
        self.norm_first, self.activation, self.dropout = norm_first, activation, attention["dropout"]

    def feedforward(self, x):
        x = self.linear1(x)
        x = F.gelu(x) if self.activation == "gelu" else F.relu(x)
        return self.linear2(F.dropout(x, self.dropout, self.training))

    def forward(self, x, mask):
        x = x.masked_fill(mask.unsqueeze(-1), 0)
        if self.norm_first:
            x = x + F.dropout(self.attention(self.norm1(x), mask), self.dropout, self.training)
            x = x + F.dropout(self.feedforward(self.norm2(x)), self.dropout, self.training)
        else:
            x = self.norm1(x + F.dropout(self.attention(x, mask), self.dropout, self.training))
            x = self.norm2(x + F.dropout(self.feedforward(x), self.dropout, self.training))
        return x.masked_fill(mask.unsqueeze(-1), 0)


class TransformerEncoder(nn.Module):
    def __init__(self, num_layers, **parameters):
        super().__init__()
        self.blocks = nn.ModuleList([EncoderBlock(**parameters) for _ in range(num_layers)])

    def forward(self, x, mask):
        for block in self.blocks:
            x = block(x, mask)
        return x


class Reshape(nn.Module):
    def __init__(self, shape):
        super().__init__()
        self.shape = tuple(shape)

    def forward(self, x):
        return x.reshape(x.shape[0], *self.shape)


class Permute(nn.Module):
    def __init__(self, axes):
        super().__init__()
        self.axes = tuple(axes)

    def forward(self, x):
        return x.permute(*self.axes)


class GlobalPool1d(nn.Module):
    def __init__(self, mode):
        super().__init__()
        self.mode = mode

    def forward(self, x):
        return x.amax(-1) if self.mode == "max" else x.sum(-1) if self.mode == "sum" else x.mean(-1)


class AdaptiveAvgPool1d(nn.Module):
    """Exact adaptive bins with deterministic native slice/reduction backward.

    Bin i covers [floor(i*L/O), ceil((i+1)*L/O)), including overlap.
    Avoids adaptive_avg_pool2d_backward_cuda's strict-determinism limitation.
    """
    def __init__(self, output_size):
        super().__init__()
        self.output_size = output_size

    def forward(self, x):
        length, out = x.shape[-1], self.output_size
        return torch.stack([x[..., i * length // out:((i + 1) * length + out - 1) // out].mean(-1)
                            for i in range(out)], dim=-1)


class CausalConv1d(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, stride, dilation, bias):
        super().__init__()
        self.left = dilation * (kernel_size - 1)
        self.conv = nn.Conv1d(in_channels, out_channels, kernel_size, stride=stride,
                              dilation=dilation, bias=bias, device="cpu", dtype=torch.float32)

    def forward(self, x):
        return self.conv(F.pad(x, (self.left, 0)))


class DepthwiseSeparableConv1d(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, stride, padding, dilation, bias):
        super().__init__()
        self.depthwise = nn.Conv1d(in_channels, in_channels, kernel_size, stride=stride, padding=padding,
                                   dilation=dilation, groups=in_channels, bias=bias, device="cpu", dtype=torch.float32)
        self.pointwise = nn.Conv1d(in_channels, out_channels, 1, bias=bias, device="cpu", dtype=torch.float32)

    def forward(self, x):
        return self.pointwise(self.depthwise(x))


class LocallyConnected1d(nn.Module):
    """Per-output-position weights, unlike a shared convolution. File-order windows."""
    def __init__(self, in_channels, out_channels, input_length, kernel_size, stride, padding_left, padding_right, dilation, bias):
        super().__init__()
        self.kernel_size, self.stride, self.dilation = kernel_size, stride, dilation
        self.padding = (padding_left, padding_right)
        length = (input_length + padding_left + padding_right - dilation * (kernel_size - 1) - 1) // stride + 1
        self.weight = nn.Parameter(torch.empty(length, out_channels, in_channels, kernel_size,
                                                device="cpu", dtype=torch.float32))
        self.bias = nn.Parameter(torch.empty(out_channels, length, device="cpu", dtype=torch.float32)) if bias else None
        bound = 1 / math.sqrt(in_channels * kernel_size)
        nn.init.uniform_(self.weight, -bound, bound)
        if self.bias is not None:
            nn.init.uniform_(self.bias, -bound, bound)

    def forward(self, x):
        windows = F.pad(x, self.padding).unfold(
            2, self.dilation * (self.kernel_size - 1) + 1, self.stride)[..., ::self.dilation]
        y = torch.einsum("bclk,lock->bol", windows, self.weight)
        return y if self.bias is None else y + self.bias


class Add(nn.Module):
    def forward(self, a, b):
        return a + b


class Multiply(nn.Module):
    def forward(self, a, b):
        return a * b


class Concat(nn.Module):
    def __init__(self, axis):
        super().__init__()
        self.axis = axis

    def forward(self, a, b):
        return torch.cat((a, b), dim=self.axis)


NATIVE = {name: getattr(nn, name) for name in (
    "Linear", "ReLU", "GELU", "Tanh", "Sigmoid", "Dropout", "Identity", "SiLU", "ELU", "SELU",
    "Softplus", "Softsign", "LeakyReLU", "PReLU", "AlphaDropout", "Dropout1d", "Conv1d",
    "MaxPool1d", "AvgPool1d", "AdaptiveAvgPool1d", "AdaptiveMaxPool1d", "Flatten", "BatchNorm1d",
    "InstanceNorm1d", "GroupNorm", "LayerNorm", "RMSNorm", "BatchNorm2d")}
CUSTOM = {cls.__name__: cls for cls in (ToChannels, Reshape, Permute, GlobalPool1d, AdaptiveAvgPool1d, CausalConv1d,
                                       SingleToken, MarkerChunk, Pad1d, ProjectedAttention,
                                       DepthwiseSeparableConv1d, LocallyConnected1d, Add, Multiply, Concat,
                                       ToSequence, SequenceReadout, RNN, LSTM, GRU, GenotypeEmbedding, Tokenize,
                                       TokenMask, SequenceMask, PositionEncoding, ClassToken, PrependMask, MaskedReadout,
                                       SelfAttention, TransformerEncoder)}
FACTORY_DTYPE = {"Linear", "Conv1d", "PReLU", "BatchNorm1d", "InstanceNorm1d", "GroupNorm", "LayerNorm", "RMSNorm", "BatchNorm2d"}
CUSTOM.update(CUSTOM_BLOCKS)
CUSTOM.update(GRAPH_RUNTIME)
CUSTOM.update(EXPERIMENTAL_RUNTIME)
CUSTOM.update(PAPER_RUNTIME)
for _retired in ("DiagonalSSM", "LinearSplineKAN"):
    CUSTOM.pop(_retired, None)
CUSTOM["ReferenceGraphSAGE"] = ReferenceGraphSAGE


def make_layer(row):
    name, kwargs = row["type"], dict(row["kwargs"])
    if name == "ReconstructMarkers":
        name = "Linear"
    if name in CUSTOM:
        return CUSTOM[name](**kwargs)
    if name not in NATIVE:
        raise ValueError(f"Unregistered runtime component {name}")
    if name in FACTORY_DTYPE:
        kwargs.update(device="cpu", dtype=torch.float32)
    return NATIVE[name](**kwargs)


class ResolvedSequential(nn.Sequential):
    def __init__(self, plan):
        super().__init__()
        if "graph_state" in plan:
            self.add_module("graph_buffers", GraphBuffers(plan["graph_state"]))
        if plan.get("reference_state"):
            self.add_module("reference_buffers", ReferenceBuffers(plan["reference_state"]))
        for row in plan["layers"]:
            if "share_with" not in row:
                layer = make_layer(row)
                if isinstance(layer, GraphLayer):
                    layer.bind_graph(self.graph_buffers)
                if isinstance(layer, ReferenceGraphSAGE):
                    layer.bind_reference(self.reference_buffers)
                self.add_module(str(row["index"]), layer)
        self.plan = plan
        self.input_features = plan["input_shape"][1]
        self.model_sha256 = plan["model_sha256"]
        self.input_representation = plan.get("input_representation", "standardized_dosage")

    def forward(self, x, return_auxiliary=False):
        additional = {}
        reference_context = None
        if self.plan.get("external_inputs") or self.plan.get("reference_state"):
            expected = {"$input", *("$input:"+name for name in self.plan.get("external_inputs", {}))}
            if self.plan.get("reference_state"):
                expected.add("$reference")
            if not isinstance(x, dict) or set(x) != expected:
                raise ValueError(f"Expected explicit tensor input mapping with keys {sorted(expected)}")
            reference_context = x.get("$reference")
            additional, x = {k: v for k, v in x.items() if k not in ("$input", "$reference")}, x["$input"]
        if not isinstance(x, torch.Tensor) or x.ndim != 2 or x.shape[0] < 1 or x.shape[1] != self.input_features:
            raise ValueError(f"Expected nonempty [batch,{self.input_features}] tensor")
        if self.input_representation == "genotype_categories":
            if x.dtype != torch.int64 or torch.any((x < 0) | (x > 3)):
                raise ValueError("Expected int64 raw genotype categories 0/1/2/3, not standardized doses")
        elif not x.is_floating_point():
            raise ValueError("Expected floating point preprocessed genotypes")
        if reference_context is not None:
            check_reference_context(reference_context, self.plan["reference_state"], x.shape[0], x.device)
        for name, width in self.plan.get("external_inputs", {}).items():
            v = additional["$input:"+name]
            if (not isinstance(v, torch.Tensor) or list(v.shape) != [x.shape[0], width]
                    or not v.is_floating_point() or v.device != x.device or not torch.isfinite(v).all()):
                raise ValueError(f"{name}: expected finite floating [batch,{width}] on the genotype device")
        values = {"$input": x, **additional}
        rows = {row["id"]: row for row in self.plan["layers"]}
        required=set()
        pending=[self.plan.get("output",self.plan["layers"][-1]["id"])]
        if return_auxiliary and "reconstruction_output" in self.plan:
            pending.append(self.plan["reconstruction_output"])
        while pending:
            identifier=pending.pop()
            if identifier in rows and identifier not in required:
                required.add(identifier)
                pending.extend(rows[identifier]["inputs"].values())
        for identifier in self.plan.get("execution_order", rows):
            if identifier not in required:
                continue
            row = rows[identifier]
            layer = self._modules[str(row.get("module_index", row["index"]))]
            ports = {p: values[source] for p, source in row["inputs"].items()}
            x = next(iter(ports.values()))
            if (self.training and x.is_cuda and row["type"] == "AdaptiveMaxPool1d"
                    and torch.are_deterministic_algorithms_enabled()):
                raise ValueError(f"{row['id']}: AdaptiveMaxPool1d CUDA deterministic backward is unsupported; select CPU")
            if isinstance(layer, (nn.BatchNorm1d, nn.BatchNorm2d)) and (layer.training or not layer.track_running_stats):
                if x.numel() // x.shape[1] < 2:
                    raise ValueError(f"{row['id']}: BatchNorm1d needs at least two batch/spatial observations")
            if isinstance(layer, ReferenceGraphSAGE):
                x = layer(ports["x"], reference_context)
            else:
                x = layer(ports["x"]) if set(ports) == {"x"} else layer(**ports)
            if list(x.shape[1:]) != row["output_shape"][1:]:
                raise ValueError(f"{row['id']}: runtime output shape disagrees with the resolved contract")
            values[identifier] = x
        prediction = values[self.plan.get("output", self.plan["layers"][-1]["id"])]
        if return_auxiliary:
            if "reconstruction_output" not in self.plan:
                raise ValueError("No reconstruction output configured")
            return prediction, values[self.plan["reconstruction_output"]]
        return prediction


def example_inputs(plan, batch, device="cpu"):
    dtype = torch.int64 if plan.get("input_representation") == "genotype_categories" else torch.float32
    x = torch.zeros(batch, plan["input_shape"][1], dtype=dtype, device=device)
    if plan.get("external_inputs") or plan.get("reference_state"):
        inputs = {"$input": x, **{"$input:"+name: torch.zeros(batch, width, dtype=torch.float32, device=device)
                                for name, width in plan.get("external_inputs", {}).items()}}
        if plan.get("reference_state"):
            k = plan["reference_state"]["neighbors"]
            inputs["$reference"] = dict(indices=torch.arange(k, device=device).expand(batch, k),
                weights=torch.full((batch, k), 1/k, dtype=torch.float32, device=device))
        return inputs
    return x


def probe_batch(plan):
    sizes = [2]
    for row in plan["layers"]:
        if "attention_cost" in row:
            c = row["attention_cost"]
            sizes.append(c["limit_elements_per_call"] // c["score_elements_per_sample"])
        if "graph_cost" in row and row["graph_cost"]["message_elements_per_sample"]:
            c = row["graph_cost"]
            sizes.append(c["limit_elements_per_call"] // c["message_elements_per_sample"])
        if "reference_cost" in row:
            c = row["reference_cost"]
            sizes.append((c["limit_elements_per_call"]-c["reference_message_elements"]) // c["query_message_elements_per_sample"])
        if "element_cost" in row:
            c = row["element_cost"]
            sizes.append(c["limit_elements_per_call"] // c["elements_per_sample"])
    if min(sizes) < 1:
        raise ValueError("Component budget cannot support even one probe/query individual")
    return min(sizes)


def build_resolved(plan, seed, max_parameter_bytes):
    if plan.get("reference_unfitted"):
        raise ValueError("Individual reference is unfitted; select the protocol and fit inside a training partition")
    if plan.get("graph_unfitted"):
        raise ValueError("LD topology is unfitted; prepare/train on the inner-training partition before building")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be an integer in [0,2**32)")
    if type(max_parameter_bytes) is not int or max_parameter_bytes < plan["parameter_bytes"] + plan.get("buffer_bytes", 0):
        raise ValueError("parameter/buffer allocation exceeds explicit budget")
    with torch.random.fork_rng(devices=[]):
        torch.random.default_generator.manual_seed(seed)
        return ResolvedSequential(plan)
