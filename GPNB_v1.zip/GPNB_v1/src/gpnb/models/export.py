from __future__ import annotations

import inspect
import json
import textwrap
import xml.etree.ElementTree as ET
from pathlib import Path

from ..config import ModelSpec, ProjectSpec, fail, load_spec, number, resolve_project_path
from ..data.files import protect_inputs, read_json, sha256, snapshot, verify_snapshots, write_json
from .core import (DEFAULT_PARAMETER_BYTES, _check_input, build_model, check_budget,
                   inspect_model, template_diff)


def source_code(spec, plan, seed=5209, max_parameter_bytes=DEFAULT_PARAMETER_BYTES):
    """Emit the resolved constructors, not a second model configuration/parser."""
    if plan != inspect_model(spec, plan["input_shape"][1], graph_state=plan.get("graph_state"),
                             reference_state=plan.get("reference_state")):
        fail("E_MODEL", "resolved_model", "resolved plan does not match ModelSpec")
    number(seed, "seed", 0, 2**32 - 1, integer=True)
    number(max_parameter_bytes, "max_parameter_bytes", 1, integer=True)
    if spec.to_dict()["schema_version"] == 2:
        from . import runtime, runtime_blocks, runtime_graph, runtime_reference, runtime_experimental, runtime_papers
        runtime_source = Path(runtime.__file__).read_text(encoding="utf-8")
        runtime_source = Path(runtime_blocks.__file__).read_text(encoding="utf-8") + "\n" + runtime_source.replace(
            "from .runtime_blocks import CUSTOM_BLOCKS\n", "")
        runtime_source = Path(runtime_graph.__file__).read_text(encoding="utf-8") + "\n" + runtime_source.replace(
            "from .runtime_graph import GRAPH_RUNTIME, GraphBuffers, GraphLayer\n", "")
        runtime_source = Path(runtime_reference.__file__).read_text(encoding="utf-8") + "\n" + runtime_source.replace(
            "from .runtime_reference import ReferenceBuffers, ReferenceGraphSAGE, check_reference_context\n", "")
        runtime_source = Path(runtime_experimental.__file__).read_text(encoding="utf-8") + "\n" + runtime_source.replace(
            "from .runtime_experimental import EXPERIMENTAL_RUNTIME\n", "")
        runtime_source = Path(runtime_papers.__file__).read_text(encoding="utf-8") + "\n" + runtime_source.replace(
            "from .runtime_papers import PAPER_RUNTIME\n", "")
        return runtime_source + f'''

import json
MODEL_SPEC = json.loads({json.dumps(spec.to_dict(), ensure_ascii=True)!r})
PLAN = json.loads({json.dumps(plan, ensure_ascii=True)!r})
MODEL_SHA256 = {spec.sha256!r}
INPUT_FEATURES = {plan["input_shape"][1]}

def build_model(seed={seed}, max_parameter_bytes={max_parameter_bytes}):
    return build_resolved(PLAN, seed, max_parameter_bytes)

if __name__ == "__main__":
    model = build_model().eval()
    with torch.no_grad():
        dtype = torch.int64 if PLAN.get("input_representation") == "genotype_categories" else torch.float32
        batch = probe_batch(PLAN)
        output = model(example_inputs(PLAN, batch))
    print(json.dumps({{"scope": "untrained architecture smoke check", "output_shape": list(output.shape),
                      "parameters": sum(p.numel() for p in model.parameters())}}))
'''
    constructors = []
    for layer in plan["layers"]:
        pairs = [f"{key}={value!r}" for key, value in layer["kwargs"].items()]
        if layer["type"] == "Linear":
            pairs += ["device='cpu'", "dtype=torch.float32"]
        constructors.append(f"            torch.nn.{layer['constructor']}({', '.join(pairs)}),")
    return f'''"""GPNB architecture export: untrained model; requires PyTorch.
Model SHA256: {spec.sha256}
No fitted weights, preprocessing, dataset or training loop is bundled here.
"""
import json
import torch

MODEL_SPEC = json.loads({json.dumps(spec.to_dict(), ensure_ascii=True)!r})
MODEL_SHA256 = {spec.sha256!r}
INPUT_FEATURES = {plan["input_shape"][1]}
PARAMETER_BYTES = {plan["parameter_bytes"]}

{inspect.getsource(_check_input)}
class Model(torch.nn.Sequential):
    def __init__(self):
        super().__init__(
{chr(10).join(constructors)}
        )
        self.input_features = INPUT_FEATURES
        self.model_sha256 = MODEL_SHA256

    def forward(self, x):
        _check_input(x, INPUT_FEATURES)
        return super().forward(x)


def build_model(seed={seed}, max_parameter_bytes={max_parameter_bytes}):
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be an integer in [0, 2**32)")
    if type(max_parameter_bytes) is not int or max_parameter_bytes < PARAMETER_BYTES:
        raise ValueError("parameter allocation budget is too small")
    with torch.random.fork_rng(devices=[]):
        torch.random.default_generator.manual_seed(seed)
        return Model()


if __name__ == "__main__":
    model = build_model().eval()
    with torch.no_grad():
        output = model(torch.zeros(2, INPUT_FEATURES, device="cpu", dtype=torch.float32))
    print(json.dumps({{"scope": "untrained architecture smoke check",
                      "model_sha256": MODEL_SHA256, "output_shape": list(output.shape),
                      "parameters": sum(p.numel() for p in model.parameters())}}))
'''


def structure_svg(plan):
    from .diagrams import topology_svg
    return topology_svg(plan)


def export_inspection(config_path, output, *, input_features=None, prepared_dir=None,
                      seed=5209, max_parameter_bytes=DEFAULT_PARAMETER_BYTES, static_only=False, baseline_path=None,
                      graph_state=None, reference_state=None):
    config_path, output = Path(config_path).resolve(), Path(output).resolve()
    if output.exists():
        fail("E_EXISTS", str(output), "choose a new model inspection directory")
    protect_inputs(output, [config_path])
    initial = snapshot(config_path)
    spec = load_spec(config_path)
    project = spec.to_dict() if isinstance(spec, ProjectSpec) else None
    model_spec = ModelSpec(project["model"]) if project else spec
    if not isinstance(model_spec, ModelSpec):
        fail("E_TYPE", str(config_path), "expected ModelSpec or ProjectSpec")
    if (input_features is None) == (prepared_dir is None):
        fail("E_MODEL", "input", "provide exactly one of input_features or prepared_dir")
    binding = None
    if prepared_dir is not None:
        from ..data.prepare import PreparedDataset
        prepared_dir = Path(prepared_dir).resolve()
        if output.is_relative_to(prepared_dir) or prepared_dir.is_relative_to(output):
            fail("E_IO", str(output), "model export must not overlap prepared data")
        prepared = PreparedDataset.load(prepared_dir)
        if project and project['run'].get('extensions', {}).get('kernel_features'):
            from ..data.kernel_features import bind_kernel
            model_spec = bind_kernel(project, prepared)
        input_features = prepared.input_features
        if graph_state is None:
            from ..graphs.state import fit_graph
            graph_state = fit_graph(model_spec, prepared)
        if reference_state is None:
            from ..graphs.individual import fit_reference
            reference_state, _ = fit_reference(model_spec, prepared)
        if project:
            context = prepared.split.value["context"]
            if project["data"]["dataset_id"] != context["dataset_id"] or project["data"]["phenotype_options"] != context["phenotype_options"]:
                fail("E_MANIFEST", "project.data", "project does not match prepared dataset/phenotype interpretation")
            descriptor = read_json(prepared_dir / "input_descriptor.json")
            from ..data.genotypes import source_paths, verify_matrix_binding
            imported = read_json(prepared_dir / "project_snapshot.json")
            verify_matrix_binding(project["data"], imported["data"], descriptor["source_files"], config_path)
            for key, path in source_paths(project["data"], config_path).items():
                current = snapshot(path)
                if current["sha256"] != descriptor["source_files"][key]["sha256"]:
                    fail("E_MANIFEST", key, "project input differs from prepared data")
        binding = {"prepared_directory": str(prepared_dir), "complete_sha256": sha256(prepared_dir / "complete.json"),
                   "model_input": prepared.report["model_input"], "dataset_id": prepared.report["dataset_id"],
                   "trait": prepared.report["trait"], "provenance": prepared.report["provenance"]}
    number(seed, "seed", 0, 2**32 - 1, integer=True)
    number(max_parameter_bytes, "max_parameter_bytes", 1, integer=True)
    plan = inspect_model(model_spec, input_features, graph_state=graph_state, reference_state=reference_state)
    baseline = load_spec(baseline_path) if baseline_path else None
    if baseline is not None and not isinstance(baseline, ModelSpec):
        fail("E_TYPE", "baseline", "expected ModelSpec")
    diff = template_diff(model_spec, baseline)
    probe = {"executed": False, "reason": "static_only"}
    import torch
    if not static_only:
        check_budget(plan, max_parameter_bytes)
        model = build_model(model_spec, input_features, seed=seed, max_parameter_bytes=max_parameter_bytes,
                            graph_state=graph_state, reference_state=reference_state).eval()
        if model_spec.to_dict()["schema_version"] == 2:
            from .runtime import probe_batch as choose_probe_batch
            probe_batch = choose_probe_batch(plan)
        else:
            probe_batch = 2
        with torch.no_grad():
            dtype = torch.int64 if plan.get("input_representation") == "genotype_categories" else torch.float32
            if plan.get("external_inputs") or plan.get("reference_state"):
                from .runtime import example_inputs
                result = model(example_inputs(plan, probe_batch))
            else:
                result = model(torch.zeros((probe_batch, input_features), device="cpu", dtype=dtype))
        actual = sum(p.numel() for p in model.parameters())
        if actual != plan["parameters"] or list(result.shape) != [probe_batch, plan["output_shape"][-1]] or not torch.isfinite(result).all():
            fail("E_MODEL", "probe", "runtime shape/count/finite-value check differs from resolved plan")
        probe = {"executed": True, "device": "cpu", "input": f"{probe_batch} rows of zeros, no real data",
                 "output_shape": list(result.shape), "parameters": actual, "finite": True}
    output.mkdir(parents=True)
    (output / "INCOMPLETE").write_text("Model inspection incomplete\n", encoding="utf-8")
    try:
        model_spec.save(output / "model.json")
        write_json(output / "resolved_model.json", plan)
        from .summary import markdown_summary
        kernel_context = (project or {}).get('run', {}).get('extensions', {}).get('kernel_features')
        if kernel_context:
            kernel_context = dict(kernel_context)
            reference_path = config_path.parent/'kernel/state.json'
            if prepared_dir and getattr(prepared, 'kernel_state', None):
                kernel_context['reference_ids'] = prepared.kernel_state.metadata['reference_ids']
            elif reference_path.is_file():
                kernel_context['reference_ids'] = read_json(reference_path)['reference_ids']
        (output / 'summary.md').write_text(markdown_summary(model_spec, plan, language='en_US', input_context=kernel_context), encoding='utf-8')
        (output / 'summary_zh.md').write_text(markdown_summary(model_spec, plan, language='zh_CN', input_context=kernel_context), encoding='utf-8')
        from ..data.encoding import encoding_description, token_mapping, grid_mapping
        encoding = encoding_description(plan.get('input_representation', 'standardized_dosage'))
        marker_state = (prepared.state if prepared_dir and (kernel_context or {}).get('mode') != 'kernel' else None)
        tokens = token_mapping(plan, marker_state)
        grid = grid_mapping(plan, marker_state)
        if kernel_context:
            mode = kernel_context['mode']
            encoding['kernel_features'] = dict(mode=mode, query_rule='K(Q,T)',
                columns='saved_training_reference_order', reference_ids=kernel_context.get('reference_ids'),
                recipe=kernel_context['kernel'], imputation=project['run']['preprocessing']['imputation'],
                reference_state='../kernel', fit_scope='current_training_partition')
            if mode == 'kernel':
                encoding.update(representation='training_reference_kernel', genotype_imputation_and_scaling_applied=None,
                    preprocessing_policy='raw selected dosage; saved kernel imputation and formula; no generic dosage scaling',
                    note='Columns are saved reference individuals, not SNP positions. Kernel input is not GBLUP.')
            rows = {row['id']: row for row in plan['layers']}
            source_port = '$input' if mode == 'kernel' else '$input:kernel'
            for mapping in tokens['mappings']:
                if rows[mapping['layer_id']]['inputs'] == {'x': source_port}:
                    mapping['coordinate_system'] = 'saved_training_reference_order'
                    mapping['reference_ids'] = kernel_context.get('reference_ids')
            for layout in grid['layouts']:
                if rows[layout['layer_id']]['inputs'] == {'x': source_port}:
                    layout.update(coordinate_system='saved_training_reference_order', layout='reference_order_user_grid',
                                  reference_ids=kernel_context.get('reference_ids'))
        write_json(output / 'input_encoding.json', encoding)
        write_json(output / 'token_mapping.json', tokens)
        write_json(output / 'grid_mapping.json', grid)
        write_json(output / "template_diff.json", diff)
        (output / "structure.svg").write_text(structure_svg(plan), encoding="utf-8")
        if project:
            from .diagrams import workflow_svg
            preview=None
            if prepared_dir:
                from ..data.split import PARTS
                import numpy as np
                multi=hasattr(prepared,"target_values")
                names=[t["id"] for t in prepared.target_state["contract"]["targets"]] if multi else [project["data"]["phenotype_options"]["trait"]]
                fold=prepared.split.value.get("cross_validation",{}).get("fold",0)
                rows=[]
                for part in PARTS:
                    indices=prepared.split.rows(part)
                    counts=np.isfinite(prepared.target_values[indices]).sum(0).tolist() if multi else [len(indices)]
                    rows.append(dict(fold=fold,partition=part,individuals=len(indices),observed=dict(zip(names,counts))))
                preview={"prepared":binding,"rows":rows}
            (output / "workflow.svg").write_text(workflow_svg(project, preview), encoding="utf-8")
        (output / "model.py").write_text(source_code(model_spec, plan, seed, max_parameter_bytes), encoding="utf-8")
        verify_snapshots({"config": initial})
        report = {"ok": True, "schema_version": 1, "kind": "model_inspection",
                  "model_sha256": model_spec.sha256, "input_features": input_features, "parameters": plan["parameters"],
                  "parameter_bytes": plan["parameter_bytes"], "allocation_budget_bytes": max_parameter_bytes,
                  "seed": seed, "probe": probe, "input_binding": binding, "torch_version": torch.__version__,
                  "scope": "Architecture only; no training, fitted weights or prediction performance."}
        write_json(output / "report.json", report)
        write_json(output / "complete.json", {"schema_version": 1,
                   "files": {p.name: sha256(p) for p in output.iterdir() if p.is_file() and p.name != "INCOMPLETE"}})
        (output / "INCOMPLETE").unlink()
        return report
    except Exception as error:
        write_json(output / "failure.json", {"ok": False, "error": str(error)})
        raise
