from __future__ import annotations

import json
import os
import platform
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

from .paths import configure_local_paths
from .environment_profiles import get_profile, recommended_profile


def run_probe(name: str, *, qt_mode="window", timeout=120) -> dict:
    env = os.environ.copy()
    if name == "qt":
        env["QT_QPA_PLATFORM"] = "offscreen" if qt_mode == "offscreen" else "windows"
    command = [sys.executable, "-m", "gpnb._probe", name]
    if name == "qt":
        command += ["--qt-mode", qt_mode]
    start = time.perf_counter()
    try:
        result = subprocess.run(command, capture_output=True, text=True, encoding="utf-8",
                                errors="replace", timeout=timeout, env=env)
    except subprocess.TimeoutExpired:
        return {"name": name, "ok": False, "error": f"Timed out after {timeout}s"}
    lines = result.stdout.strip().splitlines()
    try:
        info = json.loads(lines[-1])
    except (IndexError, json.JSONDecodeError):
        info = {"ok": False, "error": "Probe failed before producing a report"}
    info.update(name=name, exit_code=result.returncode, elapsed_seconds=round(time.perf_counter() - start, 3))
    info["ok"] = bool(info.get("ok") and result.returncode == 0)
    if result.stderr:
        info["stderr"] = result.stderr[-4000:]
    return info


def run_doctor(profile="cpu", qt_mode="window", timeout=120, quick=False) -> dict:
    root = configure_local_paths()
    selected = get_profile(profile, root)
    import psutil

    hardware = {"os": platform.platform(), "machine": platform.machine(),
                "cpu_logical": psutil.cpu_count(), "cpu_physical": psutil.cpu_count(logical=False),
                "memory_total_bytes": psutil.virtual_memory().total, "disk_free_bytes": shutil.disk_usage(root).free}
    try:
        gpu = subprocess.run(["nvidia-smi", "--query-gpu=name,memory.total,driver_version", "--format=csv,noheader"],
                             capture_output=True, text=True, timeout=10)
        hardware["nvidia_smi"] = gpu.stdout.strip() if gpu.returncode == 0 else "unavailable"
    except (OSError, subprocess.TimeoutExpired):
        hardware["nvidia_smi"] = "unavailable"
    names = ["imports"] if quick else ["imports", "bed", "cpu"]
    if selected["device"] == "cuda" and not quick:
        names.append("cuda")
    if qt_mode != "skip" and not quick:
        names.append("qt")
    checks = [run_probe(name, qt_mode=qt_mode, timeout=timeout) for name in names]
    expected_torch = selected["torch"]
    imported = checks[0].get("versions", {}).get("torch")
    if imported != expected_torch:
        checks.append({"name": "profile_build", "ok": False,
                       "error": f"Expected torch {expected_torch}, found {imported}"})
    return {"schema_version": 1, "created_utc": datetime.now(timezone.utc).isoformat(),
            "environment_profile": selected,
            "recommended_profile": recommended_profile([line.rsplit(',', 1)[-1].strip()
                for line in hardware["nvidia_smi"].splitlines()], root),
            "profile": profile, "mode": "quick_imports_only" if quick else "full",
            "python": sys.version, "python_executable": sys.executable,
            "prefix": sys.prefix, "base_prefix": sys.base_prefix,
            "isolated_venv": sys.prefix != sys.base_prefix,
            "root": str(root), "hardware": hardware, "checks": checks,
            "ok": all(c["ok"] for c in checks), "qt_mode": qt_mode,
            "scope": "Environment health; synthetic model only, no real research data loaded"}


def write_report(report: dict, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".partial")
    temporary.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)
