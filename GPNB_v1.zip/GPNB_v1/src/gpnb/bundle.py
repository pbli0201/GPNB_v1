"""Checksummed run archives; no original data/cache needed for model loading."""
from __future__ import annotations

import shutil
from pathlib import Path, PurePosixPath, PureWindowsPath

from .config import fail
from .data.files import read_json, sha256, write_json


def safe_member(root, name):
    if (not isinstance(name, str) or not name or "\\" in name or
            PureWindowsPath(name).drive or PurePosixPath(name).is_absolute() or
            any(p in ("", ".", "..") for p in name.split("/"))):
        fail("E_BUNDLE", str(name), "invalid archive relative path")
    path = root / name
    if not path.resolve().is_relative_to(root.resolve()):
        fail("E_BUNDLE", str(name), "archive member escapes its directory")
    return path


def seal(directory, kind):
    files = {p.relative_to(directory).as_posix(): sha256(p)
             for p in directory.rglob("*") if p.is_file()
             and p != directory / "complete.json" and p.name != "INCOMPLETE"}
    write_json(directory / "complete.json", {"schema_version": 1, "kind": kind, "files": files})


def verify_bundle(directory, kind=None, required=()):
    directory = Path(directory).resolve()
    try:
        if (directory / "INCOMPLETE").exists():
            fail("E_BUNDLE", str(directory), "archive is incomplete")
        manifest = read_json(directory / "complete.json")
        if (manifest.get("schema_version") != 1 or
                (kind and manifest.get("kind") != kind) or not isinstance(manifest.get("files"), dict)):
            fail("E_BUNDLE", str(directory), "unsupported completion manifest")
        if not set(required).issubset(manifest["files"]):
            fail("E_BUNDLE", str(directory), f"missing required artifacts: {sorted(set(required) - manifest['files'].keys())}")
        for name, digest in manifest["files"].items():
            path = safe_member(directory, name)
            if not path.is_file() or sha256(path) != digest:
                fail("E_BUNDLE", name, "missing file or SHA256 mismatch")
        return manifest
    except (OSError, KeyError, TypeError) as error:
        fail("E_BUNDLE", str(directory), str(error))


def capture_source(output):
    """Copy before fitting; detect source changes before publishing the run."""
    package = Path(__file__).parent
    hashes = {}
    for path in package.rglob("*.py"):
        relative = path.relative_to(package).as_posix()
        target = output / "source/gpnb" / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        hashes[relative] = sha256(path)
        shutil.copyfile(path, target)
        if sha256(target) != hashes[relative]:
            fail("E_CHANGED", str(path), "source changed during snapshot")
    from .paths import project_root
    requirements = project_root() / "requirements"
    # Old exported snapshots may have only the original locks. New runs include
    # the policy and every listed profile, so install/diagnosis/replay agree.
    from .environment_profiles import load_profiles
    names = {"cpu.lock", "cuda.lock"}
    if (requirements / "profiles.json").is_file():
        names.update(p["lock"] for p in load_profiles(project_root())["profiles"].values())
        names.add("profiles.json")
    for name in sorted(names):
        path = requirements / name
        if not path.is_file():
            fail("E_BUNDLE", str(path), "dependency lock missing")
        target = output / "requirements" / name
        target.parent.mkdir(exist_ok=True)
        shutil.copyfile(path, target)
    return hashes


def verify_source(hashes):
    package = Path(__file__).parent
    current = {p.relative_to(package).as_posix(): sha256(p) for p in package.rglob("*.py")}
    if current != hashes:
        fail("E_CHANGED", str(package), "source changed during training; retry from a stable checkout")
