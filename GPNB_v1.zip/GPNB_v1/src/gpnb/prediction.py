"""Frozen preprocessing and explicit marker alignment for arbitrary cohorts."""
from __future__ import annotations

import importlib.metadata
import platform
from pathlib import Path

import numpy as np
import torch

from .bundle import seal, verify_bundle
from .config import ModelSpec, ProjectSpec, fail, load_spec, number
from .data.bed import BedAdapter, ENCODING, MATRIX_ENCODING, validate_bed
from .data.cache import RawCache
from .data.files import order_hash, protect_inputs, read_json, sha256, snapshot, verify_snapshots, write_csv, write_json
from .data.preprocessing import PreprocessorState
from .data.tables import plink_table
from .models.core import DEFAULT_PARAMETER_BYTES, build_model
from .training.core import execution_context
from .prediction_sources import describe_prediction_source, load_predictor


RUN_REQUIRED = ("project.json", "weights.pt", "summary.json", "environment.json",
                "prepared/preprocessor/state.json", "prepared/preprocessor/arrays.npz",
                "prepared/preprocessor/complete.json", "architecture/model.json")


class Predictor:
    def __init__(self, directory, *, device="cpu", max_parameter_bytes=DEFAULT_PARAMETER_BYTES):
        directory = Path(directory).resolve()
        manifest = verify_bundle(directory)
        if manifest.get("kind") == "exported_run":
            verify_bundle(directory, "exported_run", ("run/complete.json", "export.json", "reproduce.py"))
            directory = directory / "run"
        verify_bundle(directory, "training_run", RUN_REQUIRED)
        self.directory = directory
        self.project = load_spec(directory / "project.json")
        if not isinstance(self.project, ProjectSpec):
            fail("E_BUNDLE", "project.json", "expected ProjectSpec")
        self.summary = read_json(directory / "summary.json")
        self.state = PreprocessorState.load(directory / "prepared/preprocessor")
        self.spec = ModelSpec(self.project.to_dict()["model"])
        from .data.kernel_features import load_kernel, options as kernel_options
        kernel_config = kernel_options(self.project.to_dict())
        self.kernel_state = None
        self.kernel_mode = kernel_config['mode'] if kernel_config else None
        if kernel_config:
            sample_ids = read_json(directory/'prepared/split.json')['manifest']['context']['sample_ids']
            self.kernel_state = load_kernel(self.project.to_dict(), self.state, directory/'kernel', sample_ids)
        self.input_features = (self.kernel_state.reference_count if self.kernel_mode == 'kernel' else self.state.input_features)
        architecture = load_spec(directory / "architecture/model.json")
        if (self.spec.sha256 != self.summary["model_sha256"] or architecture.sha256 != self.spec.sha256 or
                self.summary["input_features"] != self.input_features or
                self.project.to_dict()["run"]["preprocessing"] != self.state.metadata["options"] or
                self.summary["trait"] != self.project.to_dict()["data"]["phenotype_options"]["trait"] or
                self.summary["dataset_id"] != self.project.to_dict()["data"]["dataset_id"]):
            fail("E_BUNDLE", "model/preprocessor", "inconsistent model definition, feature count or preprocessing")
        self.config = {**self.project.to_dict()["run"]["training"], "device": device}
        self.target_state=None
        if self.spec.to_dict().get("task")=="multi_target_regression":
            from .data.multitask import validate_state,contract
            state=validate_state(read_json(directory/"prepared/target_state.json"))
            context=read_json(directory/"prepared/split.json")["manifest"]["context"]
            if (state["contract"]!=contract(self.project.to_dict()) or context.get("multitask")!=state["contract"]
                    or state["train_rows"]!=self.state.metadata["train_rows"]
                    or state["sample_order_sha256"]!=order_hash(context["sample_ids"])
                    or state["phenotype_sha256"]!=context["phenotype_sha256"]
                    or self.state.metadata.get("target_mode")!="separate_multi_target_state"
                    or state["standardized"]!=self.project.to_dict()["run"]["preprocessing"]["standardize_target"]):
                fail("E_BUNDLE","target_state","multi-target state differs from saved contract/data/split")
            self.target_state=state
        self.input_states = {}
        external = dict(self.spec.to_dict().get("external_inputs", {}))
        if self.kernel_mode == 'snp_kernel':
            external.pop('kernel', None)
        if external:
            from .data.additional import NumericTableState
            saved_inputs = read_json(directory/"input_states.json")
            configs = {c["id"]: c for c in self.project.to_dict()["extensions"]["input_tables"]}
            sample_ids = read_json(directory/"prepared/split.json")["manifest"]["context"]["sample_ids"]
            if set(saved_inputs) != set(external):
                fail("E_BUNDLE", "input_states.json", "input branch inventory differs from model")
            for name, value in saved_inputs.items():
                state = NumericTableState.load(value)
                if (value["config"] != configs[name] or value["train_rows"] != self.state.metadata["train_rows"]
                        or value["sample_order_sha256"] != order_hash(sample_ids)):
                    fail("E_BUNDLE", name, "input table state differs from project/sample order/training rows")
                self.input_states[name] = state
        graph_state = None
        if "graph_spec" in self.spec.to_dict():
            from .graphs.state import resolve_graph, validate_state
            graph_state = read_json(directory / "graph_state.json")
            validate_state(self.spec.to_dict()["graph_spec"], graph_state, self.state.input_features)
            expected_graph = resolve_graph(self.spec.to_dict()["graph_spec"], self.state.metadata["input_markers"],
                                           self.state.arrays["keep"], self.state.metadata["train_rows"], graph_state.get("ld_fit"))
            if graph_state != expected_graph:
                fail("E_BUNDLE", "graph_state.json", "graph state differs from saved training preprocessing")
            if "ld_fit" in graph_state and graph_state["ld_fit"] is None:
                fail("E_BUNDLE", "graph_state.json", "saved predictor requires fitted LD topology")
        self.reference_state, self.reference_features = None, None
        reference_spec = self.spec.to_dict().get("individual_graph_spec")
        if reference_spec:
            from .graphs.individual import validate_reference_state
            self.reference_state = read_json(directory/"reference_state.json")
            validate_reference_state(reference_spec, self.reference_state, self.state.input_features)
            context_ids = read_json(directory/"prepared/split.json")["manifest"]["context"]["sample_ids"]
            expected_ids = [context_ids[i] for i in self.reference_state["reference_rows"] if i < len(context_ids)]
            if (self.reference_state["training_rows"] != self.state.metadata["train_rows"]
                    or self.reference_state["input_binding_sha256"] != order_hash(context_ids)
                    or self.reference_state["reference_ids"] != expected_ids
                    or self.reference_state["feature_order_sha256"] != self.state.metadata["selected_marker_order_sha256"]):
                fail("E_BUNDLE", "reference_state.json", "reference identity/preprocessing/training scope mismatch")
            if reference_spec["protocol"] == "transductive_fixed_cohort" and len(expected_ids) != len(context_ids):
                fail("E_BUNDLE", "reference_state.json", "transductive reference must include the full fixed cohort")
        with execution_context(self.config) as selected:
            self.model = build_model(self.spec, self.input_features,
                                     max_parameter_bytes=max_parameter_bytes, graph_state=graph_state, reference_state=self.reference_state)
            try:
                weights = torch.load(directory / "weights.pt", map_location="cpu", weights_only=True)
                reference = self.model.state_dict()
                if not isinstance(weights, dict) or set(weights) != set(reference):
                    raise ValueError("state_dict keys differ")
                for name, value in weights.items():
                    if (not isinstance(value, torch.Tensor) or value.dtype != reference[name].dtype or
                            value.shape != reference[name].shape or not torch.isfinite(value).all()):
                        raise ValueError(f"invalid tensor shape/dtype/values: {name}")
                    if name.startswith("graph_buffers.") and not torch.equal(value, reference[name]):
                        raise ValueError(f"topology buffer differs from frozen graph state: {name}")
                    if name.startswith("reference_buffers.") and name != "reference_buffers.features" and not torch.equal(value, reference[name]):
                        raise ValueError(f"reference topology differs from frozen state: {name}")
                    if name == "reference_buffers.features":
                        from .graphs.individual import feature_digest
                        if feature_digest(value.numpy()) != self.reference_state["feature_sha256"]:
                            raise ValueError("reference genotype buffer differs from saved digest")
                        self.reference_features = value.numpy().copy()
                self.model.load_state_dict(weights, strict=True)
            except Exception as error:
                fail("E_BUNDLE", "weights.pt", f"cannot load tensor-only weights: {error}")
            self.model.to(selected).eval()

    def align(self, markers):
        expected = self.state.metadata["input_markers"]
        lookup = {}
        for i, row in enumerate(markers):
            if len(row) != 6 or row[1] in lookup:
                fail("E_MARKER", f"markers[{i}]", "malformed or duplicate marker")
            lookup[row[1]] = i
        columns = []
        for row in expected:
            if row[1] not in lookup:
                fail("E_MARKER", row[1], "required original marker missing (including training-filtered markers)")
            i = lookup[row[1]]
            if list(markers[i]) != row:
                fail("E_MARKER", row[1], f"chromosome/position or case-sensitive A1/A2 mismatch: expected {row}, got {list(markers[i])}")
            columns.append(i)
        return np.asarray(columns, dtype=np.int64)

    def verify_encoding_declaration(self, declaration):
        matrix = self.project.to_dict()["data"].get("matrix")
        if matrix and matrix["counted_allele"] == "DECLARED":
            if declaration != matrix.get("allele_declaration"):
                fail("E_MARKER", "allele_declaration", "no-BIM prediction requires the same explicit source/allele-coding declaration as training; allele direction cannot be inferred")

    def predict_raw(self, raw, markers, additional=None, sample_ids=None, *, allele_declaration=None):
        self.verify_encoding_declaration(allele_declaration)
        columns = self.align(markers)
        raw = np.asarray(raw)
        if raw.ndim != 2 or raw.shape[1] != len(markers):
            fail("E_MARKER", "genotypes", "matrix columns do not match the supplied marker identities")
        from .data.kernel_features import transform_inputs
        x, kernel = transform_inputs(self, raw[:, columns], getattr(self.model, "input_representation", "standardized_dosage"))
        additional = additional or {}
        if set(additional) != set(self.input_states):
            fail("E_INPUT_TABLE", "prediction", f"explicit raw input arrays required for {sorted(self.input_states)}")
        with execution_context(self.config) as device, torch.no_grad():
            inputs = torch.from_numpy(x).to(device)
            if self.input_states or self.reference_state or kernel is not None:
                inputs = {"$input": inputs, **{"$input:"+name: torch.from_numpy(state.transform(additional[name])).to(device)
                                              for name, state in self.input_states.items()}}
            if kernel is not None:
                inputs['$input:kernel'] = torch.from_numpy(kernel).to(device)
            if self.reference_state:
                from .graphs.individual import query_context
                context = query_context(self.spec.to_dict()["individual_graph_spec"], self.reference_state,
                                        self.reference_features, x, sample_ids)
                inputs["$reference"] = {key: torch.from_numpy(value).to(device) for key, value in context.items()}
            result = self.model(inputs).detach().cpu().numpy()
            expected_width=len(self.target_state["mean"]) if self.target_state else 1
            if result.shape!=(len(raw),expected_width) or not np.isfinite(result).all():
                fail("E_BUNDLE","prediction","invalid shape or nonfinite model prediction")
        if self.target_state:
            from .data.multitask import transform_targets
            return transform_targets(result,self.target_state,inverse=True)
        result=result.reshape(-1)
        return self.state.inverse_target(result)


def predict_bed(bundle, bed, output, *, bim=None, fam=None, dataset_id="new_cohort",
                device="cpu", batch_size=None, max_parameter_bytes=DEFAULT_PARAMETER_BYTES,
                progress=None, cancelled=None, input_tables=None, matrix=None, fold=None,
                phenotype=None, phenotype_options=None, identity_relation="unknown", identity_note="",
                sort_direction=None):
    from .training.core import check_cancel
    def stage(name, done=0, total=0):
        check_cancel(cancelled)
        if progress:
            progress({"event": "stage", "stage": name, "done": done, "total": total})
    stage("loading_model")
    output, bundle = Path(output).resolve(), Path(bundle).resolve()
    from .data.genotypes import open_source, validate_matrix, matrix_encoding
    if matrix is not None:
        validate_matrix(matrix)
        if bed or fam:
            fail("E_FORMAT", "matrix", "matrix prediction cannot also supply BED/FAM")
        if (matrix["counted_allele"] == "BIM_A1") != bool(bim):
            fail("E_FORMAT", "matrix", "BIM_A1 requires BIM; DECLARED no-BIM mode requires no BIM")
        paths = {"matrix": Path(matrix["path"]).resolve()}
        if bim:
            paths["bim"] = Path(bim).resolve()
    else:
        if not bed:
            fail("E_FORMAT", "bed", "select BED or an explicit matrix configuration")
        bed = Path(bed).resolve()
        paths = {"bed": bed, "bim": Path(bim).resolve() if bim else bed.with_suffix(".bim"),
                 "fam": Path(fam).resolve() if fam else bed.with_suffix(".fam")}
    input_tables = input_tables or {}
    if output.exists():
        fail("E_EXISTS", str(output), "choose a new prediction directory")
    protect_inputs(output, [*paths.values(), *(Path(p).resolve() for p in input_tables.values()),
                            *([Path(phenotype).resolve()] if phenotype else [])])
    if output.is_relative_to(bundle) or bundle.is_relative_to(output):
        fail("E_IO", str(output), "prediction output and model archive must not overlap")
    if not isinstance(dataset_id, str) or not dataset_id.strip():
        fail("E_VALUE", "dataset_id", "nonempty cohort identifier required")
    if sort_direction not in (None, "ascending", "descending"):
        fail("E_VALUE", "sort_direction", "choose ascending, descending, or no sorting")
    predictor = load_predictor(bundle, device=device, max_parameter_bytes=max_parameter_bytes, fold=fold)
    declaration = matrix.get("allele_declaration") if matrix else None
    predictor.verify_encoding_declaration(declaration)
    batch_size = predictor.config["batch_size"] if batch_size is None else batch_size
    number(batch_size, "batch_size", 1, 2**31-1, integer=True)
    files = {key: snapshot(path) for key, path in paths.items()}
    if phenotype:
        files["scoring_phenotype"] = snapshot(Path(phenotype).resolve())
    elif phenotype_options is not None:
        fail("E_VALUE", "phenotype_options", "scoring options require an optional phenotype file")
    samples, markers, adapter = open_source({"matrix": matrix}, paths, progress=stage)
    from .prediction_sources import identity_statuses, score_optional_phenotypes
    statuses, identity = identity_statuses(predictor, samples, identity_relation, identity_note, query_files=files)
    if set(input_tables) != set(predictor.input_states):
        fail("E_INPUT_TABLE", "prediction", f"provide exactly these named input tables: {sorted(predictor.input_states)}")
    additional, input_reports = {}, {}
    from .data.additional import aligned_numeric
    for name, state in predictor.input_states.items():
        stage("additional_input_" + name)
        raw, report = aligned_numeric(state.value["config"], input_tables[name], [list(s[:2]) for s in samples])
        additional[name], input_reports[name] = raw, report
        files["input_table:"+name] = report["source"]
    columns = predictor.align(markers)
    output.mkdir(parents=True)
    (output / "INCOMPLETE").write_text("Prediction in progress\n", encoding="utf-8")
    try:
        missing = adapter.scan(output / "dosage.npy", progress=stage)
        cache = RawCache(output, {"shape": [len(samples), len(markers)]}, missing)
        expected = predictor.state.metadata["input_markers"]
        width = len(predictor.targets)
        estimates = np.lib.format.open_memmap(output / "prediction_values.npy", mode="w+", dtype=np.float64,
                                               shape=(len(samples), width))
        spread = np.lib.format.open_memmap(output / "model_disagreement.npy", mode="w+", dtype=np.float64,
                                           shape=(len(samples), width))
        for start in range(0, len(samples), batch_size):
            stage("prediction", start, len(samples))
            rows = np.arange(start, min(start + batch_size, len(samples)))
            # Every member aligns and transforms this raw batch with its own
            # frozen mask/normalization/reference; predictions are already in units.
            raw = cache.batch(rows, columns)
            other = {name: values[rows] for name, values in additional.items()}
            ids = [list(samples[i][:2]) for i in rows]
            if hasattr(predictor, "predict_distribution"):
                values, deviation = predictor.predict_distribution(raw, expected, other, sample_ids=ids,
                    allele_declaration=declaration, progress=progress, cancelled=cancelled)
            else:
                values = predictor.predict_raw(raw, expected, other, sample_ids=ids, allele_declaration=declaration)
                deviation = np.zeros_like(values)
            estimates[rows] = np.asarray(values).reshape(len(rows), width)
            spread[rows] = np.asarray(deviation).reshape(len(rows), width)
        estimates.flush()
        spread.flush()
        scoring, observed, matches = None, None, None
        if phenotype:
            stage("post_prediction_scoring")
            observed, matches, scoring = score_optional_phenotypes(phenotype, phenotype_options, predictor,
                                                                  samples, estimates, statuses)
        versions = sorted({member["metadata"].get("gpnb_version", member["metadata"].get("gsapp_version", "unknown")) for member in predictor.resolved_source["members"]})
        model_version = ";".join(versions)
        def ordered_records():
            if sort_direction:
                for j in range(width):
                    rows = np.argsort(estimates[:, j] if sort_direction == "ascending" else -estimates[:, j], kind="stable")
                    for rank, row in enumerate(rows, 1):
                        yield j, row, rank
            else:
                for row in range(len(samples)):
                    for j in range(width):
                        yield j, row, ""
        def records():
            for j, row, rank in ordered_records():
                target = predictor.targets[j]
                value = float(estimates[row, j])
                record = [dataset_id, target["trait"], int(row), *samples[row][:2], value,
                          target["id"], target["environment"], target["unit"], model_version, statuses[row],
                          float(spread[row, j]), len(predictor.member_directories), rank]
                if phenotype:
                    valid = np.isfinite(observed[row, j])
                    record.extend([float(observed[row, j]) if valid else "",
                                   value - float(observed[row, j]) if valid else "", matches[row, j]])
                yield record
        fields = ["dataset_id", "trait", "fam_index", "FID", "IID", "predicted", "target_id", "environment", "unit",
                  "model_version", "identity_status", "model_disagreement_sd", "member_count", "selection_rank"]
        if phenotype:
            fields += ["observed", "prediction_minus_observed", "phenotype_match"]
        write_csv(output / "predictions.csv", fields, records())
        write_csv(output / "marker_alignment.csv", ["training_bim_index", "new_bim_index", "marker_id", "retained"],
                  ((i, int(j), expected[i][1], bool(predictor.state.arrays["keep"][i])) for i, j in enumerate(columns)))
        member_alignments = []
        if len(predictor.member_directories) > 1:
            from types import SimpleNamespace
            for index, member in enumerate(predictor.resolved_source["members"], 1):
                state = PreprocessorState.load(member["directory"] / "prepared/preprocessor")
                aligned = Predictor.align(SimpleNamespace(state=state), markers)
                filename = f"marker_alignment_member_{index}.csv"
                write_csv(output / filename, ["training_bim_index", "new_bim_index", "marker_id", "retained"],
                    ((i, int(j), state.metadata["input_markers"][i][1], bool(state.arrays["keep"][i]))
                     for i, j in enumerate(aligned)))
                member_alignments.append(dict(member_id=member["id"], path=filename))
        write_csv(output / "samples.csv", ["fam_index", "FID", "IID", "missing_genotypes"],
                  ((i, *s[:2], int(missing.samples[i])) for i, s in enumerate(samples)))
        verify_snapshots(files)
        for directory in predictor.member_directories:
            verify_bundle(directory, "training_run", RUN_REQUIRED)
        verify_bundle(bundle)
        package = Path(__file__).parent
        write_json(output / "environment.json", {
            "python": platform.python_version(), "platform": platform.platform(),
            "packages": {name: importlib.metadata.version(name) for name in ("torch", "numpy", "bed-reader")},
            "device": device, "cuda_runtime": torch.version.cuda,
            "threads": predictor.config["threads"], "deterministic": predictor.config["deterministic"],
            "source_sha256": {p.relative_to(package).as_posix(): sha256(p) for p in package.rglob("*.py")}})
        report = {"ok": True, "schema_version": 1, "kind": "prediction_run", "dataset_id": dataset_id,
                  "training_dataset_id": predictor.summary["dataset_id"], "trait": predictor.summary["trait"],
                  "training_seed": predictor.summary["seed"], "training_fold": predictor.summary["fold"],
                  "model_sha256": predictor.spec.sha256, "model_bundle": str(bundle),
                  "weights_sha256": snapshot(predictor.directory / "weights.pt")["sha256"],
                  "preprocessor_state_sha256": sha256(predictor.directory / "prepared/preprocessor/state.json"),
                  "model": predictor.spec.to_dict(),
                  "samples": len(samples), "input_markers": len(markers), "required_markers": len(columns),
                  "ignored_extra_markers": len(markers)-len(columns), "missing_genotypes": missing.total,
                  "sample_order_sha256": order_hash([list(s[:2]) for s in samples]),
                  "input_marker_order_sha256": order_hash([list(m) for m in markers]),
                  "source_files": files, "encoding": matrix_encoding(matrix) if matrix else ENCODING, "device": device, "batch_size": batch_size,
                  "output_scale": "input training phenotype scale; not automatically an estimated breeding value",
                  "project_extensions": predictor.project.to_dict().get("extensions", {}),
                  "training_provenance": predictor.state.metadata["provenance"],
                  "input_format": "matrix" if matrix else "plink", "matrix_options": matrix,
                  "new_cohort_upstream_preprocessing": "unknown; genotype files alone cannot establish prior processing",
                  "fit_performed": False, "warnings": predictor.state.metadata["warnings"],
                  "identity": identity, "targets": predictor.targets, "scoring": scoring,
                  "selection_sort": sort_direction, "model_version": model_version,
                  "member_versions": versions, "member_alignments": member_alignments,
                  "marker_alignment_scope": "marker_alignment.csv describes the first member; member_alignments lists all members when ensembled",
                  "member_count": len(predictor.member_directories),
                  "prediction_strategy": "equal_weight_original_units" if len(predictor.member_directories) > 1 else "single_model",
                  "model_disagreement": "Population SD across the loaded members in original target units; not a confidence interval or breeding-value reliability.",
                  "oof": False,
                  "member_models": [{"id": member["id"], "fold": member.get("fold"),
                      "model_sha256": read_json(member["directory"] / "summary.json")["model_sha256"],
                      "weights_sha256": sha256(member["directory"] / "weights.pt"),
                      "preprocessor_state_sha256": sha256(member["directory"] / "prepared/preprocessor/state.json")}
                      for member in predictor.resolved_source["members"]]}
        if len(predictor.member_directories) > 1:
            report["model_sha256_scope"] = "first member only; complete member_models contains every member"
            report["training_fold"] = None
        if input_reports:
            report["additional_input_matching"] = input_reports
        write_json(output / "report.json", report)
        stage("archive_verification")
        # The raw int8 decode cache is local to this prediction, not a fitted state.
        seal(output, "prediction_run")
        (output / "INCOMPLETE").unlink()
        return report
    except BaseException as error:
        write_json(output / "failure.json", {"ok": False, "error": str(error),
                   "status": "cancelled" if getattr(error, "code", "") == "E_CANCELLED" else "failed"})
        raise
