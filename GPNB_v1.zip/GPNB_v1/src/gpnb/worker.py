"""One job per process. stdout is a flushed JSONL protocol; stdin accepts cancel."""
from __future__ import annotations

import argparse
import json
import os
import sys
import threading
import time
import traceback
from pathlib import Path

import psutil

from .data.files import read_json
from .paths import configure_local_paths


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--request", required=True)
    parser.add_argument("--parent-pid", type=int, required=True)
    parser.add_argument("--parent-created", type=float, required=True)
    args = parser.parse_args(argv)
    configure_local_paths()
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
    cancelled, stopped, lock = threading.Event(), threading.Event(), threading.Lock()

    def emit(event):
        with lock:
            print(json.dumps(event, ensure_ascii=False, allow_nan=False), flush=True)

    def listen():
        for line in sys.stdin:
            if line.strip() == "cancel":
                cancelled.set()
        # Pipe EOF also means the owning desktop has gone away.
        cancelled.set()

    def watch():
        process, started, orphan_since = psutil.Process(), time.monotonic(), None
        while not stopped.wait(.5):
            try:
                parent = psutil.Process(args.parent_pid)
                alive = abs(parent.create_time() - args.parent_created) < .01 and parent.is_running()
            except psutil.Error:
                alive = False
            if not alive:
                cancelled.set()
                orphan_since = orphan_since or time.monotonic()
                if time.monotonic() - orphan_since > 3:
                    os._exit(130)  # no completed archive is published by this fallback
            try:
                sample = {"event": "resource", "elapsed_seconds": time.monotonic() - started,
                          "rss_bytes": process.memory_info().rss,
                          "cuda_allocated_bytes": None, "cuda_reserved_bytes": None}
                torch = sys.modules.get("torch")
                if torch is not None and torch.cuda.is_initialized():
                    sample.update(cuda_allocated_bytes=torch.cuda.memory_allocated(),
                                  cuda_reserved_bytes=torch.cuda.memory_reserved())
                emit(sample)
            except (psutil.Error, OSError, AttributeError):
                pass

    threading.Thread(target=listen, daemon=True).start()
    watcher = threading.Thread(target=watch, daemon=True)
    watcher.start()
    result = {"event": "result", "status": "failed"}
    try:
        request = read_json(Path(args.request))
        kind, options = request["kind"], request["options"]
        emit({"event": "stage", "stage": "loading", "kind": kind})
        if kind == "preflight":
            from .preflight import preflight_project
            summary = preflight_project(**options, progress=emit, cancelled=cancelled.is_set)
        elif kind == "export_genotypes":
            from .data.matrix_export import export_genotypes
            summary = export_genotypes(**options, progress=emit, cancelled=cancelled.is_set)
        elif kind == 'export_matrices':
            from .data.matrix_tools import export_matrices
            summary = export_matrices(**options, progress=emit, cancelled=cancelled.is_set)
        elif kind == 'export_plots':
            from .results import export_result_plots
            if cancelled.is_set():
                raise KeyboardInterrupt('cancel requested')
            summary = export_result_plots(**options, progress=emit, cancelled=cancelled.is_set)
        elif kind == "preview_split":
            from .data.preview import preview_split
            summary = preview_split(**options, progress=emit, cancelled=cancelled.is_set)
        elif kind == "train":
            from .training.run import train_project
            receipt = options.pop("preflight_report", None)
            from .runtime_start import validate_destination
            validate_destination(options['output'])
            verified_at=time.perf_counter()
            emit(dict(event='stage',stage='verifying_inputs',kind=kind))
            if receipt:
                from .preflight import verify_preflight
                verify_preflight(options["project_path"], receipt,
                                 max_parameter_bytes=options.get("max_parameter_bytes", 256 * 2**20))
            emit(dict(event='stage',stage='reusing_preflight',seconds=time.perf_counter()-verified_at,kind=kind))
            summary = train_project(**options, progress=emit, cancelled=cancelled.is_set)
        elif kind == "retry-batch":
            from .training.trait_batch import run_batch
            previous=Path(options.pop('retry_from'))
            saved=read_json(previous/'summary.json')
            summary=run_batch(previous/'project.json',retry_from=previous,operation=saved.get('operation','train'),**options,progress=emit,cancelled=cancelled.is_set)
        elif kind == "compare_cv":
            from .training.comparison import compare_cv
            summary = compare_cv(**options, progress=emit, cancelled=cancelled.is_set)
        elif kind == "predict":
            from .prediction import predict_bed
            summary = predict_bed(**options, progress=emit, cancelled=cancelled.is_set)
        elif kind == "model-package":
            from .model_package import export_model_package
            source = options.pop('bundle')
            summary = export_model_package(source, **options, progress=emit, cancelled=cancelled.is_set)
        elif kind == "final-refit":
            from .training.final_refit import final_refit_project
            summary = final_refit_project(**options, progress=emit, cancelled=cancelled.is_set)
        elif kind == "export":
            from .exporting import export_run
            if cancelled.is_set():
                raise KeyboardInterrupt("cancel requested")
            summary = export_run(**options, progress=emit, cancelled=cancelled.is_set)
        elif kind == "view":
            from .training.core import check_cancel
            check_cancel(cancelled.is_set)
            directory = Path(options["bundle"]).resolve()
            from .bundle import verify_bundle
            preliminary=read_json(directory/'summary.json') if (directory/'summary.json').is_file() else {}
            if preliminary.get('kind')=='trait_batch' and (directory/'INCOMPLETE').is_file():
                # Task status is inspectable after cancellation; no model is loaded here.
                summary=preliminary
            else:
                manifest = verify_bundle(directory)
                if manifest['kind'] in ('exported_cv', 'exported_run'):
                    directory = directory/'run'
                summary_path = directory/'summary.json'
                summary = read_json(summary_path) if summary_path.is_file() else dict(ok=True, kind=manifest['kind'])
            options['output'] = str(directory)
        else:
            raise ValueError(f"Unsupported job kind: {kind}")
        if kind in ('view', 'train', 'final-refit', 'model-package') and summary.get('kind')!='trait_batch':
            from .prediction_sources import describe_prediction_source
            from .model_package import resolve_model_source
            description = describe_prediction_source(options['output'])
            resolved = resolve_model_source(options['output'])
            result.update(model_description=description,
                          project=read_json(resolved['members'][0]['directory']/'project.json'))
        result.update(status="completed", summary=summary, output=str(options["output"]), kind=kind)
    except BaseException as error:
        result.update(status="cancelled" if isinstance(error, KeyboardInterrupt) or
                      getattr(error, "code", "") == "E_CANCELLED" else "failed",
                      error=str(error), code=getattr(error, "code", type(error).__name__))
        traceback.print_exc(file=sys.stderr)
    finally:
        stopped.set()
        watcher.join(2)
    emit(result)
    return 0 if result["status"] == "completed" else 130 if result["status"] == "cancelled" else 1


if __name__ == "__main__":
    raise SystemExit(main())
