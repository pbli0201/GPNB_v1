"""Frozen locus topology after training marker selection; never consult labels."""
from ..config import fail
from .spec import GraphSpec, canonical_edges


def resolve_graph(spec, markers=None, keep=None, train_rows=None, fit=None):
    spec = spec if isinstance(spec, GraphSpec) else GraphSpec(spec)
    value = spec.to_dict()
    if markers is not None and markers != value["markers"]:
        fail("E_GRAPH", "graph.markers", "full BIM identities/order differ from genotype input")
    keep = [True] * len(value["markers"]) if keep is None else [bool(x) for x in keep]
    if len(keep) != len(value["markers"]) or not any(keep):
        fail("E_GRAPH", "graph.keep", "marker mask must align and retain at least one marker")
    selected = {row[1]: i for i, row in enumerate(r for r, k in zip(value["markers"], keep) if k)}
    nodes, groups, dropped = [], [], []
    for node in value["nodes"]:
        group = [selected[m] for m in node["marker_ids"] if m in selected]
        if group:
            nodes.append(node["id"])
            groups.append(group)
        else:
            dropped.append(node["id"])
    if dropped and value["filtered_nodes"] == "error":
        fail("E_GRAPH", "filtered_nodes", f"training marker filter emptied nodes {dropped[:10]}")
    order = {name: i for i, name in enumerate(nodes)}
    ld = value["source"]["kind"] == "training_ld"
    raw_edges = value["edges"] if not ld or fit is None else fit["edges"]
    edges = canonical_edges(raw_edges, [n["id"] for n in value["nodes"]],
                            value["direction"], value["duplicate_edges"])
    weights = {}
    for a, b, w in edges:
        if a not in order or b not in order or (a == b and value["self_loops"] == "none"):
            continue
        i, j = order[a], order[b]
        weights[i, j] = w
        if value["direction"] == "undirected":
            weights[j, i] = w
    if value["self_loops"] == "add_unit":
        for i in range(len(nodes)):
            weights[i, i] = weights.get((i, i), 0.) + 1.
    edges = [[a, b, w] for (a, b), w in sorted(weights.items(), key=lambda item: (item[0][1], item[0][0]))]
    state = dict(schema_version=1, kind="locus_graph_state", graph_sha256=spec.sha256,
                keep=keep, nodes=nodes, groups=groups, edges=edges, dropped_nodes=dropped,
                direction=value["direction"], aggregation=value["aggregation"],
                train_rows=[] if train_rows is None else [int(i) for i in train_rows],
                scope="shared locus topology; each batch item is an independent individual")
    if ld:
        state["ld_fit"] = fit
    return state


def validate_state(spec, state, input_features):
    if type(state) is not dict:
        fail("E_GRAPH", "graph_state", "expected frozen graph object")
    value = spec.to_dict() if isinstance(spec, GraphSpec) else spec
    fit = state.get("ld_fit")
    if value["source"]["kind"] == "training_ld" and fit is not None:
        from .ld import validate_fit
        validate_fit(value, fit, state["train_rows"], state["keep"])
    expected = resolve_graph(spec, keep=state.get("keep"), train_rows=state.get("train_rows"), fit=fit)
    if state != expected or sum(state["keep"]) != input_features:
        fail("E_GRAPH", "graph_state", "frozen state differs from graph definition/retained marker count")
    return state


def fit_graph(model_spec, prepared, progress=None, cancelled=None):
    value = model_spec.to_dict()
    if "graph_spec" not in value:
        return None
    fit = None
    if value["graph_spec"]["source"]["kind"] == "training_ld":
        from .ld import fit_ld
        fit = fit_ld(value["graph_spec"], prepared, progress, cancelled)
    return resolve_graph(value["graph_spec"], prepared.state.metadata["input_markers"],
                         prepared.state.arrays["keep"], prepared.split.rows("train"), fit)


def topology_bytes(state):
    # src,dst int64; edge weight float32; node degree float32;
    # marker->node int64; group count float32. Registered once at model root.
    return 20 * len(state["edges"]) + 8 * len(state["nodes"]) + 8 * sum(map(len, state["groups"]))
