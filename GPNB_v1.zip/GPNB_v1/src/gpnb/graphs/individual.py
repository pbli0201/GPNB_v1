"""Explicit individual-reference graph protocols, independent of target labels."""
from __future__ import annotations

import hashlib
import json

import numpy as np

from ..config import Spec, choice, fail, header, number, object_fields
from ..data.files import order_hash


def reference_defaults(protocol="inductive_train_reference"):
    return dict(schema_version=1, kind="individual_graph", protocol=protocol, relationship="rbf_knn_mean",
                neighbors=8, temperature=1., minimum_weight=0., max_reference_individuals=1024,
                max_reference_cells=2_000_000, max_pair_products=100_000_000)


def validate_reference_spec(value):
    header(value, "individual_graph", "individual_graph", (
        "protocol", "relationship", "neighbors", "temperature", "minimum_weight",
        "max_reference_individuals", "max_reference_cells", "max_pair_products"))
    choice(value["protocol"], "individual_graph.protocol", ("inductive_train_reference", "transductive_fixed_cohort"))
    choice(value["relationship"], "individual_graph.relationship", ("rbf_knn_mean",))
    number(value["neighbors"], "individual_graph.neighbors", 1, 64, integer=True)
    number(value["temperature"], "individual_graph.temperature", 1e-6, 1e6)
    number(value["minimum_weight"], "individual_graph.minimum_weight", 0., 1.)
    number(value["max_reference_individuals"], "individual_graph.max_reference_individuals", 2, 16384, integer=True)
    number(value["max_reference_cells"], "individual_graph.max_reference_cells", 2, 50_000_000, integer=True)
    number(value["max_pair_products"], "individual_graph.max_pair_products", 1, 2**31-1, integer=True)


class IndividualGraphSpec(Spec):
    kind = "individual_graph"
    validator = staticmethod(validate_reference_spec)


def feature_digest(array):
    return hashlib.sha256(np.ascontiguousarray(array, dtype="<f4").tobytes()).hexdigest()


def nearest(query, reference, k, options, exclude=None):
    """Stable CPU float64 ranking; relation construction is not differentiated."""
    query, reference = np.asarray(query, dtype=np.float64), np.asarray(reference, dtype=np.float64)
    if query.ndim != 2 or reference.ndim != 2 or query.shape[1] != reference.shape[1]:
        fail("E_REFERENCE", "features", "query/reference feature widths differ")
    if not np.isfinite(query).all() or not np.isfinite(reference).all():
        fail("E_REFERENCE", "features", "finite transformed genotype features required")
    products = query.shape[0]*reference.shape[0]*reference.shape[1]
    if products > options["max_pair_products"]:
        fail("E_REFERENCE", "max_pair_products", "relationship calculation exceeds explicit product budget")
    # Direct differences avoid cancellation of squared norms and provide stable tie semantics.
    indices = np.empty((len(query), k), dtype=np.int64)
    weights = np.empty((len(query), k), dtype=np.float32)
    for row, features in enumerate(query):
        distances = np.square(reference-features).mean(1)
        if exclude is not None and exclude[row] >= 0:
            distances[exclude[row]] = np.inf
        chosen = np.argsort(distances, kind="stable")[:k]
        scores = np.exp(-distances[chosen]/options["temperature"])
        scores[scores < options["minimum_weight"]] = 0.
        total = scores.sum()
        indices[row] = chosen
        weights[row] = scores/total if total > 0 else 0.
    return indices, weights


def fit_reference(model_spec, prepared, cancelled=None):
    from ..training.core import check_cancel
    value = model_spec.to_dict().get("individual_graph_spec")
    if value is None:
        return None, None
    spec = IndividualGraphSpec(value)
    if model_spec.to_dict().get("input_representation", "standardized_dosage") != "standardized_dosage":
        fail("E_REFERENCE", "input_representation", "reference graph requires continuous transformed genotype features")
    training = [int(i) for i in prepared.split.rows("train")]
    rows = training if value["protocol"] == "inductive_train_reference" else list(range(len(prepared.samples)))
    n, m = len(rows), prepared.input_features
    if n < 2 or n > value["max_reference_individuals"] or n*m > value["max_reference_cells"]:
        fail("E_REFERENCE", "reference", "reference population/cell budget exceeded or fewer than two individuals")
    if n*n*m > value["max_pair_products"]:
        fail("E_REFERENCE", "reference", "training reference relationship product budget exceeded before reading genotypes")
    arrays = []
    for start in range(0, n, 128):
        check_cancel(cancelled)
        raw = prepared.cache.batch(rows[start:start+128])
        arrays.append(prepared.state.transform(raw, prepared.state.metadata["input_markers"]))
    features = np.ascontiguousarray(np.concatenate(arrays, axis=0), dtype=np.float32)
    k = min(value["neighbors"], n-1)
    parts_i, parts_w = [], []
    for start in range(0, n, 64):
        check_cancel(cancelled)
        idx, weight = nearest(features[start:start+64], features, k, value, np.arange(start, min(n, start+64)))
        parts_i.append(idx)
        parts_w.append(weight)
    ids = [[prepared.samples[i]["FID"], prepared.samples[i]["IID"]] for i in rows]
    state = dict(schema_version=1, kind="individual_reference_state", spec_sha256=spec.sha256,
                 protocol=value["protocol"], reference_rows=rows, training_rows=training, reference_ids=ids,
                 reference_order_sha256=order_hash(ids), feature_order_sha256=prepared.state.metadata["selected_marker_order_sha256"],
                 feature_shape=[n, m], feature_sha256=feature_digest(features), neighbors=k,
                 indices=np.concatenate(parts_i).tolist(), weights=np.concatenate(parts_w).tolist(),
                 labels_in_graph=False, genotype_visibility="inner_training_only" if value["protocol"] == "inductive_train_reference" else "entire_fixed_cohort",
                 relationship="RBF of mean squared transformed-genotype distance; stable reference-order ties; self excluded",
                 input_binding_sha256=order_hash([[s["FID"], s["IID"]] for s in prepared.samples]))
    validate_reference_state(value, state, m)
    return state, features


def validate_reference_state(spec, state, input_features):
    spec = spec if isinstance(spec, IndividualGraphSpec) else IndividualGraphSpec(spec)
    options = spec.to_dict()
    object_fields(state, "reference_state", ("schema_version", "kind", "spec_sha256", "protocol", "reference_rows",
        "training_rows", "reference_ids", "reference_order_sha256", "feature_order_sha256", "feature_shape", "feature_sha256",
        "neighbors", "indices", "weights", "labels_in_graph", "genotype_visibility", "relationship", "input_binding_sha256"))
    if (state["schema_version"] != 1 or state["kind"] != "individual_reference_state" or state["spec_sha256"] != spec.sha256
            or state["protocol"] != options["protocol"] or state["labels_in_graph"] is not False):
        fail("E_REFERENCE", "reference_state", "reference protocol/spec/label visibility mismatch")
    shape = state["feature_shape"]
    if type(shape) is not list or len(shape) != 2:
        fail("E_REFERENCE", "feature_shape", "expected [reference_individuals,features]")
    n, m = shape
    number(n, "reference_individuals", 2, options["max_reference_individuals"], integer=True)
    number(m, "reference_features", 1, integer=True)
    if m != input_features or n*m > options["max_reference_cells"] or n*n*m > options["max_pair_products"]:
        fail("E_REFERENCE", "reference_shape", "feature count or reference budget mismatch")
    for key in ("reference_rows", "training_rows"):
        rows = state[key]
        if type(rows) is not list or not rows or any(type(i) is not int or i < 0 for i in rows) or len(set(rows)) != len(rows):
            fail("E_REFERENCE", key, "unique nonnegative integer sample indices required")
    if len(state["reference_rows"]) != n or not set(state["training_rows"]) <= set(state["reference_rows"]):
        fail("E_REFERENCE", "reference_rows", "training rows must belong to the reference population")
    if options["protocol"] == "inductive_train_reference":
        if state["reference_rows"] != state["training_rows"] or state["genotype_visibility"] != "inner_training_only":
            fail("E_REFERENCE", "protocol", "inductive reference must consist solely of ordered inner-training rows")
    elif state["genotype_visibility"] != "entire_fixed_cohort" or state["reference_rows"] != list(range(n)):
        fail("E_REFERENCE", "protocol", "transductive reference must be the explicit full ordered cohort")
    ids = state["reference_ids"]
    if (type(ids) is not list or len(ids) != n or any(type(pair) is not list or len(pair) != 2
            or any(type(s) is not str or not s for s in pair) for pair in ids) or len({tuple(pair) for pair in ids}) != n):
        fail("E_REFERENCE", "reference_ids", "unique string FID/IID reference identities required")
    for key in ("reference_order_sha256", "feature_order_sha256", "feature_sha256", "input_binding_sha256"):
        digest = state[key]
        if type(digest) is not str or len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest):
            fail("E_REFERENCE", key, "invalid SHA256")
    if state["reference_order_sha256"] != order_hash(ids):
        fail("E_REFERENCE", "reference_ids", "reference order digest mismatch")
    k = min(options["neighbors"], n-1)
    if type(state["neighbors"]) is not int or state["neighbors"] != k:
        fail("E_REFERENCE", "neighbors", "reference neighbor count mismatch")
    if len(state["indices"]) != n or len(state["weights"]) != n:
        fail("E_REFERENCE", "neighbors", "missing reference rows")
    for i, (indices, weights) in enumerate(zip(state["indices"], state["weights"])):
        if (type(indices) is not list or len(indices) != k or len(set(indices)) != k
                or any(type(j) is not int or not 0 <= j < n or j == i for j in indices)
                or type(weights) is not list or len(weights) != k):
            fail("E_REFERENCE", f"neighbors[{i}]", "distinct in-range nonself neighbors required")
        for w in weights:
            number(w, f"weights[{i}]", 0., 1.)
        if not (sum(weights) == 0 or abs(sum(weights)-1.) <= 1e-6):
            fail("E_REFERENCE", f"weights[{i}]", "neighbor weights must sum to one or zero")
    return state


def query_context(spec, state, reference, features, sample_ids):
    options = IndividualGraphSpec(spec).to_dict()
    reference, features = np.asarray(reference, dtype=np.float32), np.asarray(features, dtype=np.float32)
    if reference.shape != tuple(state["feature_shape"]) or features.ndim != 2 or features.shape[1] != reference.shape[1]:
        fail("E_REFERENCE", "query", "query/reference feature shape mismatch")
    if sample_ids is None or len(sample_ids) != len(features) or any(len(pair) != 2 or any(type(s) is not str or not s for s in pair) for pair in sample_ids):
        fail("E_REFERENCE", "query_ids", "exact string FID/IID required for each query")
    if len(set(map(tuple, sample_ids))) != len(sample_ids):
        fail("E_REFERENCE", "query_ids", "duplicate query IDs")
    lookup = {tuple(pair): i for i, pair in enumerate(state["reference_ids"])}
    unknown = sum(tuple(pair) not in lookup for pair in sample_ids)
    if unknown*reference.shape[0]*reference.shape[1] > options["max_pair_products"]:
        fail("E_REFERENCE", "query.max_pair_products", "query batch relationship budget exceeded; reduce prediction batch")
    indices, weights = [], []
    for features_i, pair in zip(features, sample_ids):
        position = lookup.get(tuple(pair))
        if position is not None:
            if not np.array_equal(features_i, reference[position]):
                fail("E_REFERENCE", str(pair), "known reference ID has changed genotype features; no silent identity reassignment")
            indices.append(state["indices"][position])
            weights.append(state["weights"][position])
        else:
            if options["protocol"] == "transductive_fixed_cohort":
                fail("E_REFERENCE", str(pair), "fixed-cohort transductive model cannot accept a new individual")
            idx, w = nearest(features_i[None], reference, state["neighbors"], options)
            indices.append(idx[0])
            weights.append(w[0])
    return dict(indices=np.asarray(indices, dtype=np.int64), weights=np.asarray(weights, dtype=np.float32))
