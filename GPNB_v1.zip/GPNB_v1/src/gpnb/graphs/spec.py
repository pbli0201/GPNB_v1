"""GraphSpec stores identities and policies, independent of neural layers."""
import math
from pathlib import Path

from ..config import Spec, boolean, choice, fail, header, number, object_fields, sequence, text
from ..data.files import protect_inputs, snapshot, verify_snapshots, write_json
from ..data.tables import plink_table, text_table


def identifier(value, path):
    text(value, path)
    if value != value.strip():
        fail("E_GRAPH", path, "IDs cannot have surrounding whitespace; no silent trimming")


def canonical_edges(edges, node_ids, direction, duplicate_policy, path="edges"):
    order = {name: i for i, name in enumerate(node_ids)}
    accumulated, first = {}, {}
    for i, row in enumerate(edges):
        loc = f"{path}[{i}]"
        if type(row) not in (tuple, list) or len(row) != 3:
            fail("E_GRAPH", loc, "edge requires source, target, positive weight")
        source, target, weight = row
        identifier(source, loc + ".source")
        identifier(target, loc + ".target")
        if source not in order or target not in order:
            fail("E_GRAPH", loc, f"unknown node {source!r} or {target!r}")
        number(weight, loc + ".weight", positive=True)
        if direction == "undirected" and order[source] > order[target]:
            source, target = target, source
        key = source, target
        if key in accumulated and duplicate_policy == "error":
            fail("E_GRAPH", loc, f"duplicate edge {key}; first row={first[key]} (reverse duplicates count for undirected graphs)")
        combined = accumulated.get(key, 0.) + weight
        if not math.isfinite(combined) or not 1e-30 <= combined <= 1e30:
            fail("E_GRAPH", loc, "edge weight/sum must be in [1e-30, 1e30] for stable float32 aggregation")
        accumulated[key], first[key] = combined, first.get(key, i)
    return [[a, b, weight] for (a, b), weight in sorted(accumulated.items(), key=lambda item: (order[item[0][1]], order[item[0][0]]))]


def validate_graph(value):
    header(value, "graph", "graph", ("name", "graph_type", "source", "markers", "nodes", "edges",
                                    "direction", "self_loops", "duplicate_edges", "filtered_nodes",
                                    "aggregation", "max_edges"))
    text(value["name"], "graph.name")
    choice(value["graph_type"], "graph.graph_type", ("locus",))
    choice(value["direction"], "graph.direction", ("directed", "undirected"))
    choice(value["self_loops"], "graph.self_loops", ("add_unit", "none", "preserve"))
    choice(value["duplicate_edges"], "graph.duplicate_edges", ("error", "sum"))
    choice(value["filtered_nodes"], "graph.filtered_nodes", ("drop", "error"))
    choice(value["aggregation"], "graph.aggregation", ("mean", "sum"))
    number(value["max_edges"], "graph.max_edges", 1, 1_000_000, integer=True)
    source = value["source"]
    object_fields(source, "graph.source", ("kind", "declaration", "note", "files"), ("ld",))
    choice(source["kind"], "graph.source.kind", ("external", "training_ld"))
    choice(source["declaration"], "graph.source.declaration",
           ("unknown", "external_fixed") if source["kind"] == "external" else ("inner_training_only",))
    text(source["note"], "graph.source.note", empty=True)
    object_fields(source["files"], "graph.source.files", ("bim", "edges") if source["kind"] == "external" else ("bim",),
                  ("mapping",) if source["kind"] == "external" else ())
    if source["kind"] == "training_ld":
        ld = source.get("ld")
        object_fields(ld, "graph.source.ld", ("window", "r2_min", "same_chromosome", "weight", "max_pairs"))
        number(ld["window"], "ld.window", 1, 256, integer=True)
        number(ld["r2_min"], "ld.r2_min", 1e-6, 1.)
        boolean(ld["same_chromosome"], "ld.same_chromosome")
        choice(ld["weight"], "ld.weight", ("r2", "binary"))
        number(ld["max_pairs"], "ld.max_pairs", 1, 2_000_000, integer=True)
        if value["edges"] or value["direction"] != "undirected":
            fail("E_GRAPH", "training_ld", "LD definition has no fitted edges and requires undirected topology")
    elif "ld" in source:
        fail("E_GRAPH", "graph.source.ld", "LD settings cannot accompany an external graph")
    for name, info in source["files"].items():
        object_fields(info, f"source.files.{name}", ("path", "sha256", "bytes", "mtime_ns"))
        text(info["path"], f"source.files.{name}.path")
        digest = info["sha256"]
        if type(digest) is not str or len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest):
            fail("E_GRAPH", f"source.files.{name}", "invalid SHA256")
        number(info["bytes"], f"source.files.{name}.bytes", 0, integer=True)
        number(info["mtime_ns"], f"source.files.{name}.mtime_ns", 0, integer=True)
    sequence(value["markers"], "graph.markers")
    marker_ids = set()
    for i, row in enumerate(value["markers"]):
        sequence(row, f"graph.markers[{i}]")
        if len(row) != 6:
            fail("E_GRAPH", f"markers[{i}]", "full six-field BIM identity required")
        for field in row:
            identifier(field, f"markers[{i}]")
        try:
            valid = math.isfinite(float(row[2])) and int(row[3]) >= 0 and row[4] != row[5]
        except ValueError:
            valid = False
        if not valid:
            fail("E_GRAPH", f"markers[{i}]", "invalid BIM position or ambiguous alleles")
        if row[1] in marker_ids:
            fail("E_GRAPH", f"markers[{i}]", "duplicate marker ID")
        marker_ids.add(row[1])
    sequence(value["nodes"], "graph.nodes")
    nodes, assigned = set(), set()
    for i, node in enumerate(value["nodes"]):
        loc = f"graph.nodes[{i}]"
        object_fields(node, loc, ("id", "marker_ids"))
        identifier(node["id"], loc + ".id")
        if node["id"] in nodes:
            fail("E_GRAPH", loc, "duplicate node ID")
        nodes.add(node["id"])
        sequence(node["marker_ids"], loc + ".marker_ids")
        for marker in node["marker_ids"]:
            identifier(marker, loc)
            if marker not in marker_ids or marker in assigned:
                fail("E_GRAPH", loc, f"unknown or multiply assigned marker {marker!r}")
            assigned.add(marker)
    if assigned != marker_ids:
        fail("E_GRAPH", "graph.nodes", f"markers without a node mapping: {sorted(marker_ids - assigned)[:10]}")
    if source["kind"] == "training_ld" and value["nodes"] != [
            {"id": row[1], "marker_ids": [row[1]]} for row in value["markers"]]:
        fail("E_GRAPH", "training_ld.nodes", "LD route requires one node per marker in BIM order")
    sequence(value["edges"], "graph.edges", nonempty=False)
    if len(value["edges"]) > value["max_edges"]:
        fail("E_GRAPH", "graph.edges", "edge count exceeds explicit input budget")
    canonical_edges(value["edges"], [n["id"] for n in value["nodes"]],
                    value["direction"], value["duplicate_edges"], "graph.edges")


class GraphSpec(Spec):
    kind = "graph"
    validator = staticmethod(validate_graph)


def records(path, required, optional=(), delimiter=","):
    iterator = iter(text_table(path, delimiter))
    line, columns = next(iterator, (0, []))
    if not columns or len(set(columns)) != len(columns) or set(columns) != set(required) | (set(columns) & set(optional)):
        fail("E_GRAPH", f"{path}:{line}", f"expected columns {required}, optional {optional}")
    for line, values in iterator:
        if len(values) != len(columns):
            fail("E_GRAPH", f"{path}:{line}", "column count differs from header")
        yield line, dict(zip(columns, values))


def import_graph(bim, edges, output, *, mapping=None, name="Locus graph", direction="undirected",
                 self_loops="add_unit", duplicate_edges="error", filtered_nodes="drop", aggregation="mean",
                 max_edges=1_000_000, delimiter=",", declaration="unknown", note=""):
    bim, edges, output = Path(bim).resolve(), Path(edges).resolve(), Path(output).resolve()
    mapping = Path(mapping).resolve() if mapping else None
    if output.exists():
        fail("E_EXISTS", str(output), "choose a new graph import directory")
    paths = dict(bim=bim, edges=edges)
    if mapping:
        paths["mapping"] = mapping
    protect_inputs(output, list(paths.values()))
    number(max_edges, "max_edges", 1, 1_000_000, integer=True)
    choice(direction, "direction", ("directed", "undirected"))
    choice(duplicate_edges, "duplicate_edges", ("error", "sum"))
    files = {key: snapshot(path) for key, path in paths.items()}
    markers = [list(row) for row in plink_table(bim, "BIM")]
    marker_ids = {row[1] for row in markers}
    nodes, seen = {}, {}
    if mapping:
        for line, row in records(mapping, ("node_id", "marker_id"), delimiter=delimiter):
            for key, value in row.items():
                identifier(value, f"{mapping}:{line}.{key}")
            marker = row["marker_id"]
            if marker not in marker_ids or marker in seen:
                fail("E_GRAPH", f"{mapping}:{line}", f"unknown/repeated marker {marker!r}; first={seen.get(marker)}")
            nodes.setdefault(row["node_id"], []).append(marker)
            seen[marker] = line
    else:
        nodes = {row[1]: [row[1]] for row in markers}
    raw_edges, edge_lines = [], {}
    for line, row in records(edges, ("source", "target"), ("weight",), delimiter):
        try:
            weight = float(row.get("weight", "1"))
        except ValueError:
            fail("E_GRAPH", f"{edges}:{line}.weight", "expected a positive finite weight")
        if row["source"] not in nodes or row["target"] not in nodes:
            fail("E_GRAPH", f"{edges}:{line}", "source/target not in node mapping (IDs are case-sensitive strings)")
        number(weight, f"{edges}:{line}.weight", positive=True)
        key = tuple(sorted((row["source"], row["target"]))) if direction == "undirected" else (row["source"], row["target"])
        if key in edge_lines and duplicate_edges == "error":
            fail("E_GRAPH", f"{edges}:{line}", f"duplicate edge {key}; first at physical line {edge_lines[key]}")
        edge_lines.setdefault(key, line)
        raw_edges.append([row["source"], row["target"], weight])
        if len(raw_edges) > max_edges:
            fail("E_GRAPH", f"{edges}:{line}", "input edge budget exceeded")
    normalized = canonical_edges(raw_edges, list(nodes), direction, duplicate_edges, str(edges))
    spec = GraphSpec(dict(schema_version=1, kind="graph", name=name, graph_type="locus",
        source=dict(kind="external", declaration=declaration, note=note, files=files),
        markers=markers, nodes=[dict(id=node, marker_ids=members) for node, members in nodes.items()],
        edges=normalized, direction=direction, self_loops=self_loops, duplicate_edges=duplicate_edges,
        filtered_nodes=filtered_nodes, aggregation=aggregation, max_edges=max_edges))
    verify_snapshots(files)
    output.mkdir(parents=True)
    spec.save(output / "graph.json")
    report = dict(ok=True, kind="graph_import", graph_sha256=spec.sha256, raw_edge_rows=len(raw_edges),
                  canonical_edge_rows=len(normalized), nodes=len(nodes), markers=len(markers),
                  direction=direction, self_loops=self_loops, source_declaration=declaration,
                  scope="Graph input definition only. No training, LD fitting or prediction performed.")
    write_json(output / "report.json", report)
    return report


def create_ld_graph(bim, output, *, window=16, r2_min=.2, same_chromosome=True,
                    weight="r2", max_pairs=500_000, max_edges=200_000):
    bim, output = Path(bim).resolve(), Path(output).resolve()
    if output.exists():
        fail("E_EXISTS", str(output), "choose a new graph definition directory")
    protect_inputs(output, [bim])
    before = snapshot(bim)
    markers = [list(row) for row in plink_table(bim, "BIM")]
    spec = GraphSpec(dict(schema_version=1, kind="graph", name="Training-only window LD locus graph",
        graph_type="locus", markers=markers, nodes=[dict(id=r[1], marker_ids=[r[1]]) for r in markers], edges=[],
        source=dict(kind="training_ld", declaration="inner_training_only", note="Window uses retained BIM file order, not physical distance.",
                    files=dict(bim=before), ld=dict(window=window, r2_min=r2_min, same_chromosome=same_chromosome,
                    weight=weight, max_pairs=max_pairs)),
        direction="undirected", self_loops="add_unit", duplicate_edges="error", filtered_nodes="drop",
        aggregation="mean", max_edges=max_edges))
    verify_snapshots(dict(bim=before))
    output.mkdir(parents=True)
    spec.save(output/"graph.json")
    report = dict(ok=True, kind="training_ld_definition", graph_sha256=spec.sha256, fitted=False,
                  scope="Definition only. Edges will be fitted independently on each inner training partition.")
    write_json(output/"report.json", report)
    return report
