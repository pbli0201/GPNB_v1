"""Explicit graph data contracts and train-bound graph construction."""
