"""Bounded window Pearson r², using ONLY inner-training genotypes and means."""
import numpy as np
from ..config import fail, number, object_fields, sequence
from .spec import GraphSpec, canonical_edges


def validate_fit(value, fit, train_rows, keep=None):
    object_fields(fit, "ld_fit", ("method", "edges", "candidate_pairs", "train_rows", "imputation"))
    if fit["method"] != "window_pearson_r2_v1" or fit["imputation"] != "training_marker_mean":
        fail("E_GRAPH", "ld_fit", "unrecognized LD formula or imputation")
    if fit["train_rows"] != train_rows or not train_rows:
        fail("E_GRAPH", "ld_fit", "fitted LD requires its nonempty exact inner-training rows")
    if any(type(i) is not int or i < 0 for i in train_rows) or len(set(train_rows)) != len(train_rows):
        fail("E_GRAPH", "ld_fit.train_rows", "expected unique nonnegative integer row indices")
    number(fit["candidate_pairs"], "ld_fit.candidate_pairs", 0, value["source"]["ld"]["max_pairs"], integer=True)
    sequence(fit["edges"], "ld_fit.edges", nonempty=False)
    if len(fit["edges"]) > min(value["max_edges"], fit["candidate_pairs"]):
        fail("E_GRAPH", "ld_fit", "fitted edge budget exceeded")
    normalized = canonical_edges(fit["edges"], [n["id"] for n in value["nodes"]], "undirected", "error")
    if normalized != fit["edges"]:
        fail("E_GRAPH", "ld_fit", "canonical edge order required")
    keep = [True]*len(value["markers"]) if keep is None else keep
    selected = [row for row, retained in zip(value["markers"], keep) if retained]
    order = {row[1]: i for i, row in enumerate(selected)}
    options = value["source"]["ld"]
    pairs = sum(1 for i, row in enumerate(selected) for other in selected[i+1:i+1+options["window"]]
                if not options["same_chromosome"] or row[0] == other[0])
    if fit["candidate_pairs"] != pairs:
        fail("E_GRAPH", "ld_fit.candidate_pairs", "candidate count differs from retained-marker window")
    for a, b, weight in fit["edges"]:
        i, j = order.get(a), order.get(b)
        if (i is None or j is None or not 0 < j-i <= options["window"]
                or (options["same_chromosome"] and selected[i][0] != selected[j][0])):
            fail("E_GRAPH", "ld_fit.edges", "edge outside retained-marker window/chromosome policy")
        if not value["source"]["ld"]["r2_min"] <= weight <= 1.:
            fail("E_GRAPH", "ld_fit", "r²/edge weight outside selected threshold")
        if value["source"]["ld"]["weight"] == "binary" and weight != 1.:
            fail("E_GRAPH", "ld_fit", "binary graph requires unit edge weights")


def fit_ld(graph, prepared, progress=None, cancelled=None):
    from ..training.core import check_cancel
    value = GraphSpec(graph).to_dict()
    if prepared.state.metadata["input_markers"] != value["markers"]:
        fail("E_GRAPH", "LD.markers", "BIM identity/order differs from graph definition")
    options = value["source"]["ld"]
    selected = np.flatnonzero(prepared.state.arrays["keep"])
    rows = np.asarray(prepared.split.rows("train"), dtype=np.int64)
    if len(rows) < 2:
        fail("E_GRAPH", "LD.training", "LD requires at least two inner-training individuals")
    groups, pairs = [], 0
    for pos, i in enumerate(selected):
        neighbors = [int(j) for j in selected[pos+1:pos+1+options["window"]]
                     if not options["same_chromosome"] or value["markers"][i][0] == value["markers"][j][0]]
        pairs += len(neighbors)
        if pairs > options["max_pairs"]:
            fail("E_GRAPH", "LD.max_pairs", "candidate budget exceeded before genotype reads; reduce window")
        groups.append(neighbors)
    edges = []
    for pos, (i, neighbors) in enumerate(zip(selected, groups)):
        check_cancel(cancelled)
        if not neighbors:
            continue
        columns = np.array([int(i), *neighbors], dtype=np.int64)
        means = prepared.state.arrays["mean"][columns]
        sums = np.zeros(len(columns), dtype=np.float64)
        squares = np.zeros_like(sums)
        cross = np.zeros(len(neighbors), dtype=np.float64)
        for start in range(0, len(rows), 256):
            check_cancel(cancelled)
            raw = prepared.cache.batch(rows[start:start+256], columns)
            x = np.where(raw == -1, means, raw).astype(np.float64)
            sums += x.sum(0)
            squares += np.square(x).sum(0)
            cross += (x[:, :1]*x[:, 1:]).sum(0)
        variance = np.maximum(squares-sums*sums/len(rows), 0.)
        covariance = cross-sums[0]*sums[1:]/len(rows)
        denominator = variance[0]*variance[1:]
        r2 = np.clip(np.divide(covariance*covariance, denominator,
                              out=np.zeros_like(covariance), where=denominator > 1e-20), 0., 1.)
        for j, score, denom in zip(neighbors, r2, denominator):
            if denom > 1e-20 and score >= options["r2_min"]:
                edges.append([value["markers"][i][1], value["markers"][j][1],
                              float(score) if options["weight"] == "r2" else 1.])
                if len(edges) > value["max_edges"]:
                    fail("E_GRAPH", "LD.max_edges", "fitted edge budget exceeded; increase threshold or reduce window")
        if progress:
            progress("ld_graph", pos+1, len(selected))
    edges = canonical_edges(edges, [n["id"] for n in value["nodes"]], "undirected", "error")
    result = dict(method="window_pearson_r2_v1", edges=edges, candidate_pairs=pairs,
                  train_rows=[int(i) for i in rows], imputation="training_marker_mean")
    validate_fit(value, result, result["train_rows"], prepared.state.arrays["keep"])
    return result
