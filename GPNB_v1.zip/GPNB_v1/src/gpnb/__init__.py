"""GPNB_v1 genomic prediction application."""

from .branding import APP_NAME, FULL_NAME, VERSION as __version__
