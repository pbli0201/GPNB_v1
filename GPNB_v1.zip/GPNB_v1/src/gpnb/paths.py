from __future__ import annotations

import os
from pathlib import Path


def project_root() -> Path:
    return Path(os.environ.get("GPNB_ROOT")
                or Path(__file__).resolve().parents[2]).resolve()


def configure_local_paths() -> Path:
    root = project_root()
    for name in ("tmp", "logs", "cache/matplotlib"):
        (root / name).mkdir(parents=True, exist_ok=True)
    os.environ.update(
        GPNB_ROOT=str(root), PYTHONNOUSERSITE="1", PYTHONUTF8="1",
        TEMP=str(root / "tmp"), TMP=str(root / "tmp"),
        MPLCONFIGDIR=str(root / "cache/matplotlib"),
    )
    return root
