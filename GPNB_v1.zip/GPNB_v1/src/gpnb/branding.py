"""Public product identity; historical storage keys remain backward compatible."""

APP_NAME = "GPNB_v1"
FULL_NAME = "Genomic Prediction Network Builder"
VERSION = "1.0.0"

