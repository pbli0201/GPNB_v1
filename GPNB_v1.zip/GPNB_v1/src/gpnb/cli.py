from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from . import __version__
from .errors import GPNBError


def _configuration_command(args):
    from .config import load_spec
    from .doctor import write_report
    try:
        if args.json and args.json.exists():
            raise GPNBError("E_EXISTS", str(args.json), "choose a new result report; existing files are preserved")
        if args.command == "validate-config":
            spec = load_spec(args.path)
            if args.write_canonical:
                spec.save(args.write_canonical)
            report = {"ok": True, "kind": spec.kind, "schema_version": spec.to_dict()["schema_version"], "sha256": spec.sha256,
                      "path": str(args.path.resolve()),
                      "scope": "configuration only; files, model shapes and training are not validated"}
        else:
            from .synthetic import generate_synthetic
            path = generate_synthetic(args.output, seed=args.seed, samples=args.samples,
                                      markers=args.markers, missing_rate=args.missing_rate)
            report = {"ok": True, "project": str(path), "scope": "synthetic fixture; no model trained"}
    except GPNBError as error:
        report = {"ok": False, "error": error.as_dict(args.lang)}
    if args.json and not args.json.exists():
        try:
            write_report(report, args.json)
        except OSError as error:
            report = {"ok": False, "error": GPNBError("E_IO", str(args.json), str(error)).as_dict(args.lang)}
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["ok"] else 2


def _data_command(args):
    from .data import inspect_project
    last = {}

    def progress(stage, done, total):
        percent = int(100 * done / total) if total else 0
        if percent // 10 != last.get(stage):
            print(f"{stage}: {done}/{total} ({percent}%)", file=sys.stderr)
            last[stage] = percent // 10
    try:
        report = inspect_project(args.path, args.output, scan=args.scan if args.command == "inspect" else True,
                                 cache_root=args.cache_dir if args.command == "import" else None,
                                 block_markers=args.block_markers, memory_mib=args.memory_mib, threads=args.threads,
                                 progress=progress, language=args.lang)
        # Large order tables and the full report are on disk; keep stdout compact.
        result = {k: report[k] for k in ("ok", "dataset_id", "trait", "samples", "markers", "matching",
                                        "genotype_missing", "cache", "errors")}
        result["audit_directory"] = str(args.output.resolve())
        result["available_traits"] = [name for name, info in report["traits"].items() if info["selectable"]]
        result["genotype_preprocessing"] = report["provenance"]["genotype_preprocessing"]
        result["warnings"] = report["warnings"]
    except GPNBError as error:
        result = {"ok": False, "error": error.as_dict(args.lang)}
    except (OSError, UnicodeError) as error:
        result = {"ok": False, "error": GPNBError("E_IO", str(args.path), str(error)).as_dict(args.lang)}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["ok"] else 2


def main(argv=None):
    # JSON CLI output is UTF-8 even when invoked directly from a legacy Windows shell.
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", errors="replace")
    from .branding import APP_NAME, FULL_NAME
    parser = argparse.ArgumentParser(prog="gpnb", description=f"{APP_NAME} — {FULL_NAME} / 基因组预测网络构建软件")
    parser.add_argument("--version", action="version", version=f"{APP_NAME} {__version__}")
    commands = parser.add_subparsers(dest="command", required=True)
    gui = commands.add_parser("gui", help="Open the desktop project and sequential MLP editor")
    gui.add_argument("--project", type=Path)
    gui.add_argument("--lang", choices=["zh_CN", "en_US"])
    doctor = commands.add_parser("doctor", help="Check packages, device, BED decoding and Qt")
    from .environment_profiles import profile_ids
    doctor.add_argument("--profile", choices=profile_ids(), default="cpu")
    doctor.add_argument("--qt", choices=["window", "offscreen", "skip"], default="window")
    doctor.add_argument("--json", type=Path, help="Write a machine-readable report")
    doctor.add_argument("--timeout", type=int, default=120)
    doctor.add_argument("--quick", action="store_true", help="Only package imports; does not certify device/window")
    validate = commands.add_parser("validate-config", help="Validate ProjectSpec / ModelSpec / RunSpec JSON")
    validate.add_argument("path", type=Path)
    validate.add_argument("--write-canonical", type=Path, help="Save validated JSON to a new file")
    migrate = commands.add_parser("migrate-model", help="Copy a v1 model into explicit v2 contracts; preserve source")
    migrate.add_argument("path", type=Path)
    migrate.add_argument("--output", type=Path, required=True)
    migrate.add_argument("--lang", choices=["zh_CN", "en_US"], default="zh_CN")
    commands.add_parser("list-components", help="Describe implemented PyTorch component contracts")
    commands.add_parser("list-paper-architectures", help="List audited citations, mappings and pending candidates")
    paper = commands.add_parser("paper-template", help="Write an editable paper architecture adaptation ModelSpec")
    paper.add_argument("name")
    paper.add_argument("--output",required=True,type=Path)
    graph = commands.add_parser("import-graph", help="Import an explicit locus GraphSpec from BIM and edge/mapping CSV")
    graph.add_argument("--bim", type=Path, required=True)
    graph.add_argument("--edges", type=Path, required=True)
    graph.add_argument("--mapping", type=Path)
    graph.add_argument("--output", type=Path, required=True)
    graph.add_argument("--name", default="Locus graph")
    graph.add_argument("--direction", choices=("directed", "undirected"), default="undirected")
    graph.add_argument("--self-loops", choices=("add_unit", "none", "preserve"), default="add_unit")
    graph.add_argument("--duplicate-edges", choices=("error", "sum"), default="error")
    graph.add_argument("--filtered-nodes", choices=("drop", "error"), default="drop")
    graph.add_argument("--aggregation", choices=("mean", "sum"), default="mean")
    graph.add_argument("--max-edges", type=int, default=1_000_000)
    graph.add_argument("--declaration", choices=("unknown", "external_fixed"), default="unknown")
    graph.add_argument("--note", default="")
    graph.add_argument("--delimiter", choices=(",", "\t"), default=",")
    graph.add_argument("--lang", choices=("zh_CN", "en_US"), default="zh_CN")
    ld = commands.add_parser("define-ld-graph", help="Define window LD graph fitted only inside training partitions")
    ld.add_argument("--bim", type=Path, required=True)
    ld.add_argument("--output", type=Path, required=True)
    ld.add_argument("--window", type=int, default=16)
    ld.add_argument("--r2-min", type=float, default=.2)
    ld.add_argument("--same-chromosome", action=argparse.BooleanOptionalAction, default=True)
    ld.add_argument("--weight", choices=("r2", "binary"), default="r2")
    ld.add_argument("--max-pairs", type=int, default=500_000)
    ld.add_argument("--max-edges", type=int, default=200_000)
    ld.add_argument("--lang", choices=("zh_CN", "en_US"), default="zh_CN")
    comparison = commands.add_parser("compare-cv", help="Compare completed CV runs with the same saved folds")
    comparison.add_argument("paths", nargs="+", type=Path)
    comparison.add_argument("--output", type=Path, required=True)
    comparison.add_argument("--lang", choices=["zh_CN", "en_US"], default="zh_CN")
    generate = commands.add_parser("make-synthetic", help="Create reproducible BED/BIM/FAM/CSV fixtures in a new directory")
    generate.add_argument("--output", type=Path, required=True)
    generate.add_argument("--seed", type=int, default=5209)
    generate.add_argument("--samples", type=int, default=65)
    generate.add_argument("--markers", type=int, default=12)
    generate.add_argument("--missing-rate", type=float, default=.05)
    for command in (validate, generate):
        command.add_argument("--lang", choices=["zh_CN", "en_US"], default="zh_CN")
        command.add_argument("--json", type=Path, help="Write the result/error report")
    from .paths import project_root
    predict = commands.add_parser("predict", help="Load frozen weights/preprocessing and predict BED or hard-call CSV/TSV")
    predict.add_argument("path", type=Path, help="Completed training run or exported bundle")
    source = predict.add_mutually_exclusive_group(required=True)
    source.add_argument("--bed", type=Path)
    source.add_argument("--matrix-config", type=Path, help="Explicit hard-call CSV/TSV configuration JSON")
    predict.add_argument("--bim", type=Path)
    predict.add_argument("--fam", type=Path)
    predict.add_argument("--dataset-id", default="new_cohort")
    predict.add_argument("--device", choices=["cpu", "cuda"], default="cpu")
    predict.add_argument("--batch-size", type=int)
    predict.add_argument("--input-table", action="append", default=[], help="Numeric input branch name=path; repeat per table")
    predict.add_argument("--fold", type=int, help="Advanced: one fold; omitted means every CV member")
    predict.add_argument("--phenotype", type=Path, help="Optional observations, used only after prediction for scoring")
    predict.add_argument("--phenotype-options", type=Path, help="JSON overrides for scoring ID/delimiter/trait mapping")
    predict.add_argument("--identity-relation", choices=("unknown", "same_source", "confirmed_new"), default="unknown")
    predict.add_argument("--identity-note", default="", help="Recorded basis; required when declaring confirmed_new")
    predict.add_argument("--sort-direction", choices=("ascending", "descending"))
    package = commands.add_parser("save-model", help="Save a portable frozen predictor including every CV member")
    package.add_argument("path", type=Path)
    final = commands.add_parser("final-refit", help="Fresh internal selection followed by an all-labelled-data final model")
    final.add_argument("path", type=Path)
    final.add_argument("--cache-dir", type=Path, default=project_root() / "cache/genotypes")
    export = commands.add_parser("export", help="Export the training-time source and model, optionally with data for retraining")
    export.add_argument("path", type=Path, help="Completed training run")
    export.add_argument("--include-data", action="store_true", help="Copy local training inputs for independent retraining")
    for command in (predict, export, package, final):
        command.add_argument("--output", type=Path, required=True)
        command.add_argument("--max-parameter-mib", type=int, default=256)
        command.add_argument("--lang", choices=["zh_CN", "en_US"], default="zh_CN")
    train = commands.add_parser("train", help="Import/prepare if needed, fit on train/validation, then evaluate the restored best model")
    train.add_argument("path", type=Path, help="ProjectSpec JSON")
    train.add_argument("--output", type=Path, required=True)
    train.add_argument("--prepared-dir", type=Path, help="Reuse an existing matching A04 prepared bundle")
    train.add_argument("--preflight-report", type=Path, help="Require a matching successful preflight receipt before fitting")
    train.add_argument("--cache-dir", type=Path, default=project_root() / "cache/genotypes")
    train.add_argument("--max-parameter-mib", type=int, default=256)
    train.add_argument("--lang", choices=["zh_CN", "en_US"], default="zh_CN")
    model = commands.add_parser("inspect-model", help="Resolve MLP shapes, inspect PyTorch model, export SVG and standalone source")
    model.add_argument("path", type=Path, help="ModelSpec or ProjectSpec JSON")
    model.add_argument("--output", type=Path, required=True)
    model_input = model.add_mutually_exclusive_group(required=True)
    model_input.add_argument("--input-features", type=int)
    model_input.add_argument("--prepared-dir", type=Path, help="Verified A04 bundle; uses filtered feature count")
    model.add_argument("--seed", type=int, default=5209)
    model.add_argument("--max-parameter-mib", type=int, default=256, help="Parameter-only allocation budget, not total RAM")
    model.add_argument("--static-only", action="store_true", help="Resolve/export without allocating or probing a model")
    model.add_argument("--baseline", type=Path, help="Original ModelSpec for comparison; default basic_mlp_v1")
    model.add_argument("--lang", choices=["zh_CN", "en_US"], default="zh_CN")
    preview = commands.add_parser("preview-split", help="Persist the actual fixed/five-fold/leave-out plan without fitting preprocessing")
    preview.add_argument("path", type=Path)
    preview.add_argument("--output", type=Path, required=True)
    preview.add_argument("--cache-dir", type=Path)
    preview.add_argument("--lang", choices=["zh_CN", "en_US"], default="zh_CN")
    prepare = commands.add_parser("prepare", help="Save a shared fixed split and train-fitted preprocessing state")
    prepare.add_argument("path", type=Path, help="ProjectSpec JSON")
    prepare.add_argument("--import-dir", type=Path, required=True, help="Completed A03 import directory")
    prepare.add_argument("--output", type=Path, required=True, help="New preparation directory")
    prepare.add_argument("--block-markers", type=int, default=256)
    prepare.add_argument("--lang", choices=["zh_CN", "en_US"], default="zh_CN")
    for name in ("inspect", "import"):
        command = commands.add_parser(name, help="Audit inputs" if name == "inspect" else "Audit inputs and build a raw int8 cache")
        command.add_argument("path", type=Path, help="ProjectSpec JSON")
        command.add_argument("--output", type=Path, required=True, help="New audit directory")
        command.add_argument("--block-markers", type=int, default=256)
        command.add_argument("--memory-mib", type=int, default=64, help="Decode working-block budget, not total process RSS")
        command.add_argument("--threads", type=int, default=2)
        command.add_argument("--lang", choices=["zh_CN", "en_US"], default="zh_CN")
        if name == "inspect":
            command.add_argument("--scan", action="store_true", help="Decode all genotypes and count missing cells")
        else:
            command.add_argument("--cache-dir", type=Path, default=project_root() / "cache/genotypes")
    preflight = commands.add_parser("preflight", help="Check actual data, all folds and bounded training-only forward/backward probes")
    preflight.add_argument("path", type=Path)
    preflight.add_argument("--output", type=Path, required=True)
    preflight.add_argument("--cache-dir", type=Path)
    preflight.add_argument("--max-parameter-mib", type=int, default=256)
    raw_export = commands.add_parser("export-genotypes", help="Export raw 0/1/2 calls and missing tokens without fitted preprocessing")
    raw_export.add_argument("path", type=Path)
    raw_export.add_argument("--output", type=Path, required=True)
    raw_export.add_argument("--delimiter", choices=("tab", "comma"), default="tab")
    raw_export.add_argument("--missing-token", default="NA")
    matrices = commands.add_parser('export-matrices', help='Export descriptive cohort GRM/kernel; training uses a fold-local recipe instead')
    matrices.add_argument('path', type=Path)
    matrices.add_argument('--output', type=Path, required=True)
    matrices.add_argument('--recipe', type=Path, help='Kernel recipe JSON; default VanRaden method 1')
    matrices.add_argument('--text', action='store_true', help='Also write an explicitly requested CSV matrix')
    matrices.add_argument('--cache-dir', type=Path)
    plots = commands.add_parser('export-plots', help='Export result plots and source CSV without changing the experiment')
    plots.add_argument('path', type=Path)
    plots.add_argument('--output', type=Path, required=True)
    plots.add_argument('--target-id')
    plots.add_argument('--partition', choices=('train', 'validation', 'test'), default='test')
    plots.add_argument('--fold', type=int)
    for command in (preflight, raw_export, matrices, plots):
        command.add_argument("--lang", choices=("zh_CN", "en_US"), default="zh_CN")
    retry=commands.add_parser('retry-batch',help='Run failed trait tasks into a new directory, preserving completed tasks')
    retry.add_argument('path',type=Path,help='Previous batch result directory')
    retry.add_argument('--output',type=Path,required=True)
    retry.add_argument('--cache-dir',type=Path)
    profile=commands.add_parser('paper-profile',help='Show provenance and parameters for a paper architecture')
    profile.add_argument('name')
    preset=commands.add_parser('apply-paper-preset',help='Apply a paper architecture and optional verified settings to a new project')
    preset.add_argument('path',type=Path);preset.add_argument('name')
    preset.add_argument('--output',type=Path,required=True)
    preset.add_argument('--mode',choices=('verified','architecture'),default='verified')
    preset.add_argument('--clear-stages',action='store_true')
    args = parser.parse_args(argv)
    if args.command in ('paper-profile','apply-paper-preset'):
        from .models.paper_presets import parameter_profile,apply_preset
        if args.command=='paper-profile':result=parameter_profile(args.name)
        else:
            from .preflight import resolved_project
            from .config import ProjectSpec
            result=apply_preset(resolved_project(args.path),args.name,args.mode,clear_stages=args.clear_stages)
            ProjectSpec(result).save(args.output)
            result=dict(ok=True,project=str(args.output.resolve()),mode=args.mode)
        print(json.dumps(result,ensure_ascii=False,indent=2));return 0
    if args.command=='retry-batch':
        from .data.files import read_json
        from .training.trait_batch import run_batch
        result=run_batch(args.path/'project.json',args.output,retry_from=args.path,cache_root=args.cache_dir,operation=read_json(args.path/'summary.json').get('operation','train'))
        print(json.dumps(result,ensure_ascii=False,indent=2))
        return 0 if result['ok'] else 2
    if args.command in ("preflight", "export-genotypes", 'export-matrices', 'export-plots'):
        try:
            if args.command == "preflight":
                from .preflight import preflight_project
                result = preflight_project(args.path, args.output, cache_root=args.cache_dir,
                    max_parameter_bytes=args.max_parameter_mib * 2**20,
                    progress=lambda event: print(json.dumps(event, ensure_ascii=False), file=sys.stderr, flush=True))
            elif args.command == 'export-matrices':
                from .data.matrix_tools import export_matrices
                from .data.kernels import default_recipe
                from .data.files import read_json
                recipe = read_json(args.recipe) if args.recipe else default_recipe()
                result = export_matrices(args.path, args.output, recipe, cache_root=args.cache_dir, text=args.text,
                    progress=lambda event: print(json.dumps(event, ensure_ascii=False), file=sys.stderr, flush=True))
            elif args.command == 'export-plots':
                from .results import export_result_plots
                result = export_result_plots(args.path, args.output, language='zh' if args.lang == 'zh_CN' else 'en',
                    target_id=args.target_id, partition=args.partition, fold=args.fold)
            else:
                from .data.matrix_export import export_genotypes
                result = export_genotypes(args.path, args.output,
                    delimiter='\t' if args.delimiter == 'tab' else ',', missing_token=args.missing_token)
        except (GPNBError, OSError, RuntimeError, MemoryError) as error:
            error = error if isinstance(error, GPNBError) else GPNBError('E_IO', str(args.path), str(error))
            result = dict(ok=False, error=error.as_dict(args.lang))
        except KeyboardInterrupt:
            return 130
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result.get('ok') else 2
    if args.command in ("list-paper-architectures", "paper-template"):
        from .models.paper_templates import paper_catalog, paper_template
        try:
            if args.command == "list-paper-architectures":
                result = paper_catalog()
            else:
                spec=paper_template(args.name); spec.save(args.output)
                result=dict(ok=True,path=str(args.output),sha256=spec.sha256)
        except (GPNBError,OSError) as error:
            print(json.dumps(dict(ok=False,error=str(error)),ensure_ascii=False));return 2
        print(json.dumps(result,ensure_ascii=False,indent=2));return 0
    if args.command in ("import-graph", "define-ld-graph"):
        from .graphs.spec import import_graph, create_ld_graph
        try:
            options = vars(args).copy()
            options.pop("command")
            options.pop("lang")
            result = (import_graph if args.command == "import-graph" else create_ld_graph)(**options)
        except (GPNBError, OSError) as error:
            error = error if isinstance(error, GPNBError) else GPNBError("E_IO", "graph", str(error))
            result = dict(ok=False, error=error.as_dict(args.lang))
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result["ok"] else 2
    if args.command == "compare-cv":
        from .training.comparison import compare_cv
        try:
            result = compare_cv(args.paths, args.output)
        except GPNBError as error:
            result = {"ok": False, "error": error.as_dict(args.lang)}
        except OSError as error:
            result = {"ok": False, "error": GPNBError("E_IO", str(args.output), str(error)).as_dict(args.lang)}
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result["ok"] else 2
    if args.command == "list-components":
        from .models.registry import COMPONENTS
        print(json.dumps([c.describe() for c in COMPONENTS.values()], ensure_ascii=False, indent=2))
        return 0
    if args.command == "migrate-model":
        from .models.migration import migrate_file
        try:
            result = migrate_file(args.path, args.output)
        except GPNBError as error:
            result = {"ok": False, "error": error.as_dict(args.lang)}
        except OSError as error:
            result = {"ok": False, "error": GPNBError("E_IO", str(args.path), str(error)).as_dict(args.lang)}
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result["ok"] else 2
    if args.command == "gui":
        from .gui.app import main as gui_main
        gui_args = []
        if args.project:
            gui_args += ["--project", str(args.project)]
        if args.lang:
            gui_args += ["--lang", args.lang]
        return gui_main(gui_args)
    if args.command in ("predict", "export", "save-model", "final-refit"):
        try:
            if args.command == "predict":
                from .prediction import predict_bed
                from .data.genotypes import load_matrix_config
                from .data.additional import parse_table_arguments
                from .data.files import read_json
                result = predict_bed(args.path, args.bed, args.output, bim=args.bim, fam=args.fam,
                                     dataset_id=args.dataset_id, device=args.device, batch_size=args.batch_size,
                                     max_parameter_bytes=args.max_parameter_mib * 1024**2,
                                     input_tables=parse_table_arguments(args.input_table),
                                     matrix=load_matrix_config(args.matrix_config) if args.matrix_config else None,
                                     fold=args.fold, phenotype=args.phenotype,
                                     phenotype_options=read_json(args.phenotype_options) if args.phenotype_options else None,
                                     identity_relation=args.identity_relation, identity_note=args.identity_note,
                                     sort_direction=args.sort_direction)
            elif args.command == "save-model":
                from .model_package import export_model_package
                result = export_model_package(args.path, args.output)
            elif args.command == "final-refit":
                from .training.final_refit import final_refit_project
                result = final_refit_project(args.path, args.output, cache_root=args.cache_dir,
                    max_parameter_bytes=args.max_parameter_mib * 1024**2,
                    progress=lambda e: print(json.dumps(e, ensure_ascii=False), file=sys.stderr, flush=True))
            else:
                from .exporting import export_run
                result = export_run(args.path, args.output, include_data=args.include_data,
                                    max_parameter_bytes=args.max_parameter_mib * 1024**2)
        except KeyboardInterrupt:
            result = {"ok": False, "error": GPNBError("E_CANCELLED", args.command, "Ctrl+C").as_dict(args.lang)}
        except GPNBError as error:
            result = {"ok": False, "error": error.as_dict(args.lang)}
        except (OSError, RuntimeError, MemoryError, KeyError, TypeError) as error:
            result = {"ok": False, "error": GPNBError("E_BUNDLE", str(args.path), str(error)).as_dict(args.lang)}
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result["ok"] else 2
    if args.command == "train":
        from .training.run import train_project
        def progress(event):
            print(json.dumps(event, ensure_ascii=False), file=sys.stderr, flush=True)
        try:
            if args.preflight_report:
                from .preflight import verify_preflight
                verify_preflight(args.path, args.preflight_report, max_parameter_bytes=args.max_parameter_mib * 2**20)
            result = train_project(args.path, args.output, prepared_dir=args.prepared_dir,
                                   cache_root=args.cache_dir, max_parameter_bytes=args.max_parameter_mib * 1024**2,
                                   progress=progress)
        except KeyboardInterrupt:
            result = {"ok": False, "error": GPNBError("E_CANCELLED", "train", "Ctrl+C").as_dict(args.lang)}
        except GPNBError as error:
            result = {"ok": False, "error": error.as_dict(args.lang)}
        except (OSError, RuntimeError, MemoryError) as error:
            result = {"ok": False, "error": GPNBError("E_TRAIN", str(args.path), str(error)).as_dict(args.lang)}
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result["ok"] else 2
    if args.command == "inspect-model":
        from .models.export import export_inspection
        try:
            result = export_inspection(args.path, args.output, input_features=args.input_features,
                                       prepared_dir=args.prepared_dir, seed=args.seed,
                                       max_parameter_bytes=args.max_parameter_mib * 1024**2,
                                       static_only=args.static_only, baseline_path=args.baseline)
        except GPNBError as error:
            result = {"ok": False, "error": error.as_dict(args.lang)}
        except (OSError, RuntimeError, MemoryError) as error:
            result = {"ok": False, "error": GPNBError("E_MODEL", str(args.path), str(error)).as_dict(args.lang)}
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result["ok"] else 2
    if args.command == "preview-split":
        from .data.preview import preview_split
        try:
            result = preview_split(args.path, args.output, cache_root=args.cache_dir)
        except (GPNBError, OSError, UnicodeError) as error:
            error = error if isinstance(error, GPNBError) else GPNBError("E_IO", str(args.path), str(error))
            result = {"ok": False, "error": error.as_dict(args.lang)}
        except KeyboardInterrupt:
            return 130
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result["ok"] else 2
    if args.command == "prepare":
        from .data.prepare import prepare_project
        try:
            result = prepare_project(args.path, args.import_dir, args.output, block_markers=args.block_markers)
        except GPNBError as error:
            result = {"ok": False, "error": error.as_dict(args.lang)}
        except (OSError, UnicodeError) as error:
            result = {"ok": False, "error": GPNBError("E_IO", str(args.path), str(error)).as_dict(args.lang)}
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result["ok"] else 2
    if args.command in ("inspect", "import"):
        return _data_command(args)
    if args.command != "doctor":
        return _configuration_command(args)
    if args.timeout <= 0:
        parser.error("--timeout must be positive")
    from .doctor import run_doctor, write_report
    try:
        report = run_doctor(args.profile, args.qt, args.timeout, args.quick)
    except Exception as error:
        print(f"FAIL: {type(error).__name__}: {error}")
        return 1
    for check in report["checks"]:
        print(f"{'PASS' if check['ok'] else 'FAIL'} {check['name']}: {check.get('error', 'OK')}")
    if args.json:
        write_report(report, args.json)
        print(f"Report / 报告: {args.json.resolve()}")
    print("Environment check only. Use 'gui' for the desktop editor or 'train' for CLI training.")
    return 0 if report["ok"] else 1
