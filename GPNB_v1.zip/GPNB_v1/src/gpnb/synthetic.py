"""Small, reproducible BED/phenotype fixtures; never used as a production encoder."""
from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path

import numpy as np

from .config import ProjectSpec, default_model, default_run, fail, number

GENERATOR_VERSION = "1"


def encode_bed(dosage: np.ndarray) -> bytes:
    """A1 dosage 2/missing/1/0 -> BED low-first bit codes 00/01/10/11."""
    if dosage.ndim != 2 or not np.isin(dosage, [-1, 0, 1, 2]).all():
        fail("E_VALUE", "dosage", "expected 2D A1 dosage in {-1,0,1,2}")
    n, m = dosage.shape
    result = bytearray(b"\x6c\x1b\x01")
    codes = {-1: 1, 0: 3, 1: 2, 2: 0}
    for j in range(m):
        for start in range(0, n, 4):
            byte = 0
            for offset in range(min(4, n - start)):
                byte |= codes[int(dosage[start + offset, j])] << (2 * offset)
            result.append(byte)
    return bytes(result)


def _csv(path, header, rows):
    with Path(path).open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, lineterminator="\n")
        writer.writerow(header)
        writer.writerows(rows)


def generate_synthetic(output: Path, *, seed=5209, samples=65, markers=12, missing_rate=.05) -> Path:
    """Create a fresh directory. Stable bytes for identical args + pinned NumPy.

    FAM order and phenotype row order deliberately differ. Truth includes latent
    dosages so later tests can verify the known signal without fitting a model.
    """
    number(seed, "seed", 0, 2**32 - 1, integer=True)
    number(samples, "samples", 8, 4096, integer=True)
    number(markers, "markers", 3, 4096, integer=True)
    number(missing_rate, "missing_rate", 0, .5)
    if samples * markers > 1_000_000:
        fail("E_LIMIT", "samples*markers", "maximum 1,000,000 cells")
    output = Path(output).resolve()
    try:
        output.mkdir(parents=True, exist_ok=False)
    except FileExistsError:
        fail("E_EXISTS", str(output), "choose a new fixture directory")
    except OSError as error:
        fail("E_IO", str(output), str(error))
    incomplete = output / "INCOMPLETE"
    try:
        incomplete.write_text("Generation incomplete; do not use as a dataset.\n", encoding="utf-8")
        streams = [np.random.Generator(np.random.PCG64(s)) for s in np.random.SeedSequence(seed).spawn(4)]
        latent = streams[0].binomial(2, .35, size=(samples, markers)).astype(np.int8)
        latent[:4, 0] = [0, 1, 2, 1]
        observed = latent.copy()
        mask = streams[1].random(observed.shape) < missing_rate
        observed[mask] = -1
        # Stable edge cases, recorded separately from the stochastic missing rate.
        observed[:3, 0] = latent[:3, 0]
        observed[3, 0] = -1
        coefficients = np.zeros(markers)
        coefficients[:3] = [2, -1.5, .5]
        signal = .25 + latent @ coefficients
        noise = streams[2].normal(0, .1, samples)
        target = signal + noise
        order = streams[3].permutation(samples)
        if np.array_equal(order, np.arange(samples)):
            order = np.roll(order, 1)
        fids = [f"{i % 3:03d}" for i in range(samples)]
        iids = [f"{i:06d}" for i in range(samples)]
        snps = [f"marker_{j:04d}" for j in range(markers)]
        (output / "genotypes.bed").write_bytes(encode_bed(observed))
        (output / "genotypes.fam").write_text(
            "".join(f"{fid}\t{iid}\t0\t0\t0\t-9\n" for fid, iid in zip(fids, iids)), encoding="utf-8")
        (output / "genotypes.bim").write_text(
            "".join(f"scaffold_{j % 2 + 1}\t{snp}\t0\t{j + 1}\tA\ta\n" for j, snp in enumerate(snps)),
            encoding="utf-8")
        _csv(output / "phenotype.csv", ["FID", "IID", "trait", "negative_control"],
             ((fids[i], iids[i], "" if i in (1, samples - 1) else format(target[i], ".17g"),
               "-9" if i == 0 else "0") for i in order))
        _csv(output / "expected_dosage.csv", ["FID", "IID", *snps],
             ((fids[i], iids[i], *observed[i].tolist()) for i in range(samples)))
        _csv(output / "latent_dosage.csv", ["FID", "IID", *snps],
             ((fids[i], iids[i], *latent[i].tolist()) for i in range(samples)))
        _csv(output / "expected_signal.csv", ["FID", "IID", "signal", "noise", "target"],
             ((fids[i], iids[i], *(format(v, ".17g") for v in (signal[i], noise[i], target[i])))
              for i in range(samples)))
        # A02 only records provenance. A03 will read this and compute file audits.
        manifest = {
            "schema_version": 1, "kind": "synthetic_manifest", "generator_version": GENERATOR_VERSION,
            "numpy": np.__version__, "rng": "PCG64; SeedSequence.spawn(4)", "seed": seed,
            "samples": samples, "markers": markers, "requested_random_missing_rate": missing_rate,
            "missing_cells": int((observed == -1).sum()), "forced_missing_cell": [3, 0],
            "forced_observed_cells": [[0, 0], [1, 0], [2, 0]],
            "encoding": {"counted_allele": "BIM_A1", "dosage": [0, 1, 2], "missing_in_truth_csv": -1,
                         "bed_codes": {"00": 2, "01": "missing", "10": 1, "11": 0}},
            "signal": {"intercept": .25, "coefficients": coefficients.tolist(), "noise_sd": .1},
            "phenotype_missing_fam_indices": [1, samples - 1],
            "phenotype_row_fam_indices": order.tolist(),
            "genotype_preprocessing": {"status": "none", "fit_scope": None},
            "family_interpretation": "FID is an arbitrary string identifier, not a biological family",
            "marker_positions": "synthetic positions; not biological coordinates",
            "files": {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                      for p in sorted(output.iterdir()) if p.is_file() and p.name != "INCOMPLETE"},
        }
        (output / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        project = ProjectSpec({
            "schema_version": 1, "kind": "project", "project_id": f"synthetic_{seed}",
            "name": "合成数据 MLP / Synthetic MLP", "language": "zh_CN",
            "data": {"dataset_id": f"synthetic_{seed}", "bed": "genotypes.bed", "bim": "genotypes.bim",
                     "fam": "genotypes.fam", "phenotype": "phenotype.csv", "manifest": "manifest.json",
                     "split_groups": None,
                     "phenotype_options": {"delimiter": ",", "encoding": "utf-8", "id_mode": "fid_iid",
                                           "id_columns": ["FID", "IID"], "trait": "trait",
                                           "missing_tokens": ["", "NA", "NaN"]}},
            "output_dir": "runs", "model": default_model().to_dict(), "run": default_run().to_dict(),
            "extensions": {"synthetic_generator_version": GENERATOR_VERSION},
        })
        project.save(output / "project.json")
        incomplete.unlink()
        return output / "project.json"
    except OSError as error:
        fail("E_IO", str(output), str(error))
