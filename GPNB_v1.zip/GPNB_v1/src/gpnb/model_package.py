"""Portable, checksummed frozen predictors, separate from reproducible experiments.

The public resolver does not construct a torch model. It verifies every member
before returning any of them, including when an advanced single fold is chosen.
All paths in a package inventory are relative; training input paths in the
member project are replaced by non-operative input placeholders.
"""
from __future__ import annotations

import copy
import shutil
from pathlib import Path

from .bundle import safe_member, seal, verify_bundle
from .config import ProjectSpec, fail, load_spec
from .data.files import order_hash, protect_inputs, read_json, sha256, write_json
from .errors import GPNBError

PACKAGE_KIND = "prediction_model_package"
MEMBER_REQUIRED = (
    "project.json", "weights.pt", "summary.json", "environment.json",
    "prepared/preprocessor/state.json", "prepared/preprocessor/arrays.npz",
    "prepared/preprocessor/complete.json", "prepared/split.json", "architecture/model.json",
)


def _targets(project):
    contract = project.get("extensions", {}).get("multitask")
    if contract:
        return [{key: target[key] for key in ("id", "column", "trait", "environment", "unit", "correction")}
                for target in contract["targets"]]
    trait = project["data"]["phenotype_options"]["trait"]
    target = project.get("extensions", {}).get("target", {})
    if not isinstance(target, dict):
        target = {}
    return [dict(id=trait, column=trait, trait=trait,
                 environment=target.get("environment", "unspecified"),
                 unit=target.get("unit", target.get("units", "unspecified")),
                 correction=target.get("correction", "unspecified"))]


def _canonical_metadata(value):
    """Normalize a historical storage key in memory; frozen files stay intact."""
    normalized = dict(value)
    if "gsapp_version" in normalized:
        legacy = normalized.pop("gsapp_version")
        if "gpnb_version" in normalized and normalized["gpnb_version"] != legacy:
            fail("E_BUNDLE", "gpnb_version", "conflicting current and historical version metadata")
        normalized.setdefault("gpnb_version", legacy)
    return normalized


def _member_metadata(directory):
    manifest = verify_bundle(directory, "training_run", MEMBER_REQUIRED)
    project = load_spec(directory / "project.json")
    if not isinstance(project, ProjectSpec):
        fail("E_BUNDLE", "project.json", "expected a saved project")
    project = project.to_dict()
    required = set()
    model = project["model"]
    kernel_config = project["run"].get("extensions", {}).get("kernel_features")
    if model.get("graph_spec"):
        required.add("graph_state.json")
    if model.get("individual_graph_spec"):
        required.add("reference_state.json")
    if model.get("task") == "multi_target_regression":
        required.add("prepared/target_state.json")
    if project.get("extensions", {}).get("input_tables"):
        required.add("input_states.json")
    if kernel_config:
        required.update(("kernel/state.json", "kernel/arrays.npz", "kernel/complete.json", "kernel/binding.json"))
    if not required.issubset(manifest["files"]):
        fail("E_BUNDLE", str(directory), f"missing required model states: {sorted(required - manifest['files'].keys())}")
    summary = read_json(directory / "summary.json")
    environment = read_json(directory / "environment.json")
    from .data.preprocessing import PreprocessorState
    state = PreprocessorState.load(directory / "prepared/preprocessor")
    context = read_json(directory / "prepared/split.json")["manifest"]["context"]
    ids, rows = context["sample_ids"], state.metadata["train_rows"]
    if (not isinstance(ids, list) or not ids or
            any(not isinstance(pair, list) or len(pair) != 2 or
                any(not isinstance(v, str) for v in pair) for pair in ids) or
            len({tuple(pair) for pair in ids}) != len(ids) or any(i >= len(ids) for i in rows)):
        fail("E_BUNDLE", "prepared/split.json", "invalid sample identities or training rows")
    inputs = []
    for item in project.get("extensions", {}).get("input_tables", []):
        inputs.append({k: v for k, v in item.items() if k != "path"})
    from .data.kernel_features import options
    kernel = options(project)
    reference = project["model"].get("individual_graph_spec", {})
    declaration = project["data"].get("matrix", {}).get("allele_declaration") if project["data"].get("matrix") else None
    identity = project.get("extensions", {}).get("prediction_identity", {})
    explicit = (isinstance(identity, dict) and all(isinstance(identity.get(key), str) and identity[key].strip()
                                                for key in ("namespace", "project_origin")))
    if (directory / "prediction_origin.json").is_file() and "prediction_origin.json" not in manifest["files"]:
        fail("E_BUNDLE", "prediction_origin.json", "prediction identity provenance is not covered by the archive manifest")
    if "prediction_origin.json" in manifest["files"]:
        origin = read_json(directory / "prediction_origin.json")
        if origin.get("schema_version") != 1 or origin.get("kind") != "prediction_origin":
            fail("E_BUNDLE", "prediction_origin.json", "invalid prediction identity provenance")
        genotype_files = origin["source_genotype_files"]
    elif "prepared/input_descriptor.json" in manifest["files"]:
        descriptor = read_json(directory / "prepared/input_descriptor.json")
        genotype_files = {key: {field: item[field] for field in ("sha256", "bytes")}
                          for key, item in descriptor["source_files"].items()
                          if key in ("bed", "bim", "fam", "matrix")}
    else:
        genotype_files = {}
    import re
    if (not isinstance(genotype_files, dict) or set(genotype_files) - {"bed", "bim", "fam", "matrix"} or
            any(not isinstance(item, dict) or set(item) != {"sha256", "bytes"} or
                not isinstance(item["sha256"], str) or not re.fullmatch(r"[0-9a-f]{64}", item["sha256"]) or
                type(item["bytes"]) is not int or item["bytes"] < 0 for item in genotype_files.values())):
        fail("E_BUNDLE", "prediction_origin.json", "invalid genotype source identity fingerprints")
    return dict(
        model_name=project["model"]["name"], model_sha256=summary["model_sha256"],
        dataset_id=project["data"]["dataset_id"], source_project_id=project["project_id"],
        source_project_sha256=environment.get("original_project_sha256"),
        source_genotype_files=genotype_files,
        gpnb_version=_canonical_metadata(environment).get("gpnb_version", "unknown"), targets=_targets(project),
        target_interpretation=project.get("extensions", {}).get("target", {}),
        training_ids=[ids[i] for i in rows], training_ids_sha256=order_hash([ids[i] for i in rows]),
        identity=dict(namespace=identity.get("namespace") if explicit else None,
                      project_origin=identity.get("project_origin") if explicit else None,
                      status="declared" if explicit else "not_declared",
                      policy="Equal ID text or equal genotype alone does not establish individual identity."),
        input_requirements=dict(genotypes=True, original_markers=state.metadata["raw_features"],
                                selected_markers=state.input_features, encoding=state.metadata["encoding"],
                                allele_declaration=declaration, numeric_tables=inputs,
                                kernel_mode=kernel["mode"] if kernel else None,
                                permits_unknown_individuals=reference.get("protocol") != "transductive_fixed_cohort",
                                individual_graph_protocol=reference.get("protocol"),
                                **({"imputation_reference": "knn"} if state.metadata.get("imputer", {}).get("method") == "knn" else {})),
        final_refit=summary.get("final_refit"),
        bytes=sum(safe_member(directory, name).stat().st_size for name in manifest["files"]),
    )


def _aggregate(members, method, *, origin_kind):
    first = members[0]["metadata"]
    for member in members[1:]:
        current = member["metadata"]
        if current["targets"] != first["targets"]:
            fail("E_BUNDLE", member["id"], "ensemble target order, meaning or units differ")
        for key in ("numeric_tables", "encoding", "allele_declaration"):
            if current["input_requirements"][key] != first["input_requirements"][key]:
                fail("E_BUNDLE", member["id"], f"ensemble input contract differs: {key}")
    seen = set()
    identities = []
    for member in members:
        for pair in member["metadata"]["training_ids"]:
            key = tuple(pair)
            if key not in seen:
                identities.append(pair)
                seen.add(key)
    requirements = copy.deepcopy(first["input_requirements"])
    requirements["permits_unknown_individuals"] = all(
        member["metadata"]["input_requirements"]["permits_unknown_individuals"] for member in members)
    return dict(origin_kind=origin_kind, origin_method=method, member_count=len(members),
                strategy="equal_weight_original_units" if len(members) > 1 else "single_model",
                targets=first["targets"], model_name=first["model_name"],
                gpnb_version=first["gpnb_version"], dataset_id=first["dataset_id"],
                source_project_id=first["source_project_id"], source_project_sha256=first["source_project_sha256"],
                source_genotype_files=first["source_genotype_files"],
                identity=first["identity"], training_ids=identities,
                training_ids_sha256=order_hash(identities), input_requirements=requirements,
                target_interpretation=first["target_interpretation"], final_refit=first.get("final_refit"),
                bytes=sum(member["metadata"]["bytes"] for member in members),
                evaluation="Use archived outer-test/OOF predictions for evaluation of the training cohort; an all-member ensemble is not OOF.",
                disagreement="Between-member prediction SD is model disagreement, not confidence or breeding-value reliability.")


def resolve_model_source(source, *, fold=None):
    """Resolve and verify all frozen members; return Paths plus JSON metadata.

    ``fold`` is an optional one-based *original fold number*, never a rank based
    on test performance. Missing members are rejected before fold selection.
    """
    source = Path(source).resolve()
    try:
        manifest = verify_bundle(source)
        kind, directory = manifest["kind"], source
        if kind in ("exported_run", "exported_cv"):
            verify_bundle(source, kind, ("run/complete.json", "export.json"))
            directory = source / "run"
            inner_kind = "training_run" if kind == "exported_run" else "cross_validation"
            verify_bundle(directory, inner_kind)
        elif kind == "final_refit":
            verify_bundle(source, kind, ("summary.json",))
            final = read_json(source / "summary.json")
            directory = safe_member(source, final["model_directory"])
            verify_bundle(directory, "training_run", MEMBER_REQUIRED)
            if not read_json(directory / "summary.json").get("final_refit"):
                fail("E_BUNDLE", final["model_directory"], "final model is missing its refit provenance")
            inner_kind = "training_run"
        else:
            inner_kind = kind
        package_metadata = None
        if inner_kind == PACKAGE_KIND:
            verify_bundle(source, PACKAGE_KIND, ("model_package.json",))
            package = read_json(source / "model_package.json")
            if (package.get("schema_version") != 1 or package.get("kind") != PACKAGE_KIND or
                    not isinstance(package.get("members"), list) or not package["members"] or
                    package.get("member_count") != len(package["members"])):
                fail("E_BUNDLE", "model_package.json", "invalid model member inventory")
            members, seen = [], set()
            for item in package["members"]:
                relative = item["directory"]
                member_dir = safe_member(source, relative)
                if relative in seen or not relative.startswith("members/"):
                    fail("E_BUNDLE", relative, "duplicate or invalid model member directory")
                seen.add(relative)
                metadata = _member_metadata(member_dir)
                # Compare semantic metadata, excluding archive size which is descriptive.
                if any(metadata.get(k) != v for k, v in _canonical_metadata(item["metadata"]).items() if k != "bytes"):
                    fail("E_BUNDLE", relative, "model package metadata differs from its frozen member")
                members.append(dict(id=item["id"], fold=item.get("fold"), directory=member_dir, metadata=metadata))
            method = package["metadata"]["origin_method"]
            origin_kind = package["metadata"]["origin_kind"]
            package_metadata = _canonical_metadata(package["metadata"])
        elif inner_kind == "training_run":
            metadata = _member_metadata(directory)
            members = [dict(id="model", fold=None, directory=directory, metadata=metadata)]
            method = "final_refit" if metadata.get("final_refit") else "fixed_split"
            origin_kind = inner_kind
        elif inner_kind == "cross_validation":
            verify_bundle(directory, inner_kind, ("summary.json",))
            summary = read_json(directory / "summary.json")
            records = summary["fold_runs"]
            count = summary["folds"]
            if (type(count) is not int or count < 2 or not isinstance(records, list) or len(records) != count or
                    {r.get("fold") for r in records} != set(range(1, count + 1))):
                fail("E_BUNDLE", "summary.json", "CV archive must contain every unique declared fold")
            members, directories = [], set()
            for item in sorted(records, key=lambda r: r["fold"]):
                member_dir = safe_member(directory, item["directory"])
                if member_dir in directories:
                    fail("E_BUNDLE", item["directory"], "different folds cannot share one model directory")
                directories.add(member_dir)
                metadata = _member_metadata(member_dir)
                if item.get("summary", {}).get("model_sha256") != metadata["model_sha256"]:
                    fail("E_BUNDLE", item["directory"], "fold model differs from CV inventory")
                members.append(dict(id=f"fold_{item['fold']}", fold=item["fold"], directory=member_dir, metadata=metadata))
            method, origin_kind = summary.get("method", "five_fold"), inner_kind
        else:
            fail("E_BUNDLE", str(source), f"unsupported prediction source kind: {inner_kind}")
        if len({m["id"] for m in members}) != len(members):
            fail("E_BUNDLE", str(source), "model member IDs must be unique")
        metadata = _aggregate(members, method, origin_kind=origin_kind)
        if package_metadata is not None:
            if any(metadata.get(k) != v for k, v in package_metadata.items() if k != "bytes"):
                fail("E_BUNDLE", "model_package.json", "package metadata differs from its members")
        if fold is not None:
            if type(fold) is not int or fold < 1:
                fail("E_BUNDLE", "fold", "choose a positive original fold number")
            chosen = [member for member in members if member["fold"] == fold]
            if len(chosen) != 1:
                fail("E_BUNDLE", "fold", "requested fold does not exist in this model source")
            members = chosen
            metadata = _aggregate(members, method, origin_kind=origin_kind)
            metadata["selected_fold"] = fold
        return dict(kind=kind, source=source, members=members, metadata=metadata)
    except GPNBError:
        raise
    except (OSError, KeyError, TypeError, ValueError, IndexError) as error:
        fail("E_BUNDLE", str(source), f"invalid prediction source: {error}")


def _portable_project(project):
    value = copy.deepcopy(project)
    data = value["data"]
    for key in ("bed", "bim", "fam", "phenotype"):
        if data.get(key) is not None:
            data[key] = f"prediction_inputs/{key}"
    for key in ("manifest", "split_groups"):
        data[key] = None
    if data.get("matrix"):
        data["matrix"]["path"] = "prediction_inputs/genotypes.txt"
    for item in value.get("extensions", {}).get("input_tables", []):
        item["path"] = f"prediction_inputs/{item['id']}.csv"
    value["output_dir"] = "prediction_outputs"
    value["run"]["split"]["reuse_manifest"] = "prepared/split.json"
    return value


def export_model_package(source, output, *, progress=None, cancelled=None):
    """Save only state needed for prediction; originals and experiments stay intact."""
    from .prediction import Predictor
    from .training.core import check_cancel
    source, output = Path(source).resolve(), Path(output).resolve()
    if output.exists():
        fail("E_EXISTS", str(output), "choose a new model package directory")
    protect_inputs(output, [source])
    if output.is_relative_to(source) or source.is_relative_to(output):
        fail("E_IO", str(output), "model package and source archive must not overlap")
    resolved = resolve_model_source(source)
    source_digest = sha256(source / "complete.json")
    check_cancel(cancelled)
    output.mkdir(parents=True)
    (output / "INCOMPLETE").write_text("Model package is incomplete.\n", encoding="utf-8")
    try:
        packed = []
        for i, member in enumerate(resolved["members"], 1):
            check_cancel(cancelled)
            if progress:
                progress(dict(event="stage", stage="saving_model_member", done=i - 1, total=len(resolved["members"])))
            origin = member["directory"]
            # Check weights, architecture and every fitted-state binding before publishing.
            predictor = Predictor(origin, device="cpu")
            project = _portable_project(predictor.project.to_dict())
            del predictor
            relative = f"members/member_{i}"
            target = output / relative
            inventory = verify_bundle(origin, "training_run", MEMBER_REQUIRED)["files"]
            selected = set(MEMBER_REQUIRED)
            for name in inventory:
                if (name.startswith("kernel/") or name in ("input_states.json", "graph_state.json", "reference_state.json",
                        "prepared/target_state.json", "architecture/model.md", "architecture/summary.md", "final_refit.json")):
                    selected.add(name)
            for name in sorted(selected):
                check_cancel(cancelled)
                destination = safe_member(target, name)
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(safe_member(origin, name), destination)
                if sha256(destination) != inventory[name]:
                    fail("E_CHANGED", name, "source model changed while saving its package")
            ProjectSpec(project).save(target / "project.json", overwrite=True)
            write_json(target / "prediction_origin.json", dict(schema_version=1, kind="prediction_origin",
                       source_genotype_files=member["metadata"]["source_genotype_files"],
                       interpretation="Exact source-file hashes including ID-bearing files can identify a known cohort. Genotype equality alone cannot identify a person or animal."))
            if (target / "input_states.json").exists():
                states = read_json(target / "input_states.json")
                configs = {item["id"]: item for item in project["extensions"]["input_tables"]}
                for name, state in states.items():
                    state["config"] = configs[name]
                    # This is a provenance reference, never reopened at prediction.
                    # Keep its checksum while rebasing its path with the config.
                    state["report"]["source"]["path"] = configs[name]["path"]
                write_json(target / "input_states.json", states)
            seal(target, "training_run")
            metadata = _member_metadata(target)
            packed.append(dict(id=member["id"], fold=member["fold"], directory=relative, metadata=metadata))
        aggregate = _aggregate(packed, resolved["metadata"]["origin_method"], origin_kind=resolved["metadata"]["origin_kind"])
        report = dict(ok=True, schema_version=1, kind=PACKAGE_KIND, member_count=len(packed),
                      members=packed, metadata=aggregate, source_manifest_sha256=source_digest,
                      includes_training_phenotypes=False, includes_training_data=False,
                      contains_reference_genotypes=any(m["metadata"]["input_requirements"]["kernel_mode"] or
                          m["metadata"]["input_requirements"]["individual_graph_protocol"] or
                          m["metadata"]["input_requirements"].get("imputation_reference") for m in packed),
                      input_paths="Member projects use relative placeholders. Prediction takes explicit query files and never reads training inputs.",
                      purpose="Frozen prediction. Use the separate full experiment export for retraining/audit.")
        write_json(output / "model_package.json", report)
        (output / "README.txt").write_text(
            "GPNB 可预测模型包 / Frozen prediction model package\n"
            "在预测页面选择本文件夹；无需原始训练文件或新个体表型。\n"
            "Select this folder on the Prediction page. No training files or query phenotypes are needed.\n"
            "gpnb predict MODEL_PACKAGE --bed NEW.bed --output NEW_DIRECTORY\n"
            "全部声明成员均须完整；CV预测先还原原单位再等权平均。\n"
            "All declared members are required; CV predictions average inverse-transformed outputs in original units.\n"
            "包含样本身份；KNN填补、核和个体图模型还包含预测必需的参考基因型。\n"
            "Contains sample identities and, for KNN imputation/kernel/individual-graph models, required reference genotypes.\n"
            "不复制训练表型值和原始完整基因型文件；此包仍不是匿名档案。\n"
            "Training phenotype values and the original full genotype input are not copied. This is not an anonymized archive.\n"
            "需要兼容的GPNB/PyTorch环境；每个成员记录实际版本。\n"
            "This package requires a compatible GPNB/PyTorch installation; versions are recorded per member.\n",
            encoding="utf-8")
        verify_bundle(source)
        if sha256(source / "complete.json") != source_digest:
            fail("E_CHANGED", str(source), "source model inventory changed while saving its package")
        check_cancel(cancelled)
        seal(output, PACKAGE_KIND)
        (output / "INCOMPLETE").unlink()
        resolve_model_source(output)
        if progress:
            progress(dict(event="stage", stage="saving_model_member", done=len(packed), total=len(packed)))
        return report
    except BaseException as error:
        write_json(output / "failure.json", dict(ok=False, error=str(error)))
        if not (output / "INCOMPLETE").exists():
            (output / "INCOMPLETE").write_text("Model package verification failed.\n", encoding="utf-8")
        raise
