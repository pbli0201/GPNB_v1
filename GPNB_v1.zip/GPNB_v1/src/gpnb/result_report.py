"""Portable offline report of archived results, without modifying sealed runs."""
import html
import json


def write_report(output, summary, metrics, *, language='en', partition='test', fold=None):
    zh = language == 'zh'
    escape = lambda x: html.escape(str(x))
    def pairs(value):
        return '<pre>' + escape(json.dumps(value, ensure_ascii=False, indent=2)) + '</pre>'
    headers = list(metrics[0])
    table = '<table><tr>' + ''.join('<th>' + escape(h) + '</th>' for h in headers) + '</tr>'
    for row in metrics:
        table += '<tr>' + ''.join('<td>' + escape('—' if row.get(h) is None else row[h]) + '</td>' for h in headers) + '</tr>'
    table += '</table>'
    blocks = []
    from .data.files import read_json
    for i, metric in enumerate(metrics, 1):
        name = f'target_{i:03}'
        record = read_json(output / name / 'summary.json')
        blocks.append('<section><h2>' + escape(metric['trait']) + '</h2><h3>' + ('数据与实际配置' if zh else 'Data and actual configuration') + '</h3><details><summary>' + ('查看详情' if zh else 'Details') + '</summary>' + pairs(record.get('overview', {})) + pairs(record.get('configuration', {})) + '</details><p>' + escape(record['evaluation']) + '</p>')
        for kind in ('combination', 'scatter', 'error', 'learning', 'folds'):
            file = next((f'{name}/{kind}.{ext}' for ext in ('svg', 'png') if (output/name/f'{kind}.{ext}').is_file()), None)
            if file: blocks.append(f'<img src="{file}" alt="{escape(kind)}">')
        blocks.append(f'<p><a href="{name}/predictions.csv">' + ('逐样本预测 CSV' if zh else 'Per-sample predictions CSV') + '</a></p></section>')
    title = 'GPNB 结果报告' if zh else 'GPNB result report'
    note = '预测保持性状原单位；不自动等同育种值。评价范围：' if zh else 'Predictions use original trait units; not automatically breeding values. Evaluation: '
    page = '<!doctype html><html lang="'+('zh-CN' if zh else 'en')+'"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+title+'</title><style>body{max-width:1200px;margin:30px auto;padding:20px;font:16px/1.8 "Segoe UI","Microsoft YaHei",sans-serif;color:#203542}table{border-collapse:collapse}th,td{border:1px solid #ccc;padding:7px}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f3f6f7;padding:16px}img{max-width:49%;height:auto}.scroll{overflow:auto}section{border-top:1px solid #ddd;margin-top:30px}@media(max-width:700px){img{max-width:100%}}</style><h1>'+title+'</h1><p>'+escape(note+partition+' / '+str(fold))+'</p><div class="scroll">'+table+'</div>'+''.join(blocks)+'</html>'
    (output/'report.html').write_text(page, encoding='utf-8')
